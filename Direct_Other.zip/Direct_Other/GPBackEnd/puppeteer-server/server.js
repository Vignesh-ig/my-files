const express = require('express');
const puppeteer = require('puppeteer');

const app = express();
const port = process.env.PORT || 3000;

// Middleware to accept HTML content
app.use(express.text({ type: ['text/html', 'text/plain'], limit: '10mb' }));

let browser;

// Initialize Puppeteer browser once
puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
}).then(launchedBrowser => {
    browser = launchedBrowser;
});

// Health check
app.get('/', (req, res) => res.send('PDF Generator Service is running'));

// PDF generation endpoint
app.post('/generate-pdf', async (req, res) => {
    try {
        const html = req.body;
        if (!html?.trim()) return res.status(400).json({ error: 'HTML content is required' });

        const page = await browser.newPage();
        page.setDefaultNavigationTimeout(60);

        await page.setContent(html, {
            waitUntil: 'load',
            timeout: 60000
        });

        const pdf = await page.pdf({
            format: 'A4',
            printBackground: true,
            margin: { top: '20mm', right: '20mm', bottom: '20mm', left: '20mm' }
        });

        await page.close();

        res.set({
            'Content-Type': 'application/pdf',
            'Content-Disposition': 'attachment; filename=document.pdf'
        }).send(pdf);

    } catch (error) {
        console.error('PDF Generation Error:', error);
        res.status(500).json({ error: 'Failed to generate PDF', details: error.message });
    }
});

// Clean up on exit
process.on('exit', () => browser?.close());

app.listen(port, () => console.log(`Server running on port ${port}`));