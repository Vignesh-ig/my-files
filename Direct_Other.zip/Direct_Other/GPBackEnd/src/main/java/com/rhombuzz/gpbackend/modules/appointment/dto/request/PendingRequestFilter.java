package com.rhombuzz.gpbackend.modules.appointment.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

import java.util.Set;

@Validated
@Getter
@Setter
public class PendingRequestFilter {
    @Positive
    private Long providerId;

    @Positive
    private Long locationId;

    @Positive
    private Long serviceId;

    private Set<@NotNull(message = "Filter type cannot be null") FilterType> filters;

    public enum FilterType {
        PROVIDER,
        LOCATION,
        SERVICE
    }
}
