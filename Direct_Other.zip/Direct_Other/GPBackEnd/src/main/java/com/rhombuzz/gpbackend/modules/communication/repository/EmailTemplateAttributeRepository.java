package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplateAttribute;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface EmailTemplateAttributeRepository extends JpaRepository<EmailTemplateAttribute, Long> {

    @Query("SELECT e FROM EmailTemplateAttribute e WHERE e.groupId = ?1")
    Optional<EmailTemplateAttribute> findByGroupId(String groupId );

    void deleteByGroupId(String groupId);
}
