package com.rhombuzz.gpbackend.integration.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Data
@NoArgsConstructor
@Table(name = "integrations", indexes = {
        @Index(name = "idx_integrations_med_group_id", columnList = "med_group_id")
})
public class Integration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name="integration_name", nullable = false, length = 45)
    private String integrationName;

    @Column(name = "integration_type", nullable = false, length = 45)
    private String integrateType;
}
