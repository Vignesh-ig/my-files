package com.rhombuzz.gpbackend.modules.support.service.impl;

import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.support.dto.request.SupportRequest;
import com.rhombuzz.gpbackend.modules.support.dto.request.TicketRequest;
import com.rhombuzz.gpbackend.modules.support.dto.response.SupportResponse;
import com.rhombuzz.gpbackend.modules.support.dto.response.TicketResponse;
import com.rhombuzz.gpbackend.modules.support.entity.Support;
import com.rhombuzz.gpbackend.modules.support.entity.Ticket;
import com.rhombuzz.gpbackend.modules.support.repository.SupportRepository;
import com.rhombuzz.gpbackend.modules.support.repository.TicketRepository;
import com.rhombuzz.gpbackend.modules.support.service.SupportTicketService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class SupportTicketServiceImpl implements SupportTicketService {
    private final MedGroupService medGroupService;
    private final SupportRepository supportRepository;
    private final TicketRepository ticketRepository;

    @Override
    public void saveSupport(SupportRequest request, MultipartFile image) {
        log.info("Saving new support request for group: {}", request.groupId());
        String username = Utils.getCurrentUsername();

        Support support = Support.fromRequest(request);
        support.setUsername(username);

        Ticket ticket = buildTicket(
                request.groupId(),
                null,
                username,
                request.description(),
                image,
                false);
        ticket.setSupport(support);
        ticket.setStatus(Ticket.Status.IN_PROGRESS);

        support.setTickets(List.of(ticket));
        supportRepository.save(support);
        log.info("Support request saved successfully with id: {}", support.getId());
    }

    @Override
    public void saveUserTicket(TicketRequest request, MultipartFile image) {
        log.info("Saving user ticket for support: {}, group: {}", request.supportId(), request.groupId());
        saveTicket(request, image, false);
    }

    @Override
    public void saveAdminTicket(TicketRequest request, MultipartFile image) {
        log.info("Saving admin ticket for support: {}, group: {}", request.supportId(), request.groupId());
        saveTicket(request, image, true);
    }

    @Override
    public void updateTicketStatus(Long ticketId, Long supportId, String groupId, Ticket.Status status) {
        log.info("Updating ticket status - ID: {}, Support ID: {}, Group: {}, Status: {}", ticketId, supportId, groupId, status);
        Ticket ticket = getTicket(ticketId, supportId, groupId);
        Ticket.Status existingStatus = ticket.getStatus();

        if (existingStatus.equals(status)) {
            log.warn("Ticket status is already set to: {}", status);
            throw new BadRequestException("Ticket status is already set to: " + status);
        }

        ticket.setStatus(status);
        ticketRepository.save(ticket);
        log.info("Ticket status updated successfully to: {}", status);
    }

    @Override
    public Page<SupportResponse> getSupports(Pageable pageable) {
        log.info("Getting supports list");
        return supportRepository.findAll(pageable)
                .map(SupportResponse::fromEntity);
    }

    @Override
    public List<TicketResponse> getSupportTickets(Long supportId, String groupId) {
        log.info("Getting tickets for support: {}, group: {}", supportId, groupId);
        return ticketRepository.findBySupportId(supportId, groupId).stream()
                .map(TicketResponse::fromEntity)
                .toList();
    }

    @Override
    public Map<String, Object> getTicketImage(Long ticketId, Long supportId, String groupId) {
        log.info("Getting ticket image for support: {}, group: {}", supportId, groupId);
        Ticket ticket = getTicket(ticketId, supportId, groupId);

        byte[] imageBytes = ticket.getImage();
        String imageName = ticket.getImageName();

        Map<String, Object> imageResponse = Map.of(
                "imageName", imageName,
                "base64Image", Base64.getEncoder().encodeToString(imageBytes)
        );
        return imageBytes == null ? null : imageResponse;
    }

    private Ticket getTicket(Long ticketId, Long supportId, String groupId) {
        return ticketRepository.findById(ticketId, supportId, groupId)
                .orElseThrow(() -> {
                    log.error("Ticket not found - ID: {}, Support ID: {}, Group: {}", ticketId, supportId, groupId);
                    return new NotFoundException("Ticket not found");
                });
    }

    private void saveTicket(TicketRequest request, MultipartFile image, boolean isAdmin) {
        String groupId = request.groupId();
        Long supportId = request.supportId();

        if (!isAdmin) {
            Ticket lastTicket = ticketRepository.findLastTicket(supportId, groupId).orElse(null);
            validateUserTicket(lastTicket, groupId);
        }

        String username = isAdmin ? "admin" : Utils.getCurrentUsername();
        Ticket.Status status = isAdmin ? Ticket.Status.MORE_INFO : Ticket.Status.IN_PROGRESS;

        Ticket ticket = buildTicket(
                groupId,
                supportId,
                username,
                request.message(),
                image,
                isAdmin);
        ticket.setStatus(status);

        if (ticketRepository.exists(Example.of(ticket))) {
            log.error("Duplicate ticket detected for group: {}", groupId);
            throw new ConflictException("Ticket already exists");
        }

        ticketRepository.save(ticket);
        log.info("Ticket saved successfully - Creator type: {}, Group: {}", isAdmin ? "admin" : "user", groupId);
    }

    private void validateUserTicket(Ticket lastTicket, String groupId) {
        if (lastTicket != null && !lastTicket.isAdmin()) {
            log.error("Cannot create user ticket for group {} because the last ticket was also created by a user", groupId);
            throw new ConflictException("User cannot create consecutive tickets");
        }
    }

    private Ticket buildTicket(String groupId, Long supportId, String username,
                               String description, MultipartFile image, boolean isAdmin) {
        MedGroup medGroup = medGroupService.getMedGroup(groupId);
        LocalDateTime dateTime = medGroupService.getCurrentDateTime(groupId);

        Ticket.TicketBuilder builder = Ticket.builder()
                .medGroup(medGroup)
                .createdAt(dateTime)
                .createdBy(username)
                .description(description)
                .isAdmin(isAdmin);

        if (supportId != null) {
            builder.support(getSupport(supportId, groupId));
        }

        Ticket ticket = builder.build();

        if (image != null && !image.isEmpty()) {
            attachImage(ticket, image);
        }

        return ticket;
    }

    private Support getSupport(Long supportId, String groupId) {
        log.info("Getting support for group: {}", groupId);
        return supportRepository.findById(supportId, groupId)
                .orElseThrow(() -> {
                    log.error("Support not found for group: {}", groupId);
                    return new NotFoundException("Support not found");
                });
    }

    private void attachImage(Ticket ticket, MultipartFile image) {
        try {
            ticket.setImage(image.getBytes());
            ticket.setImageName(image.getOriginalFilename());
        } catch (IOException e) {
            log.error("Failed to process image for ticket: {}", e.getMessage());
        }
    }
}