package com.rhombuzz.gpbackend.modules.appointment.dto.response;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AppointmentFormBuilderSettingResponse {
    private boolean showAddressFields;
    private boolean showReasonField;
    private boolean showPreferredContactField;
    private boolean showInsuranceCompanyField;
    private boolean showInsuranceIdField;
    private boolean showInsuranceGroupIdField;
}