package com.rhombuzz.gpbackend.modules.medgroup.event.publisher;

import com.rhombuzz.gpbackend.modules.medgroup.event.model.MedgroupRemoveEvent;

public interface MedgroupEventPublisher {

    void publishMedgroupRemoveEvent(MedgroupRemoveEvent event);

}
