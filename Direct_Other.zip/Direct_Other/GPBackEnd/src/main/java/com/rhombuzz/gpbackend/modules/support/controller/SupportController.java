package com.rhombuzz.gpbackend.modules.support.controller;

import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import com.rhombuzz.gpbackend.modules.support.dto.request.SupportRequest;
import com.rhombuzz.gpbackend.modules.support.dto.request.TicketRequest;
import com.rhombuzz.gpbackend.modules.support.dto.response.SupportResponse;
import com.rhombuzz.gpbackend.modules.support.dto.response.TicketResponse;
import com.rhombuzz.gpbackend.modules.support.entity.Ticket;
import com.rhombuzz.gpbackend.modules.support.service.SupportTicketService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/supports")
@Validated
public class SupportController {
    private final SupportTicketService supportTicketService;

    @PostMapping
    public ResponseEntity<Void> saveSupport(
            @RequestPart @Valid SupportRequest request,
            @RequestPart(name = "image", required = false)
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png", "gif"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png", "image/gif"},
                    required = false
            ) MultipartFile file
    ) {
        supportTicketService.saveSupport(request, file);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PostMapping("/user")
    public ResponseEntity<Void> saveUserTicket(
            @RequestPart @Valid TicketRequest request,
            @RequestPart(name = "image", required = false)
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png", "gif"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png", "image/gif"},
                    required = false
            ) MultipartFile file
    ) {
        supportTicketService.saveUserTicket(request, file);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PostMapping("/admin")
    public ResponseEntity<Void> saveAdminTicket(
            @RequestPart @Valid TicketRequest request,
            @RequestPart(name = "image", required = false)
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png", "gif"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png", "image/gif"},
                    required = false
            ) MultipartFile file
    ) {
        supportTicketService.saveAdminTicket(request, file);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PatchMapping("/{supportId}/tickets/{ticketId}")
    public ResponseEntity<Void> updateTicketStatus(
            @PathVariable @NotNull Long supportId,
            @PathVariable @NotNull Long ticketId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotNull Ticket.Status status
            ) {
        supportTicketService.updateTicketStatus(ticketId, supportId, groupId, status);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<Page<SupportResponse>> getSupports(Pageable pageable) {
        Page<SupportResponse> supports = supportTicketService.getSupports(pageable);
        return ResponseEntity.ok(supports);
    }

    @GetMapping("/{supportId}/tickets")
    public ResponseEntity<List<TicketResponse>> getSupportTickets(
            @PathVariable @NotNull Long supportId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<TicketResponse> supportTickets = supportTicketService.getSupportTickets(supportId, groupId);
        return ResponseEntity.ok(supportTickets);
    }

    @GetMapping("/{supportId}/tickets/{ticketId}/image")
    public ResponseEntity<Map<String, Object>> getTicketImage(
            @PathVariable @NotNull Long supportId,
            @PathVariable @NotNull Long ticketId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Map<String, Object> imageResponse = supportTicketService.getTicketImage(ticketId, supportId, groupId);
        return ResponseEntity.ok(imageResponse);
    }
}
