package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RunCheckResponse {
    private boolean isS3BucketExist;
    private boolean isIamGroupExist;
    private boolean isIamUserExist;
    private boolean isIamPolicyExist;
    private boolean isMedGroupExist;
    private boolean isUsernameExist;
    private boolean isUserEmailExist;
}
