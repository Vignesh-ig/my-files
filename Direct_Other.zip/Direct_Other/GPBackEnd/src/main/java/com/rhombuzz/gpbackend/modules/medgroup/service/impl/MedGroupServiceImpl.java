package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.component.CredentialsFactory;
import com.rhombuzz.gpbackend.enums.Role;
import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.auth.dto.request.SaveUserRequest;
import com.rhombuzz.gpbackend.modules.auth.dto.response.UserExistsResponse;
import com.rhombuzz.gpbackend.modules.auth.dto.response.UserResponse;
import com.rhombuzz.gpbackend.modules.auth.service.UserService;
import com.rhombuzz.gpbackend.modules.medgroup.dto.AWSDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.MedGroupDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.RunCheckRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveMedGroupRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.RunCheckResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.SaveMedGroupResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.event.model.MedgroupRemoveEvent;
import com.rhombuzz.gpbackend.modules.medgroup.event.publisher.MedgroupEventPublisher;
import com.rhombuzz.gpbackend.modules.medgroup.repository.MedGroupRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.Asset;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.services.iam.IamClient;
import software.amazon.awssdk.services.iam.model.*;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.NoSuchBucketException;
import software.amazon.awssdk.services.s3.model.ObjectIdentifier;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class MedGroupServiceImpl implements MedGroupService {
    private final MedGroupRepository medGroupRepository;
    private final CredentialsFactory credentialsFactory;
    private final UserService userService;
    private final MedgroupEventPublisher medgroupEventPublisher;
    private S3Client s3Client;
    private IamClient iamClient;
    private final Executor asyncExecutor;

    @Override
    public RunCheckResponse runCheck(RunCheckRequest request) {
        log.info("Running check for group: {}", request.groupName());

        s3Client = credentialsFactory.s3Client(CredentialsFactory.AccessType.ADMIN);
        iamClient = credentialsFactory.iamClient(CredentialsFactory.AccessType.ADMIN);

        UserExistsResponse userExistsResponse = checkUserExist(request.username(), request.email());
        return RunCheckResponse.builder()
                .isS3BucketExist(checkS3BucketExist(request.groupName()))
                .isIamGroupExist(checkIAMGroupExist(request.groupName()))
                .isIamUserExist(checkIAMUserExist(request.username()))
                .isIamPolicyExist(checkIAMPolicyExist(request.groupName()))
                .isMedGroupExist(checkGroupExist(request.groupId()))
                .isUsernameExist(userExistsResponse.isUsernameExists())
                .isUserEmailExist(userExistsResponse.isEmailExists())
                .build();
    }

    @Override
    public SaveMedGroupResponse saveMedGroup(SaveMedGroupRequest medGroupRequest, MultipartFile image) {
        log.info("Saving group: {}", medGroupRequest.groupName());

        s3Client = credentialsFactory.s3Client(CredentialsFactory.AccessType.ADMIN);
        iamClient = credentialsFactory.iamClient(CredentialsFactory.AccessType.ADMIN);

        SaveMedGroupResponse response = new SaveMedGroupResponse();

        synchronized (this) {
            validateResources(medGroupRequest);
            log.info("Validated resources for group: {}", medGroupRequest.groupName());

            try {
                s3Client.createBucket(request -> request.bucket(medGroupRequest.groupName()));
                log.info("Created bucket for group: {}", medGroupRequest.groupName());
                response.setS3BucketCreated(true);
            } catch (Exception e) {
                log.error("Error creating S3 bucket for group: {}. Error: {}", medGroupRequest.groupName(), e.getMessage());
                response.setS3BucketCreated(false);
            }

            AccessKey accessKey = setupIAMResources(medGroupRequest, response);
            log.info("Created IAM resources for group: {}", medGroupRequest.groupName());

            try {
                MedGroup medGroup = buildMedGroup(medGroupRequest, accessKey, image);
                medGroupRepository.save(medGroup);
                log.info("Saved group with id: {}", medGroup.getGroupId());
                response.setGroupCreated(true);

                createDefaultUser(medGroupRequest, response);
                log.info("Created default user: {}", medGroupRequest.groupName());

            } catch (Exception e) {
                log.error("Error saving group: {}. Error: {}", medGroupRequest.groupName(), e.getMessage());
                response.setGroupCreated(false);
                response.setUserCreated(false);
            }

            return response;
        }
    }

    @Override
    public LocalDateTime getCurrentDateTime(String groupId) {
        return medGroupRepository.getTimeZone(groupId)
                .map(timZone -> LocalDateTime.now(timZone.toZoneId()).withNano(0))
                .orElseThrow(() -> new NotFoundException("Group not found"));
    }

    @Override
    public MedGroup getMedGroup(String groupId) {
        return medGroupRepository.findByGroupId(groupId)
                .orElseThrow(() -> new NotFoundException("Group not found"));
    }

    @Override
    public AWSDTO getAWSAccess(String groupId) {
        log.info("Getting AWS access for group: {}", groupId);
        return medGroupRepository.getAWSAccess(groupId)
                .orElseThrow(() -> new NotFoundException("Group not found"));
    }

    @Override
    public List<MedGroup> getMedGroups() {
        log.info("Getting all groups");
        return medGroupRepository.findAll();
    }

    @Override
    public List<MedGroupDTO> getMedGroupNames() {
        return medGroupRepository.getMedGroupNames();
    }

    @Override
    public boolean isMedGroupExists(String groupId) {
        log.info("Checking if group exists: {}", groupId);
        return medGroupRepository.existsByGroupId(groupId);
    }

    @Override
    public byte[] getAsset(Asset assetName) {
        log.info("Getting asset: {}", assetName);
        String asset = switch (assetName) {
            case INSERT_MED_GROUP -> getMedGroupQuery();
            case INSERT_USER -> getUserQuery();
        };
        return asset.getBytes();
    }

    @Override
    public MedGroup.AppointmentType getAppointmentType(String groupId) {
        log.info("Getting appointment type for group: {}", groupId);
        return medGroupRepository.findAppointmentType(groupId)
                .orElseThrow(() -> new NotFoundException("Group not found"));
    }

    @Override
    public void updateAppointmentType(String groupId, MedGroup.AppointmentType appointmentType) {
        log.info("updating appointment type for group: {}", groupId);
        MedGroup medGroup = getMedGroup(groupId);
        medGroup.setAppointmentType(appointmentType);
        medGroupRepository.save(medGroup);
    }

    @Override
    public TimeZone getTimezone(String groupId) {
        return medGroupRepository.getTimeZone(groupId)
                .orElseThrow(() -> new NotFoundException("Group not found"));
    }

    @Override
    public String getGroupDescription(String groupId) {
        return medGroupRepository.findGroupDescriptionByGroupId(groupId);
    }

    @Override
    @Transactional
    public void removeMedgroup(String groupId) {

        log.info("Removing medgroup: {}", groupId);

        MedGroup medGroup = getMedGroup(groupId);

        String groupName = medGroup.getGroupName();

        try {
            medgroupEventPublisher.publishMedgroupRemoveEvent(new MedgroupRemoveEvent(groupId));
        } catch (Exception e) {
            log.error("Error removing medgroup data for medgroup: {}", groupId, e);
        }

        medGroupRepository.delete(medGroup);
        log.info("Removed medgroup: {}", groupId);

        CompletableFuture.runAsync(() -> removeAwsResources(groupName), asyncExecutor)
                .exceptionally(ex -> {
                    log.error("Error removing AWS resources for group: {}. Error: {}", groupName, ex.getMessage());
                    return null;
                });
    }

    private void removeAwsResources(String groupName) {

        s3Client = credentialsFactory.s3Client(CredentialsFactory.AccessType.ADMIN);
        iamClient = credentialsFactory.iamClient(CredentialsFactory.AccessType.ADMIN);

        try {
            removeIamResources(groupName);
        } catch (Exception e) {
            log.error("Failed to remove IAM resources for group: {}", groupName, e);
        }

        try {
            deleteS3Bucket(groupName);
        } catch (Exception e) {
            log.error("Failed to delete S3 bucket: {}", groupName, e);
        }

        log.info("Completed removal of AWS resources for group: {}", groupName);
    }

    private void removeIamResources(String groupName) {

        log.info("Removing IAM resources for group: {}", groupName);

        try {
            List<User> iamUsers = iamClient.getGroup(request -> request.groupName(groupName))
                    .users();

            if (iamUsers.isEmpty()) {
                log.error("No IAM users found in group: {}", groupName);
                throw new NotFoundException("No IAM users found in group: " + groupName);
            }

            String userName = iamUsers.getFirst().userName();

            try {
                iamClient.removeUserFromGroup(request -> request.userName(userName).groupName(groupName));
                log.info("Removed user: {} from group: {}", userName, groupName);
            } catch (Exception e) {
                log.error("Error removing user: {} from group: {}", userName, groupName, e);
            }

            try {
                iamClient.deleteLoginProfile(request -> request.userName(userName));
                log.info("Deleted login profile for user: {}", userName);
            } catch (Exception e) {
                log.error("Error deleting login profile for user: {}", userName, e);
            }

            try {

                List<AccessKeyMetadata> accessKeyMetadataList = iamClient.listAccessKeys(request -> request.userName(userName)).accessKeyMetadata();

                for (AccessKeyMetadata accessKey : accessKeyMetadataList) {
                    try {
                        iamClient.deleteAccessKey(request -> request.userName(userName).accessKeyId(accessKey.accessKeyId()));
                    } catch (Exception e) {
                        log.error("Error deleting access key for user: {}", userName, e);
                    }
                }
                log.info("Deleted access keys for user: {}", userName);

            } catch (Exception e) {
                log.error("Error deleting access key for user: {}", userName, e);
            }

            try {
                iamClient.deleteUser(request -> request.userName(userName));
                log.info("Deleted IAM user: {}", userName);
            } catch (Exception e) {
                log.error("Error deleting IAM user: {}", userName, e);
            }
        } catch (Exception e) {
            log.error("Error deleting IAM resources", e);
        }

        removePolicyAndUserGroup(groupName);
    }

    private void removePolicyAndUserGroup(String groupName) {

        log.info("Removing policy from group: {}", groupName);

        List<AttachedPolicy> attachedPolicies = iamClient.listAttachedGroupPolicies(request ->
                request.groupName(groupName)).attachedPolicies();

        for (AttachedPolicy policy : attachedPolicies) {
            try {
                iamClient.detachGroupPolicy(request -> request.groupName(groupName).policyArn(policy.policyArn()));
                log.info("Detached policy: {} from group: {}", policy.policyName(), groupName);

                iamClient.deletePolicy(request -> request.policyArn(policy.policyArn()));
                log.info("Deleted policy: {} for group: {}", policy.policyName(), groupName);
            } catch (Exception e) {
                log.error("Error removing policy: {} from group: {}", policy.policyName(), groupName, e);
            }
        }

        try {
            iamClient.deleteGroup(request -> request.groupName(groupName));
            log.info("Deleted IAM group: {}", groupName);
        } catch (Exception e) {
            log.error("Error deleting IAM group: {}", groupName, e);
        }
    }

    private void deleteS3Bucket(String groupName) {

        log.info("Deleting S3 bucket: {}", groupName);
        try {
            List<ObjectIdentifier> objectsToDelete = s3Client.listObjectsV2Paginator(request -> request.bucket(groupName))
                    .contents()
                    .stream()
                    .map(s3Object -> ObjectIdentifier.builder().key(s3Object.key()).build())
                    .collect(Collectors.toList());

            if (!objectsToDelete.isEmpty()) {

                log.info("Deleting {} objects from S3 bucket: {}", objectsToDelete.size(), groupName);

                // Delete objects in batches of 1000
                for (int i = 0; i < objectsToDelete.size(); i += 1000) {
                    int end = Math.min(i + 1000, objectsToDelete.size());
                    List<ObjectIdentifier> batch = objectsToDelete.subList(i, end);
                    s3Client.deleteObjects(request -> request.bucket(groupName)
                            .delete(delete -> delete.objects(batch)));
                    log.info("Deleted objects {} to {} from S3 bucket: {}", i + 1, end, groupName);
                }

            } else {
                log.info("No objects found in S3 bucket: {}", groupName);
            }

            s3Client.deleteBucket(request -> request.bucket(groupName));
            log.info("Deleted S3 bucket: {}", groupName);
        } catch (Exception e) {
            log.error("Error deleting S3 bucket: {}. Error: {}", groupName, e.getMessage());
        }

    }

    private void createDefaultUser(SaveMedGroupRequest medGroupRequest, SaveMedGroupResponse response) {
        log.info("Creating default user: {}", medGroupRequest.groupName());
        try {
            SaveUserRequest userRequest = new SaveUserRequest();
            userRequest.setGroupId(medGroupRequest.groupId());
            userRequest.setUsername(medGroupRequest.username());
            userRequest.setPassword(medGroupRequest.password());
            userRequest.setFirstName(medGroupRequest.firstName());
            userRequest.setLastName(medGroupRequest.lastName());
            userRequest.setEmail(medGroupRequest.email());
            userRequest.setGroupId(medGroupRequest.groupId());

            UserResponse.Role superUser = userService.getGroupRoles().stream()
                    .filter(role -> role.getName().equals(Role.SUPER_USER))
                    .findFirst()
                    .orElseThrow(() -> new NotFoundException("Role not found"));
            userRequest.setRoleId(superUser.getId());

            userService.saveUser(userRequest);
            response.setUserCreated(true);
        } catch (Exception e) {
            log.error("Error creating default user for group: {}. Error: {}", medGroupRequest.groupName(), e.getMessage());
            response.setUserCreated(false);
        }
    }

    private MedGroup buildMedGroup(SaveMedGroupRequest request, AccessKey accessKey, MultipartFile image) {
        MedGroup medGroup = MedGroup.builder()
                .groupId(request.groupId())
                .groupName(request.groupName())
                .s3AccessKey(accessKey.accessKeyId())
                .s3SecretKey(accessKey.secretAccessKey())
                .groupType(request.groupType())
                .timeZone(TimeZone.getTimeZone(request.timeZone()))
                .groupDescription(request.groupDescription())
                .officePhone(request.officePhone())
                .defaultAddress(request.defaultAddress())
                .email(request.email())
                .firstName(String.format("%s %s", request.firstName(), request.lastName()))
                .appointmentType(MedGroup.AppointmentType.SPECIFIC)
                .build();

        if (image != null) {
            try {
                medGroup.setImage(image.getBytes());
                medGroup.setImageName(request.groupId() + "-image");
            } catch (IOException e) {
                throw new InternalServerErrorException("Error processing image: " + e.getMessage());
            }
        }

        return medGroup;
    }

    private AccessKey setupIAMResources(SaveMedGroupRequest medGroupRequest, SaveMedGroupResponse response) {
        String groupName = medGroupRequest.groupName();
        String username = medGroupRequest.username();

        try {
            iamClient.createGroup(request -> request.groupName(groupName));
            log.info("Created IAM group for group: {}", groupName);
            response.setIamGroupCreated(true);
        } catch (Exception e) {
            log.error("Error creating IAM group for group: {}. Error: {}", groupName, e.getMessage());
            response.setIamGroupCreated(false);
        }

        String userArn = "";
        try {
            userArn = iamClient.createUser(request -> request.userName(username)).user().arn();
            log.info("Created IAM user for group: {}", username);
            response.setIamUserCreated(true);
        } catch (Exception e) {
            log.error("Error creating IAM user for user: {}. Error: {}", username, e.getMessage());
            response.setIamUserCreated(false);
        }

        try {
            iamClient.addUserToGroup(request -> request.userName(username).groupName(groupName));
            log.info("AWS: User added to group: {}", groupName);
            response.setIamUserAddedToGroup(true);
        } catch (Exception e) {
            log.error("Error adding user: {} to group: {}. Error: {}", username, groupName, e.getMessage());
            response.setIamUserAddedToGroup(false);
        }

        try {
            iamClient.createLoginProfile(request -> request.userName(username).password(medGroupRequest.password()));
            log.info("Created login profile for user: {}", username);
            response.setIamLoginProfileCreated(true);
        } catch (Exception e) {
            log.error("Error creating login profile for user: {}. Error: {}", username, e.getMessage());
            response.setIamLoginProfileCreated(false);
        }

        createAndAttachPolicy(groupName, userArn, response);
        log.info("AWS: Policy created and attached to group: {}", groupName);

        AccessKey accessKey = null;
        try {
            accessKey = iamClient.createAccessKey(request -> request.userName(username)).accessKey();
            log.info("AWS: Access key created for user: {}", username);
            response.setAccessKeyCreated(true);
        } catch (Exception e) {
            log.error("Error creating access key for user: {}. Error: {}", username, e.getMessage());
            response.setAccessKeyCreated(false);
        }

        return accessKey;
    }

    private void createAndAttachPolicy(String groupName, String userArn, SaveMedGroupResponse response) {
        String policyName = groupName + "pol1";
        String policyDocument = buildPolicyDocument(groupName);

        try {
            iamClient.createPolicy(request -> request.policyName(policyName).policyDocument(policyDocument));
            log.info("AWS: Policy created for group: {}", groupName);
            response.setIamPolicyCreated(true);
        } catch (Exception e) {
            log.error("Error creating IAM policy for group: {}. Error: {}", groupName, e.getMessage());
            response.setIamPolicyCreated(false);
        }

        String policyArn = getArnPolicy(groupName, userArn);
        try {
            iamClient.attachGroupPolicy(request -> request.policyArn(policyArn).groupName(groupName));
            log.info("AWS: Policy attached to group: {}", groupName);
            response.setIamPolicyAttached(true);
        } catch (Exception e) {
            log.error("Error attaching IAM policy to group: {}. Error: {}", groupName, e.getMessage());
            response.setIamPolicyAttached(false);
        }
    }

    private String buildPolicyDocument(String groupName) {
        return String.format(getPolicy(), groupName, groupName);
    }

    private void validateResources(SaveMedGroupRequest medGroupRequest) {
        log.info("Validating resources for group: {}", medGroupRequest.groupName());

        if (checkS3BucketExist(medGroupRequest.groupName())) {
            log.error("AWS: S3 bucket with name: {} already exists", medGroupRequest.groupName());
            throw new ConflictException("S3 bucket with name: " + medGroupRequest.groupName() + " already exists");
        }

        if (checkIAMGroupExist(medGroupRequest.groupName())) {
            log.error("AWS: IAM group with name: {} already exists", medGroupRequest.groupName());
            throw new ConflictException("IAM group with name: " + medGroupRequest.groupName() + " already exists");
        }

        if (checkIAMUserExist(medGroupRequest.username())) {
            log.error("AWS: IAM user with name: {} already exists", medGroupRequest.username());
            throw new ConflictException("IAM user with name: " + medGroupRequest.username() + " already exists");
        }

        if (checkIAMPolicyExist(medGroupRequest.groupName())) {
            log.error("AWS: IAM policy for group: {} already exists", medGroupRequest.groupName());
            throw new ConflictException("IAM policy for group: " + medGroupRequest.groupName() + " already exists");
        }

        if (checkGroupExist(medGroupRequest.groupId())) {
            log.error("Group with id: {} already exists", medGroupRequest.groupId());
            throw new ConflictException("Group with id: " + medGroupRequest.groupId() + " already exists");
        }

        UserExistsResponse userExistsResponse = checkUserExist(medGroupRequest.username(), medGroupRequest.email());

        if (userExistsResponse.isEmailExists()) {
            log.error("User with email: {} already exists", medGroupRequest.email());
            throw new ConflictException("User with username: " + medGroupRequest.email() + " already exists");
        }

        if (userExistsResponse.isUsernameExists()) {
            log.error("User with username: {} already exists", medGroupRequest.username());
            throw new ConflictException("User with username: " + medGroupRequest.username() + " already exists");
        }
    }

    private UserExistsResponse checkUserExist(String username, String email) {
        log.info("Checking user: {}", username);
        return userService.isUserExists(username, email);
    }

    private boolean checkGroupExist(String groupId) {
        log.info("Checking group: {}", groupId);
        return medGroupRepository.findByGroupId(groupId).isPresent();
    }

    private boolean checkIAMPolicyExist(String groupName) {
        log.info("Checking IAM policy for group: {}", groupName);
        try {
            return iamClient.listPolicies().policies().parallelStream()
                    .anyMatch(policy -> policy.policyName().equals(groupName + "pol1"));

        } catch (NoSuchEntityException e) {
            log.info("IAM policy not found for group: {}", groupName);
            return false;
        }
    }

    private boolean checkIAMUserExist(String username) {
        log.info("Checking IAM user: {}", username);
        try {
            iamClient.getUser(request -> request.userName(username));
            return true;
        } catch (NoSuchEntityException e) {
            log.info("IAM user not found for group: {}", username);
            return false;
        }
    }

    private boolean checkIAMGroupExist(String groupName) {
        log.info("Checking IAM group: {}", groupName);
        try {
            iamClient.getGroup(request -> request.groupName(groupName));
            return true;
        } catch (NoSuchEntityException e) {
            log.info("IAM group not found for group: {}", groupName);
            return false;
        }
    }

    private boolean checkS3BucketExist(String groupName) {
        log.info("Checking if bucket exists: {}", groupName);
        try {
            s3Client.headBucket(request -> request.bucket(groupName));
            return true;
        } catch (NoSuchBucketException e) {
            log.info("S3 bucket not found: {}", groupName);
            return false;
        } catch (AwsServiceException e) {
            int statusCode = e.statusCode();
            if (statusCode == 400 || statusCode == 403) {
                log.info("S3 bucket exists: {}", groupName);
                return true;
            } else {
                log.error("Error checking S3 bucket: {}. Status code: {}", groupName, statusCode);
                throw new InternalServerErrorException("Error checking S3 bucket: " + e.getMessage());
            }
        }
    }

    private String getArnPolicy(String groupName, String arn) {
        String accountId = arn.split(":")[4];
        return "arn:aws:iam::" + accountId + ":policy/" + groupName + "pol1";
    }

    private String getPolicy() {
        return """
                {
                    "Version": "2012-10-17",
                    "Statement": [
                        {
                            "Sid": "AllowGroupToSeeBucket",
                            "Action": [
                                "s3:ListBucket"
                            ],
                            "Effect": "Allow",
                            "Resource": [
                                "arn:aws:s3:::%s"
                            ]
                        },
                        {
                            "Sid": "AllowUserToReadAndWriteObjectData",
                            "Action": [
                                "s3:GetObject",
                                "s3:PutObject",
                                "s3:DeleteObject"
                            ],
                            "Effect": "Allow",
                            "Resource": [
                                "arn:aws:s3:::%s/*"
                            ]
                        }
                    ]
                }
                """;
    }

    private String getMedGroupQuery() {
        return """
                SET @group_id = '{YOUR_GROUP_ID}';
                SET @group_name = '{YOUR_GROUP_NAME}';
                SET @email = '{YOUR_EMAIL}';
                SET @first_name = '{YOUR_FIRST_NAME}';
                SET @last_name = '{YOUR_LAST_NAME}';
                
                SET @s3_access_key = '{YOUR_S3_ACCESS_KEY}'; -- Generated from AWS IAM
                SET @s3_secret_key = '{YOUR_S3_SECRET_KEY}'; -- Generated from AWS IAM
                
                SET @group_type = '{YOUR_GROUP_TYPE}'; -- e.g., 'DENTAL_COVER_PAGE', 'GENERAL_MEDICINE', etc.
                SET @time_zone = '{YOUR_TIME_ZONE}'; -- e.g., 'US/Eastern
                
                SET @group_description = '{YOUR_GROUP_DESCRIPTION}';
                SET @office_phone = '{YOUR_OFFICE_PHONE}'; -- e.g., '1234567890'
                SET @address = '{YOUR_ADDRESS}';
                
                INSERT INTO med_groups (group_id,
                                        appt_alert_office_email,
                                        appointment_type,
                                        default_address,
                                        default_booking_fee,
                                        email,
                                        ems_phone,
                                        ems_toll_free_phone_number,
                                        facebook_link,
                                        first_name,
                                        from_name,
                                        google_place_id,
                                        group_description,
                                        group_name,
                                        group_type,
                                        image,
                                        image_name,
                                        office_phone,
                                        per_text_fee,
                                        pre_reminder_days,
                                        prepaid_text_count,
                                        reminder_days,
                                        reminder_type,
                                        s3_access_key,
                                        s3_secret_key,
                                        stripe_account_id,
                                        stripe_efm_fee_percent,
                                        time_zone,
                                        yelp_link,
                                        telehealth)
                VALUES (@group_id,
                        null,
                        null,
                        @address,
                        null,
                        @email,
                        null,
                        null,
                        null,
                        CONCAT(@first_name, ' ', @last_name),
                        null,
                        null,
                        @group_description,
                        @group_name,
                        @group_type,
                        null,
                        null,
                        @office_phone,
                        0.08,
                        6,
                        5000,
                        0,
                        'CALENDAR_DAYS',
                        @s3_access_key,
                        @s3_secret_key,
                        null,
                        null,
                        @time_zone,
                        null,
                        null);
                """;
    }

    private String getUserQuery() {
        return """
                SET @user_id = '{YOUR_AUTH0_USER_ID}';
                SET @password = '{YOUR_BCRYPT_HASHED_PASSWORD}';
                SET @user_name = '{YOUR_USER_NAME}';
                
                INSERT INTO users (user_id,
                                   password,
                                   user_name)
                VALUES (@user_id,
                        @password,
                        @user_name);
                
                """;
    }
}
