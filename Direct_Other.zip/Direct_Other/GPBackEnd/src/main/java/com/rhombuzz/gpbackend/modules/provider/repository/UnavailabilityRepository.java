package com.rhombuzz.gpbackend.modules.provider.repository;

import com.rhombuzz.gpbackend.modules.provider.entity.Unavailability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface UnavailabilityRepository extends JpaRepository<Unavailability, Long> {

    @Query("SELECT u FROM Unavailability u WHERE u.provider.id = ?1 AND u.medGroup.groupId = ?2")
    List<Unavailability> findByProviderId(Long providerId, String groupId);

    @Query("SELECT u FROM Unavailability u WHERE u.id = ?1 AND u.provider.id = ?2 AND u.medGroup.groupId = ?3")
    Optional<Unavailability> findById(Long id, Long providerId, String groupId);

    @Modifying
    @Query("DELETE FROM Unavailability u WHERE u.id = ?1 AND u.provider.id = ?2 AND u.medGroup.groupId = ?3")
    void deleteById(Long id, Long providerId, String groupId);

    @Query("SELECT COUNT(u) > 0 FROM Unavailability u WHERE u.provider.id = ?1 AND u.medGroup.groupId = ?2 AND u.exceptionDate = ?3")
    boolean exists(Long providerId, String groupId, LocalDate exceptionDate);
}
