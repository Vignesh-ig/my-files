package com.rhombuzz.gpbackend.modules.medgroup.controller;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.OfficeClosureRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.OfficeClosureResponse;
import com.rhombuzz.gpbackend.modules.medgroup.service.OfficeClosureService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/office-closures")
@Validated
public class OfficeClosureController {
    private final OfficeClosureService officeClosureService;

    @PostMapping
    public ResponseEntity<Void> saveOfficeClosure(@RequestBody @Valid OfficeClosureRequest request) {
        officeClosureService.saveOfficeClosure(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<List<OfficeClosureResponse>> getOfficeClosures(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<OfficeClosureResponse> officeClosures = officeClosureService.getOfficeClosures(groupId);
        return ResponseEntity.ok(officeClosures);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateOfficeClosure(
            @PathVariable @NotNull Long id,
            @RequestBody @Valid OfficeClosureRequest request
    ) {
        officeClosureService.updateOfficeClosure(id, request);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOfficeClosure(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        officeClosureService.deleteOfficeClosure(id, groupId);
        return ResponseEntity.noContent().build();
    }
}
