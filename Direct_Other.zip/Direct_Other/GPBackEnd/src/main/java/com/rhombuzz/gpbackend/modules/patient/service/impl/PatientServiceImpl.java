package com.rhombuzz.gpbackend.modules.patient.service.impl;

import com.rhombuzz.gpbackend.component.CredentialsFactory;
import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.appointment.dto.request.SaveFormAppointmentRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.AWSDTO;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.dto.PatientCSVDTO;
import com.rhombuzz.gpbackend.modules.patient.dto.request.*;
import com.rhombuzz.gpbackend.modules.patient.dto.response.*;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.repository.PatientRepository;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.CSVUtils;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PatientServiceImpl implements PatientService {
    private final PatientRepository patientRepository;
    private final MedGroupService medGroupService;
    private final ActivityService activityService;
    private final CredentialsFactory credentialsFactory;
    private S3Client s3Client;

    @Override
    public Map<String, Object> savePatient(SavePatientRequest request) {
        log.info("Saving patient {}", request);

        Patient patient = createPatientFromRequest(request);
        return checkAndSavePatient(patient);
        //Todo: add data to MedGroupInsights
    }

    @Override
    public void updatePatient(Long id, UpdatePatientRequest request) {
        String fullName = request.firstName() + " " + request.lastName();

        log.info("Patient update:  {}", fullName);
        Patient patient = getPatientById(id, request.groupId());

        updatePatient(patient, request);
        patientRepository.save(patient);
        log.info("Patient {} updated successfully", fullName);

        //Todo: Track on activities.
    }

    @Override
    @Transactional
    public void deletePatient(Long id, String groupId) {
        log.info("Deleting patient {}", id);
        if (!patientRepository.existsById(id, groupId)) {
            patientNotFoundLog(id);
            throw new NotFoundException("Patient not found");
        }
        patientRepository.deleteById(id, groupId);
        log.info("Patient {} deleted", id);

        //Todo: Track on activities.
    }

    @Override
    public Page<PatientResponseList> getPatients(String groupId, Pageable pageable) {
        log.info("Getting all patients for group {}", groupId);
        return patientRepository.findByMedGroup_GroupId(groupId, pageable);
    }

    @Override
    public PatientResponse getPatient(Long id, String groupId) {
        log.info("Getting patient {}", id);
        return patientRepository.findByIdAndMedGroup_GroupId(id, groupId)
                .orElseThrow(() -> {
                    patientNotFoundLog(id);
                    return new NotFoundException("Patient not found");
                });
    }

    @Override
    public void loadPatientsFromCsv(MultipartFile file, String groupId) {
        log.info("Loading patients from CSV for group {}", groupId);

        MedGroup medGroup = medGroupService.getMedGroup(groupId);
        List<PatientCSVDTO> patientCSVDTOS = CSVUtils.loadFromCsv(file, PatientCSVDTO.class).stream()
                .peek(Utils::validateObject)
                .toList();

        patientCSVDTOS.forEach(patientCSVDTO -> {
            Patient patient = Patient.fromCSVDTO(patientCSVDTO);
            log.debug("Patient to save: {} - {}", patient.getFirstName(), patient.isSubmissionFlag());
            patient.setMedGroup(medGroup);
            checkAndSavePatient(patient);
            log.info("Patient {} saved successfully", patient.getFirstName() + " " + patient.getLastName());
        });

        //Todo: add data to MedGroupInsights
        log.info("Patients loaded successfully for group {}", groupId);
    }

    @Override
    public void uploadDocuments(List<MultipartFile> files, Long patientId, String groupId) {
        log.info("Uploading patient {} to group {}", patientId, groupId);

        if (!patientRepository.existsById(patientId, groupId)) {
            patientNotFoundLog(patientId);
            throw new NotFoundException("Patient not found");
        }

        AWSDTO awsAccess = getAWSCredentials(groupId);
        s3Client = getS3Client(groupId);

        String bucketName = awsAccess.getGroupName();
        try {
            for (MultipartFile file : files) {
                String fileName = file.getOriginalFilename();
                String key = patientId + "/uploads/" + fileName;
                if (!doesObjectExists(bucketName, key, s3Client)) {
                    PutObjectRequest request = PutObjectRequest.builder()
                            .bucket(bucketName)
                            .key(key)
                            .build();
                    s3Client.putObject(request, RequestBody.fromBytes(file.getBytes()));
                    log.info("Document uploaded for patient {} in group {}", patientId, groupId);
                }
            }

        } catch (Exception e) {
            log.error("Error uploading document to S3: {}", e.getMessage(), e);
            throw new InternalServerErrorException("Error uploading document to S3");
        }
    }

    @Override
    public DocumentStatusResponse getDocuments(Long patientId, String groupId) {
        log.info("Getting documents for patient {} in group {}", patientId, groupId);

        try {
            ZoneId timezone = medGroupService.getMedGroup(groupId).getTimeZone().toZoneId();
            AWSDTO awsAccess = getAWSCredentials(groupId);
            s3Client = getS3Client(groupId);
            String bucketName = awsAccess.getGroupName();

            Map<String, String> folders = Map.of(
                    "uploads", patientId + "/uploads/",
                    "submission", patientId + "/",
                    "attachments", patientId + "/attachments/"
            );

            List<DocumentStatusResponse.DocumentFrom> documentSources = folders.entrySet().stream()
                    .map(entry -> {
                        List<DocumentResponse> documents = listDocumentsInFolder(bucketName, entry.getValue(), timezone);
                        return new DocumentStatusResponse.DocumentFrom(entry.getKey(), documents);
                    })
                    .toList();

            return patientRepository.findById(patientId, groupId)
                    .map(patient -> DocumentStatusResponse.builder()
                            .claimedBy(patient.getClaimedBy())
                            .reviewStatus(patient.isReviewStatus())
                            .documents(documentSources)
                            .build())
                    .orElseThrow(() -> {
                        patientNotFoundLog(patientId);
                        return new NotFoundException("Patient not found");
                    });
        } catch (Exception e) {
            log.error("Error getting documents from S3: {}", e.getMessage(), e);
            throw new InternalServerErrorException("Error getting documents from S3");
        }
    }

    @Override
    public Resource downloadDocument(Long patientId, String fileName, String folderName, String groupId) {
        log.info("Downloading patient {} from group {}", patientId, groupId);

        AWSDTO awsAccess = getAWSCredentials(groupId);
        s3Client = getS3Client(groupId);

        String key = getS3Key(patientId, fileName, folderName);

        try {
            var response = s3Client.getObject(request -> request.bucket(awsAccess.getGroupName())
                    .key(key));

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            response.transferTo(outputStream);

            ByteArrayResource resource = new ByteArrayResource(outputStream.toByteArray());
            log.info("Document downloaded for patient {} in group {}", patientId, groupId);
            return resource;

        } catch (NoSuchKeyException e) {
            log.error("Document not found in S3: {}", e.getMessage(), e);
            throw new NotFoundException("Document not found");
        } catch (Exception e) {
            log.error("Error downloading document from S3: {}", e.getMessage(), e);
            throw new InternalServerErrorException("Error downloading document from S3");
        }
    }

    @Override
    public void deleteDocument(Long patientId, String fileName, String folderName, String groupId) {
        log.info("Deleting patient {} from group {}", patientId, groupId);

        AWSDTO awsAccess = getAWSCredentials(groupId);
        s3Client = getS3Client(groupId);

        String key = getS3Key(patientId, fileName, folderName);

        try {
            s3Client.deleteObject(request -> request.bucket(awsAccess.getGroupName())
                    .key(key));
            log.info("Document deleted for patient {} in group {}", patientId, groupId);
        } catch (Exception e) {
            log.error("Error deleting document from S3: {}", e.getMessage(), e);
            throw new InternalServerErrorException("Error deleting document from S3");
        }
    }

    @Override
    public Patient getPatientById(Long id, String groupId) {
        return patientRepository.findById(id, groupId)
                .orElseThrow(() -> {
                    patientNotFoundLog(id);
                    return new NotFoundException("Patient not found");
                });
    }

    @Override
    @Transactional
    public void mergePatient(MergePatientRequest request) {
        log.info("Merging patient {} into patient {}", request.sourceId(), request.targetId());
        validateMergePatients(request);

        String bucketName = getAWSCredentials(request.groupId()).getGroupName();
        String sourcePrefix = request.sourceId() + "/uploads/";
        S3Client s3Client = getS3Client(request.groupId());

        s3Client.listObjectsV2(b -> b.bucket(bucketName).prefix(sourcePrefix))
                .contents()
                .parallelStream()
                .forEach(object -> {
                    String fileName = object.key().substring(sourcePrefix.length());
                    String targetKey = request.targetId() + "/uploads/" + fileName;

                    s3Client.copyObject(c -> c.sourceBucket(bucketName)
                            .sourceKey(object.key())
                            .destinationBucket(bucketName)
                            .destinationKey(targetKey));

                    s3Client.deleteObject(d -> d.bucket(bucketName).key(object.key()));
                    log.info("Document {} moved from {} to {}", fileName, request.sourceId(), request.targetId());
                });

        deletePatient(request.sourceId(), request.groupId());

        log.info("patient {} merged from patient {}", request.targetId(), request.sourceId());
    }

    @Override
    public List<Map<Long, PatientResponseList>> getMergePatients(MergePatientRequest request) {
        log.info("Getting patients for merge: sourceId={}, targetId={}", request.sourceId(), request.targetId());
        validateMergePatients(request);

        List<Long> patientIds = List.of(request.sourceId(), request.targetId());
        Map<Long, PatientResponseList> patients = patientRepository.findByIdInAndMedGroup_GroupId(patientIds, request.groupId())
                .stream()
                .collect(Collectors.toMap(
                        PatientResponseList::getId,
                        patient -> patient
                ));

        if (patients.size() != 2) {
            patientIds.stream()
                    .filter(id -> !patients.containsKey(id))
                    .forEach(id -> {
                        patientNotFoundLog(id);
                        throw new NotFoundException("Patient not found: " + id);
                    });
        }

        return List.of(Map.of(
                request.sourceId(), patients.get(request.sourceId()),
                request.targetId(), patients.get(request.targetId())
        ));
    }

    @Override
    public Patient getPatientByPhone(String phone, String groupId) {
        log.info("Getting patient by phone {} in group {}", phone, groupId);
        return patientRepository.findByPhone(phone, groupId)
                .orElseThrow(() -> {
                    log.error("Patient not found with phone: {}", phone);
                    return new NotFoundException("Patient not found");
                });
    }

    @Override
    public void updatePhoneValid(Long patientId, String groupId, boolean valid) {
        log.info("Updating phone validity for patient {} in group {}", patientId, groupId);
        Patient patient = getPatientById(patientId, groupId);
        patient.setCellPhoneValid(valid);

        patientRepository.save(patient);
        log.info("Phone validity updated for patient {} in group {}", patientId, groupId);
    }

    @Override
    public Map<String, Object> isPatientExists(PatientExistsRequest request) {
        log.info("Checking if patient exists with request: {}", request);
        String[] status = checkPatientExistence(request.groupId(), request.firstName(), request.lastName(),
                request.dob(), request.cellPhone(), request.email());

        log.info("Patient existence check result: {}", status[0]);
        if ("UPDATE".equals(status[0])) {
            return Map.of(
                    "exists", true,
                    "patientId", status[1],
                    "patient", patientRepository.getPatientBasicDetailsByIdAndGroupId(Long.parseLong(status[1]), request.groupId()).orElseThrow(
                            () -> new NotFoundException("Patient not found")
                    )
            );
        } else {
            return Map.of("exists", false);
        }
    }

    @Override
    public void updateSubmissionFlagAndDateTime(Long patientId, String groupId, boolean submitted) {
        log.info("Updating submission flag and submission date for patient {} in group {}", patientId, groupId);
        Patient patient = getPatientById(patientId, groupId);
        patient.setSubmissionFlag(submitted);
        patient.setDocumentSubmissionDateTime(medGroupService.getCurrentDateTime(groupId));
        patientRepository.save(patient);
        log.info("Submission flag is set as {} and submission date is updated for patient {} in group {}", submitted, patientId, groupId);
    }

    @Override
    public void saveFileToS3Bucket(SaveFileRequest request) {
        AWSDTO awsAccess = getAWSCredentials(request.getGroupId());
        s3Client = getS3Client(request.getGroupId());

        String bucketName = awsAccess.getGroupName();
        try {
            for (byte[] file : request.getFileData()) {
                String key = request.getKey();
                PutObjectRequest objectRequest = PutObjectRequest.builder()
                        .bucket(bucketName)
                        .key(key)
                        .build();
                s3Client.putObject(objectRequest, RequestBody.fromBytes(file));
                log.info("File uploaded for patient {} in group {}", request.getPatientId(), request.getGroupId());

            }
        } catch (Exception e) {
            log.error("Error uploading document to S3: {}", e.getMessage(), e);
            throw new InternalServerErrorException("Error uploading document to S3");
        }
    }

    @Override
    public void updateSubmissionDateTime(Long patientId, String groupId) {
        log.info("Updating submission date for patient {} in group {}", patientId, groupId);

        Patient patient = getPatientById(patientId, groupId);
        patient.setDocumentSubmissionDateTime(medGroupService.getCurrentDateTime(groupId));

        patientRepository.save(patient);
        log.info("Submission date is updated for patient {} in group {}", patientId, groupId);
    }

    @Override
    public void saveManualPatient(SaveManualPatientRequest request) {
        log.info("Saving manual patient {}", request);
        Patient patient = createPatientFromRequest(request);

        String[] status = checkPatientExistence(request.groupId(), request.firstName(), request.lastName(),
                request.dob(), request.cellPhone(), request.email());

        if ("UPDATE".equals(status[0])) {
            log.error("This patient {} already exists with ID {}", patient.getFirstName() + " " + patient.getLastName(), status[1]);
            throw new ConflictException("This patient already exists with ID " + status[1]);
        }

        Long patientId = saveNewPatient(patient);

        log.info("A new manual patient {} has been created with ID {}", patient.getFirstName() + " " + patient.getLastName(), patientId);
        ActivityRequest activity = buildActivity(
                patient,
                request.groupId(),
                "MANUAL PATIENT",
                "A new manual patient " + patient.getFirstName() + " " + patient.getLastName() + " has been created with ID " + patientId
        );
        activityService.saveActivity(activity);

    }

    @Override
    public boolean isPatientExists(Long patientId, String groupId) {
        log.info("Checking existence of patient {} in group {}", patientId, groupId);
        return patientRepository.existsById(patientId, groupId);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Long saveAppointmentFormPatientDetails(SaveFormAppointmentRequest.PatientDetails request, String groupId, LocalDateTime currentDateTime) {
        log.info("Saving appointment form patient details for group {}", groupId);
        String[] status = checkPatientExistence(groupId, request.getFirstName(), request.getLastName(),
                request.getDob(), request.getCellPhone(), request.getEmail());

        Long patientId;
        if ("UPDATE".equals(status[0])) {
            patientId = Long.parseLong(status[1]);
            updatePatientUsingAppointmentFormPatientDetails(patientId, groupId, currentDateTime, request);
        } else {
            MedGroup medGroup = new MedGroup();
            medGroup.setGroupId(groupId);
            medGroup.setTimeZone(medGroupService.getTimezone(groupId));

            Patient patient = Patient.builder()
                    .medGroup(medGroup)
                    .firstName(request.getFirstName())
                    .lastName(request.getLastName())
                    .dob(request.getDob())
                    .gender(request.getGender())
                    .cellPhone(request.getCellPhone())
                    .email(request.getEmail())
                    .preferredContactMethod(request.getPreferredContactMethod())
                    .streetAddress(request.getStreetAddress())
                    .city(request.getCity())
                    .state(request.getState())
                    .zipCode(request.getZipCode())
                    .createdDateTime(currentDateTime)
                    .lastModifiedDateTime(currentDateTime)
                    .build();
            patientId = patientRepository.save(patient).getId();

            ActivityRequest activity = buildActivity(
                    new Patient(patientId),
                    groupId,
                    "NEW PATIENT - APPOINTMENT FORM",
                    "The patient (" + request.getFirstName() + " " + request.getLastName() + ") record got added via appointment page."
            );
            activityService.saveActivity(activity);
        }

        return patientId;
    }

    @Transactional
    @Override
    public void updatePatientHomePhoneByIdAndGroupId(Long patientId, String groupId, String homePhone) {
        log.info("Updating home phone for patient {} in group {}", patientId, groupId);
        LocalDateTime updatedAt = medGroupService.getCurrentDateTime(groupId);
        if (!patientRepository.existsById(patientId, groupId)) {
            log.info("Patient not found for update homephone with id: {} and groupId: {}", patientId, groupId);
            throw new NotFoundException("Patient not found");
        }
        patientRepository.updateHomePhoneByIdAndGroupId(patientId, groupId, homePhone, updatedAt);
    }

    @Transactional
    @Override
    public void updatePatientCellPhoneByIdAndGroupId(Long patientId, String groupId, String cellPhone) {
        log.info("Updating cell phone for patient {} in group {}", patientId, groupId);
        LocalDateTime updatedAt = medGroupService.getCurrentDateTime(groupId);
        if (!patientRepository.existsById(patientId, groupId)) {
            log.info("Patient not found for update cellphone with id: {} and groupId: {}", patientId, groupId);
            throw new NotFoundException("Patient not found");
        }
        patientRepository.updateCellPhoneByIdAndGroupId(patientId, groupId, cellPhone, updatedAt);
    }

    @Override
    public PreferredLanguage getPreferredLanguage(Long patientId, String groupId) {
        log.info("Fetching preferredLanguage for patient id {}, group Id {}", patientId, groupId);
        if (!patientRepository.existsById(patientId, groupId)) {
            patientNotFoundLog(patientId);
            throw new NotFoundException("Patient not found");
        }
        return patientRepository.findPreferredLanguage(patientId, groupId)
                .orElseGet(() -> {
                    log.warn("PreferredLanguage is null");
                    return null;
                });
    }

    @Override
    public PatientMessageResponse getPatientAndApptDetails(String groupId, Long patientId) {
        log.info("Get patient DOB and appointment details for patient {} in group {}", patientId, groupId);
        LocalDateTime currentDateTime = medGroupService.getCurrentDateTime(groupId);
        PageRequest limitOne = PageRequest.of(0, 1);

        return patientRepository.findFirstPatientUpcomingAppointment(
                        groupId, patientId, currentDateTime.toLocalDate(), limitOne)
                .stream()
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Patient not found or no upcoming appointment available"));
    }

    private String getS3Key(Long patientId, String fileName, String folderName) {
        if (folderName != null && folderName.equalsIgnoreCase("submission")) {
            return patientId + "/" + fileName;
        } else {
            return patientId + "/" + folderName + "/" + fileName;
        }
    }

    private List<DocumentResponse> listDocumentsInFolder(String bucketName, String prefix, ZoneId timezone) {
        return s3Client.listObjectsV2(request -> request.bucket(bucketName)
                        .prefix(prefix)
                        .delimiter("/"))
                .contents()
                .stream()
                .map(s3Object -> DocumentResponse.fromS3ObjectWithTimezone(s3Object, timezone))
                .toList();
    }

    private void validateMergePatients(MergePatientRequest request) {
        if (request.sourceId().equals(request.targetId())) {
            throw new BadRequestException("Source and target patient IDs are the same");
        }

        String sourceGroupId = getPatientGroupId(request.sourceId());
        String targetGroupId = getPatientGroupId(request.targetId());

        if (!sourceGroupId.equals(targetGroupId)) {
            throw new BadRequestException("Patients belong to different groups");
        }

        if (!sourceGroupId.equals(request.groupId())) {
            throw new BadRequestException("Group ID does not match patient group ID");
        }
    }

    private String getPatientGroupId(Long id) {
        return patientRepository.findGroupId(id)
                .orElseThrow(() -> {
                    patientNotFoundLog(id);
                    return new NotFoundException("Patient not found");
                });
    }

    private Patient createPatientFromRequest(SavePatientRequest request) {
        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Patient patient = Patient.fromRequest(request);
        patient.setMedGroup(medGroup);
        return patient;
    }

    private Patient createPatientFromRequest(SaveManualPatientRequest request) {
        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Patient patient = Patient.fromManualPatientRequest(request);
        patient.setMedGroup(medGroup);
        return patient;
    }

    private Map<String, Object> checkAndSavePatient(Patient patient) {
        String[] status = checkPatientExistence(patient.getMedGroup().getGroupId(), patient.getFirstName(), patient.getLastName(),
                patient.getDob(), patient.getCellPhone(), patient.getEmail());
        log.info("Patient {} status: {}", patient.getFirstName() + " " + patient.getLastName(), status[0]);

        Long patientId = "UPDATE".equals(status[0])
                ? updatePatient(Long.parseLong(status[1]), patient)
                : saveNewPatient(patient);

        return Map.of(
                "STATUS", status[0],
                "PATIENT_ID", patientId
        );
    }

    private Long saveNewPatient(Patient patient) {
        Patient savedPatient = patientRepository.save(patient);
        log.info("Patient {} saved", patient.getFirstName() + " " + patient.getLastName());

        //Todo: Track on activities.
        //Todo: Call IntegrationService to send patient data to external system
        return savedPatient.getId();
    }

    private S3Client getS3Client(String groupId) {
        return credentialsFactory.s3Client(CredentialsFactory.AccessType.GROUP, groupId);
    }

    private AWSDTO getAWSCredentials(String groupId) {
        return medGroupService.getAWSAccess(groupId);
    }

    private boolean doesObjectExists(String bucketName, String key, S3Client s3Client) {
        log.info("Checking if object exists in bucket {}", bucketName);

        try {
            s3Client.headObject(request -> request
                    .bucket(bucketName)
                    .key(key));
            log.info("Object exists in bucket {}", bucketName);
            return true;
        } catch (NoSuchKeyException e) {
            log.info("Object does not exist in bucket {}", bucketName);
            return false;
        } catch (Exception e) {
            log.error("Error checking if object exists in bucket: {}", e.getMessage(), e);
            throw new InternalServerErrorException("Error checking if object exists in bucket");
        }
    }

    private void patientNotFoundLog(Long id) {
        log.error("Patient not found with id: {}", id);
    }

    private void updatePatient(Patient patient, UpdatePatientRequest request) {
        patient.setFirstName(request.firstName());
        patient.setLastName(request.lastName());
        patient.setPreferredFirstName(request.preferredFirstName());
        patient.setDob(request.dob());
        patient.setGender(request.gender());
        patient.setCellPhone(request.cellPhone());
        patient.setHomePhone(request.homePhone());
        patient.setEmail(request.email());
        patient.setOptOut(request.optOut());
        patient.setStreetAddress(request.streetAddress());
        patient.setCity(request.city());
        patient.setZipCode(request.zipCode());
        patient.setPreferredContactMethod(request.contactMethod());
        patient.setPreferredLanguage(request.preferredLanguage());
    }

    private Long updatePatient(Long id, Patient patient) {
        String fullName = patient.getFirstName() + " " + patient.getLastName();

        log.info("Updating patient {}", fullName);
        Patient existingPatient = getPatientById(id, patient.getMedGroup().getGroupId());

        Patient updatedPatient = buildingUpdatePatient(existingPatient, patient);
        Long patientId = patientRepository.save(updatedPatient).getId();

        log.info("Patient {} updated", fullName);

        //Todo: Track on activities.
        //Todo: Call IntegrationService to send patient data to external system

        return patientId;
    }

    public String[] checkPatientExistence(String groupId, String firstName, String lastName, LocalDate dob,
                                          String cellPhone, String email) {
        log.info("Checking patient {}", firstName + " " + lastName);

        String patientStatus;
        Long patientId = null;
        String[] resultArray = new String[2];
        int patientCount;

        try {
            // Process names to handle special characters
            String fName = processName(firstName);
            String lName = processName(lastName);

            // Step 1: Validate by first name, last name, and DOB
            List<Patient> patientsByNameAndDob = patientRepository.findByGroupIdAndNameAndDob(
                    groupId, firstName, fName, lastName, lName, dob);

            patientCount = patientsByNameAndDob.size();

            boolean isContactInfoEmpty = isEmpty(cellPhone) && isEmpty(email);
            boolean hasBothContacts = !isEmpty(cellPhone) && !isEmpty(email);

            if (patientCount == 0) {
                // Step 2: No exact match found, check with cell phone and email
                if (isContactInfoEmpty) {
                    patientStatus = "CREATE";
                } else {
                    List<Patient> matchingPatients = findMatchingPatients(
                            groupId, firstName, fName, lastName, lName, cellPhone, email, hasBothContacts);

                    if (matchingPatients != null && !matchingPatients.isEmpty()) {
                        patientStatus = "UPDATE";
                        patientId = matchingPatients.getFirst().getId();
                        patientCount = matchingPatients.size();
                    } else {

                        List<Patient> existingPatientsByContact = patientRepository.findByGroupIdAndNameAndPhoneOrEmail(
                                groupId, firstName, fName, lastName, lName, cellPhone, email);

                        if (existingPatientsByContact != null && !existingPatientsByContact.isEmpty()) {
                            patientStatus = "UPDATE";
                            patientId = existingPatientsByContact.getFirst().getId();
                            patientCount = existingPatientsByContact.size();
                        } else {
                            patientStatus = "CREATE";
                        }
                    }
                }
            } else {

                // If 1 or more patients exist by name & DOB
                if (patientCount == 1) {
                    patientStatus = "UPDATE";
                    patientId = patientsByNameAndDob.getFirst().getId();
                } else {

                    // More than one match by name and DOB, check contact details
                    if (isContactInfoEmpty) {
                        patientStatus = "UPDATE";
                        patientId = patientsByNameAndDob.getFirst().getId();
                    } else {
                        List<Patient> matchingPatients = findMatchingPatientsInList(
                                groupId, cellPhone, email, patientsByNameAndDob, hasBothContacts);

                        if (matchingPatients != null && !matchingPatients.isEmpty()) {
                            patientStatus = "UPDATE";
                            patientId = matchingPatients.getFirst().getId();
                            patientCount = matchingPatients.size();
                        } else {
                            patientStatus = "UPDATE";
                            patientId = patientsByNameAndDob.getFirst().getId();
                        }
                    }
                }
            }

            log.info("Patient action status: {}, patientId: {}, patientCount: {}", patientStatus, patientId, patientCount);

            resultArray[0] = patientStatus;
            resultArray[1] = (patientId != null) ? String.valueOf(patientId) : null;

        } catch (Exception e) {
            log.error("Exception in checkPatientExistence method: {}", e.getMessage(), e);
        }
        return resultArray;
    }


    private String processName(String name) {
        if (name == null) return null;
        return name.replaceAll("[-()]", " ")
                .replaceAll("\\s+", " ")
                .replaceAll("[^a-zA-Z\\s]", "")
                .trim();
    }

    private List<Long> getPatientIds(List<Patient> patients) {
        return patients.stream()
                .map(Patient::getId)
                .collect(Collectors.toList());
    }

    private boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    private List<Patient> findMatchingPatients(String groupId, String firstName, String fName, String lastName, String lName, String cellPhone, String email, boolean hasBothContacts) {
        if (hasBothContacts) {
            return patientRepository.findByGroupIdAndNameAndPhoneOrEmail(groupId, firstName, fName, lastName, lName, cellPhone, email);
        } else if (!isEmpty(cellPhone)) {
            return patientRepository.findByGroupIdAndNameAndPhone(groupId, firstName, fName, lastName, lName, cellPhone);
        } else if (!isEmpty(email)) {
            return patientRepository.findByGroupIdAndNameAndEmail(groupId, firstName, fName, lastName, lName, email);
        }
        return null;
    }

    private List<Patient> findMatchingPatientsInList(String groupId, String cellPhone, String email, List<Patient> patientsByNameAndDob, boolean hasBothContacts) {
        List<Long> patientIds = getPatientIds(patientsByNameAndDob);

        if (hasBothContacts) {
            return patientRepository.findByGroupIdAndPhoneOrEmailInPatientIds(groupId, cellPhone, email, patientIds);
        } else if (!isEmpty(cellPhone)) {
            return patientRepository.findByGroupIdAndPhoneInPatientIds(groupId, cellPhone, patientIds);
        } else if (!isEmpty(email)) {
            return patientRepository.findByGroupIdAndEmailInPatientIds(groupId, email, patientIds);
        }
        return null;
    }

    private Patient buildingUpdatePatient(Patient existingPatient, Patient updatedPatient) {
        existingPatient.setFirstName(updatedPatient.getFirstName());
        existingPatient.setLastName(updatedPatient.getLastName());
        existingPatient.setPreferredFirstName(updatedPatient.getPreferredFirstName());
        existingPatient.setDob(updatedPatient.getDob());
        existingPatient.setGender(updatedPatient.getGender());
        existingPatient.setHomePhone(updatedPatient.getHomePhone());
        existingPatient.setCellPhone(updatedPatient.getCellPhone());
        existingPatient.setWorkPhone(updatedPatient.getWorkPhone());
        existingPatient.setEmail(updatedPatient.getEmail());
        existingPatient.setSsn(updatedPatient.getSsn());
        existingPatient.setStreetAddress(updatedPatient.getStreetAddress());
        existingPatient.setCity(updatedPatient.getCity());
        existingPatient.setState(updatedPatient.getState());
        existingPatient.setZipCode(updatedPatient.getZipCode());
        existingPatient.setPreferredLanguage(updatedPatient.getPreferredLanguage());

        return existingPatient;
    }

    private ActivityRequest buildActivity(Patient patient, String groupId, String actType, String activityDescription) {
        return ActivityRequest.builder()
                .patient(patient)
                .groupId(groupId)
                .activityType(actType)
                .activityDescription(activityDescription)
                .build();
    }

    private void updatePatientUsingAppointmentFormPatientDetails(Long patientId, String groupId, LocalDateTime currentDateTime, SaveFormAppointmentRequest.PatientDetails request) {
        log.info("Updating patient {} details from appointment form for group {}", patientId, groupId);
        try {
            PatientCellphoneAndEmailResponse patientCellPhoneEmail = patientRepository.getCellPhoneAndEmailById(patientId, groupId);

            String cellPhone = patientCellPhoneEmail.cellPhone();
            String email = patientCellPhoneEmail.email();

            if (!(cellPhone != null && cellPhone.equals(request.getCellPhone()))
                    || !(email != null && email.equals(request.getEmail()))) {
                patientRepository.updateCellPhoneAndEmailByIdAndGroupId(patientId, groupId, request.getCellPhone(), request.getEmail(), currentDateTime);

                ActivityRequest activity = buildActivity(
                        new Patient(patientId),
                        groupId,
                        "UPDATE PATIENT",
                        "Appointment form submitted for existing patient ID " + patientId
                );
                if (!(cellPhone != null && cellPhone.equals(request.getCellPhone()))
                        || !(email != null && email.equals(request.getEmail()))) {
                    activity.setActivityDescription("The patient (" + request.getFirstName() + " " + request.getLastName() + ") record got updated via appointment page due to new cellphone and email.");
                } else if (!(cellPhone.equalsIgnoreCase(request.getCellPhone()))) {
                    activity.setActivityDescription("The patient (" + request.getFirstName() + " " + request.getLastName() + ") record got updated via appointment page due to new cellphone.");
                } else if (!(email.equalsIgnoreCase(request.getEmail()))) {
                    activity.setActivityDescription("The patient (" + request.getFirstName() + " " + request.getLastName() + ") record got updated via appointment page due to new email.");
                }
                activityService.saveActivity(activity);
            }
        } catch (Exception e) {
            log.info("Error updating patient contact details from appointment form: {}", e.getMessage(), e);
        }

        ContactMethod preferredContactMethod = request.getPreferredContactMethod();
        patientRepository.updateAddressByIdAndGroupId(
                patientId,
                groupId,
                request.getStreetAddress(),
                request.getCity(),
                request.getState(),
                request.getZipCode(),
                preferredContactMethod != null ? preferredContactMethod.name() : null,
                currentDateTime
        );

        ActivityRequest activity = buildActivity(
                new Patient(patientId),
                groupId,
                "UPDATE PATIENT - ADDRESS",
                "The patient (" + request.getFirstName() + " " + request.getLastName() + ") record got updated via appointment page due to new address."
        );
        activityService.saveActivity(activity);
    }
}
