package com.rhombuzz.gpbackend.modules.appointment.dto.request;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public record SaveCanceledAppointmentRequest(

        @NotNull(message = "Medical group cannot be null")
        MedGroup medGroup,

        @NotNull(message = "Patient cannot be null")
        Patient patient,

        @NotNull(message = "Provider cannot be null")
        Provider provider,

        Location location,

        @NotNull(message = "Scheduled date and time cannot be null")
        LocalDateTime scheduledDateTime,

        @NotBlank(message = "Cancellation reason cannot be blank")
        String canceledBy,

        @NotBlank(message = "Location name cannot be blank")
        String locationName
) {
}
