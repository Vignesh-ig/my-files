package com.rhombuzz.gpbackend.modules.provider.controller;

import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveUnavailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.UnavailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.service.UnavailabilityService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/unavailabilities")
@PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
public class UnavailabilityController {
    private final UnavailabilityService unavailabilityService;

    @GetMapping("/providers/{providerId}")
    public ResponseEntity<List<UnavailabilityResponse>> getUnavailabilities(
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<UnavailabilityResponse> unavailabilities = unavailabilityService.getUnavailabilities(providerId, groupId);
        return ResponseEntity.ok(unavailabilities);
    }

    @PostMapping
    public ResponseEntity<Void> saveUnavailability(@RequestBody @Valid SaveUnavailabilityRequest request) {
        unavailabilityService.saveUnavailability(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{id}/providers/{providerId}")
    public ResponseEntity<Void> deleteUnavailability(
            @PathVariable @NotNull Long id,
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        unavailabilityService.deleteUnavailability(id, providerId, groupId);
        return ResponseEntity.noContent().build();
    }
}
