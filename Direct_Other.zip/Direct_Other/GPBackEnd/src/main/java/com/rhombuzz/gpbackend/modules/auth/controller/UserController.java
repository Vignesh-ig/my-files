package com.rhombuzz.gpbackend.modules.auth.controller;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.auth.dto.request.SaveUserRequest;
import com.rhombuzz.gpbackend.modules.auth.dto.response.UserExistsResponse;
import com.rhombuzz.gpbackend.modules.auth.dto.response.UserResponse;
import com.rhombuzz.gpbackend.modules.auth.service.UserService;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.util.AccessType;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/users")
@Validated
@PreAuthorize("hasAnyRole(" + AccessType.ADMIN_AND_SUPER + ")")
public class UserController {
    private final UserService userService;
    private final MedGroupService medGroupService;

    @GetMapping
    public ResponseEntity<List<UserResponse>> getUsersInGroup(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId) {
        return ResponseEntity.ok(userService.getUsers(groupId));
    }

    @PostMapping
    public ResponseEntity<Void> saveUser(@RequestBody @Valid SaveUserRequest request) {

        if (!medGroupService.isMedGroupExists(request.getGroupId())) {
            throw new NotFoundException("Medical Group not found with ID: " + request.getGroupId());
        }

        userService.saveUser(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/{userId}")
    public ResponseEntity<UserResponse> getUser(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @PathVariable @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId) {
        return ResponseEntity.ok(userService.getUser(userId, groupId));
    }

    @PatchMapping("/{userId}/email")
    public ResponseEntity<Void> updateEmail(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @PathVariable @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @RequestParam @NotBlank @Email String email) {
        userService.updateEmail(userId, groupId, email);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{userId}/role")
    public ResponseEntity<Void> updateRole(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @PathVariable @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @RequestParam @NotBlank @Pattern(regexp = RegexPattern.ROLE_ID) String oldRoleId,
            @RequestParam @NotBlank @Pattern(regexp = RegexPattern.ROLE_ID) String newRoleId) {
        userService.updateRole(userId, groupId, oldRoleId, newRoleId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteUser(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @PathVariable @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId) {
        userService.deleteUser(userId, groupId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/check-existence")
    public ResponseEntity<UserExistsResponse> isUserExists(
            @RequestParam @NotBlank @Size(min = 7, max = 15) String username,
            @RequestParam @NotBlank @Email String email) {
        UserExistsResponse userExistsResponse = userService.isUserExists(username, email);
        return ResponseEntity.ok(userExistsResponse);
    }

    @GetMapping("/roles/group")
    public ResponseEntity<List<UserResponse.Role>> getGroupRoles() {
        return ResponseEntity.ok(userService.getGroupRoles());
    }

    @GetMapping("/roles/management")
    @PreAuthorize("hasRole(" + AccessType.MANAGEMENT + ")")
    public ResponseEntity<UserResponse.Role> getManagementRole() {
        return ResponseEntity.ok(userService.getManagementRole());
    }

    @PatchMapping("/{userId}/password")
    @PreAuthorize("hasAnyRole(" + AccessType.ADMIN_AND_SUPER + ")")
    public ResponseEntity<Void> changePassword(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @PathVariable @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @RequestParam @Pattern(regexp = RegexPattern.PASSWORD) String oldPassword,
            @RequestParam @Pattern(regexp = RegexPattern.PASSWORD) String newPassword) {
        userService.changePassword(userId, groupId, oldPassword, newPassword);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/names")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<List<String>> getUserNames(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId) {
        return ResponseEntity.ok(userService.getUserNames(groupId));
    }

    @PatchMapping("/{userId}/block")
    public ResponseEntity<Void> blockUser(
            @PathVariable @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        userService.blockUnblockUser(userId, groupId, true);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{userId}/unblock")
    public ResponseEntity<Void> unblockUser(
            @PathVariable @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        userService.blockUnblockUser(userId, groupId, false);
        return ResponseEntity.noContent().build();
    }
}