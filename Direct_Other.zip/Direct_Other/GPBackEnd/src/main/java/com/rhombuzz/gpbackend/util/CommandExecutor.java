package com.rhombuzz.gpbackend.util;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

@Slf4j
public class CommandExecutor {

    private static final boolean IS_WINDOWS = System.getProperty("os.name").toLowerCase().contains("win");

    public record CommandResult(int exitCode, String output, String error) {

        public boolean isSuccess() {
            return exitCode == 0;
        }
    }

    public static CommandResult execute(String command, Path workingDirectory) throws IOException, InterruptedException {
        return execute(command, workingDirectory, 30, TimeUnit.SECONDS);
    }

    public static CommandResult execute(String command, Path workingDirectory, long timeout, TimeUnit timeUnit)
            throws IOException, InterruptedException {

        ProcessBuilder processBuilder = createProcessBuilder(command);

        if (workingDirectory != null) {
            processBuilder.directory(workingDirectory.toFile());
        }

        // Redirect error stream to output stream for simpler handling
        processBuilder.redirectErrorStream(true);

        log.debug("Executing command: {} in directory: {}", command, workingDirectory);

        Process process = processBuilder.start();

        // Read combined output and error streams
        StringBuilder output = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append(System.lineSeparator());
                log.debug("Command output: {}", line);
            }
        }

        boolean finished = process.waitFor(timeout, timeUnit);

        if (!finished) {
            process.destroyForcibly();
            throw new InterruptedException("Command execution timed out after " + timeout + " " + timeUnit);
        }

        int exitCode = process.exitValue();

        return new CommandResult(exitCode, output.toString().trim(), "");
    }

    private static ProcessBuilder createProcessBuilder(String command) {
        if (IS_WINDOWS) {
            return new ProcessBuilder("cmd", "/c", command);
        } else {
            return new ProcessBuilder("sh", "-c", command);
        }
    }
}