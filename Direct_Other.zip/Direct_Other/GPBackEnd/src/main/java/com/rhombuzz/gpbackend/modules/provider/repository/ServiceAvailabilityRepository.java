package com.rhombuzz.gpbackend.modules.provider.repository;

import com.rhombuzz.gpbackend.modules.provider.dto.response.ServiceAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.ServiceAvailability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ServiceAvailabilityRepository extends JpaRepository<ServiceAvailability, Long> {

    @Query(value = """
            SELECT sa.id AS id,
                   sa.start_time AS startTime,
                   sa.end_time AS endTime,
                   sa.day AS day,
                   p.id AS providerId,
                   p.name AS providerName,
                   l.id AS locationId,
                   l.name AS locationName,
                   GROUP_CONCAT(s.id) AS serviceIds
            FROM service_availabilities sa
            JOIN providers p ON sa.provider_id = p.id
            JOIN locations l ON sa.location_id = l.id
            LEFT JOIN service_availability_services sas ON sa.id = sas.service_availability_id
            LEFT JOIN services s ON sas.service_id = s.id
            WHERE sa.provider_id = ?1 AND sa.med_group_id = ?2
            GROUP BY sa.id, sa.start_time, sa.end_time, sa.day, p.id, p.name, l.id, l.name
    """, nativeQuery = true)
    List<ServiceAvailabilityResponse> findByProviderId(Long providerId, String groupId);

    @Query("SELECT sa FROM ServiceAvailability sa WHERE sa.id = ?1 AND sa.provider.id = ?2 AND sa.location.id = ?3 AND sa.medGroup.groupId = ?4")
    Optional<ServiceAvailability> findById(Long id, Long providerId, Long locationId, String groupId);

    @Modifying
    @Query("DELETE FROM ServiceAvailability sa WHERE sa.id = ?1 AND sa.provider.id = ?2 AND sa.location.id = ?3 AND sa.medGroup.groupId = ?4")
    void deleteById(Long id, Long providerId, Long locationId, String groupId);

    @Query("SELECT sa FROM ServiceAvailability sa WHERE sa.id = ?1 AND sa.provider.id = ?2 AND sa.medGroup.groupId = ?3")
    Optional<ServiceAvailability> findById(Long id, Long providerId, String groupId);
}
