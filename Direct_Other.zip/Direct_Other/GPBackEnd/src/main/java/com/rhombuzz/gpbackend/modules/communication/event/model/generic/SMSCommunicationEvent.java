package com.rhombuzz.gpbackend.modules.communication.event.model.generic;

import lombok.Getter;

@Getter
public class SMSCommunicationEvent extends CommunicationEvent {
    private final String fromNumber;
    private final String toNumber;
    private final String content;
    private final String sender;

    public SMSCommunicationEvent(String groupId, Long patientId, String fromNumber, String toNumber, String content, String sender) {
        super(groupId, patientId);
        this.fromNumber = fromNumber;
        this.toNumber = toNumber;
        this.content = content;
        this.sender = sender;
    }
}
