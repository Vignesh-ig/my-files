package com.rhombuzz.gpbackend.modules.provider.dto.response;

import com.rhombuzz.gpbackend.modules.provider.entity.Provider;

public record BookingTypeResponse(
        Provider.BookingType bookingType,
        int bookingPerSlot,
        int bookingPerDay
) {
}
