package com.rhombuzz.gpbackend.modules.communication.dto;

import com.rhombuzz.gpbackend.modules.communication.entity.SMS;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.MessageStatus;

import java.time.LocalDateTime;

public record SMSMessageDTO(
        Long id,
        String message,
        String sender,
        SMS.SMSType smsType,
        MessageStatus messageStatus,
        String messageUUID,
        LocalDateTime dateTime
) {
}
