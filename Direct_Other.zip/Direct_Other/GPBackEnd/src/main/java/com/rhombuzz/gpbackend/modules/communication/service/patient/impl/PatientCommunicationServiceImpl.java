package com.rhombuzz.gpbackend.modules.communication.service.patient.impl;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MultilingualEmailTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MultilingualSMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.event.model.EventType;
import com.rhombuzz.gpbackend.modules.communication.event.model.generic.EmailCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.generic.SMSCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionEmailEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionSMSEvent;
import com.rhombuzz.gpbackend.modules.communication.event.publisher.CommunicationEventPublisher;
import com.rhombuzz.gpbackend.modules.communication.event.publisher.RequestSubmissionsEventPublisher;
import com.rhombuzz.gpbackend.modules.communication.service.EmailTemplateService;
import com.rhombuzz.gpbackend.modules.communication.service.SMSTemplateService;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationService;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationValidator;
import com.rhombuzz.gpbackend.modules.communication.service.patient.TemplateProcessor;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.BiFunction;
import java.util.function.Consumer;

@Slf4j
@Service
@RequiredArgsConstructor
public class PatientCommunicationServiceImpl implements PatientCommunicationService {

    private final SMSTemplateService smsTemplateService;
    private final PatientCommunicationValidator validator;
    private final TemplateProcessor templateProcessor;
    private final EmailTemplateService emailTemplateService;

    private final CommunicationEventPublisher communicationEventPublisher;
    private final RequestSubmissionsEventPublisher requestSubmissionsEventPublisher;

    private final Executor asyncExecutor;

    @Override
    public void validateAndSendEmail(String groupId, Set<Long> patientIds, Appointment appointment, String templateId, EventType eventType) {
        if (eventType == EventType.ASYNC) {
            CompletableFuture.runAsync(() -> processEmailCommunication(
                    groupId,
                    patientIds,
                    templateId,
                    appointment,
                    this::createEmailEvent,
                    communicationEventPublisher::publishEmailEvent,
                    "Email"
            ), asyncExecutor).exceptionally(ex -> {
                log.error("Error processing email communication asynchronously for groupId: {}, templateId: {}, patientIds: {}. Error: {}",
                        groupId, templateId, patientIds, ex.getMessage());
                return null;
            });

        } else {
            processEmailCommunication(
                    groupId,
                    patientIds,
                    templateId,
                    appointment,
                    this::createEmailEvent,
                    communicationEventPublisher::publishEmailEvent,
                    "Email"
            );
        }
    }

    @Override
    public void validateAndSendSMS(String groupId, Set<Long> patientIds, Appointment appointment, String templateId, EventType eventType) {
        if (eventType == EventType.ASYNC) {
            CompletableFuture.runAsync(() -> processSMSCommunication(
                    groupId,
                    patientIds,
                    templateId,
                    appointment,
                    (patient, processedContent) -> createSmsEvent(patient, processedContent, "SYSTEM"),
                    communicationEventPublisher::publishSMSEvent,
                    "SMS"
            ), asyncExecutor).exceptionally(ex -> {
                log.error("Error processing SMS communication asynchronously for groupId: {}, templateId: {}, patientIds: {}. Error: {}",
                        groupId, templateId, patientIds, ex.getMessage());
                return null;
            });

        } else {
            processSMSCommunication(
                    groupId,
                    patientIds,
                    templateId,
                    appointment,
                    (patient, processedContent) -> createSmsEvent(patient, processedContent, "SYSTEM"),
                    communicationEventPublisher::publishSMSEvent,
                    "SMS"
            );
        }
    }

    @Override
    public void validateAndRequestSubmissionViaEmail(String groupId, Set<@NotNull @Positive Long> patientIds, String templateId) {
        processEmailCommunication(
                groupId,
                patientIds,
                templateId,
                null,
                this::createRequestSubmissionEmailEvent,
                requestSubmissionsEventPublisher::publishRequestSubmissionEvent,
                "Request Submission Email"
        );
    }

    @Override
    public void validateAndRequestSubmissionViaSMS(String groupId, Set<@NotNull @Positive Long> patientIds, String templateId) {
        processSMSCommunication(
                groupId,
                patientIds,
                templateId,
                null,
                this::createRequestSubmissionSmsEvent,
                requestSubmissionsEventPublisher::publishRequestSubmissionEvents,
                "Request Submission SMS"
        );
    }

    @Override
    public void validateAndSendDirectSMS(String groupId, Long patientId, Appointment appointment, String content, @NotBlank String sender, EventType eventType) {
        if (eventType == EventType.ASYNC) {
            CompletableFuture.runAsync(() -> processPrivateSMSCommunication(
                    groupId,
                    patientId,
                    content,
                    appointment,
                    (patient, processedContent) -> createSmsEvent(patient, processedContent, sender),
                    communicationEventPublisher::publishSMSEvent
            ), asyncExecutor).exceptionally(ex -> {
                log.error("Error processing direct SMS communication asynchronously for groupId: {}, patientId: {}. Error: {}",
                        groupId, patientId, ex.getMessage());
                return null;
            });

        } else {
            processPrivateSMSCommunication(
                    groupId,
                    patientId,
                    content,
                    appointment,
                    (patient, processedContent) -> createSmsEvent(patient, processedContent, Utils.getCurrentUsername()),
                    communicationEventPublisher::publishSMSEvent
            );
        }
    }

    @Override
    public void validateAndSendDirectEmail(String groupId, Long patientId, Appointment appointment, String subject, String content, EventType eventType) {
        if (eventType == EventType.ASYNC) {
            CompletableFuture.runAsync(() -> processPrivateEmailCommunication(
                    groupId,
                    patientId,
                    content,
                    subject,
                    appointment,
                    this::createEmailEvent,
                    communicationEventPublisher::publishEmailEvent
            ), asyncExecutor).exceptionally(ex -> {
                log.error("Error processing direct Email communication asynchronously for groupId: {}, patientId: {}. Error: {}",
                        groupId, patientId, ex.getMessage());
                return null;
            });
        } else {
            processPrivateEmailCommunication(
                    groupId,
                    patientId,
                    content,
                    subject,
                    appointment,
                    this::createEmailEvent,
                    communicationEventPublisher::publishEmailEvent
            );
        }
    }

    private <E> void processPrivateEmailCommunication(
            String groupId,
            Long patientId,
            String content,
            String subject,
            Appointment appointment,
            TriFunction<Patient, String, String, E> eventCreator,
            Consumer<List<E>> eventPublisher
    ) {
        if (!validator.isDirectCommunicationAllowed(groupId, ContactMethod.EMAIL)) {
            return;
        }

        Patient patient = validator.getValidPatientForCommunication(
                groupId, patientId, ContactMethod.EMAIL);
        if (patient != null) {
            String processedContent = templateProcessor.processTemplate(patient, appointment, content);
            E event = eventCreator.apply(patient, subject, processedContent);
            eventPublisher.accept(List.of(event));
        }
    }

    private <E> void processPrivateSMSCommunication(
            String groupId,
            Long patientId,
            String content,
            Appointment appointment,
            BiFunction<Patient, String, E> eventCreator,
            Consumer<List<E>> eventPublisher
    ) {
        if (!validator.isDirectCommunicationAllowed(groupId, ContactMethod.SMS)) {
            return;
        }

        Patient patient = validator.getValidPatientForCommunication(
                groupId, patientId, ContactMethod.SMS);
        if (patient != null) {
            String processedContent = templateProcessor.processTemplate(patient, appointment, content);
            E event = eventCreator.apply(patient, processedContent);
            eventPublisher.accept(List.of(event));
        }
    }

    private <E> void processEmailCommunication(
            String groupId,
            Set<Long> patientIds,
            String templateId,
            Appointment appointment,
            TriFunction<Patient, String, String, E> eventCreator,
            Consumer<List<E>> eventPublisher,
            String communicationType) {

        log.info("Validating and sending {} for groupId: {}, templateId: {}, patientIds: {}",
                communicationType, groupId, templateId, patientIds);

        if (!validator.isCommunicationAllowed(groupId, templateId, ContactMethod.EMAIL)) {
            log.info("{} communication not allowed for groupId: {}, templateId: {}",
                    communicationType, groupId, templateId);
            return;
        }

        MultilingualEmailTemplateResponse template = emailTemplateService.getEmailTemplate(templateId, groupId);

        List<E> events = patientIds.parallelStream()
                .map(patientId -> validator.getValidPatientForCommunication(
                        groupId, patientId, ContactMethod.EMAIL))
                .filter(Objects::nonNull)
                .map(patient -> {
                    String content = validator.getLocalizedContent(patient, template::getContent);
                    String processedContent = templateProcessor.processTemplate(patient, appointment, content);
                    return eventCreator.apply(patient, template.getSubject(), processedContent);
                })
                .toList();

        if (!events.isEmpty()) {
            log.info("Publishing {} events for groupId: {}, templateId: {}, patientIds: {}",
                    communicationType, groupId, templateId, patientIds);
            eventPublisher.accept(events);
        }
    }

    private <E> void processSMSCommunication(
            String groupId,
            Set<Long> patientIds,
            String templateId,
            Appointment appointment,
            BiFunction<Patient, String, E> eventCreator,
            Consumer<List<E>> eventPublisher,
            String communicationType) {

        logCommunication("Validating and sending", communicationType, groupId, templateId, patientIds);

        if (!validator.isCommunicationAllowed(groupId, templateId, ContactMethod.SMS)) {
            logCommunication("Communication not allowed", communicationType, groupId, templateId, patientIds);
            return;
        }

        MultilingualSMSTemplateResponse template = smsTemplateService.getSMSTemplate(templateId, groupId);

        List<E> events = patientIds.parallelStream()
                .map(patientId -> validator.getValidPatientForCommunication(
                        groupId, patientId, ContactMethod.SMS))
                .filter(Objects::nonNull)
                .map(patient -> {
                    String content = validator.getLocalizedContent(patient, template::getContent);
                    String processedContent = templateProcessor.processTemplate(patient, appointment, content);
                    return eventCreator.apply(patient, processedContent);
                })
                .toList();

        if (!events.isEmpty()) {
            logCommunication("Publishing events", communicationType, groupId, templateId, patientIds);
            eventPublisher.accept(events);
        }
    }

    private void logCommunication(String action, String communicationType, String groupId, String templateId, Set<Long> patientIds) {
        log.info("{} {} for groupId: {}, templateId: {}, patientIds: {}",
                action, communicationType, groupId, templateId, patientIds);
    }

    private EmailCommunicationEvent createEmailEvent(Patient patient, String subject, String processedContent) {
        MedGroup medGroup = patient.getMedGroup();
        return new EmailCommunicationEvent(
                medGroup.getGroupId(),
                patient.getId(),
                medGroup.getEmail(),
                patient.getEmail(),
                subject,
                processedContent
        );
    }

    private SMSCommunicationEvent createSmsEvent(Patient patient, String processedContent, String sender) {
        MedGroup medGroup = patient.getMedGroup();
        return new SMSCommunicationEvent(
                medGroup.getGroupId(),
                patient.getId(),
                medGroup.getEmsPhone(),
                patient.getCellPhone(),
                processedContent,
                sender
        );
    }

    private RequestSubmissionEmailEvent createRequestSubmissionEmailEvent(Patient patient, String subject, String processedContent) {
        return new RequestSubmissionEmailEvent(
                patient.getMedGroup().getGroupId(),
                patient.getId(),
                patient.getMedGroup().getEmail(),
                patient.getEmail(),
                subject,
                processedContent
        );
    }

    private RequestSubmissionSMSEvent createRequestSubmissionSmsEvent(Patient patient, String processedContent) {
        return new RequestSubmissionSMSEvent(
                patient.getMedGroup().getGroupId(),
                patient.getId(),
                patient.getMedGroup().getEmsPhone(),
                patient.getCellPhone(),
                processedContent
        );
    }

    @FunctionalInterface
    interface TriFunction<T, U, V, R> {
        R apply(T t, U u, V v);
    }
}