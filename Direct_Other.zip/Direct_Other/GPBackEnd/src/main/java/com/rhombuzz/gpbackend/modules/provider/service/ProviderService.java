package com.rhombuzz.gpbackend.modules.provider.service;

import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveBookingTypeRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveProviderRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.UpdateProviderRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.BookingTypeResponse;
import com.rhombuzz.gpbackend.modules.provider.dto.response.ProviderResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@Validated
public interface ProviderService {

    void saveProvider(
            @Valid SaveProviderRequest request,
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png"},
                    required = false
            ) MultipartFile image
    );

    void updateProvider(
            @NotNull @Positive Long id,
            @Valid UpdateProviderRequest request,
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png"},
                    required = false
            ) MultipartFile image
    );

    @Transactional
    void deleteProvider(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Page<ProviderResponse> getProviders(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    );

    Provider getProviderById(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Map<String, Object> getProviderImage(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<ProviderDTO> getProviderNames(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateDefaultApptDuration(
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Min(5) Integer defaultApptDuration
    );

    Integer getDefaultApptDuration(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long providerId
    );

    boolean isProviderExists(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    BookingTypeResponse getBookingTypeDetails(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateBookingTypeDetails(
            @NotNull @Positive Long id,
            @Valid SaveBookingTypeRequest request
    );
}
