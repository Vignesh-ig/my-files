package com.rhombuzz.gpbackend.modules.provider.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.provider.entity.id.ProviderOfferingId;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "provider_services", indexes = {
        @Index(name = "idx_provider_service_provider_id", columnList = "provider_id"),
        @Index(name = "idx_provider_service_service_id", columnList = "service_id")
})
public class ProviderOffering {

    @EmbeddedId
    private ProviderOfferingId id;

    @Column(name = "visible_to_patient")
    private Boolean visibleToPatient;

    @Column(name = "visit_type")
    @Enumerated(EnumType.STRING)
    private Service.VisitType visitType;

    @Column(name = "disabled")
    private boolean disabled;

    @Column(name = "created_at", nullable = false, updatable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime createdAt;

    @Column(name = "updated_at", columnDefinition = "DATETIME(0)")
    private LocalDateTime updatedAt;

    @PrePersist
    private void beforePersist() {
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    private void beforeUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
