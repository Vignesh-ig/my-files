package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.appointment.service.AppointmentService;
import com.rhombuzz.gpbackend.modules.communication.dto.request.EmailRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.EmailSendRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.Email;
import com.rhombuzz.gpbackend.modules.communication.event.model.EventType;
import com.rhombuzz.gpbackend.modules.communication.repository.EmailRepository;
import com.rhombuzz.gpbackend.modules.communication.service.EmailService;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailServiceImpl implements EmailService {
    private final JavaMailSender mailSender;
    private final PatientService patientService;
    private final EmailRepository emailRepository;
    private final PatientCommunicationService patientCommunicationService;
    private final AppointmentService appointmentService;

    @Override
    public EmailResponse sendEmail(EmailSendRequest request) {
        log.info("Preparing to send email");

        try {
            MimeMessage message = mailSender.createMimeMessage();
            setupMessage(request, message);

            log.info("Sending email");
            mailSender.send(message);
            log.info("Email sent successfully");

            saveEmail(request.groupId(), request.patientId(), request.body(), true);
            return EmailResponse.builder()
                    .success(true)
                    .message("Email sent successfully")
                    .build();

        } catch (Exception e) {
            log.error("Error sending email", e);
            saveEmail(request.groupId(), request.patientId(), request.body(), false);
            return EmailResponse.builder()
                    .success(false)
                    .message("Error sending email")
                    .build();
        }
    }

    @Override
    public void sendDirectEmail(EmailRequest request) {
        log.info("Send direct Email to patient with ID: {}", request.patientId());
        Appointment appointment = appointmentService.getLatestPatientAppointment(request.patientId(), request.groupId());
        patientCommunicationService.validateAndSendDirectEmail(request.groupId(), request.patientId(), appointment,
                request.subject(), request.content(), EventType.SYNC);
    }

    private void saveEmail(String groupId, Long patientId, String content, boolean sentStatus) {
        log.info("Saving email for patientId: {} in group {}", patientId, groupId);
        Patient patient = patientService.getPatientById(patientId, groupId);

        Email email = new Email();
        email.setPatient(patient);
        email.setMedGroup(patient.getMedGroup());
        email.setMessage(content);
        email.setDateTime(patient.getMedGroup().getCurrentDateTime());
        email.setMessageStatus(sentStatus ? Email.EmailStatus.SENT : Email.EmailStatus.UNSENT);

        emailRepository.save(email);
        log.info("Email saved successfully for patientId: {} in group {}", patientId, groupId);
    }

    private void setupMessage(EmailSendRequest request, MimeMessage message) throws MessagingException {
        MimeMessageHelper helper = new MimeMessageHelper(message);

        helper.setTo(request.toEmail());
        helper.setFrom(request.fromEmail());
        helper.setSubject(request.subject());
        helper.setText(request.body(), true);
    }
}
