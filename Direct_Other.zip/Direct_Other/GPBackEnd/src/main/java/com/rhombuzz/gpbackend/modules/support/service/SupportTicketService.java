package com.rhombuzz.gpbackend.modules.support.service;

import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import com.rhombuzz.gpbackend.modules.support.dto.request.SupportRequest;
import com.rhombuzz.gpbackend.modules.support.dto.request.TicketRequest;
import com.rhombuzz.gpbackend.modules.support.dto.response.SupportResponse;
import com.rhombuzz.gpbackend.modules.support.dto.response.TicketResponse;
import com.rhombuzz.gpbackend.modules.support.entity.Ticket;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@Validated
public interface SupportTicketService {

    void saveSupport(
            @Valid SupportRequest request,
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png", "gif"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png", "image/gif"},
                    required = false
            ) MultipartFile image
    );

    void saveUserTicket(
            @Valid TicketRequest request,
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png", "gif"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png", "image/gif"},
                    required = false
            ) MultipartFile image
    );

    void saveAdminTicket(
            @Valid TicketRequest request,
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png", "gif"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png", "image/gif"},
                    required = false
            ) MultipartFile image
    );

    void updateTicketStatus(
            @NotNull @Positive Long ticketId,
            @NotNull @Positive Long supportId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull Ticket.Status status
    );

    Page<SupportResponse> getSupports(
            Pageable pageable
    );

    List<TicketResponse> getSupportTickets(
            @NotNull @Positive Long supportId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Map<String, Object> getTicketImage(
            @NotNull @Positive Long ticketId,
            @NotNull @Positive Long supportId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
