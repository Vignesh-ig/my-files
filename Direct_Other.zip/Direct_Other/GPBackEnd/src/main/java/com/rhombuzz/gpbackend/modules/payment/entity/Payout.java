package com.rhombuzz.gpbackend.modules.payment.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "payouts", indexes = {
        @Index(name = "idx_payout_med_group_id", columnList = "med_group_id")
})
public class Payout {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "payout_id", length = 90, nullable = false)
    private String payoutId;

    @Column(name = "amount", precision = 16, scale = 2, nullable = false)
    private BigDecimal amount;

    @Column(name = "payout_date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime payoutDateTime;

    @Column(name = "payout_status", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private Status payoutStatus;

    @Column(name = "reconciled_by", length = 45, nullable = false)
    private String reconciledBy;

    @Column(name = "num_of_payments")
    private Integer numOfPayments;

    @Column(name = "expected_date", nullable = false)
    private LocalDate expectedDate;

    public enum Status {

        IN_TRANSIT,
        PAID
    }

}
