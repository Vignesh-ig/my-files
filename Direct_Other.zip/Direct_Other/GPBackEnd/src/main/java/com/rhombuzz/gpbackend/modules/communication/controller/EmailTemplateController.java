package com.rhombuzz.gpbackend.modules.communication.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.UpdateEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateAttributesResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import com.rhombuzz.gpbackend.modules.communication.service.EmailTemplateService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/email-templates")
@Validated
@PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
public class EmailTemplateController {
    private final EmailTemplateService emailTemplateService;

    @PostMapping
    public ResponseEntity<Void> saveEmailTemplate(
            @RequestBody @Valid SaveEmailTemplateRequest request
    ) {
        emailTemplateService.saveEmailTemplate(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<Map<EmailTemplate.TemplateGroup, List<EmailTemplateIdResponse>>> getEmailTemplates(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Map<EmailTemplate.TemplateGroup, List<EmailTemplateIdResponse>> templates = emailTemplateService.getEmailTemplatesNameWithGroup(groupId);
        return ResponseEntity.ok(templates);
    }

    @GetMapping("/{templateId}")
    public ResponseEntity<EmailTemplateResponse> getEmailTemplate(
            @PathVariable @NotBlank String templateId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotNull PreferredLanguage language
            ) {
        EmailTemplateResponse template = emailTemplateService.getEmailTemplate(templateId, groupId, language);
        return ResponseEntity.ok(template);
    }

    @PutMapping("/{templateId}")
    public ResponseEntity<Void> updateEmailTemplate(
            @PathVariable @NotBlank String templateId,
            @RequestBody @Valid UpdateEmailTemplateRequest request
    ) throws JsonProcessingException {
        emailTemplateService.updateEmailTemplate(templateId, request);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/attributes")
    public ResponseEntity<EmailTemplateAttributesResponse> getEmailTemplateAttributes(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        EmailTemplateAttributesResponse attributes = emailTemplateService.getEmailTemplateAttributes(groupId);
        return ResponseEntity.ok(attributes);
    }

    @GetMapping("/external")
    public ResponseEntity<List<EmailTemplateIdResponse>> getExternalSMSTemplates(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<EmailTemplateIdResponse> templates = emailTemplateService.getEmailTemplates(groupId, TemplateType.EXTERNAL);
        return ResponseEntity.ok(templates);
    }

    @GetMapping("/{templateId}/patients/{patientId}")
    public ResponseEntity<EmailTemplateResponse> getEmailTemplateForPatient(
            @PathVariable @NotBlank String templateId,
            @PathVariable @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        EmailTemplateResponse template = emailTemplateService.getEmailTemplateByPatientId(templateId, patientId, groupId);
        return ResponseEntity.ok(template);
    }
}