package com.rhombuzz.gpbackend.modules.provider.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "service_availabilities", indexes = {
        @Index(name = "idx_service_availability_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_service_availability_provider_id", columnList = "provider_id"),
        @Index(name = "idx_service_availability_location_id", columnList = "location_id")
})
public class ServiceAvailability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "provider_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Provider provider;

    @ManyToOne
    @JoinColumn(name = "location_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Location location;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "service_availability_services",
        joinColumns = @JoinColumn(name = "service_availability_id", referencedColumnName = "id"),
        inverseJoinColumns = @JoinColumn(name = "service_id", referencedColumnName = "id")
    )
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Set<Service> services;

    @Column(name = "start_time", nullable = false, columnDefinition = "TIME(0)")
    private LocalTime startTime;

    @Column(name = "end_time", nullable = false, columnDefinition = "TIME(0)")
    private LocalTime endTime;

    @Column(name = "day", length = 45, nullable = false)
    @Enumerated(EnumType.STRING)
    private DayOfWeek day;

}
