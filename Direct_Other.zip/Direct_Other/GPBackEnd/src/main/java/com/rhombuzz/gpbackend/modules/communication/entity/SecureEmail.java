package com.rhombuzz.gpbackend.modules.communication.entity;


import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "secure_emails", indexes = {
        @Index(name = "idx_secure_email_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_secure_email_patient_id", columnList = "patient_id")
})
public class SecureEmail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @Column(name = "email_date_time", columnDefinition = "DATETIME(0)")
    private LocalDateTime emailDateTime;

    @Column(name = "email_subject", length = 100, nullable = false)
    private String emailSubject;

    @Lob
    @Column(name = "email_message", nullable = false, columnDefinition = "TEXT")
    private String emailMessage;

    @Column(name = "sent_by", length = 45, nullable = false)
    private String sentBy;

    @Column(name = "is_read")
    private boolean isRead;

    @Column(name = "has_attachment")
    private boolean hasAttachment;

}
