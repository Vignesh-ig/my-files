package com.rhombuzz.gpbackend.enums;

public enum PreferredLanguage {

    ENGLISH,
    SPANISH

}
