package com.rhombuzz.gpbackend.modules.auth.repository;

import com.rhombuzz.gpbackend.modules.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, String> {

    void deleteByGroupId(String groupId);
}
