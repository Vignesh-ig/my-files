package com.rhombuzz.gpbackend.component;

import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.util.CommandExecutor;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.nio.file.Files;
import java.nio.file.Path;

@Slf4j
@Component
public class PdfGenerator {

    @Value("${puppeteer.server.path}")
    private String puppeteerServerPath;

    @Value("${puppeteer.server.port}")
    private int puppeteerServerPort;

    @Value("${puppeteer.enabled}")
    private boolean puppeteerEnabled;

    @PostConstruct
    public void initializeNodeServer() {
        if (!puppeteerEnabled) {
            log.warn("puppeteer server initialization is disabled by configuration");
            return;
        }

        Path projectPath = Path.of(puppeteerServerPath);
        Path nodeModulesPath = projectPath.resolve("node_modules");

        if (!Files.exists(nodeModulesPath)) {
            log.info("Installing Node.js dependencies for Puppeteer server...");
            executeCommand("npm install", projectPath);
            log.info("Node.js dependencies installed successfully");
        }

        log.info("Starting Puppeteer server...");
        executeCommand("pm2 start ecosystem.config.js", projectPath);
        log.info("Puppeteer server started successfully");
    }

    public byte[] generatePdf(String html) {
        if (!puppeteerEnabled) {
            log.error("puppeteer server initialization is disabled by configuration");
            throw new InternalServerErrorException("Puppeteer server initialization is disabled");
        }

        try {
            byte[] pdfBytes = RestClient.create("http://localhost:" + puppeteerServerPort)
                    .post()
                    .uri("/generate-pdf")
                    .contentType(MediaType.TEXT_HTML)
                    .body(html)
                    .retrieve()
                    .body(byte[].class);

            log.info("PDF generated successfully");
            return pdfBytes;

        } catch (Exception e) {
            log.error("Failed to generate PDF", e);
            throw new InternalServerErrorException("Failed to generate PDF");
        }
    }

    @PreDestroy
    public void shutdown() {
        if (!puppeteerEnabled) {
            return;
        }

        log.info("Shutting down puppeteer server...");
        executeCommand("pm2 delete puppeteer-server", null);
        log.info("Puppeteer server stopped successfully");
    }

    private void executeCommand(String command, Path workingDirectory) {
        try {
            CommandExecutor.CommandResult result = CommandExecutor.execute(command, workingDirectory);

            if (!result.isSuccess()) {
                log.error("Command failed with exit code {}: {}", result.exitCode(), result.error());
                throw new InternalServerErrorException("Command execution failed: " + command);
            }

            if (!result.output().isEmpty()) {
                log.debug("Command output: {}", result.output());
            }

        } catch (Exception e) {
            log.error("Failed to execute command: {}", command, e);
            throw new InternalServerErrorException("Failed to execute command: " + command);
        }
    }
}