package com.rhombuzz.gpbackend.modules.appointment.dto.request;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Builder
@Data
public class SaveFormAppointmentRequest {
    @NotBlank(message = "Group ID cannot be blank")
    @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters")
    private String groupId;

    @NotNull(message = "Patient details cannot be null")
    @Valid
    private PatientDetails patient;

    @NotNull(message = "Appointment details cannot be null")
    @Valid
    private AppointmentDetails appointment;

    @Builder
    @Data
    public static class PatientDetails {
        @NotBlank(message = "First name cannot be blank")
        @Size(max = 45, message = "Patient first name must be at most 45 characters long")
        @Pattern(regexp = RegexPattern.NAME, message = "First name must contain only letters")
        private String firstName;

        @NotBlank(message = "Last name cannot be blank")
        @Size(max = 45, message = "Patient last name must be at most")
        @Pattern(regexp = RegexPattern.NAME, message = "Last name must contain only letters")
        private String lastName;

        @NotBlank(message = "Cell Phone cannot be blank")
        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone number must be exactly 10 digits")
        private String cellPhone;

        @NotBlank(message = "Email cannot be blank")
        @Email(message = "Email should be valid")
        @Size(max = 45, message = "Email must be at most 45 characters long")
        private String email;

        @NotNull(message = "Date of Birth cannot be null")
        @PastOrPresent(message = "Date of Birth must be in the past or present")
        private LocalDate dob;

        @NotNull(message = "Gender cannot be null")
        private Gender gender;

        @Size(max = 200, message = "Street Address must be at most 200 characters long")
        private String streetAddress;

        @Size(max = 45, message = "City must be at most 45 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "City must contain only letters and spaces")
        private String city;

        @Size(max = 45, message = "State must be at most 45 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "State must contain only letters and spaces")
        private String state;

        @Pattern(regexp = RegexPattern.FIVE_DIGITS)
        private String zipCode;

        private ContactMethod preferredContactMethod;
    }

    @Builder
    @Data
    public static class AppointmentDetails {
        @NotNull(message = "Provider ID cannot be null")
        @Positive(message = "Provider ID must be a positive number")
        private Long providerId;

        @NotNull(message = "Location ID cannot be null")
        @Positive(message = "Location ID must be a positive number")
        private Long locationId;

        @NotNull(message = "Service ID cannot be null")
        @Positive(message = "Service ID must be a positive number")
        private Long serviceId;

        @NotNull(message = "Schedule date cannot be null")
        private LocalDate scheduleDate;

        @NotNull(message = "Schedule time cannot be null")
        private LocalTime scheduleTime;

        @NotNull(message = "Telehealth flag cannot be null")
        private Boolean isTelehealth;

        private String reason;
        private boolean isWaitingForEarlyAppointment;

        private String insuranceCompany;
        private String insuranceCompanyCode;
        private String insuranceId;
        private String insuranceGroupId;
    }
}