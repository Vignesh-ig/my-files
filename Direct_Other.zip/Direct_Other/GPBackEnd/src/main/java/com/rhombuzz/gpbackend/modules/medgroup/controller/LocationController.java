package com.rhombuzz.gpbackend.modules.medgroup.controller;

import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveLocationRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.LocationResponse;
import com.rhombuzz.gpbackend.modules.medgroup.service.LocationService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/locations")
@Validated
public class LocationController {
    private final LocationService locationService;

    @PostMapping
    @PreAuthorize("hasAnyRole(" + AccessType.ADMIN + ")")
    public ResponseEntity<Void> saveLocation(@RequestBody @Valid SaveLocationRequest request) {
        locationService.saveLocation(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    @PreAuthorize("hasAnyRole(" + AccessType.ADMIN + ")")
    public ResponseEntity<Page<LocationResponse>> getLocations(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<LocationResponse> locations = locationService.getLocations(groupId, pageable);
        return ResponseEntity.ok(locations);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole(" + AccessType.ADMIN + ")")
    public ResponseEntity<Void> updateLocation(
            @PathVariable @NotNull Long id,
            @RequestBody @Valid SaveLocationRequest request
    ) {
        locationService.updateLocation(id, request);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole(" + AccessType.ADMIN + ")")
    public ResponseEntity<Void> deleteLocation(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        locationService.deleteLocation(id, groupId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/names")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<List<LocationDTO>> getLocationNames(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<LocationDTO> locationNames = locationService.getLocationNames(groupId);
        return ResponseEntity.ok(locationNames);
    }

    @GetMapping("/names/providers/{providerId}")
    public ResponseEntity<List<LocationDTO>> getProviderLocations(
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<LocationDTO> locationNames = locationService.getProviderLocations(providerId, groupId);
        return ResponseEntity.ok(locationNames);
    }
}
