package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.rhombuzz.gpbackend.enums.PreferredLanguage;

public record MultilingualSMSTemplateResponse(
        String templateName,
        String englishContent,
        String spanishContent,
        String templateUsage
) {
    public String getContent(PreferredLanguage language) {
        return language == PreferredLanguage.SPANISH ? spanishContent : englishContent;
    }
}
