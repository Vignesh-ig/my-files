package com.rhombuzz.gpbackend.modules.appointment.repository;

import com.rhombuzz.gpbackend.modules.appointment.dto.response.AllAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.PatientAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.TodayAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface AppointmentRepository extends JpaRepository<Appointment, Long>,
        JpaSpecificationExecutor<Appointment> {

    @Procedure(procedureName = "get_appointment_available_dates")
    List<Date> getAvailableDates(
            String groupId,
            Long providerId,
            Long locationId,
            Long serviceId,
            LocalDateTime currentDateTime
    );

    @Procedure(value = "get_appointment_available_slots")
    List<Time> getAvailableSlots(
            String groupId,
            Long providerId,
            LocalDate appointmentDate,
            Long locationId,
            LocalDateTime currentDateTime,
            Long serviceId
    );

    @Procedure(procedureName = "get_appointment_available_dates_at_patient_end")
    List<Date> getAvailableDatesAtPatientEnd(
            String groupId,
            Long providerId,
            Long locationId,
            Long serviceId,
            LocalDateTime currentDateTime
    );

    @Procedure(value = "get_appointment_available_slots_at_patient_end")
    List<Time> getAvailableSlotsAtPatientEnd(
            String groupId,
            Long providerId,
            LocalDate appointmentDate,
            Long locationId,
            LocalDateTime currentDateTime,
            Long serviceId
    );

    @Query("SELECT new com.rhombuzz.gpbackend.modules.appointment.dto.response.PatientAppointmentResponse(" +
            "a.id, a.status, a.scheduledDate, a.scheduledTime, a.isTelehealth, a.reasonForVisit, new com.rhombuzz.gpbackend" +
            ".modules.provider.dto.ProviderDTO(a.provider.id, a.provider.name), new com.rhombuzz.gpbackend" +
            ".modules.medgroup.dto.ServiceDTO(CASE WHEN a.service IS NULL THEN NULL ELSE CAST(a.service.id AS LONG) END, a.serviceName), new com.rhombuzz.gpbackend" +
            ".modules.medgroup.dto.LocationDTO(CASE WHEN a.location IS NULL THEN NULL ELSE CAST(a.location.id AS LONG) END, a.locationName), new com.rhombuzz.gpbackend" +
            ".modules.patient.dto.InsuranceDTO(a.insuranceCompanyName, a.insuranceCompanyCode, a.insuranceGroupId, " +
            "a.insuranceId)) FROM Appointment a WHERE a.patient.id = ?1 AND a.medGroup.groupId = ?2 AND a.isProviderConfirmed = true AND a.isDoNotShow = false")
    Page<PatientAppointmentResponse> findByPatientId(Long patientId, String groupId, Pageable pageable);

    @Modifying
    @Query("UPDATE Appointment a SET a.status = ?4, a.checkInDateTime = ?3, a.updatedAt = ?3 WHERE a.id = ?1 AND a.medGroup.groupId = ?2")
    void saveCheckInStatus(Long id, String groupId, LocalDateTime currentDateTime, AppointmentStatus status);

    @Modifying
    @Query("UPDATE Appointment a SET a.status = ?4, a.checkOutDateTime = ?3, a.updatedAt = ?3 WHERE a.id = ?1 AND a.medGroup.groupId = ?2")
    void saveCheckOutStatus(Long id, String groupId, LocalDateTime currentDateTime, AppointmentStatus status);

    @Modifying
    @Query("UPDATE Appointment a SET a.status = CASE WHEN ?5 = true THEN ?4 ELSE a.status END, a.isPatientConfirmed = true, a.updatedAt = ?3 WHERE a.id = ?1 AND a.medGroup.groupId = ?2")
    void savePatientConfirmed(Long id, String groupId, LocalDateTime currentDateTime, AppointmentStatus status, boolean isUpcoming);

    @Modifying
    @Query("UPDATE Appointment a SET a.status = ?4, a.updatedAt = ?3 WHERE a.id = ?1 AND a.medGroup.groupId = ?2")
    void saveNoShow(Long id, String groupId, LocalDateTime currentDateTime, AppointmentStatus status);

    @Query("SELECT DISTINCT a.scheduledDate FROM Appointment a WHERE (?1 IS NULL OR a.provider.id = ?1) AND (?2 IS NULL OR a.location.id = ?2) AND (?3 IS NULL OR a.service.id = ?3) AND a.medGroup.groupId = ?4 AND FUNCTION('MONTH', a.scheduledDate) = ?5 AND FUNCTION('YEAR', a.scheduledDate) = ?6 AND a.isProviderConfirmed = true ORDER BY a.scheduledDate")
    Set<LocalDate> getAvailableAppointmentDates(Long providerId, Long locationId, Long serviceId, String groupId, int month, int year);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.appointment.dto.response.AllAppointmentResponse(" +
            "a.patient.id, CONCAT(a.patient.firstName ,' ',a.patient.lastName), a.patient.cellPhone, a.patient.dob, a.id, a.isPatientConfirmed, a.status, a.scheduledDate, a.scheduledTime, a.isTelehealth, a.reasonForVisit, new com.rhombuzz.gpbackend" +
            ".modules.provider.dto.ProviderDTO(a.provider.id, a.provider.name), new com.rhombuzz.gpbackend" +
            ".modules.medgroup.dto.ServiceDTO(CASE WHEN a.service IS NULL THEN NULL ELSE CAST(a.service.id AS LONG) END, a.serviceName), new com.rhombuzz.gpbackend" +
            ".modules.medgroup.dto.LocationDTO(CASE WHEN a.location IS NULL THEN NULL ELSE CAST(a.location.id AS LONG) END, a.locationName), new com.rhombuzz.gpbackend" +
            ".modules.patient.dto.InsuranceDTO(a.insuranceCompanyName, a.insuranceCompanyCode, a.insuranceGroupId, " +
            "a.insuranceId)) FROM Appointment a " +
            "WHERE (?1 IS NULL OR a.provider.id = ?1) " +
            "AND (?2 IS NULL OR a.location.id = ?2) " +
            "AND (?3 IS NULL OR a.service.id = ?3) " +
            "AND a.medGroup.groupId = ?4 AND a.scheduledDate = ?5 AND a.isProviderConfirmed = true AND a.isDoNotShow = false")
    Page<AllAppointmentResponse> getAppointments(Long providerId, Long locationId, Long serviceId, String groupId, LocalDate scheduledDate, Pageable pageable);

    @Query("SELECT DISTINCT a.scheduledDate FROM Appointment a WHERE (?1 IS NULL OR a.provider.id = ?1) AND (?2 IS NULL OR a.location.id = ?2) AND (?3 IS NULL OR a.service.id = ?3) AND a.medGroup.groupId = ?4 AND a.scheduledDate >= ?5 AND a.isProviderConfirmed = true ORDER BY a.scheduledDate ASC LIMIT 1")
    LocalDate findRecentAvailableAppointmentDate(Long providerId, Long locationId, Long serviceId, String groupId, LocalDate scheduledDate);

    @Query("SELECT DISTINCT a.scheduledDate FROM Appointment a WHERE (?1 IS NULL OR a.provider.id = ?1) AND (?2 IS NULL OR a.location.id = ?2) AND (?3 IS NULL OR a.service.id = ?3) AND a.medGroup.groupId = ?4 AND a.scheduledDate > ?5 AND a.isProviderConfirmed = true ORDER BY a.scheduledDate ASC LIMIT 1")
    LocalDate findNextAvailableAppointmentDate(Long providerId, Long locationId, Long serviceId, String groupId, LocalDate scheduledDate);

    @Query("SELECT DISTINCT a.scheduledDate FROM Appointment a WHERE (?1 IS NULL OR a.provider.id = ?1) AND (?2 IS NULL OR a.location.id = ?2) AND (?3 IS NULL OR a.service.id = ?3) AND a.medGroup.groupId = ?4 AND a.scheduledDate < ?5 AND a.isProviderConfirmed = true ORDER BY a.scheduledDate DESC LIMIT 1")
    LocalDate findPreviousAvailableAppointmentDate(Long providerId, Long locationId, Long serviceId, String groupId, LocalDate scheduledDate);

    @Query("SELECT COUNT(a) > 0 FROM Appointment a WHERE a.patient.id = ?1  AND a.medGroup.groupId = ?2 AND a.scheduledDate = ?3 AND a.scheduledTime = ?4")
    boolean existsByPatientIdAndAppointmentDateTime(Long patientId, String groupId, LocalDate date, LocalTime time);

    @Query("SELECT a FROM Appointment a WHERE a.id = ?1 AND a.provider.id = ?2 AND a.location.id = ?3 AND a.service.id = ?4 AND a.patient.id = ?5 AND a.medGroup.groupId = ?6")
    Optional<Appointment> findById(Long id, Long providerId, Long locationId, Long serviceId, Long patientId, String groupId);

    @Query("SELECT a FROM Appointment a WHERE a.id = ?1 AND a.patient.id = ?2 AND a.medGroup.groupId = ?3")
    Optional<Appointment> findByIdAndPatientId(Long id, Long patientId, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.appointment.dto.response.PatientAppointmentResponse(" +
            "a.id, a.scheduledDate, a.scheduledTime, " +
            "new com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO(" +
            "a.provider.id, a.provider.name), " +
            "new com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO(" +
            "CASE WHEN a.location IS NULL THEN NULL ELSE CAST(a.location.id AS LONG) END, a.locationName), " +
            "new com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO(" +
            "CASE WHEN a.service IS NULL THEN NULL ELSE CAST(a.service.id AS LONG) END, a.serviceName), a.status) " +
            "FROM Appointment a " +
            "WHERE a.patient.id = ?1 " +
            "AND a.medGroup.groupId = ?2 " +
            "AND a.isProviderConfirmed = true " +
            "AND a.scheduledDate >= ?3")
    Page<PatientAppointmentResponse> findByPatientId(Long patientId, String groupId, LocalDate currentDate, Pageable pageable);

    @Query("SELECT a FROM Appointment a WHERE a.id = ?1 AND a.medGroup.groupId = ?2")
    Optional<Appointment> findByIdAndGroupId(Long id, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.appointment.dto.response.TodayAppointmentResponse(" +
            "a.patient.id, CONCAT(a.patient.firstName ,' ',a.patient.lastName), a.patient.cellPhone, a.patient.dob, a.id, a.status, a.scheduledDate, a.scheduledTime, a.checkInDateTime, a.checkOutDateTime, a.isTelehealth, a.reasonForVisit, new com.rhombuzz.gpbackend" +
            ".modules.provider.dto.ProviderDTO(a.provider.id, a.provider.name), new com.rhombuzz.gpbackend" +
            ".modules.medgroup.dto.ServiceDTO(CASE WHEN a.service IS NULL THEN NULL ELSE CAST(a.service.id AS LONG) END, a.serviceName), new com.rhombuzz.gpbackend" +
            ".modules.medgroup.dto.LocationDTO(CASE WHEN a.location IS NULL THEN NULL ELSE CAST(a.location.id AS LONG) END, a.locationName), new com.rhombuzz.gpbackend" +
            ".modules.patient.dto.InsuranceDTO(a.insuranceCompanyName, a.insuranceCompanyCode, a.insuranceGroupId, " +
            "a.insuranceId)) FROM Appointment a " +
            "WHERE (?1 IS NULL OR a.provider.id = ?1) " +
            "AND (?2 IS NULL OR a.location.id = ?2) " +
            "AND (?3 IS NULL OR a.service.id = ?3) " +
            "AND a.medGroup.groupId = ?4 AND a.scheduledDate = ?5 AND a.isProviderConfirmed = true AND a.isDoNotShow = false " +
            "ORDER BY CASE WHEN a.checkInDateTime IS NOT NULL AND a.checkOutDateTime IS NULL THEN 0 ELSE 1 END, " +
            "CASE WHEN a.checkInDateTime IS NOT NULL AND a.checkOutDateTime IS NULL THEN a.checkInDateTime ELSE a.scheduledTime END ASC")
    Page<TodayAppointmentResponse> getTodayAppointments(Long providerId, Long locationId, Long serviceId, String groupId, LocalDate scheduledDate, Pageable pageable);

    @Query("SELECT a FROM Appointment a WHERE a.patient.id = ?1 AND a.medGroup.groupId = ?2 " +
            "AND a.scheduledDate >= ?3 AND a.isProviderConfirmed = true " +
            "ORDER BY a.scheduledDate ASC, a.scheduledTime ASC LIMIT 1")
    Optional<Appointment> findByPatientId(Long patientId, String groupId, LocalDate currentDate);

    @Query("SELECT COUNT(a) > 0 FROM Appointment a WHERE a.patient.id = ?1 AND a.medGroup.groupId = ?2 " +
            "AND a.scheduledDate >= ?3 AND a.isProviderConfirmed = true " +
            "ORDER BY a.scheduledDate ASC, a.scheduledTime ASC LIMIT 1")
    boolean existsByPatientId(Long patientId, String groupId, LocalDate currentDate);
}
