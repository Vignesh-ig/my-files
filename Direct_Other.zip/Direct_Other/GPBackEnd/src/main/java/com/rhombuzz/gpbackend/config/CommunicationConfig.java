package com.rhombuzz.gpbackend.config;

import com.plivo.api.Plivo;
import com.rhombuzz.gpbackend.component.CredentialsFactory;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class CommunicationConfig {

    @Value("${spring.profiles.active}")
    private String activeProfile;

    private final CredentialsFactory factory;

    @Bean
    public JavaMailSender createMailSender() {
        String host = factory.getValue("HOST", "AMAZON_EMAIL", "");
        int port = Integer.parseInt(factory.getValue("PORT", "AMAZON_EMAIL", "5"));
        String username = factory.getValue("ID", "AMAZON_EMAIL", "");
        String password = factory.getValue("TOKEN", "AMAZON_EMAIL", "");

        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

        mailSender.setHost(host);
        mailSender.setPort(port);
        mailSender.setUsername(username);
        mailSender.setPassword(password);

        Properties properties = mailSender.getJavaMailProperties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");

        mailSender.setJavaMailProperties(properties);
        return mailSender;
    }

    @PostConstruct
    public void initializePlivo() {
        log.info("Initializing Plivo SDK using credentials from database");

        try {
            String authId = factory.getValue("ID", "PLIVO", "ID");
            String authToken = factory.getValue("TOKEN", "PLIVO", "TOKEN");

            initPlivo(authId, authToken);
        } catch (Exception e) {
            if (activeProfile.equalsIgnoreCase("prod")) {
                throw new RuntimeException("Failed to initialize Plivo SDK in production environment", e);
            }
            log.warn("Plivo SDK initialization failed in non-production environment: {}", e.getMessage());
        }
    }

    private void initPlivo(String authId, String authToken) {
        Plivo.init(authId, authToken);
        log.info("Plivo SDK initialized successfully");
    }

}
