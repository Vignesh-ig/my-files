package com.rhombuzz.gpbackend.modules.appointment.entity;


import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentSession;
import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentStatus;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "appointment_archives", indexes = {
        @Index(name = "idx_appointment_archive_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_appointment_archive_provider_id", columnList = "provider_id"),
        @Index(name = "idx_appointment_archive_patient_id", columnList = "patient_id"),
        @Index(name = "idx_appointment_archive_service_id", columnList = "service_id"),
        @Index(name = "idx_appointment_archive_location_id", columnList = "location_id")
})
public class AppointmentArchive {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "provider_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Provider provider;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "service_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Service service;

    @ManyToOne
    @JoinColumn(name = "location_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Location location;

    @Column(name = "scheduled_date", nullable = false)
    private LocalDate scheduledDate;

    @Column(name = "scheduled_time", columnDefinition = "TIME(0)")
    private LocalTime scheduledTime;

    @Column(name = "reason_for_visit", length = 500)
    private String reasonForVisit;

    @Column(name = "check_in_date_time", columnDefinition = "DATETIME(0)")
    private LocalDateTime checkInDateTime;

    @Column(name = "created_at", nullable = false, updatable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime createdAt;

    @Column(name = "updated_at", columnDefinition = "DATETIME(0)")
    private LocalDateTime updatedAt;

    @Column(name = "is_provider_confirmed")
    private boolean isProviderConfirmed;

    @Column(name = "is_patient_confirmed")
    private boolean isPatientConfirmed;

    @Column(name = "is_reminder_sent")
    private boolean isReminderSent;

    @Column(name = "duration")
    private int duration;

    @Column(name = "check_out_date_time", columnDefinition = "DATETIME(0)")
    private LocalDateTime checkOutDateTime;

    @Column(name = "fixed_number")
    private Integer fixedNumber;

    @Column(name = "session")
    @Enumerated(EnumType.STRING)
    private AppointmentSession session;

    @Column(name = "reference", length = 45)
    private String reference;

    @Column(name = "is_survey_completed")
    private boolean isSurveyCompleted;

    @Column(name = "status", length = 45)
    @Enumerated(EnumType.STRING)
    private AppointmentStatus status;

    @Column(name = "is_do_not_show")
    private boolean isDoNotShow;

    @Column(name = "is_telehealth")
    private boolean isTelehealth;

    @Column(name = "telehealth_meeting_id")
    private Integer telehealthMeetingId;

    @Column(name = "telehealth_meeting_url", length = 45)
    private String telehealthMeetingUrl;

    @Column(name = "is_waitlist_requested")
    private boolean isWaitlistRequested;

    @Column(name = "is_cancel_requested")
    private boolean isCancelRequested;

    @Column(name = "email_confirm_secure_id", length = 100)
    private String emailConfirmSecureId;

    @Column(name = "insurance_company_name", length = 100)
    private String insuranceCompanyName;

    @Column(name = "insurance_company_code", length = 50)
    private String insuranceCompanyCode;

    @Column(name = "insurance_id", length = 45)
    private String insuranceId;

    @Column(name = "insurance_group_id", length = 45)
    private String insuranceGroupId;

    @PrePersist
    private void beforePersist() {
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    private void beforeUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
