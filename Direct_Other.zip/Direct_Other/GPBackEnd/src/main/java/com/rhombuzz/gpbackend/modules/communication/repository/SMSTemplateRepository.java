package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.dto.response.MultilingualSMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSTemplate;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SMSTemplateRepository extends JpaRepository<SMSTemplate, Long> {

    @Query("SELECT new com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse(t.templateId, t.name, t.templateGroup) " +
            "FROM SMSTemplate t WHERE t.groupId = ?1")
    List<SMSTemplateIdResponse> findTemplateGroups(String groupId);

    @Query("SELECT t FROM SMSTemplate t WHERE t.templateId = ?1 AND t.groupId = ?2")
    Optional<SMSTemplate> findByTemplateId(String templateId, String groupId);

    @Query("SELECT t.isRestricted FROM SMSTemplate t WHERE t.templateId = ?1 AND t.groupId = ?2")
    Optional<Boolean> isTemplateRestricted(String templateId, String groupId);

    @Query("SELECT COUNT(t) > 0 FROM SMSTemplate t WHERE t.name = ?1 AND t.groupId = ?2")
    boolean existsByTemplateName(String name, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse(t.templateId, t.name, t.templateGroup) " +
            "FROM SMSTemplate t WHERE t.groupId = ?1 AND t.templateType = ?2")
    List<SMSTemplateIdResponse> findByGroupIdAndTemplateType(String groupId, TemplateType templateType);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateResponse(" +
            "st.name, " +
            "CASE WHEN ?3 = 'SPANISH' THEN st.spanishContent ELSE st.englishContent END, " +
            "st.templateUsage) " +
            "FROM SMSTemplate st " +
            "WHERE st.templateId = ?1 AND st.groupId = ?2")
    Optional<SMSTemplateResponse> getSMSTemplate(String templateId, String groupId, String language);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.communication.dto.response.MultilingualSMSTemplateResponse(" +
            "st.name, " +
            "st.englishContent, " +
            "st.spanishContent, " +
            "st.templateUsage) " +
            "FROM SMSTemplate st " +
            "WHERE st.templateId = ?1 AND st.groupId = ?2")
    Optional<MultilingualSMSTemplateResponse> getSMSTemplate(String templateId, String groupId);

    void deleteByGroupId(String groupId);
}
