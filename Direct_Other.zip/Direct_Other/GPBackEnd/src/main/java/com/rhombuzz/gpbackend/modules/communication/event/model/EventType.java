package com.rhombuzz.gpbackend.modules.communication.event.model;

public enum EventType {
    ASYNC,
    SYNC
}
