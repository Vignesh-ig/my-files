package com.rhombuzz.gpbackend.modules.communication.dto.response;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class EmailResponse {
    private boolean success;
    private String message;
}
