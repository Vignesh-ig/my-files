package com.rhombuzz.gpbackend.modules.patient.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class SaveFileRequest {
    @NotBlank(message = "Group ID cannot be blank")
    @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
    private String groupId;

    @NotNull(message = "Patient ID cannot be null")
    @Min(value = 1, message = "Patient ID must be at least 1")
    private Long patientId;

    @NotBlank(message = "Key cannot be blank")
    private String key;

    @NotNull(message = "File data cannot be null")
    private List<byte[]> fileData;
}
