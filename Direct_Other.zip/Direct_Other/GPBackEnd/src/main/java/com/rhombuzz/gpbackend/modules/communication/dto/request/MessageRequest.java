package com.rhombuzz.gpbackend.modules.communication.dto.request;

import jakarta.validation.constraints.*;

public record MessageRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        String groupId,

        @NotNull(message = "Patient ID cannot be null")
        @Positive(message = "Patient ID must be a positive number")
        Long patientId,

        @NotBlank(message = "Message content cannot be blank")
        String content
) {
}
