package com.rhombuzz.gpbackend.modules.support.entity;

import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "surveys", indexes = {
        @Index(name = "idx_survey_med_group_id", columnList = "med_group_id")
})
public class Survey {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "date_time", columnDefinition = "DATETIME(0)")
    private LocalDateTime dateTime;

    @Column(name = "gender", length = 45)
    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Column(name = "age_group", length = 45)
    private String ageGroup;

    @Column(name = "question1", length = 45)
    private String question1;

    @Column(name = "question2", length = 45)
    private String question2;

    @Column(name = "question3", length = 45)
    private String question3;

    @Column(name = "question4", length = 45)
    private String question4;

    @Column(name = "question5", length = 45)
    private String question5;

    @Column(name = "question6", length = 45)
    private String question6;

    @Column(name = "question7", length = 45)
    private String question7;

    @Column(name = "question8", length = 45)
    private String question8;

    @Column(name = "question9", length = 45)
    private String question9;

    @Column(name = "question10", length = 45)
    private String question10;

    @Column(name = "question11", length = 45)
    private String question11;

    @Lob
    @Column(name = "comments", columnDefinition = "TEXT")
    private String comments;

}
