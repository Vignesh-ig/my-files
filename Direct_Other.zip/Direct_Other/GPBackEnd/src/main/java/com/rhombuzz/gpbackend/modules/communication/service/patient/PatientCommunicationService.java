package com.rhombuzz.gpbackend.modules.communication.service.patient;

import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.communication.event.model.EventType;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.util.Set;

public interface PatientCommunicationService {
    void validateAndSendEmail(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotEmpty Set<@NotNull @Positive Long> patientIds,
            Appointment appointment,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotNull EventType eventType
            );

    void validateAndSendSMS(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotEmpty Set<@NotNull @Positive Long> patientIds,
            Appointment appointment,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotNull EventType eventType
    );

    void validateAndRequestSubmissionViaEmail(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotEmpty Set<@NotNull @Positive Long> patientIds,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId
    );

    void validateAndRequestSubmissionViaSMS(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotEmpty Set<@NotNull @Positive Long> patientIds,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId
    );

    void validateAndSendDirectSMS(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long patientId,
            Appointment appointment,
            @NotBlank String content,
            @NotBlank String sender,
            @NotNull EventType eventType
    );

    void validateAndSendDirectEmail(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long patientId,
            Appointment appointment,
            @NotBlank String subject,
            @NotBlank String content,
            @NotNull EventType eventType
    );
}
