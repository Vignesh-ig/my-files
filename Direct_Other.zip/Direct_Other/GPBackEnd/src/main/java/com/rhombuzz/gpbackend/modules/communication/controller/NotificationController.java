package com.rhombuzz.gpbackend.modules.communication.controller;

import com.rhombuzz.gpbackend.modules.communication.dto.request.NotificationRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.NotificationResponse;
import com.rhombuzz.gpbackend.modules.communication.service.NotificationService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/notifications")
@Validated
public class NotificationController {
    private final NotificationService notificationService;

    @GetMapping("/group")
    public ResponseEntity<List<NotificationResponse>> getNotifications(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<NotificationResponse> notifications = notificationService.getNotifications(groupId);
        return ResponseEntity.ok(notifications);
    }

    @GetMapping
    public ResponseEntity<List<NotificationResponse>> getNotificationsForUser() {
        List<NotificationResponse> notifications = notificationService.getNotifications();
        return ResponseEntity.ok(notifications);
    }

    @GetMapping("/count")
    public ResponseEntity<Map<String, Long>> getNotificationsCount(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId) {
        Map<String, Long> count = notificationService.getNotificationsCount(groupId);
        return ResponseEntity.ok(count);
    }

    @PostMapping
    public ResponseEntity<Void> saveNotification(@RequestBody @Valid NotificationRequest request) {
        notificationService.saveNotification(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PatchMapping("/hide/{id}")
    public ResponseEntity<Void> hideNotification(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        notificationService.hideNotification(id, groupId);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/show/{id}")
    public ResponseEntity<Void> showNotification(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        notificationService.showNotification(id, groupId);
        return ResponseEntity.noContent().build();
    }

}
