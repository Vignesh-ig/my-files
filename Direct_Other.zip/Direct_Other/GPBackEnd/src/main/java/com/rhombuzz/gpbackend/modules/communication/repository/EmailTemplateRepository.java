package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.dto.EmailTemplateDTO;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface EmailTemplateRepository extends JpaRepository<EmailTemplate, Long> {
    @Query("SELECT e FROM EmailTemplate e WHERE e.groupId = ?1")
    List<EmailTemplate> findEmailTemplates(String groupId);

    @Query("SELECT e FROM EmailTemplate e WHERE e.templateId = ?1 AND e.groupId = ?2")
    Optional<EmailTemplate> getEmailTemplate(String templateId, String groupId);

    @Query("SELECT e.isRestricted FROM EmailTemplate e WHERE e.groupId = ?1 AND e.templateId = ?2")
    boolean isRestricted(String groupId, String templateId);

    @Query("SELECT COUNT(t) > 0 FROM EmailTemplate t WHERE t.name = ?1 AND t.groupId = ?2")
    boolean existsByTemplateName(String name, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateIdResponse(t.templateId, t.name, t.templateGroup) " +
            "FROM EmailTemplate t WHERE t.groupId = ?1 AND t.templateType = ?2")
    List<EmailTemplateIdResponse> findByGroupIdAndTemplateType(String groupId, TemplateType templateType);

    @Query("""
            SELECT new com.rhombuzz.gpbackend.modules.communication.dto.EmailTemplateDTO(
                et.name,
                CASE WHEN ?3 = 'SPANISH' THEN et.spanishContent ELSE et.englishContent END,
                CASE WHEN ?3 = 'SPANISH' THEN et.attribute.spanishHeaderFooter ELSE et.attribute.englishHeaderFooter END,
                et.attribute.style,
                et.subject,
                et.templateUsage
            ) FROM EmailTemplate et WHERE et.templateId = ?1
                    AND et.groupId = ?2
            """)
Optional<EmailTemplateDTO> getEmailTemplate(String templateId, String groupId, String language);

    void deleteByGroupId(String groupId);
}