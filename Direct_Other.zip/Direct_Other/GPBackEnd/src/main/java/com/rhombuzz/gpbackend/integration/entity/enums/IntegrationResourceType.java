package com.rhombuzz.gpbackend.integration.entity.enums;

public enum IntegrationResourceType {

    PATIENT("Patient"),
    APPOINTMENT("Appointment"),
    INSURANCE("Insurance"),
    DOCUMENT("Document"),
    WEBHOOK("Webhook"),
    POLLING("Polling"),
    ;

    private final String label;

    IntegrationResourceType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
