package com.rhombuzz.gpbackend.modules.patient.dto.response;

import lombok.Builder;

import java.time.LocalDate;
import java.time.LocalTime;

@Builder
public record PatientMessageResponse(
        LocalDate patientDOB,
        LocalDate scheduledDate,
        LocalTime scheduledTime,
        String insuranceCompanyName,
        String insuranceCompanyCode
) {
}
