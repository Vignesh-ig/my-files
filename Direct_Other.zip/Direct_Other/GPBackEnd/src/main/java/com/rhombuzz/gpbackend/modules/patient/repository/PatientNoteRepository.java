package com.rhombuzz.gpbackend.modules.patient.repository;

import com.rhombuzz.gpbackend.modules.patient.entity.PatientNote;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PatientNoteRepository extends JpaRepository<PatientNote, Long> {

    @Query("SELECT pn FROM PatientNote pn WHERE pn.patient.id = ?1 AND pn.medGroup.groupId = ?2")
    Page<PatientNote> findByPatientId(Long patientId, String groupId, Pageable pageable);

}
