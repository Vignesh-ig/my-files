package com.rhombuzz.gpbackend.modules.support.dto.response;

import com.rhombuzz.gpbackend.modules.support.entity.Ticket;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Builder
@Data
public class TicketResponse {
    private Long id;
    private Long supportId;
    private Ticket.Status status;
    private String description;
    private LocalDateTime createdAt;
    private String createdBy;

    public static TicketResponse fromEntity(Ticket ticket) {
        return TicketResponse.builder()
                .id(ticket.getId())
                .supportId(ticket.getSupport().getId())
                .status(ticket.getStatus())
                .description(ticket.getDescription())
                .createdAt(ticket.getCreatedAt())
                .createdBy(ticket.getCreatedBy())
                .build();
    }
}
