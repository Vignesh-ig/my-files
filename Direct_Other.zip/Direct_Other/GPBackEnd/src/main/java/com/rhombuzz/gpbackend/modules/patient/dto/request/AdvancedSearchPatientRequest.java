package com.rhombuzz.gpbackend.modules.patient.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.List;

public record AdvancedSearchPatientRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotEmpty(message = "Criteria list cannot be empty")
        List<@NotNull(message = "Criteria cannot be null")
                @Valid SearchCriteria> criteria
) {
    @Getter
    @RequiredArgsConstructor
    public enum FilterType {
        FIRST_NAME("firstName"),
        LAST_NAME("lastName"),
        DOB("dob"),
        CELL_PHONE("cellPhone"),
        LANGUAGE("preferredLanguage");

        private final String columnName;
    }

    @Getter
    public enum CompareOperator {
        EQUAL,
        NOT_EQUAL,
        LIKE,
        BEFORE,
        AFTER
    }

    @Getter
    public enum LogicalOperator {
        AND,
        OR
    }

    public record SearchCriteria(
            @NotNull(message = "Filter type is required")
            FilterType filterType,

            @NotNull(message = "Compare operator is required")
            CompareOperator compareOperator,

            String value,

            LogicalOperator logicalOperator
    ) {
    }
}