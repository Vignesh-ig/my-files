package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.dto.SMSMessageDTO;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MessagePatientResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMS;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface SMSRepository extends JpaRepository<SMS, Long> {

    @Query("""
            SELECT p.id AS patientId,
                   CONCAT(p.firstName, ' ', p.lastName) AS patientName,
                   p.cellPhone AS cellPhone,
                   COUNT(CASE WHEN s.isRead = false THEN 1 END) AS unreadCount
            FROM SMS s
            JOIN s.patient p
            WHERE s.medGroup.groupId = ?1
              AND p.medGroup.groupId = ?1
              AND (?2 IS NULL
                   OR (?2 = -1 AND p.preferredLocation IS NULL)
                   OR p.preferredLocation.id = ?2)
            GROUP BY p.id, p.firstName, p.lastName, p.cellPhone
            """)
    Page<MessagePatientResponse> findPatients(
            String groupId,
            Long locationId,
            Pageable pageable
    );

    @Query("""
            SELECT p.id AS patientId,
                   CONCAT(p.firstName, ' ', p.lastName) AS patientName,
                   p.cellPhone AS cellPhone,
                   COUNT(CASE WHEN s.isRead = false THEN 1 END) AS unreadCount
            FROM SMS s
            JOIN s.patient p
            WHERE s.medGroup.groupId = ?1
              AND p.medGroup.groupId = ?1
              AND (?2 IS NULL
                   OR (?2 = -1 AND p.preferredLocation IS NULL)
                   OR p.preferredLocation.id = ?2)
              AND s.isRead = false
            GROUP BY p.id, p.firstName, p.lastName, p.cellPhone
            """)
    Page<MessagePatientResponse> findUnreadPatients(
            String groupId,
            Long locationId,
            Pageable pageable
    );

    @Query("""
            SELECT p.id AS patientId,
                   CONCAT(p.firstName, ' ', p.lastName) AS patientName,
                   p.cellPhone AS cellPhone,
                   COUNT(CASE WHEN s.isRead = false THEN 1 END) AS unreadCount
            FROM SMS s
            JOIN s.patient p
            WHERE s.medGroup.groupId = ?1
              AND p.medGroup.groupId = ?1
              AND (?2 IS NULL
                   OR (?2 = -1 AND p.preferredLocation IS NULL)
                   OR p.preferredLocation.id = ?2)
              AND (?3 IS NULL OR ?3 = ''
                   OR LOWER(p.firstName) LIKE LOWER(CONCAT('%', ?3, '%'))
                   OR LOWER(p.lastName) LIKE LOWER(CONCAT('%', ?3, '%'))
                   OR p.cellPhone LIKE CONCAT('%', ?3, '%'))
            GROUP BY p.id, p.firstName, p.lastName, p.cellPhone
            """)
    Page<MessagePatientResponse> findPatientsWithUnreadCountAndSearch(
            String groupId,
            Long locationId,
            String searchTerm,
            Pageable pageable
    );

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SMS s SET s.isRead = true WHERE s.medGroup.groupId = ?1 AND s.patient.id = ?2 AND s.isRead = false")
    int markUnreadMessagesAsRead(String groupId, Long patientId);

    @Query("""
        SELECT new com.rhombuzz.gpbackend.modules.communication.dto.SMSMessageDTO(
            s.id,
            s.message,
            s.sender,
            s.smsType,
            ss.messageStatus,
            s.messageUUID,
            s.dateTime
        )
        FROM SMS s
        LEFT JOIN SMSStatus ss ON s.messageUUID = ss.messageUUID
        LEFT JOIN s.patient p
        WHERE s.medGroup.groupId = ?1
            AND s.patient.id = ?2
        ORDER BY s.dateTime DESC
    """)
    Page<SMSMessageDTO> findRecentMessages(String groupId, Long patientId, Pageable pageable);

}
