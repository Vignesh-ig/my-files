package com.rhombuzz.gpbackend.modules.provider.dto;

import java.time.LocalTime;

public record TimeValidationDTO(
        LocalTime startTime,
        LocalTime endTime
) {
}
