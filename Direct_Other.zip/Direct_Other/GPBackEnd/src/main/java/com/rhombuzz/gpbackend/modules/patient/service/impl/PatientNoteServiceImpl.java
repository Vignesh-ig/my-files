package com.rhombuzz.gpbackend.modules.patient.service.impl;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.dto.request.PatientNoteRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientNoteResponse;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.entity.PatientNote;
import com.rhombuzz.gpbackend.modules.patient.repository.PatientNoteRepository;
import com.rhombuzz.gpbackend.modules.patient.service.PatientNoteService;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class PatientNoteServiceImpl implements PatientNoteService {

    private final MedGroupService medGroupService;
    private final PatientNoteRepository patientNoteRepository;
    private final PatientService patientService;
    private final ActivityService activityService;

    @Override
    public void savePatientNote(PatientNoteRequest request) {
        String username = Utils.getCurrentUsername();
        log.info("savePatientNote: method called for patientId='{}', userName='{}'", request.patientId(), username);
        Patient patient = patientService.getPatientById(request.patientId(), request.groupId());
        PatientNote patientNote = buildPatientNote(request, username);
        patientNote.setPatient(patient);

        patientNoteRepository.save(patientNote);
        log.info("Patient note saved for patientId='{}'", request.patientId());

        String description = String.format("Patient note for (%s) added by %s", request.noteType(), username);
        saveActivity(request.groupId(), description, patient);
    }

    @Override
    public Page<PatientNoteResponse> getPatientNotes(Long patientId, String groupId, Pageable pageable) {
        log.info("Getting patient notes for patientId='{}'", patientId);
        return patientNoteRepository.findByPatientId(patientId, groupId, pageable)
                .map(PatientNoteResponse::fromEntity);
    }

    private void saveActivity(String groupId, String description, Patient patient) {
        ActivityRequest request = new ActivityRequest() {{
            setGroupId(groupId);
            setActivityDescription(description);
            setPatient(patient);
            setActivityType("PATIENT NOTE");
        }};

        activityService.saveActivity(request);
    }

    private PatientNote buildPatientNote(PatientNoteRequest request, String username) {
        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        LocalDateTime dateTime = medGroupService.getCurrentDateTime(request.groupId());

        PatientNote patientNote = PatientNote.fromRequest(request);
        patientNote.setMedGroup(medGroup);
        patientNote.setUserName(username);
        patientNote.setCurrentDateTime(dateTime);
        return patientNote;
    }
}