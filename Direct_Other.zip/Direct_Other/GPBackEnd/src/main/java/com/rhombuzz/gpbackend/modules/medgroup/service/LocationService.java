package com.rhombuzz.gpbackend.modules.medgroup.service;

import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveLocationRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.LocationResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
public interface LocationService {

    void saveLocation(
            @Valid SaveLocationRequest saveLocationRequest
    );

    Page<LocationResponse> getLocations(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    );

    @Transactional
    void deleteLocation(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateLocation(
            @NotNull @Positive Long id,
            @Valid SaveLocationRequest saveLocationRequest
    );

    Location getLocationById(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<LocationDTO> getLocationNames(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    boolean isLocationExists(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<LocationDTO> getProviderLocations(
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
