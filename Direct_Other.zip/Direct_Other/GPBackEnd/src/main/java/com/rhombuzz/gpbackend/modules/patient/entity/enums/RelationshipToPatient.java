package com.rhombuzz.gpbackend.modules.patient.entity.enums;

public enum RelationshipToPatient {

    SELF,
    SPOUSE,
    CHILD,
    LIFE_PARTNER,
    FATHER,
    MOTHER,
    GUARANTOR,
    OTHER
}
