package com.rhombuzz.gpbackend.modules.communication.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class SMSTemplateResponse {
    private String templateName;
    private String content;
    private String templateUsage;
}
