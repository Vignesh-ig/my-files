package com.rhombuzz.gpbackend.modules.task.dto.response;

import com.rhombuzz.gpbackend.modules.task.entity.Activity;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Builder
@Data
public class ActivityResponse {
    private LocalDate activityDate;
    private LocalTime activityTime;
    private String activityType;
    private String activityDescription;
    private String content;

    public static ActivityResponse fromEntity(Activity activity) {
        LocalDateTime dateTime = activity.getDateTime();
        return ActivityResponse.builder()
                .activityDate(dateTime.toLocalDate())
                .activityTime(dateTime.toLocalTime())
                .activityType(activity.getType())
                .activityDescription(activity.getDescription())
                .content(activity.getContent())
                .build();
    }
}
