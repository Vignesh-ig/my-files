package com.rhombuzz.gpbackend.modules.communication.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.UpdateEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateAttributesResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MultilingualEmailTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Map;

@Validated
public interface EmailTemplateService {
    void saveEmailTemplate(
            @Valid SaveEmailTemplateRequest request
    );

    MultilingualEmailTemplateResponse getEmailTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    EmailTemplateResponse getEmailTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            PreferredLanguage preferredLanguage
    );

    Map<EmailTemplate.TemplateGroup, List<EmailTemplateIdResponse>> getEmailTemplatesNameWithGroup(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateEmailTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @Valid UpdateEmailTemplateRequest request
    ) throws JsonProcessingException;

    boolean isRestrictedTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    EmailTemplateAttributesResponse getEmailTemplateAttributes(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<EmailTemplateIdResponse> getEmailTemplates(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull TemplateType templateType
    );

    EmailTemplateResponse getEmailTemplateByPatientId(
            @NotBlank String templateId,
            @NotNull Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void removeEmailTemplatesAndAttributes(@NotBlank @Size(min = 10, max = 10) String groupId);
}
