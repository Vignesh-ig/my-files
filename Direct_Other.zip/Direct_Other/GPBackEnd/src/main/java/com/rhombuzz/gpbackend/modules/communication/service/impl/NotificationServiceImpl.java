package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.communication.dto.request.NotificationRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.NotificationResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.Notification;
import com.rhombuzz.gpbackend.modules.communication.repository.NotificationRepository;
import com.rhombuzz.gpbackend.modules.communication.service.NotificationService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService {
    private final NotificationRepository notificationRepository;
    private final MedGroupService medGroupService;

    @Override
    public void saveNotification(NotificationRequest request) {
        log.info("Saving notification");
        if (request.priority().equals(Notification.Priority.SEVERE)) {
            boolean isSevereNotificationExist = notificationRepository.existsByPriority(Notification.Priority.SEVERE);
            if (isSevereNotificationExist) {
                log.error("Severe notification already exists");
                throw new ConflictException("Severe notification already exists");
            }
        }

        medGroupService.getMedGroups().forEach(medGroup -> {
            Notification notification = Notification.builder()
                    .medGroup(medGroup)
                    .dateTime(LocalDateTime.now(medGroup.getTimeZone().toZoneId()))
                    .message(request.message())
                    .priority(request.priority())
                    .build();

            notificationRepository.save(notification);
            log.info("Notification saved for group {}", medGroup.getGroupId());
        });
    }

    @Override
    @Transactional
    public List<NotificationResponse> getNotifications(String groupId) {
        log.info("Retrieving notifications for group {}", groupId);
        List<NotificationResponse> response = notificationRepository.findByGroupId(groupId).stream()
                .map(NotificationResponse::fromEntity)
                .peek(notificationResponse -> notificationResponse.setIsHidden(null))
                .toList();

        notificationRepository.updateSeenNotification(true, groupId);
        return response;
    }

    @Override
    public List<NotificationResponse> getNotifications() {
        log.info("Getting notifications");
        return notificationRepository.findNotifications().stream()
                .map(NotificationResponse::fromEntity)
                .toList();
    }

    @Override
    public void hideNotification(Long id, String groupId) {
        log.info("Hiding notification with id {} for group {}", id, groupId);
        setHiddenStatus(id, true, groupId);
        log.info("Notification with id {} for group {} hidden", id, groupId);
    }

    @Override
    public void showNotification(Long id, String groupId) {
        log.info("Showing notification with id {} for group {}", id, groupId);
        setHiddenStatus(id, false, groupId);
        log.info("Notification with id {} for group {} shown", id, groupId);
    }

    @Override
    public Map<String, Long> getNotificationsCount(String groupId) {
        long count = notificationRepository.countByGroupId(groupId);
        return Map.of("count", count);
    }

    private void setHiddenStatus(Long id, boolean status, String groupId) {
        Notification notification = notificationRepository.findById(id, groupId)
                .orElseThrow(() -> new NotFoundException("Notification not found"));
        if (notification.getPriority().equals(Notification.Priority.SEVERE) && !status) {
            log.error("Severe notification can't be shown");
            throw new ConflictException("Severe notification can't be shown");
        }
        notification.setHidden(status);
        notificationRepository.save(notification);
    }
}
