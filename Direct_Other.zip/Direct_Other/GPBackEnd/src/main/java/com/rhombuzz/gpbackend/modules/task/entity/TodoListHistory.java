package com.rhombuzz.gpbackend.modules.task.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "todo_list_histories", indexes = {
        @Index(name = "idx_todo_list_history_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_todo_list_history_todo_list_id", columnList = "todo_list_id"),
})
public class TodoListHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "todo_list_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private TodoList todoList;

    @Column(name = "created_by", length = 45, nullable = false)
    private String createdBy;

    @Column(name = "date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime dateTime;

    @Column(name = "action_detail", length = 1000, nullable = false)
    private String actionDetail;

    @Column(name = "action_type", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private ActionType actionType;

    @Column(name = "assign_to", length = 45, nullable = false)
    private String assignTo;

    public enum ActionType {

        CREATE,
        DELETE,
        RE_ASSIGN
    }

}
