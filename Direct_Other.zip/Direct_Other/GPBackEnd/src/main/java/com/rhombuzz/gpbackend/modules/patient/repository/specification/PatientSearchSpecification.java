package com.rhombuzz.gpbackend.modules.patient.repository.specification;

import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import org.springframework.data.jpa.domain.Specification;

public class PatientSearchSpecification {

    public static Specification<Patient> hasGroupId(String groupId) {
        return (root, query, cb) ->
                cb.equal(root.get("medGroup").get("groupId"), groupId);
    }

    public static Specification<Patient> searchAll(String searchTerm) {
        return (root, query, cb) -> {
            if (searchTerm == null || searchTerm.isEmpty()) {
                return null;
            }

            return cb.or(
                        cb.like(cb.lower(root.get("firstName")), "%" + searchTerm.toLowerCase() + "%"),
                        cb.like(cb.lower(root.get("lastName")), "%" + searchTerm.toLowerCase() + "%"),
                        cb.like(cb.lower(root.get("cellPhone")), "%" + searchTerm.toLowerCase() + "%"),
                        cb.like(cb.lower(root.get("email")), "%" + searchTerm.toLowerCase() + "%"),
                        cb.like(root.get("dob").as(String.class), "%" + searchTerm + "%")
            );
        };
    }
}
