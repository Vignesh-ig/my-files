package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.rhombuzz.gpbackend.modules.patient.entity.PatientNote;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class PatientNoteResponse {
    Long id;
    String userName;
    String patientNote;
    PatientNote.NoteType noteType;
    LocalDateTime currentDateTime;

    public static PatientNoteResponse fromEntity(PatientNote patientNote) {
        return PatientNoteResponse.builder()
                .id(patientNote.getId())
                .userName(patientNote.getUserName())
                .patientNote(patientNote.getPatientNote())
                .noteType(patientNote.getNoteType())
                .currentDateTime(patientNote.getCurrentDateTime())
                .build();
    }
}
