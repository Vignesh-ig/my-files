package com.rhombuzz.gpbackend.modules.patient.entity;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.dto.PatientCSVDTO;
import com.rhombuzz.gpbackend.modules.patient.dto.request.SaveManualPatientRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.request.SavePatientRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "patients", indexes = {
        @Index(name = "idx_patient_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_patient_preferred_location_id", columnList = "preferred_location_id"),
})
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "preferred_location_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Location preferredLocation;

    @Column(name = "first_name", nullable = false, length = 45)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 45)
    private String lastName;

    @Column(name = "preferred_first_name", length = 45)
    private String preferredFirstName;

    @Column(name = "home_phone", length = 10)
    private String homePhone;

    @Column(name = "dob", nullable = false)
    private LocalDate dob;

    @Column(name = "cell_phone", nullable = false, length = 10)
    private String cellPhone;

    @Column(name = "is_cell_phone_valid")
    private boolean isCellPhoneValid;

    @Column(name = "email", length = 60)
    private String email;

    @Column(name = "is_email_valid")
    private boolean isEmailValid;

    @Column(name = "work_phone", length = 10)
    private String workPhone;

    @Column(name = "ssn", length = 9)
    private String ssn;

    @Column(name = "street_address", length = 200)
    private String streetAddress;

    @Column(name = "city", length = 45)
    private String city;

    @Column(name = "state", length = 45)
    private String state;

    @Column(name = "zip_code", length = 10)
    private String zipCode;

    @Column(name = "gender", length = 45)
    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Column(name = "preferred_language", length = 45)
    @Enumerated(EnumType.STRING)
    private PreferredLanguage preferredLanguage;

    @Column(name = "created_date_time", updatable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime createdDateTime;

    @Column(name = "document_submission_date_time", columnDefinition = "DATETIME(0)")
    private LocalDateTime documentSubmissionDateTime;

    @Column(name = "opt_out", length = 45)
    @Enumerated(EnumType.STRING)
    private ContactMethod optOut;

    @Column(name = "patient_ref_number", length = 45)
    private String patientReferenceNumber;

    @Column(name = "submission_flag")
    private boolean submissionFlag;

    @Column(name = "request_form_flag")
    private boolean requestFormFlag;

    @Column(name = "stripe_customer_id", length = 90)
    private String stripeCustomerId;

    @Column(name = "stripe_payment_method_id", length = 45)
    private String stripePaymentMethodId;

    @Column(name = "stripe_customer_creation_date")
    private LocalDate stripeCustomerCreationDate;

    @Column(name = "claimed_by", length = 45)
    private String claimedBy;

    @Column(name = "review_status")
    private boolean reviewStatus;

    @Column(name = "card_on_file_status")
    private boolean cardOnFileStatus;

    @Column(name = "secure_id_for_patient", length = 100)
    private String secureIdForPatient;

    @Column(name = "secure_id_to_form", length = 100)
    private String secureIdToForm;

    @Column(name = "secure_id_to_download", length = 100)
    private String secureIdToDownload;

    @Column(name = "otp_code", length = 8)
    private Integer otpCode;

    @Column(name = "secure_id_to_email", length = 100)
    private String secureIdToEmail;

    @Column(name = "secure_email_otp_code", length = 8)
    private Integer secureEmailOtpCode;

    @Column(name = "preferred_contact_method", length = 45)
    @Enumerated(EnumType.STRING)
    private ContactMethod preferredContactMethod;

    @Column(name = "default_copay_amount", precision = 5, scale = 2)
    private BigDecimal defaultCopayAmount;

    @Column(name = "default_payment_reason", length = 45)
    private String defaultPaymentReason;

    @Column(name = "bulk_time_stamp", columnDefinition = "DATETIME(0)")
    private LocalDateTime bulkTimeStamp;

    @Column(name = "last_modified_date_time", columnDefinition = "DATETIME(0)")
    private LocalDateTime lastModifiedDateTime;

    public Patient(Long id) {
        this.id = id;
    }

    @PrePersist
    protected void onCreate() {
        if(this.createdDateTime == null)
            createdDateTime = LocalDateTime.now(this.medGroup.getTimeZone().toZoneId());
        if(this.lastModifiedDateTime == null)
            lastModifiedDateTime = LocalDateTime.now(this.medGroup.getTimeZone().toZoneId());
        isCellPhoneValid = StringUtils.hasText(cellPhone);
        isEmailValid = StringUtils.hasText(email);
    }

    @PreUpdate
    protected void onUpdate() {
        lastModifiedDateTime = LocalDateTime.now(this.medGroup.getTimeZone().toZoneId());
    }

    public static Patient fromRequest(SavePatientRequest request) {
        return Patient.builder()
                .firstName(request.firstName())
                .lastName(request.lastName())
                .preferredFirstName(request.preferredFirstName())
                .dob(request.dob())
                .gender(request.gender())
                .homePhone(request.homePhone())
                .cellPhone(request.cellPhone())
                .workPhone(request.workPhone())
                .email(request.email())
                .ssn(request.ssn())
                .streetAddress(request.streetAddress())
                .city(request.city())
                .state(request.state())
                .zipCode(request.zipCode())
                .preferredLanguage(request.preferredLanguage())
                .build();
    }

    public static Patient fromCSVDTO(PatientCSVDTO patientCSVDTO) {
        return Patient.builder()
                .firstName(patientCSVDTO.getFirstName())
                .lastName(patientCSVDTO.getLastName())
                .email(patientCSVDTO.getEmail())
                .homePhone(patientCSVDTO.getHomePhone())
                .dob(patientCSVDTO.getDob())
                .cellPhone(patientCSVDTO.getCellPhone())
                .ssn(patientCSVDTO.getSsn())
                .city(patientCSVDTO.getCity())
                .state(patientCSVDTO.getState())
                .zipCode(patientCSVDTO.getZipCode())
                .gender(patientCSVDTO.getGender())
                .preferredLanguage(patientCSVDTO.getPreferredLanguage())
                .optOut(patientCSVDTO.getOptOut())
                .submissionFlag(patientCSVDTO.getSubmissionFlag())
                .patientReferenceNumber(patientCSVDTO.getPatientReferenceNumber())
                .build();
    }

    public static Patient fromManualPatientRequest(SaveManualPatientRequest request) {
        return Patient.builder()
                .firstName(request.firstName())
                .lastName(request.lastName())
                .dob(request.dob())
                .gender(request.gender())
                .cellPhone(request.cellPhone())
                .email(request.email())
                .build();
    }
}
