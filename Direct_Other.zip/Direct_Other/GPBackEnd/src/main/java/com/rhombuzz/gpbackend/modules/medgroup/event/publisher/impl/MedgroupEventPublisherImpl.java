package com.rhombuzz.gpbackend.modules.medgroup.event.publisher.impl;

import com.rhombuzz.gpbackend.modules.medgroup.event.model.MedgroupRemoveEvent;
import com.rhombuzz.gpbackend.modules.medgroup.event.publisher.MedgroupEventPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MedgroupEventPublisherImpl implements MedgroupEventPublisher {

    private final ApplicationEventPublisher eventPublisher;

    @Override
    public void publishMedgroupRemoveEvent(MedgroupRemoveEvent event) {
        eventPublisher.publishEvent(event);
    }
}
