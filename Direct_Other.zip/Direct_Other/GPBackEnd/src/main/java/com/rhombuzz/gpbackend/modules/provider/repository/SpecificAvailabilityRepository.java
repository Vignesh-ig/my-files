package com.rhombuzz.gpbackend.modules.provider.repository;

import com.rhombuzz.gpbackend.modules.provider.dto.response.SpecificAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.SpecificAvailability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SpecificAvailabilityRepository extends JpaRepository<SpecificAvailability, Long> {

    @Query("SELECT new com.rhombuzz.gpbackend.modules.provider.dto.response.SpecificAvailabilityResponse(" +
            "sa.id, new com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO(sa.provider.id, sa.provider.name), " +
            "sa.scheduleDate, sa.startTime, sa.endTime, new com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO(" +
            "sa.location.id, sa.location.name)) FROM SpecificAvailability sa WHERE sa.provider.id = ?1 AND sa.medGroup.groupId = ?2")
    List<SpecificAvailabilityResponse> findByProviderId(Long providerId, String groupId);

    @Query("SELECT sa FROM SpecificAvailability sa WHERE sa.id = ?1 AND sa.provider.id = ?2 AND sa.location.id = ?3 AND sa.medGroup.groupId = ?4")
    Optional<SpecificAvailability> findById(Long id, Long providerId, Long locationId, String groupId);

    @Query(value = "SELECT sa FROM SpecificAvailability sa WHERE sa.provider.id = ?1 " +
            "AND sa.medGroup.groupId = ?2 ORDER BY sa.scheduleDate DESC, sa.startTime DESC LIMIT 1")
    Optional<SpecificAvailability> findLatestByProviderId(Long providerId, String groupId);

    @Modifying
    @Query("DELETE FROM SpecificAvailability sa WHERE sa.id = ?1 AND sa.provider.id = ?2 AND sa.location.id = ?3 AND sa.medGroup.groupId = ?4")
    void deleteById(Long id, Long providerId, Long locationId, String groupId);
}
