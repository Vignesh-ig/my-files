package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupFlag;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class DashboardFlagResponse {
    private boolean reminder;
    private boolean preReminder;
    private boolean officeClosedAutoReply;
    private boolean missedAppointmentFollowUp;
    private boolean recallAppointmentReminder;
    private boolean autoRequestQuickSurvey;
    private boolean autoRequestPayment;
    private boolean notifyPaymentSuccess;
    private boolean bookingFee;

    private FormSubmissionEmailAlert formSubmissionEmailAlert;
    private AppointmentRequestEmailAlert appointmentRequestEmailAlert;

    public static DashboardFlagResponse fromEntity(MedGroupFlag medGroupFlag) {
        return DashboardFlagResponse.builder()
                .reminder(medGroupFlag.isReminder())
                .preReminder(medGroupFlag.isPreReminder())
                .officeClosedAutoReply(medGroupFlag.isOfficeClosedAutoReply())
                .missedAppointmentFollowUp(medGroupFlag.isMissedAppointmentFollowUp())
                .recallAppointmentReminder(medGroupFlag.isRecallAppointmentReminder())
                .autoRequestQuickSurvey(medGroupFlag.isAutoRequestQuickSurvey())
                .formSubmissionEmailAlert(
                        new FormSubmissionEmailAlert(medGroupFlag.isFormSubmissionEmailAlert(), medGroupFlag.getMedGroup().getEmail())
                )
                .appointmentRequestEmailAlert(
                       new AppointmentRequestEmailAlert(medGroupFlag.isAppointmentRequestEmailAlert(), medGroupFlag.getMedGroup().getAppointmentAlertOfficeEmail())
                )
                .autoRequestPayment(medGroupFlag.isAutoRequestPayment())
                .notifyPaymentSuccess(medGroupFlag.isNotifyPaymentSuccess())
                .bookingFee(medGroupFlag.isBookingFee())
                .build();
    }

    public record FormSubmissionEmailAlert(boolean flagValue, String email) {}
    public record AppointmentRequestEmailAlert(boolean flagValue, String email) {}
}
