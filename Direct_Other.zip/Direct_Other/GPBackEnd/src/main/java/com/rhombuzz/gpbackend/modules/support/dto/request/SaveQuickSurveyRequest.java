package com.rhombuzz.gpbackend.modules.support.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDateTime;

public record SaveQuickSurveyRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Patient ID cannot be null")
        @Positive(message = "Patient ID must be a positive number")
        Long patientId,

        @NotNull(message = "Appointment ID cannot be null")
        @Positive(message = "Appointment ID must be a positive number")
        Long appointmentId,

        @NotNull(message = "Requested date and time cannot be null")
        LocalDateTime requestedDateTime
) {
}
