package com.rhombuzz.gpbackend.modules.communication.entity;

import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_templates", indexes = {
        @Index(name = "idx_sms_template_group_id", columnList = "group_id")
})
public class SMSTemplate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "group_id", length = 10, nullable = false)
    private String groupId;

    @Column(name = "template_id", length = 100, nullable = false)
    private String templateId;

    @Column(name = "name", length = 45, nullable = false)
    private String name;

    @Lob
    @Column(name = "english_content", nullable = false, columnDefinition = "TEXT")
    private String englishContent;

    @Lob
    @Column(name = "spanish_content", nullable = false, columnDefinition = "TEXT")
    private String spanishContent;

    @Column(name = "template_type", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private TemplateType templateType;

    @Column(name = "template_group", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private TemplateGroup templateGroup;

    @Lob
    @Column(name = "template_usage", columnDefinition = "TEXT")
    private String templateUsage;

    @Column(name = "is_restricted")
    private boolean isRestricted;

    public static SMSTemplate fromRequest(SaveSMSTemplateRequest request) {
        String templateId = request.name().trim().replaceAll("\\s+", "_").toUpperCase();
        String templateName = request.name().trim().replaceAll("\\s+", " ");

        return SMSTemplate.builder()
                .groupId(request.groupId())
                .templateGroup(TemplateGroup.CUSTOM)
                .templateId(templateId)
                .englishContent(request.englishContent())
                .spanishContent(request.spanishContent())
                .templateType(TemplateType.EXTERNAL)
                .name(templateName)
                .templateUsage(request.templateUsage())
                .build();

    }

    public enum TemplateGroup {

        APPOINTMENT_INTERACTION,
        APPOINTMENT_REMINDER,
        APPOINTMENT_CANCELED,
        APPOINTMENT_WAITLIST,
        APPOINTMENT_RESCHEDULED,
        APPOINTMENT_GENERAL,
        APPOINTMENT_CONFIRMATION,
        APPOINTMENT_AVAILABILITY,
        APPOINTMENT_CHECKIN_ALERT,
        PAYMENT,
        SURVEY,
        WORKFLOW,
        FORMS,
        CUSTOM
    }
}
