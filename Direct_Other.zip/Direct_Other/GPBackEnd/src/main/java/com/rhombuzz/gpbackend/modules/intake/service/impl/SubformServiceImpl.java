package com.rhombuzz.gpbackend.modules.intake.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.modules.intake.service.PdfService;
import com.rhombuzz.gpbackend.modules.intake.service.SubformService;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.dto.request.SaveFileRequest;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.patient.service.SubmissionService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class SubformServiceImpl implements SubformService {
    private final MedGroupService medGroupService;
    private final PatientService patientService;
    private final ActivityService activityService;
    private final SubmissionService submissionService;
    private final PdfService pdfService;

    @Value("${templates.output.path}")
    private String outputPath;

    @Override
    public void saveSubform(JsonNode request) {
        log.info("Saving subform");

        String groupId = request.path("groupId").asText();
        Long patientId = request.path("patientId").asLong();

        String firstName = request.get("patient").get("firstName").asText();
        String lastName = request.get("patient").get("lastName").asText();

        String patientName = firstName + " " + lastName;
        String formName = request.path("formName").asText();

        String activityDescription = "Patient (" + patientName + ") has submitted the " + formName + ".";
        ActivityRequest activityRequest = buildActivity(patientId, groupId, formName, activityDescription);

        activityService.saveActivity(activityRequest);

        pdfService.savePDF(patientId, groupId, patientName, request);

        patientService.updateSubmissionDateTime(patientId, groupId);
        submissionService.updateClaimedByAndReviewStatus(patientId, groupId);

        log.info("Subform PDF saved successfully for patient {}", patientId);
    }

    @Override
    public void saveAttachments(Long patientId, String groupId, List<MultipartFile> files) {
        log.info("Uploading patient {} to group {}", patientId, groupId);

        MedGroup medGroup = medGroupService.getMedGroup(groupId);
        String groupName = medGroup.getGroupName();

        Patient patient = patientService.getPatientById(patientId, groupId);
        String patientName = patient.getFirstName() + " " + patient.getLastName();

        String activityDescription = "Patient (" + patientName + ") has submitted the required document(s).";
        ActivityRequest activityRequest = buildActivity(patientId, groupId, "documents", activityDescription);

        activityService.saveActivity(activityRequest);

        try {
            for (MultipartFile file : files) {
                String fileName = buildAttachmentFileName(file, medGroupService.getCurrentDateTime(groupId));

                String outputFullPath = Paths.get(outputPath, groupName, String.valueOf(patientId), fileName).toString();
                savePdfToOutput(file.getBytes(), outputFullPath);

                SaveFileRequest saveFileRequest = SaveFileRequest.builder()
                        .groupId(groupId)
                        .patientId(patientId)
                        .key(patientId + "/attachments/" + fileName)
                        .fileData(List.of(file.getBytes()))
                        .build();
                patientService.saveFileToS3Bucket(saveFileRequest);

                deleteFile(outputFullPath);
                log.info("Deleted local file after upload: {}", outputFullPath);
            }
            patientService.updateSubmissionDateTime(patientId, groupId);
            submissionService.updateClaimedByAndReviewStatus(patientId, groupId);
        } catch (Exception e) {
            log.error("Error uploading attachments document to S3: {}", e.getMessage(), e);
            throw new InternalServerErrorException("Error uploading attachments document to S3");
        }
    }

    private void savePdfToOutput(byte[] pdfBytes, String filePath) {
        Utils.savePdf(pdfBytes, filePath, log);
    }

    private void deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            if (file.delete()) {
                log.info("Deleted local PDF file: {}", filePath);
            } else {
                log.warn("Failed to delete local PDF file: {}", filePath);
            }
        }
    }

    private String buildAttachmentFileName(MultipartFile file, LocalDateTime currentDateTime) {
        String originalFilename = file.getOriginalFilename();
        String extension = "";

        String baseName = "file"; // fallback name

        if (originalFilename != null && originalFilename.contains(".")) {
            int dotIndex = originalFilename.lastIndexOf('.');
            baseName = originalFilename.substring(0, dotIndex);
            extension = originalFilename.substring(dotIndex + 1);
        } else if (originalFilename != null) {
            baseName = originalFilename; // no extension
        }

        String fileCurrentDateTime = currentDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss"));
        return String.format("%s-%s.%s", baseName, fileCurrentDateTime, extension);
    }

    private ActivityRequest buildActivity(Long patientId, String groupId, String formName, String activityDescription) {
        Patient patient = patientService.getPatientById(patientId, groupId);
        return ActivityRequest.builder()
                .patient(patient)
                .groupId(groupId)
                .activityType(formName.toUpperCase())
                .activityDescription(activityDescription)
                .build();
    }

}
