package com.rhombuzz.gpbackend.modules.patient.dto.request;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public record UpdatePatientRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        String groupId,

        @NotBlank(message = "First name cannot be blank")
        String firstName,

        @NotBlank(message = "Last name cannot be blank")
        String lastName,

        @NotNull(message = "Date of birth cannot be null")
        @PastOrPresent(message = "Date of birth must be in the past or present")
        LocalDate dob,

        @NotNull(message = "Gender cannot be null")
        Gender gender,

        @NotNull(message = "Phone number cannot be null")
        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Phone number must be exactly 10 digits")
        String cellPhone,

        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Home phone number must be exactly 10 digits")
        String homePhone,

        @NotNull(message = "Email cannot be null")
        @Email(message = "Email must be a valid email address")
        String email,

        @Pattern(regexp = RegexPattern.FIVE_DIGITS, message = "Zip code must be exactly 5 digits")
        String zipCode,

        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "City must contain only letters and spaces")
        String city,

        ContactMethod optOut,
        String streetAddress,
        ContactMethod contactMethod,
        String preferredFirstName,
        PreferredLanguage preferredLanguage
) {
}
