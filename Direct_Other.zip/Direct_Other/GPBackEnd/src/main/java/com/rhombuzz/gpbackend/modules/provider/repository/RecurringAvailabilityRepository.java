package com.rhombuzz.gpbackend.modules.provider.repository;

import com.rhombuzz.gpbackend.modules.provider.dto.response.RecurringAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.RecurringAvailability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface RecurringAvailabilityRepository extends JpaRepository<RecurringAvailability, Long> {

    @Query("SELECT new com.rhombuzz.gpbackend.modules.provider.dto.response" +
            ".RecurringAvailabilityResponse(ra.id, ra.startTime, ra.endTime, " +
            "new com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO(ra.location.id, " +
            "ra.location.name), ra.day) FROM RecurringAvailability ra WHERE ra.provider.id = ?1 " +
            "AND ra.medGroup.groupId = ?2")
    List<RecurringAvailabilityResponse> findByProviderId(Long providerId, String groupId);

    @Query("SELECT ra FROM RecurringAvailability ra WHERE ra.id = ?1 AND ra.provider.id = ?2 AND ra.location.id = ?3 AND ra.medGroup.groupId = ?4")
    Optional<RecurringAvailability> findById(Long id, Long providerId, Long locationId, String groupId);

    @Query("SELECT ra FROM RecurringAvailability ra WHERE ra.id = ?1 AND ra.provider.id = ?2 AND ra.medGroup.groupId = ?3")
    Optional<RecurringAvailability> findById(Long id, Long providerId, String groupId);

    @Modifying
    @Query("DELETE FROM RecurringAvailability ra WHERE ra.id = ?1 AND ra.provider.id = ?2 AND ra.location.id = ?3 AND ra.medGroup.groupId = ?4")
    void deleteById(Long id, Long providerId, Long locationId, String groupId);
}