package com.rhombuzz.gpbackend.modules.medgroup.service;

import com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormBuilderSettingResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.CustomizationRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.CustomizationResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.util.Map;

@Validated
public interface CustomizationService {

    void updateCustomization(
            @Valid CustomizationRequest request
    );

    CustomizationResponse getCustomization(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Map<String, Object> getThankYouPageContent(String groupId);

    AppointmentFormBuilderSettingResponse getAppointmentFormBuilderSetting(String groupId);
}
