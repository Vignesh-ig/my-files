package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupInsights;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;

public interface MedGroupInsightsRepository extends JpaRepository<MedGroupInsights, Long> {

    @Query("SELECT COUNT(mi) > 0 FROM MedGroupInsights mi WHERE mi.medGroup.groupId = ?1 AND mi.insightDate = ?2")
    boolean existsByGroupIdAndInsightDate(String groupId, LocalDate insightDate);

    @Modifying
    @Transactional
    @Query("UPDATE MedGroupInsights m SET m.appointmentBookedByPatient = m.appointmentBookedByPatient + ?3," +
            " m.totalAppointmentCreated = m.totalAppointmentCreated + ?3 WHERE m.medGroup.groupId = ?1 AND m.insightDate = ?2")
    void incrementAppointmentBookedByPatient(String groupId, LocalDate date, int count);

    @Modifying
    @Transactional
    @Query("UPDATE MedGroupInsights m SET m.appointmentBookedByStaff = m.appointmentBookedByStaff + ?3," +
            " m.totalAppointmentCreated = m.totalAppointmentCreated + ?3 WHERE m.medGroup.groupId = ?1 AND m.insightDate = ?2")
    void incrementAppointmentBookedByStaff(String groupId, LocalDate date, int count);

    @Modifying
    @Transactional
    @Query("UPDATE MedGroupInsights m SET m.appointmentCanceledByPatient = m.appointmentCanceledByPatient + ?3," +
            " m.totalAppointmentCanceled = m.totalAppointmentCanceled + ?3 WHERE m.medGroup.groupId = ?1 AND m.insightDate = ?2")
    void incrementAppointmentCanceledByPatient(String groupId, LocalDate date, int count);

    @Modifying
    @Transactional
    @Query("UPDATE MedGroupInsights m SET m.appointmentCanceledByStaff = m.appointmentCanceledByStaff + ?3," +
            " m.totalAppointmentCanceled = m.totalAppointmentCanceled + ?3 WHERE m.medGroup.groupId = ?1 AND m.insightDate = ?2")
    void incrementAppointmentCanceledByStaff(String groupId, LocalDate date, int count);
}
