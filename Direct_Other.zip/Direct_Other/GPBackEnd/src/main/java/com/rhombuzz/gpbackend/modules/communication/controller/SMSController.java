package com.rhombuzz.gpbackend.modules.communication.controller;

import com.rhombuzz.gpbackend.modules.communication.dto.SMSMessageDTO;
import com.rhombuzz.gpbackend.modules.communication.dto.request.MessageRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.PatientMessageRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MessagePatientResponse;
import com.rhombuzz.gpbackend.modules.communication.service.PatientInteractionService;
import com.rhombuzz.gpbackend.modules.communication.service.SMSService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/sms")
@Validated
public class SMSController {
    private final SMSService smsService;
    private final PatientInteractionService patientInteractionService;

    @PostMapping("/send")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Void> sendMessage(
            @RequestBody @Valid MessageRequest request
    ){
        smsService.sendDirectSMS(request);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/patients")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Page<MessagePatientResponse>> getPatientsWithUnreadCount(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam(required = false) Long locationId,
            @RequestParam @NotNull Boolean unreadOnly,
            Pageable pageable
    ) {
        Page<MessagePatientResponse> patients = smsService.getPatientsWithUnreadCount(groupId, locationId, unreadOnly, pageable);
        return ResponseEntity.ok(patients);
    }

    @PostMapping("/callback")
    public ResponseEntity<Void> handleSmsCallback(
            PatientMessageRequest request
    ) {
        patientInteractionService.processPatientSMS(request);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/patients/search")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Page<MessagePatientResponse>> searchPatient(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam(required = false) Long locationId,
            @RequestParam @NotBlank String searchTerm,
            Pageable pageable
    ) {
        Page<MessagePatientResponse> patients = smsService.searchPatientsWithUnreadCount(groupId, locationId, searchTerm, pageable);
        return ResponseEntity.ok(patients);
    }

    @GetMapping("/messages")
    public ResponseEntity<Page<SMSMessageDTO>> getPatients(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotNull Long patientId,
            @RequestParam @PositiveOrZero Integer unReadCount,
            Pageable pageable
    ) {
        Page<SMSMessageDTO> smsMessages = smsService.getSMSMessagesByPatientId(groupId, patientId, unReadCount, pageable);
        return ResponseEntity.ok(smsMessages);
    }

}