package com.rhombuzz.gpbackend.modules.appointment.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public record ConfirmAppointmentRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters")
        String groupId,

        @NotNull(message = "Patient ID cannot be null")
        @Positive(message = "Patient ID must be a positive number")
        Long patientId,

        @NotNull(message = "Provider ID cannot be null")
        @Positive(message = "Provider ID must be a positive number")
        Long providerId,

        @NotNull(message = "Service ID cannot be null")
        @Positive(message = "Service ID must be a positive number")
        Long serviceId,

        @NotNull(message = "Location ID cannot be null")
        @Positive(message = "Location ID must be a positive number")
        Long locationId

) {
}
