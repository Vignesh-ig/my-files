package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.plivo.api.exceptions.PlivoRestException;
import com.plivo.api.exceptions.PlivoValidationException;
import com.plivo.api.models.message.Message;
import com.plivo.api.models.message.MessageCreateResponse;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.api.dto.request.GetConfigValueRequest;
import com.rhombuzz.gpbackend.modules.api.service.ConfigService;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.appointment.service.AppointmentService;
import com.rhombuzz.gpbackend.modules.communication.dto.SMSMessageDTO;
import com.rhombuzz.gpbackend.modules.communication.dto.request.MessageRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSSendRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MessagePatientResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSSendResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMS;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.MessageStatus;
import com.rhombuzz.gpbackend.modules.communication.event.model.EventType;
import com.rhombuzz.gpbackend.modules.communication.repository.SMSRepository;
import com.rhombuzz.gpbackend.modules.communication.service.SMSService;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.net.URI;
import java.util.Collections;

@Slf4j
@Service
@RequiredArgsConstructor
public class SMSServiceImpl implements SMSService {
    private final ConfigService configService;
    private final SMSRepository smsRepository;

    private final AppointmentService appointmentService;
    private final PatientCommunicationService patientCommunicationService;
    private final PatientService patientService;

    @Override
    public SMSSendResponse sendSMS(SMSSendRequest request) {
        log.info("Send SMS method called");
        String serverUrl = configService.getConfigValue(new GetConfigValueRequest("SERVER_URL", "GENERAL"))
                .orElseThrow(() -> new NotFoundException("Server URL not configured"));

        String statusDeliveryUrl = serverUrl + "/api/v1/sms-status";

        String fromNumber = sanitizeNumber(request.fromNumber());
        String toNumber = sanitizeNumber(request.toNumber());

        MessageCreateResponse response;

        try {
            response = Message.creator(
                    fromNumber,
                    Collections.singletonList(toNumber),
                    request.message()
            ).url(URI.create(statusDeliveryUrl).toURL()).create();
            String messageUuid = response.getMessageUuid().getFirst();

            boolean success;
            Message statusResponse = Message.getter(messageUuid).get();
            String sentStatus = statusResponse.getMessageState();
            log.info("SMS sent with UUID: {}, Status: {}", messageUuid, sentStatus);
            success = sentStatus != null &&
                    MessageStatus.fromString(sentStatus) == MessageStatus.SENT ||
                    MessageStatus.fromString(sentStatus) == MessageStatus.DELIVERED ||
                    MessageStatus.fromString(sentStatus) == MessageStatus.QUEUED;

            saveToSmsTable(request.groupId(), request.patientId(), request.message(), request.senderName(), messageUuid, success);
            return new SMSSendResponse(success, messageUuid);

        } catch (IOException | PlivoRestException | PlivoValidationException e) {
            log.error("Error sending SMS: {}", e.getMessage());
            saveToSmsTable(request.groupId(), request.patientId(), request.message(), request.senderName(), null, false);
            return new SMSSendResponse(false, null);
        }
    }

    @Override
    public void sendDirectSMS(MessageRequest request) {
        log.info("Send direct SMS to patient with ID: {}", request.patientId());
        Appointment appointment = appointmentService.getLatestPatientAppointment(request.patientId(), request.groupId());
        patientCommunicationService.validateAndSendDirectSMS(request.groupId(), request.patientId(), appointment, request.content(), Utils.getCurrentUsername(), EventType.SYNC);
    }

    @Override
    public Page<MessagePatientResponse> getPatientsWithUnreadCount(String groupId, Long locationId, Boolean unreadOnly, Pageable pageable) {
        log.info("Retrieving message patients for groupId: {} and locationId: {}", groupId, locationId);
        if (Boolean.TRUE.equals(unreadOnly)) {
            return smsRepository.findUnreadPatients(groupId, locationId, pageable);
        }
        return smsRepository.findPatients(groupId, locationId, pageable);
    }

    @Override
    public Page<MessagePatientResponse> searchPatientsWithUnreadCount(String groupId, Long locationId, String searchTerm, Pageable pageable) {
        log.info("Searching message patients for groupId: {}, locationId: {}, searchTerm: {}", groupId, locationId, searchTerm);
        return smsRepository.findPatientsWithUnreadCountAndSearch(groupId, locationId, searchTerm, pageable);
    }

    private void saveToSmsTable(String groupId, Long patientId, String message, String sender, String messageUUID, boolean sentStatus) {
        log.info("Saving SMS to database for patientId: {} in group {}", patientId, groupId);
        Patient patient = patientService.getPatientById(patientId, groupId);
        patient.setCellPhoneValid(sentStatus);

        SMS sms = new SMS();
        SMS.SMSType smsType = sender.equalsIgnoreCase("PATIENT") ? SMS.SMSType.PATIENT : SMS.SMSType.SYSTEM;

        sms.setMedGroup(patient.getMedGroup());
        sms.setPatient(patient);
        sms.setSmsType(smsType);
        sms.setSender(sender);
        sms.setMessage(message);
        sms.setMessageUUID(messageUUID);
        sms.setDateTime(patient.getMedGroup().getCurrentDateTime());
        sms.setRead(smsType != SMS.SMSType.PATIENT);

        smsRepository.save(sms);
        log.info("SMS saved successfully for patientId: {} in group {}", patientId, groupId);
    }

    @Transactional
    @Override
    public Page<SMSMessageDTO> getSMSMessagesByPatientId(String groupId, Long patientId,
                                                        Integer unReadCount, Pageable pageable) {
        log.info("Fetching messages for patient ID: {}, group ID: {}", patientId, groupId);

        if (unReadCount != null && unReadCount > 0) {
            int updatedCount = smsRepository.markUnreadMessagesAsRead(groupId, patientId);
            log.debug("Successfully marked {} messages as read", updatedCount);
        }

       return smsRepository.findRecentMessages(groupId, patientId, pageable);
    }

    private String sanitizeNumber(String number) {
        String trimmedNumber = number.trim();
        return 10 == trimmedNumber.length() ? "1" + trimmedNumber : trimmedNumber;
    }

}
