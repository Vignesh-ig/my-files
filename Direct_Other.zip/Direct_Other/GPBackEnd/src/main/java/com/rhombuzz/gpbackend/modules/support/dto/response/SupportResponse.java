package com.rhombuzz.gpbackend.modules.support.dto.response;

import com.rhombuzz.gpbackend.modules.support.entity.Support;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class SupportResponse {
    private Long id;
    private String groupId;
    private String username;
    private Support.Problem problem;
    private String summary;

    public static SupportResponse fromEntity(Support support) {
        return SupportResponse.builder()
                .id(support.getId())
                .groupId(support.getMedGroup().getGroupId())
                .username(support.getUsername())
                .problem(support.getProblem())
                .summary(support.getSummary())
                .build();
    }
}
