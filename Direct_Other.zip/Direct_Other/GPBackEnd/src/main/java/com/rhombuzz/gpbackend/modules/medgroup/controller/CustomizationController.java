package com.rhombuzz.gpbackend.modules.medgroup.controller;

import com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormBuilderSettingResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.CustomizationRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.CustomizationResponse;
import com.rhombuzz.gpbackend.modules.medgroup.service.CustomizationService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/customizations")
@Validated
public class CustomizationController {
    private final CustomizationService customizationService;

    @GetMapping
    public ResponseEntity<CustomizationResponse> getCustomizations(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        CustomizationResponse customization = customizationService.getCustomization(groupId);
        return ResponseEntity.ok(customization);
    }

    @PatchMapping
    public ResponseEntity<Void> updateCustomization(@RequestBody @Valid CustomizationRequest request) {
        customizationService.updateCustomization(request);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/thank-you-page-content")
    public ResponseEntity<?> getThankYouPageContent(@RequestParam String groupId) {
        return ResponseEntity.ok(customizationService.getThankYouPageContent(groupId));
    }

    @GetMapping("/appointment-form-builder-setting")
    @PreAuthorize("hasRole("+ AccessType.SUPER_USER +")")
    public ResponseEntity<AppointmentFormBuilderSettingResponse> getAppointmentFormBuilderSetting(@RequestParam String groupId) {
        AppointmentFormBuilderSettingResponse setting = customizationService.getAppointmentFormBuilderSetting(groupId);
        return ResponseEntity.ok(setting);
    }
}
