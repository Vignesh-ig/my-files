package com.rhombuzz.gpbackend.modules.task.repository;

import com.rhombuzz.gpbackend.modules.task.entity.TodoList;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface TodoListRepository extends JpaRepository<TodoList, Long> {

    @Query("SELECT t FROM TodoList t WHERE t.id = ?1 AND t.medGroup.groupId = ?2 AND t.isDeleted = false")
    Optional<TodoList> findById(Long id, String groupId);

    @Query("SELECT t FROM TodoList t WHERE t.medGroup.groupId = ?1 AND t.isDeleted = false ORDER BY t.dateTime DESC")
    Page<TodoList> findByGroupId(String groupId, Pageable pageable);

    @Modifying
    @Query("UPDATE TodoList t SET t.isRead = ?1 WHERE t.medGroup.groupId = ?2 AND t.isDeleted = false")
    void updateReadTodoList(boolean isRead, String groupId);
}
