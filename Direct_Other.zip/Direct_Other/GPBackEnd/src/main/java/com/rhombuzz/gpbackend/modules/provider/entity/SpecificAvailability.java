package com.rhombuzz.gpbackend.modules.provider.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveSpecificAvailabilityRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "specific_availabilities", indexes = {
        @Index(name = "idx_specific_availability_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_specific_availability_provider_id", columnList = "provider_id"),
        @Index(name = "idx_specific_availability_location_id", columnList = "location_id")
})
public class SpecificAvailability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "provider_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Provider provider;

    @ManyToOne
    @JoinColumn(name = "location_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Location location;

    @Column(name = "schedule_date", nullable = false)
    private LocalDate scheduleDate;

    @Column(name = "start_time", nullable = false, columnDefinition = "TIME(0)")
    private LocalTime startTime;

    @Column(name = "end_time", nullable = false, columnDefinition = "TIME(0)")
    private LocalTime endTime;

    @Column(name = "day", length = 45, nullable = false)
    @Enumerated(EnumType.STRING)
    private DayOfWeek day;

    public static SpecificAvailability fromRequest(SaveSpecificAvailabilityRequest request) {
        return SpecificAvailability.builder()
                .scheduleDate(request.date())
                .startTime(request.startTime())
                .endTime(request.endTime())
                .day(request.date().getDayOfWeek())
                .build();
    }
}
