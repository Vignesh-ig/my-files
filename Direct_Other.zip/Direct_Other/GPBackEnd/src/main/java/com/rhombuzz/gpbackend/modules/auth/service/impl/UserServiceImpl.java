package com.rhombuzz.gpbackend.modules.auth.service.impl;

import com.auth0.client.mgmt.RolesEntity;
import com.auth0.client.mgmt.UsersEntity;
import com.auth0.client.mgmt.filter.RolesFilter;
import com.auth0.client.mgmt.filter.UserFilter;
import com.auth0.exception.APIException;
import com.auth0.exception.Auth0Exception;
import com.auth0.json.mgmt.roles.RolesPage;
import com.auth0.json.mgmt.users.User;
import com.auth0.json.mgmt.users.UsersPage;
import com.rhombuzz.gpbackend.component.TokenValidator;
import com.rhombuzz.gpbackend.enums.Role;
import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.auth.dto.request.SaveUserRequest;
import com.rhombuzz.gpbackend.modules.auth.dto.response.UserExistsResponse;
import com.rhombuzz.gpbackend.modules.auth.dto.response.UserResponse;
import com.rhombuzz.gpbackend.modules.auth.repository.UserRepository;
import com.rhombuzz.gpbackend.modules.auth.service.UserService;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class UserServiceImpl implements UserService {
    private final String auth0Database;
    private final UserRepository userRepository;
    private final TokenValidator tokenValidator;
    private final PasswordEncoder passwordEncoder;
    private final UserFilter userFilter;

    public UserServiceImpl(String auth0Database,
                           TokenValidator tokenValidator,
                           PasswordEncoder passwordEncoder,
                           UserRepository userRepository) {
        this.auth0Database = auth0Database;
        this.tokenValidator = tokenValidator;
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
        this.userFilter = new UserFilter()
                .withSearchEngine("v3")
                .withConnection(auth0Database);
    }

    @Override
    public void saveUser(SaveUserRequest request) {
        log.info("Saving user with name: {}", request.getUsername());

        checkUserExists(request);
        validateRoleId(request.getRoleId());

        User user = buildUser(request);

        try {
            User createdUser = executeWithRetry(() ->
                    getUsers().create(user).execute().getBody()
            );

            if (createdUser == null) {
                throw new InternalServerErrorException("User creation response body was null");
            }

            assignRoleToUser(request.getRoleId(), createdUser.getId());
            persistUserToDatabase(createdUser.getId(), request.getPassword(), createdUser.getUsername(), request.getGroupId());

        } catch (Auth0Exception e) {
            log.error("Failed to create user: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to create user: " + e.getMessage());
        }
    }

    @Override
    public UserResponse getUser(String userId, String groupId) {
        log.info("Getting user with id: {} and groupId: {}", userId, groupId);

        User user = fetchAndValidateUser(userId, groupId);
        UserResponse response = UserResponse.fromEntity(user);
        enrichWithRole(response, user.getId());

        return response;
    }

    @Override
    public List<UserResponse> getUsers(String groupId) {
        log.info("Getting users with groupId: {}", groupId);

        try {
            userFilter.withQuery("user_metadata.groupId:" + groupId);
            UsersPage usersPage = executeWithRetry(() ->
                    getUsers().list(userFilter).execute().getBody()
            );

            if (usersPage == null || CollectionUtils.isEmpty(usersPage.getItems())) {
                noUserFoundLog(groupId);
                return Collections.emptyList();
            }

            return usersPage.getItems().parallelStream()
                    .map(this::mapToUserResponse)
                    .toList();

        } catch (Auth0Exception e) {
            log.error("Failed to get users: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to get users: " + e.getMessage());
        }
    }

    @Override
    public void deleteUser(String userId, String groupId) {
        log.info("Deleting user with id: {} and groupId: {}", userId, groupId);

        User user = fetchAndValidateUser(userId, groupId);

        try {
            executeWithRetry(() -> {
                getUsers().delete(user.getId()).execute();
                return null;
            });
            userRepository.deleteById(user.getId());
            log.info("User with id: {} deleted successfully", userId);
        } catch (Auth0Exception e) {
            log.error("Failed to delete user: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to delete user: " + e.getMessage());
        }
    }

    @Override
    public void updateEmail(String userId, String groupId, String email) {
        log.info("Updating email for user with id: {} and groupId: {}", userId, groupId);

        fetchAndValidateUser(userId, groupId);

        if (checkUserExistsByEmail(email)) {
            throw new ConflictException("User with email '" + email + "' already exists");
        }

        User user = new User();
        user.setEmail(email);

        try {
            executeWithRetry(() -> {
                getUsers().update(userId, user).execute();
                return null;
            });
            log.info("Email updated successfully for user with id: {}", userId);
        } catch (Auth0Exception e) {
            log.error("Failed to update email: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to update email: " + e.getMessage());
        }
    }

    @Override
    public void updateRole(String userId, String groupId, String oldRoleId, String newRoleId) {
        log.info("Updating role for user with id: {} and groupId: {}", userId, groupId);

        if (oldRoleId.equals(newRoleId)) {
            throw new BadRequestException("Old role ID is the same as new role ID");
        }

        fetchAndValidateUser(userId, groupId);
        validateRoleIds(oldRoleId, newRoleId);

        try {
            executeWithRetry(() -> {
                getUsers().removeRoles(userId, List.of(oldRoleId)).execute();
                getUsers().addRoles(userId, List.of(newRoleId)).execute();
                return null;
            });
        } catch (Auth0Exception e) {
            log.error("Failed to update role for user {}: {}", userId, e.getMessage());
            throw new InternalServerErrorException("Failed to update role: " + e.getMessage());
        }
    }

    @Override
    public UserExistsResponse isUserExists(String username, String email) {
        log.info("Checking if user with username: {} or email: {} exists", username, email);

        return new UserExistsResponse(
                checkUserExistsByEmail(email),
                checkUserExistsByUsername(username)
        );
    }

    @Override
    public List<UserResponse.Role> getGroupRoles() {
        log.info("Fetching group roles");

        try {
            RolesPage rolesPage = executeWithRetry(() ->
                    getRoles().list(null).execute().getBody()
            );

            if (rolesPage == null || CollectionUtils.isEmpty(rolesPage.getItems())) {
                log.info("No roles found");
                return Collections.emptyList();
            }

            return rolesPage.getItems().stream()
                    .filter(role -> !isSystemRole(role.getName()))
                    .map(this::mapToRoleResponse)
                    .toList();

        } catch (Auth0Exception e) {
            log.error("Failed to get group roles: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to get group roles: " + e.getMessage());
        }
    }

    @Override
    public UserResponse.Role getManagementRole() {
        log.info("Fetching management role");

        try {
            RolesPage rolesPage = executeWithRetry(() ->
                    getRoles().list(new RolesFilter().withName(Role.MANAGEMENT.name()))
                            .execute().getBody()
            );

            if (rolesPage == null || CollectionUtils.isEmpty(rolesPage.getItems())) {
                log.info("No management role found");
                return null;
            }

            return mapToRoleResponse(rolesPage.getItems().getFirst());

        } catch (Auth0Exception e) {
            log.error("Failed to get management role: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to get management role: " + e.getMessage());
        }
    }

    @Override
    public void changePassword(String userId, String groupId, String oldPassword, String newPassword) {
        log.info("Changing password for user with id: {} and groupId: {}", userId, groupId);

        if (oldPassword.equals(newPassword)) {
            throw new BadRequestException("Old password is the same as new password");
        }

        fetchAndValidateUser(userId, groupId);

        com.rhombuzz.gpbackend.modules.auth.entity.User existingUser =
                userRepository.findById(userId)
                        .orElseThrow(() -> new NotFoundException("User not found"));

        if (!passwordEncoder.matches(oldPassword, existingUser.getPassword())) {
            throw new BadRequestException("Old password does not match");
        }

        updatePasswordInAuth0AndDatabase(userId, newPassword, existingUser);
    }

    @Override
    public List<String> getUserNames(String groupId) {
        log.info("Fetching user names for groupId: {}", groupId);

        try {
            userFilter.withQuery("user_metadata.groupId:" + groupId);
            UsersPage usersPage = executeWithRetry(() ->
                    getUsers().list(userFilter).execute().getBody()
            );

            if (usersPage == null || CollectionUtils.isEmpty(usersPage.getItems())) {
                noUserFoundLog(groupId);
                return Collections.emptyList();
            }

            return usersPage.getItems().stream()
                    .map(User::getUsername)
                    .toList();

        } catch (Auth0Exception e) {
            log.error("Failed to get user names: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to get user names: " + e.getMessage());
        }
    }

    @Override
    public void blockUnblockUser(String userId, String groupId, boolean blockFlag) {
        String action = blockFlag ? "Blocking" : "Unblocking";
        log.info("{} user with id: {} and groupId: {}", action, userId, groupId);

        fetchAndValidateUser(userId, groupId);
        User user = new User();
        user.setBlocked(blockFlag);

        try {
            executeWithRetry(() -> {
                getUsers().update(userId, user).execute();
                return null;
            });
            log.info("User with id: {} {} successfully", userId, blockFlag ? "blocked" : "unblocked");
        } catch (Auth0Exception e) {
            log.error("Failed to block user: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to block user: " + e.getMessage());
        }
    }

    @Override
    @Transactional
    public void deleteUsers(String groupId) {

        log.info("Deleting users with groupId: {}", groupId);

        try {
            userFilter.withQuery("user_metadata.groupId:" + groupId);
            UsersPage usersPage = executeWithRetry(() ->
                    getUsers().list(userFilter).execute().getBody()
            );

            if (usersPage == null || CollectionUtils.isEmpty(usersPage.getItems())) {
                noUserFoundLog(groupId);
                return;
            }

            for (User user : usersPage.getItems()) {
                try {
                    executeWithRetry(() -> {
                        getUsers().delete(user.getId()).execute();
                        return null;
                    });
                } catch (Exception e) {
                    log.error("Failed to delete user with id {}: {}", user.getId(), e.getMessage());
                }
            }
            log.info("All users with groupId: {} deleted from Auth0", groupId);

            userRepository.deleteByGroupId(groupId);

        } catch (Exception e) {
            log.error("Failed to delete users of medgroup {}", groupId, e);
        }
    }

    private UsersEntity getUsers() {
        tokenValidator.refreshTokenIfExpired();
        return tokenValidator.users();
    }

    private RolesEntity getRoles() {
        tokenValidator.refreshTokenIfExpired();
        return tokenValidator.roles();
    }

    private <T> T executeWithRetry(Auth0Operation<T> operation) throws Auth0Exception {
        try {
            return operation.execute();
        } catch (APIException e) {
            if (e.getStatusCode() == 401) {
                log.warn("Token expired, refreshing and retrying");
                tokenValidator.refreshTokenIfExpired();
                return operation.execute();
            }
            throw e;
        }
    }

    private User buildUser(SaveUserRequest request) {
        User user = new User();
        user.setEmail(request.getEmail());
        user.setUsername(request.getUsername());
        user.setName(request.getFirstName() + " " + request.getLastName());
        user.setPassword(request.getPassword().toCharArray());
        user.setConnection(auth0Database);
        user.setUserMetadata(Map.of("groupId", request.getGroupId()));
        return user;
    }

    private void persistUserToDatabase(String userId, String password, String username, String groupId) {
        com.rhombuzz.gpbackend.modules.auth.entity.User user =
                new com.rhombuzz.gpbackend.modules.auth.entity.User();
        user.setUserId(userId);
        user.setPassword(passwordEncoder.encode(password));
        user.setUserName(username);
        user.setGroupId(groupId);
        userRepository.save(user);
        log.info("Saved user to Database with id: {}", userId);
    }

    private void validateRoleId(String roleId) {
        log.info("Validating role id {}", roleId);
        try {
            com.auth0.json.mgmt.roles.Role role = executeWithRetry(() ->
                    getRoles().get(roleId).execute().getBody()
            );
            if (role == null) {
                throw new NotFoundException("Role with id " + roleId + " not found");
            }
        } catch (Auth0Exception e) {
            log.error("Failed to validate role id: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to validate role id: " + e.getMessage());
        }
    }

    private void validateRoleIds(String... roleIds) {
        for (String roleId : roleIds) {
            validateRoleId(roleId);
        }
    }

    private User fetchAndValidateUser(String userId, String groupId) {
        try {
            User user = executeWithRetry(() ->
                    getUsers().get(userId, userFilter).execute().getBody()
            );

            validateUserBelongsToGroup(user, userId, groupId);
            return user;

        } catch (APIException e) {
            if (e.getStatusCode() == 404) {
                throw new NotFoundException("User not found");
            }
            throw new InternalServerErrorException("Failed to fetch user: " + e.getMessage());
        } catch (Auth0Exception e) {
            log.error("Failed to fetch user: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to fetch user: " + e.getMessage());
        }
    }

    private void validateUserBelongsToGroup(User user, String userId, String groupId) {
        Map<String, Object> userMetadata = user.getUserMetadata();
        if (userMetadata == null || !groupId.equals(userMetadata.get("groupId"))) {
            log.error("User {} doesn't belong to group {}", userId, groupId);
            throw new BadRequestException("User not found in specified group");
        }
    }

    private void checkUserExists(SaveUserRequest request) {
        if (checkUserExistsByEmail(request.getEmail())) {
            throw new ConflictException("User with email '" + request.getEmail() + "' already exists");
        }
        if (checkUserExistsByUsername(request.getUsername())) {
            throw new ConflictException("User with username '" + request.getUsername() + "' already exists");
        }
    }

    private boolean checkUserExistsByEmail(String email) {
        try {
            List<User> users = executeWithRetry(() ->
                    getUsers().listByEmail(email, userFilter).execute().getBody()
            );
            return users != null && !users.isEmpty();
        } catch (Auth0Exception e) {
            log.error("Failed to check user existence by email: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to check user existence by email: " + e.getMessage());
        }
    }

    private boolean checkUserExistsByUsername(String username) {
        try {
            userFilter.withQuery("username:" + username);
            UsersPage page = executeWithRetry(() ->
                    getUsers().list(userFilter).execute().getBody()
            );
            return page != null && !CollectionUtils.isEmpty(page.getItems());
        } catch (Auth0Exception e) {
            log.error("Failed to check user existence by username: {}", e.getMessage());
            throw new InternalServerErrorException("Failed to check user existence by username: " + e.getMessage());
        }
    }

    private void assignRoleToUser(String roleId, String userId) {
        try {
            executeWithRetry(() -> {
                getRoles().assignUsers(roleId, List.of(userId)).execute();
                return null;
            });
            log.info("Role {} assigned to user {}", roleId, userId);
        } catch (Auth0Exception e) {
            throw new InternalServerErrorException("Failed to assign role: " + e.getMessage());
        }
    }

    private void enrichWithRole(UserResponse response, String userId) {
        try {
            RolesPage rolesPage = executeWithRetry(() ->
                    getUsers().listRoles(userId, null).execute().getBody()
            );

            if (rolesPage != null && !CollectionUtils.isEmpty(rolesPage.getItems())) {
                response.setRole(mapToRoleResponse(rolesPage.getItems().getFirst()));
            }
        } catch (Auth0Exception e) {
            log.warn("Failed to fetch roles for user {}: {}", userId, e.getMessage());
        }
    }

    private UserResponse mapToUserResponse(User user) {
        UserResponse response = UserResponse.fromEntity(user);
        enrichWithRole(response, user.getId());
        return response;
    }

    private UserResponse.Role mapToRoleResponse(com.auth0.json.mgmt.roles.Role role) {
        try {
            return new UserResponse.Role(
                    role.getId(),
                    Role.valueOf(role.getName().toUpperCase())
            );
        } catch (IllegalArgumentException e) {
            log.warn("Invalid role name: {}", role.getName());
            return null;
        }
    }

    private boolean isSystemRole(String roleName) {
        return Role.ADMIN.name().equalsIgnoreCase(roleName) ||
                Role.MANAGEMENT.name().equalsIgnoreCase(roleName);
    }

    private void updatePasswordInAuth0AndDatabase(String userId, String newPassword,
                                                  com.rhombuzz.gpbackend.modules.auth.entity.User existingUser) {
        User user = new User();
        user.setPassword(newPassword.toCharArray());

        try {
            executeWithRetry(() -> {
                getUsers().update(userId, user).execute();
                return null;
            });

            existingUser.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(existingUser);
            log.info("Password changed successfully for user with id: {}", userId);

        } catch (Auth0Exception e) {
            log.error("Failed to change password for user {}: {}", userId, e.getMessage());
            throw new InternalServerErrorException("Failed to change password: " + e.getMessage());
        }
    }

    private void noUserFoundLog(String groupId) {
        log.info("No users found for groupId: {}", groupId);
    }

    @FunctionalInterface
    private interface Auth0Operation<T> {
        T execute() throws Auth0Exception;
    }
}