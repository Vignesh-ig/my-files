package com.rhombuzz.gpbackend.modules.provider.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.LocationService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.provider.dto.RecurringAvailabilityDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.TimeValidationDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveRecurringAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.RecurringAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.provider.entity.RecurringAvailability;
import com.rhombuzz.gpbackend.modules.provider.repository.RecurringAvailabilityRepository;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import com.rhombuzz.gpbackend.modules.provider.service.RecurringAvailabilityService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class RecurringAvailabilityServiceImpl implements RecurringAvailabilityService {
    private static final String ACTIVITY_TYPE = "MANAGE AVAILABILITY";

    private final RecurringAvailabilityRepository recurringAvailabilityRepository;
    private final ProviderService providerService;
    private final LocationService locationService;
    private final ActivityService activityService;
    private final MedGroupService medGroupService;

    @Override
    public void saveRecurringAvailability(SaveRecurringAvailabilityRequest request) {
        log.info("Saving recurring availability for provider {} on {}",
                request.providerId(), request.dayOfWeek());

        Utils.validateTimeOrder(
                request.recurringAvailabilities().stream()
                        .map(dto -> new TimeValidationDTO(dto.startTime(), dto.endTime()))
                        .toList()
        );

        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Provider provider = providerService.getProviderById(request.providerId(), request.groupId());

        List<RecurringAvailability> availabilitiesToSave = request.recurringAvailabilities().stream()
                .map(dto -> dto.id() != null
                        ? updateExistingAvailability(dto, request)
                        : buildNewAvailability(dto, request, medGroup, provider))
                .toList();

        if (availabilitiesToSave.isEmpty()) {
            log.info("No new or updated availabilities for provider {}", request.providerId());
            return;
        }

        List<RecurringAvailability> saved = recurringAvailabilityRepository.saveAll(availabilitiesToSave);
        log.info("Saved {} availabilities for provider {}", saved.size(), request.providerId());

        saveActivity(
                request.groupId(),
                String.format("The user (%s) has added/updated availability slots for provider (%s) on (%s).",
                        Utils.getCurrentUsername(), provider.getName(), request.dayOfWeek()),
                provider
        );

        // Todo: Notify waitlist Patients
    }

    @Override
    public Map<DayOfWeek, List<RecurringAvailabilityResponse>> getRecurringAvailabilities(Long providerId, String groupId) {
        log.info("Fetching recurring availabilities for provider: {}", providerId);

        return recurringAvailabilityRepository.findByProviderId(providerId, groupId).stream()
                .collect(Collectors.groupingBy(RecurringAvailabilityResponse::getDay));
    }

    @Override
    @Transactional
    public void deleteRecurringAvailability(Long id, Long providerId, Long locationId, String groupId) {
        log.info("Deleting recurring availability ID: {}", id);

        RecurringAvailability recurringAvailability = recurringAvailabilityRepository.findById(id, providerId, locationId, groupId)
                .orElseThrow(() -> throwNotFoundException(id, providerId, groupId));

        recurringAvailabilityRepository.deleteById(id, providerId, locationId, groupId);
        log.info("Deleted recurring availability ID: {}", id);

        String description = String.format("The user (%s) has deleted an availability slot for provider (%s) on (%s).",
                Utils.getCurrentUsername(), recurringAvailability.getProvider().getName(), recurringAvailability.getDay());
        saveActivity(groupId, description, recurringAvailability.getProvider());
    }

    private RecurringAvailability updateExistingAvailability(RecurringAvailabilityDTO dto, SaveRecurringAvailabilityRequest request) {
        RecurringAvailability availability = recurringAvailabilityRepository
                .findById(dto.id(), request.providerId(), request.groupId())
                .orElseThrow(() -> throwNotFoundException(dto.id(), request.providerId(), request.groupId()));

        availability.setStartTime(dto.startTime());
        availability.setEndTime(dto.endTime());

        if (!availability.getLocation().getId().equals(dto.locationId())) {
            checkLocationExists(dto.locationId(), request.groupId());
            Location newLocation = Location.builder().id(dto.locationId()).build();
            availability.setLocation(newLocation);
        }
        return availability;
    }

    private NotFoundException throwNotFoundException(Long id, Long providerId, String groupId) {
        log.error("Recurring availability not found for ID: {} and provider ID: {} in group: {}", id, providerId, groupId);
        return new NotFoundException("Recurring availability not found");
    }

    private RecurringAvailability buildNewAvailability(
            RecurringAvailabilityDTO dto,
            SaveRecurringAvailabilityRequest request,
            MedGroup medGroup,
            Provider provider) {

        checkLocationExists(dto.locationId(), request.groupId());
        Location location = Location.builder().id(dto.locationId()).build();

        return RecurringAvailability.builder()
                .medGroup(medGroup)
                .day(request.dayOfWeek())
                .startTime(dto.startTime())
                .endTime(dto.endTime())
                .location(location)
                .provider(provider)
                .build();
    }

    private void checkLocationExists(Long locationId, String groupId) {
        if (!locationService.isLocationExists(locationId, groupId)) {
            log.error("Location ID: {} not found in group: {}", locationId, groupId);
            throw new NotFoundException("Location not found");
        }
    }

    private void saveActivity(String groupId, String description, Provider provider) {
        ActivityRequest activityRequest = new ActivityRequest() {{
            setGroupId(groupId);
            setProvider(provider);
            setActivityDescription(description);
            setActivityType(ACTIVITY_TYPE);
        }};

        activityService.saveActivity(activityRequest);
    }
}