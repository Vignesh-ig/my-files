package com.rhombuzz.gpbackend.modules.medgroup.service;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.UpdateDashboardFlagRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.UpdateAdminFlagRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.AdminFlagResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.DashboardFlagResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

@Validated
public interface MedGroupFlagService {

    void updateAdminFlag(
            @Valid UpdateAdminFlagRequest request
    );

    AdminFlagResponse getAdminFlag(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateDashboardFlag(
            @Valid UpdateDashboardFlagRequest request
    );

    DashboardFlagResponse getDashboardFlag(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
