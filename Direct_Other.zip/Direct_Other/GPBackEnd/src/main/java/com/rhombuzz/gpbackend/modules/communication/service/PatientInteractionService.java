package com.rhombuzz.gpbackend.modules.communication.service;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.dto.request.PatientMessageRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMS;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSStatus;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.MessageStatus;
import com.rhombuzz.gpbackend.modules.communication.event.model.EventType;
import com.rhombuzz.gpbackend.modules.communication.repository.SMSRepository;
import com.rhombuzz.gpbackend.modules.communication.repository.SMSStatusRepository;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationService;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.MedGroupTimingResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.entity.OfficeClosure;
import com.rhombuzz.gpbackend.modules.medgroup.entity.embeddable.DayTiming;
import com.rhombuzz.gpbackend.modules.medgroup.repository.MedGroupRepository;
import com.rhombuzz.gpbackend.modules.medgroup.repository.OfficeClosureRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupFlagService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupTimingService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.repository.PatientRepository;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PatientInteractionService {

    private final MedGroupRepository medGroupRepository;
    private final PatientRepository patientRepository;
    private final MedGroupFlagService medGroupFlagService;
    private final OfficeClosureRepository officeClosureRepository;
    private final MedGroupTimingService medGroupTimingService;
    private final SMSTemplateService smsTemplateService;
    private final SMSRepository smsRepository;
    private final PatientCommunicationService patientCommunicationService;
    private final SMSStatusRepository smsStatusRepository;
    private final ActivityService activityService;

    public void processPatientSMS(PatientMessageRequest request) {
        log.info("Processing patient SMS: from={}, to={}, text={}, messageUUID={}", request.from(), request.to(), request.text(), request.messageUUID());
        String fromNumber = request.from().substring(1);
        String toNumber = request.to().substring(1);
        String text = sanitizeText(request.text());
        String messageUUID = request.messageUUID();

        Optional<MedGroup> medgroupOpt = medGroupRepository.findByEmsPhone(toNumber);
        if (medgroupOpt.isEmpty()) {
            medgroupOpt = medGroupRepository.findByEmsTollFreePhoneNumber(toNumber);
            if (medgroupOpt.isEmpty()) {
                log.error("Medgroup not found for phone number: {}", toNumber);
                throw new RuntimeException("Medgroup not found for this Patient SMS");
            }
            log.debug("Alert: Medgroup received reply from patient {} to toll free number {}",
                    fromNumber, toNumber);
        }

        MedGroup medGroup = medgroupOpt.get();
        String groupId = medGroup.getGroupId();

        List<Patient> patients = patientRepository.findByCellPhoneAndGroupId(fromNumber, groupId);
        LocalDateTime currentDateTime = medGroup.getCurrentDateTime();

        if (patients.isEmpty()) {
            log.info("Handling unknown patient: fromNumber={}, text={}, messageUUID={}, groupId={}", fromNumber, text, messageUUID, groupId);
            handleUnknownPatient(fromNumber, text, messageUUID, medGroup, currentDateTime);
            return;
        }

        Patient patient = patients.getFirst();
        log.debug("Found patient: patientId={}, groupId={}", patient.getId(), groupId);


        saveToSMSTable(medGroup, patient, text, messageUUID, currentDateTime);
        saveToSMSStatusTable(medGroup, patient, messageUUID, currentDateTime);

        PreferredLanguage preferredLanguage = Optional.ofNullable(patient.getPreferredLanguage())
                .orElse(PreferredLanguage.ENGLISH);

        if (patient.getOptOut() != ContactMethod.SMS) {
            processPatientMessage(patient, medGroup, text, preferredLanguage, currentDateTime);
        } else {
            processOptedOutPatient(patient, medGroup, text);
        }
        log.info("Completed processing patient SMS: from={}, to={}, messageUUID={}", request.from(), request.to(), request.messageUUID());
    }

    private String sanitizeText(String text) {
        if (text == null) return "";

        text = text.replaceAll("(\\r|\\n|\\r\\n)+", "\\\\n");
        text = text.replaceAll("\\\\", "\\\\\\\\");
        text = text.replaceAll("\"", "\\\\\"");
        text = text.replaceAll("'", "\\\\'");
        text = text.replaceAll("/", "\\\\/");
        return text.trim();
    }

    private void saveToSMSStatusTable(MedGroup medGroup, Patient patient, String messageUUID, LocalDateTime currentDateTime) {
        SMSStatus smsStatus = new SMSStatus();
        smsStatus.setMedGroup(medGroup);
        smsStatus.setPatient(patient);
        smsStatus.setMessageUUID(messageUUID);
        smsStatus.setSmsDate(currentDateTime.toLocalDate());
        smsStatus.setMessageStatus(MessageStatus.RECEIVED);

        smsStatusRepository.save(smsStatus);
    }

    private void saveToSMSTable(MedGroup medGroup, Patient patient, String text, String messageUUID, LocalDateTime currentDateTime) {
        log.info("Saving SMS to for patient ID: {} in group ID: {}", patient.getId(), medGroup.getGroupId());
        boolean isRead = text.equalsIgnoreCase("start");

        SMS sms = new SMS();
        sms.setMedGroup(medGroup);
        sms.setPatient(patient);
        sms.setDateTime(currentDateTime);
        sms.setMessage(text);
        sms.setSmsType(SMS.SMSType.PATIENT);
        sms.setSender("PATIENT");
        sms.setMessageUUID(messageUUID);
        sms.setRead(isRead);

        smsRepository.save(sms);
        log.info("SMS saved successfully for patient ID: {} in group ID: {}", patient.getId(), medGroup.getGroupId());
    }

    private void handleUnknownPatient(String fromNumber, String text, String messageUUID, MedGroup medGroup, LocalDateTime currentDateTime) {
        String groupId = medGroup.getGroupId();
        log.debug("Creating unknown patient record: fromNumber={}, text={}, messageUUID={}, groupId={}", fromNumber, text, messageUUID, groupId);

        Patient unknownPatient = new Patient();
        unknownPatient.setFirstName("Unknown");
        unknownPatient.setLastName(currentDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH:mm:ss")));
        unknownPatient.setDob(currentDateTime.toLocalDate());
        unknownPatient.setCellPhone(fromNumber);
        unknownPatient.setMedGroup(medGroup);

        patientRepository.save(unknownPatient);
        log.info("Saved unknown patient record: patientId={}, groupId={}", unknownPatient.getId(), groupId);

        saveToSMSTable(medGroup, unknownPatient, text, messageUUID, currentDateTime);
        saveToSMSStatusTable(medGroup, unknownPatient, messageUUID, currentDateTime);

        String content = smsTemplateService.getSMSTemplate("UNKNOWN_CONTACT_WORKFLOW", groupId, PreferredLanguage.ENGLISH)
                .getContent();
        sendSMS(unknownPatient.getId(), groupId, content);
    }

    private void sendSMS(Long patientId, String groupId, String content) {
        patientCommunicationService.validateAndSendDirectSMS(groupId, patientId, null, content, "SYSTEM", EventType.ASYNC);
    }

    private void processOptedOutPatient(Patient patient, MedGroup medGroup, String text) {
        log.debug("Processing opted-out patient: patientId={}, text={}", patient.getId(), text);
        Long patientId = patient.getId();
        String groupId = medGroup.getGroupId();

        if (text.equalsIgnoreCase("start")) {
            log.info("Handling opt-in for patient: patientId={}, groupId={}", patientId, groupId);
            handleOptIn(groupId, patient, text);
        } else {
            log.debug("Ignoring message from opted-out patient: patientId={}, text={}", patientId, text);

            String description = String.format("Patient (%s %s) opted out of getting SMS messages. " +
                    "Message was not sent. They can still send text messages.", patient.getFirstName(), patient.getLastName());
            saveToActivity(groupId, patient, description, text);
        }
    }

    private void saveToActivity(String groupId, Patient patient, String description, String text) {
        ActivityRequest request = new ActivityRequest();
        request.setGroupId(groupId);
        request.setPatient(patient);
        request.setActivityDescription(description);
        request.setContent(text);
        request.setActivityType("SMS");

        activityService.saveActivity(request);
    }

    private void handleOptIn(String groupId, Patient patient, String text) {
        log.info("Opting in patient: patientId={}", patient.getId());
        patient.setOptOut(null);
        patientRepository.save(patient);
        log.debug("Patient opted in successfully: patientId={}", patient.getId());

        String description = String.format("Patient (%s %s) sent a message with the word start. " +
                "They are going to be getting SMS messages again from the medgroup.", patient.getFirstName(), patient.getLastName());
        saveToActivity(groupId, patient, description, text);
    }

    private void processPatientMessage(Patient patient, MedGroup medGroup, String text, PreferredLanguage preferredLanguage, LocalDateTime currentDateTime) {
        log.debug("Processing patient message: patientId={}, text={}", patient.getId(), text);

        if (text.equalsIgnoreCase("stop")) {
            log.info("Handling opt-out for patient: patientId={}", patient.getId());
            handleOptOut(medGroup, patient, text);
            return;
        }

        boolean isDuringOfficeHours = checkOfficeHours(medGroup, currentDateTime);
        log.debug("Office hours check: isDuringOfficeHours={}, groupId={}", isDuringOfficeHours, medGroup.getGroupId());

        if (!isDuringOfficeHours) {
            log.info("Sending auto-reply to patient: patientId={}, groupId={}", patient.getId(), medGroup.getGroupId());
            sendAutoReplyMessage(patient, medGroup, preferredLanguage, currentDateTime);
        }

        String description = String.format("Patient (%s %s) sent a SMS message.", patient.getFirstName(), patient.getLastName());
        saveToActivity(medGroup.getGroupId(), patient, description, text);
    }

    private void handleOptOut(MedGroup medGroup, Patient patient, String text) {
        log.info("Opting out patient: patientId={}", patient.getId());
        patient.setOptOut(ContactMethod.SMS);
        patientRepository.save(patient);
        log.debug("Patient opted out successfully: patientId={}", patient.getId());

        String description = String.format("Patient (%s %s) sent a message with the word stop. " +
                "They will no longer get any SMS messages from the medgroup.", patient.getFirstName(), patient.getLastName());
        saveToActivity(medGroup.getGroupId(), patient, description, text);
    }

    private void sendAutoReplyMessage(Patient patient, MedGroup medGroup, PreferredLanguage preferredLanguage, LocalDateTime currentDateTime) {
        Long patientId = patient.getId();
        String groupId = medGroup.getGroupId();

        SMSTemplateResponse template = smsTemplateService.getSMSTemplate("AUTO_REPLY_TEXT_MESSAGE", groupId, preferredLanguage);
        String content = template.getContent();
        Optional<OfficeClosure> officeClosureOptional = officeClosureRepository.findByCloseDate(groupId, currentDateTime.toLocalDate());

        if (officeClosureOptional.isPresent()) {
            OfficeClosure officeClosure = officeClosureOptional.get();
            if (officeClosure.getReason() != null) {
                content += "Reason: " + officeClosure.getReason();
            }
        }

        sendSMS(patientId, groupId, content);
    }

    private boolean checkOfficeHours(MedGroup medGroup, LocalDateTime currentDateTime) {
        log.info("Checking office hours");
        boolean isOfficeClosedAutoReply = medGroupFlagService.getDashboardFlag(medGroup.getGroupId()).isOfficeClosedAutoReply();
        if (!isOfficeClosedAutoReply) {
            return true;
        }

        LocalDate currentDate = currentDateTime.toLocalDate();
        LocalTime currentTime = currentDateTime.toLocalTime();

        boolean exists = officeClosureRepository.existsByCloseDate(medGroup.getGroupId(), currentDate);

        if (exists) {
            return false;
        }

        DayTiming dayTiming = getTime(currentDate, medGroup.getGroupId());

        LocalTime startTime = dayTiming.getStartTime();
        LocalTime endTime = dayTiming.getEndTime();

        return startTime != null && endTime != null && currentTime.isAfter(startTime) && currentTime.isBefore(endTime);

    }

    private DayTiming getTime(LocalDate currentDate, String groupId) {
        MedGroupTimingResponse timing = medGroupTimingService.getMedGroupTiming(groupId);
        return switch (currentDate.getDayOfWeek()) {
            case SUNDAY -> timing.getSunday();
            case MONDAY -> timing.getMonday();
            case TUESDAY ->  timing.getTuesday();
            case WEDNESDAY -> timing.getWednesday();
            case THURSDAY -> timing.getThursday();
            case FRIDAY -> timing.getFriday();
            case SATURDAY -> timing.getSaturday();
        };
    }
}