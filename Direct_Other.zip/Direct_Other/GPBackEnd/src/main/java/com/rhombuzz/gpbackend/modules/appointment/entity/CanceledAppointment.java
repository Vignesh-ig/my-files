package com.rhombuzz.gpbackend.modules.appointment.entity;

import com.rhombuzz.gpbackend.modules.appointment.dto.request.SaveCanceledAppointmentRequest;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "canceled_appointments", indexes = {
        @Index(name = "idx_canceled_appointment_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_canceled_appointment_provider_id", columnList = "provider_id"),
        @Index(name = "idx_canceled_appointment_patient_id", columnList = "patient_id"),
        @Index(name = "idx_canceled_appointment_location_id", columnList = "location_id")
})
public class CanceledAppointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "provider_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Provider provider;

    @ManyToOne
    @JoinColumn(name = "patient_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "location_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Location location;

    @Column(name = "scheduled_date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime scheduledDateTime;

    @Column(name = "canceled_date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime canceledDateTime;

    @Column(name = "canceled_by", length = 45, nullable = false)
    private String canceledBy;

    @Column(name = "location_name", length = 45)
    private String locationName;

    public static CanceledAppointment fromRequest(SaveCanceledAppointmentRequest request) {
        return CanceledAppointment.builder()
                .scheduledDateTime(request.scheduledDateTime())
                .canceledBy(request.canceledBy())
                .medGroup(request.medGroup())
                .provider(request.provider())
                .patient(request.patient())
                .location(request.location())
                .locationName(request.locationName())
                .build();
    }
}
