package com.rhombuzz.gpbackend.modules.task.service;

public interface ActivityArchiveService {
}
