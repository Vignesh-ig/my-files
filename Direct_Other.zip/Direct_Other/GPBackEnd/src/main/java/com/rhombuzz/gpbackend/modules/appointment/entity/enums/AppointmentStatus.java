package com.rhombuzz.gpbackend.modules.appointment.entity.enums;

import lombok.Getter;

@Getter
public enum AppointmentStatus {

    COMPLETED("Completed"),
    UPCOMING("Upcoming"),
    PATIENT_CONFIRMED("Patient Confirmed"),
    CHECKED_IN("Checked In"),
    NO_SHOW("No Show");

    private final String label;

    AppointmentStatus(String label) {
        this.label = label;
    }
}
