package com.rhombuzz.gpbackend.exception.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;
import org.springframework.http.HttpStatus;

import java.util.Map;

@Builder
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Error {
    private String message;
    private int statusCode;
    private HttpStatus status;
    private Map<String, String> errors;
}
