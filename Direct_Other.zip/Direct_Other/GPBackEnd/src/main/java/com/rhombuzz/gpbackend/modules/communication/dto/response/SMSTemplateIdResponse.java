package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSTemplate;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SMSTemplateIdResponse {
    private String templateId;
    private String templateName;
    @JsonIgnore
    private SMSTemplate.TemplateGroup templateGroup;

    public SMSTemplateIdResponse(String templateId, String templateName){
        this.templateId = templateId;
        this.templateName = templateName;
    }
}
