package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record SaveLocationRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Location name cannot be blank")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "Location ID must contain only letters and whitespaces")
        @Size(max = 45, message = "Location name must be up to 45 characters long")
        String name,

        @NotBlank(message = "Location address cannot be blank")
        @Size(max = 100, message = "Location address must be up to 100 characters long")
        String address,

        @Pattern(regexp = RegexPattern.NO_WHITESPACE, message = "Location reference cannot contain whitespace")
        String locationReference,

        @Pattern(regexp = RegexPattern.NO_WHITESPACE, message = "Location reference code cannot contain whitespace")
        String locationReferenceCode,

        Integer locationHours,
        String googlePlaceId,
        String appointmentColor,
        String callAppointmentId,
        boolean isPrimary) {
}
