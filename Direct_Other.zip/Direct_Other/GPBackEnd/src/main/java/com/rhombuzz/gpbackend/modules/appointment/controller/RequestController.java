package com.rhombuzz.gpbackend.modules.appointment.controller;

import com.rhombuzz.gpbackend.modules.appointment.dto.request.PendingRequestFilter;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.PendingRequestResponse;
import com.rhombuzz.gpbackend.modules.appointment.service.RequestService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/v1/requests/appointments")
public class RequestController {
    private final RequestService requestService;

    @GetMapping("/pending")
    public ResponseEntity<Page<PendingRequestResponse>> getPendingRequests(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @Valid PendingRequestFilter filter,
            Pageable pageable
    ) {
        Page<PendingRequestResponse> pendingRequests = requestService.getPendingRequests(groupId, filter, pageable);
        return ResponseEntity.ok(pendingRequests);
    }
}
