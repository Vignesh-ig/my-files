package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.fasterxml.jackson.databind.JsonNode;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplateAttribute;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailTemplateAttributesResponse {
    private JsonNode englishHeaderFooter;
    private JsonNode spanishHeaderFooter;
    private JsonNode style;

    public static EmailTemplateAttributesResponse fromEntity(EmailTemplateAttribute emailTemplateAttribute){
        return EmailTemplateAttributesResponse.builder()
                .englishHeaderFooter(emailTemplateAttribute.getEnglishHeaderFooter())
                .spanishHeaderFooter(emailTemplateAttribute.getSpanishHeaderFooter())
                .style(emailTemplateAttribute.getStyle())
                .build();
    }
}
