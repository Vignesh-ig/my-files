package com.rhombuzz.gpbackend.modules.communication.controller;

import com.rhombuzz.gpbackend.modules.communication.dto.request.EmailRequest;
import com.rhombuzz.gpbackend.modules.communication.service.EmailService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/email")
@PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
public class EmailController {
    private final EmailService emailService;

    @PostMapping("/send")
    public ResponseEntity<Void> sendEmail(
            @RequestBody @Valid EmailRequest request
    ) {
        emailService.sendDirectEmail(request);
        return ResponseEntity.ok().build();
    }
}
