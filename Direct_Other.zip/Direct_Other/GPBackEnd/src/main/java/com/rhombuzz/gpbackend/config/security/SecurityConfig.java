package com.rhombuzz.gpbackend.config.security;

import com.rhombuzz.gpbackend.component.AuthenticationErrorHandler;
import com.rhombuzz.gpbackend.util.Endpoints;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {
    private static final String ROLE_CLAIM = "userRoles";
    private final AuthenticationErrorHandler errorHandler;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http.authorizeHttpRequests(request -> request
                        .requestMatchers(Endpoints.V1_PUBLIC_APIs).permitAll()
                        .requestMatchers(Endpoints.DENIED_APIs).denyAll()
                        .anyRequest().authenticated())
                .cors(Customizer.withDefaults())
                .csrf(AbstractHttpConfigurer::disable)
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(jwt -> jwt.jwtAuthenticationConverter(makeCombinedConverter()))
                        .authenticationEntryPoint(errorHandler))
                .build();
    }

    private JwtAuthenticationConverter makeCombinedConverter() {
        // Create the permissions converter
        final var jwtAuthoritiesConverter = new JwtGrantedAuthoritiesConverter();
        jwtAuthoritiesConverter.setAuthoritiesClaimName("permissions");
        jwtAuthoritiesConverter.setAuthorityPrefix("");

        Converter<Jwt, Collection<GrantedAuthority>> rolesConverter = jwt -> {
            if (!jwt.hasClaim(ROLE_CLAIM)) {
                return Collections.emptyList();
            }

            List<String> roles = jwt.getClaim(ROLE_CLAIM);
            return roles.stream()
                    .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                    .collect(Collectors.toList());
        };

        Converter<Jwt, Collection<GrantedAuthority>> combinedConverter = jwt -> Stream.concat(
                        jwtAuthoritiesConverter.convert(jwt).stream(),
                        Objects.requireNonNull(rolesConverter.convert(jwt)).stream())
                .collect(Collectors.toList());

        final var jwtAuthConverter = new JwtAuthenticationConverter();
        jwtAuthConverter.setJwtGrantedAuthoritiesConverter(combinedConverter);

        return jwtAuthConverter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
