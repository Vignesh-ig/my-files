package com.rhombuzz.gpbackend.modules.communication.event.publisher;

import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionEmailEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionSMSEvent;

import java.util.List;

public interface RequestSubmissionsEventPublisher {

    void publishRequestSubmissionEvents(List<RequestSubmissionSMSEvent> events);

    void publishRequestSubmissionEvent(List<RequestSubmissionEmailEvent> events);
}
