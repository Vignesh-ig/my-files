package com.rhombuzz.gpbackend.modules.patient.repository.specification;

import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDate;
import java.util.Objects;

public class AwaitingSpecification {

    public static Specification<Patient> defaultSpecification() {
        return (root, query, cb) ->
                cb.equal(root.get("submissionFlag"), false);
    }

    public static Specification<Patient> hasGroupId(String groupId) {
        return (root, query, cb) ->
                cb.equal(root.get("medGroup").get("groupId"), groupId);
    }

    public static Specification<Patient> hasFilter(AwaitingFilter awaitingFilter, LocalDate currentDate) {
        return (root, query, cb) -> {
            if (awaitingFilter == null) {
                return cb.conjunction();
            }

            Subquery<Long> subquery = Objects.requireNonNull(query).subquery(Long.class);
            Root<Appointment> appointmentRoot = subquery.from(Appointment.class);

            Predicate patientMatch = cb.equal(appointmentRoot.get("patient"), root);
            Predicate providerConfirmed = cb.equal(appointmentRoot.get("isProviderConfirmed"), true);

            Expression<LocalDate> dateExpression = appointmentRoot.get("scheduledDate");
            Predicate datePredicate = switch (awaitingFilter) {
                case TODAY -> cb.equal(dateExpression, currentDate);
                case TOMORROW -> cb.equal(dateExpression, currentDate.plusDays(1));
                case DAY_AFTER_TOMORROW -> cb.equal(dateExpression, currentDate.plusDays(2));
                case NEXT_7_DAYS -> cb.between(dateExpression, currentDate, currentDate.plusDays(7));
            };

            subquery.select(cb.literal(1L))
                    .where(cb.and(patientMatch, providerConfirmed, datePredicate));

            return cb.exists(subquery);
        };
    }


    public enum AwaitingFilter {
        TODAY,
        TOMORROW,
        DAY_AFTER_TOMORROW,
        NEXT_7_DAYS
    }
}
