package com.rhombuzz.gpbackend.modules.communication.dto.request;

import jakarta.validation.constraints.*;

public record EmailSendRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        String groupId,

        @NotNull(message = "Patient ID cannot be null")
        @Positive(message = "Patient ID must be a positive number")
        Long patientId,

        @NotBlank(message = "From email address cannot be blank")
        @Email(message = "Invalid email format")
        String fromEmail,

        @NotBlank(message = "Recipient email address cannot be blank")
        @Email(message = "Invalid email format")
        String toEmail,

        @NotBlank(message = "Subject cannot be blank")
        String subject,

        @NotBlank(message = "Body cannot be blank")
        String body
) {
}
