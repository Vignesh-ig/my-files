package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.ServiceResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface ServiceRepository extends JpaRepository<Service, Long> {

    @Query("SELECT COUNT(s) > 0 FROM Service s WHERE s.serviceName = ?1 AND s.medGroup.groupId = ?2")
    boolean isServiceExist(String serviceType, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.medgroup.dto.response.ServiceResponse(" +
            "s.id, s.serviceName, s.duration, s.reference, s.colorCode, s.visibleToPatient, s.recall, s.allowReminder, " +
            "s.recallPeriod, s.bookingFeeAmount, s.visitType) FROM Service s WHERE s.medGroup.groupId = ?1")
    Page<ServiceResponse> findByGroupId(String groupId, Pageable pageable);

    @Query("SELECT s FROM Service s WHERE s.id = ?1 AND s.medGroup.groupId = ?2")
    Optional<Service> findById(Long id, String groupId);

    @Query("SELECT COUNT(s) > 0 FROM Service s WHERE s.id = ?1 AND s.medGroup.groupId = ?2")
    boolean existsById(Long id, String groupId);

    @Modifying
    @Query("DELETE FROM Service s WHERE s.id = ?1 AND s.medGroup.groupId = ?2")
    void deleteById(Long id, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.medgroup.dto.response.ServiceResponse(" +
            "s.id, s.serviceName, s.duration, s.reference, s.colorCode, s.visibleToPatient, s.recall, s.allowReminder, " +
            "s.recallPeriod, s.bookingFeeAmount, s.visitType) FROM Service s WHERE s.id NOT IN ?1 AND s.medGroup.groupId = ?2")
    Page<ServiceResponse> findByServiceIds(Set<Long> serviceIds, String groupId, Pageable pageable);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO(s.id, s.serviceName) FROM Service s WHERE s.id IN ?1 AND s.medGroup.groupId = ?2")
    List<ServiceDTO> findServiceNamesByIds(List<Long> serviceIds, String groupId);
}
