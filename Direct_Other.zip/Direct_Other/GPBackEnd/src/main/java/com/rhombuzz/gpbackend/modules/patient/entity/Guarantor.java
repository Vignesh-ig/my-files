package com.rhombuzz.gpbackend.modules.patient.entity;

import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.dto.request.GuarantorRequest;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.RelationshipToPatient;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "guarantors", indexes = {
        @Index(name = "idx_guarantor_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_guarantor_patient_id", columnList = "patient_id")
})
public class Guarantor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @Column(name = "first_name", length = 45, nullable = false)
    private String firstName;

    @Column(name = "last_name", length = 45, nullable = false)
    private String lastName;

    @Column(name = "dob", nullable = false)
    private LocalDate dateOfBirth;

    @Column(name = "relationship_to_patient", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private RelationshipToPatient relationshipToPatient;

    @Column(name = "address", length = 200)
    private String address;

    @Column(name = "city", length = 45, nullable = false)
    private String city;

    @Column(name = "state", length = 45, nullable = false)
    private String state;

    @Column(name = "zip_code", length = 5, nullable = false)
    private String zipCode;

    @Column(name = "cell_phone", length = 10, nullable = false)
    private String cellPhone;

    @Column(name = "home_phone", length = 10)
    private String homePhone;

    @Column(name = "gender", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private Gender gender;

    public static Guarantor fromRequest(GuarantorRequest request) {
        return Guarantor.builder()
                .firstName(request.firstName())
                .lastName(request.lastName())
                .dateOfBirth(request.dob())
                .gender(request.gender())
                .relationshipToPatient(request.relationshipToPatient())
                .address(request.address())
                .city(request.city())
                .state(request.state())
                .zipCode(request.zipCode())
                .cellPhone(request.cellPhone())
                .homePhone(request.homePhone())
                .build();
    }
}
