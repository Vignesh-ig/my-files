package com.rhombuzz.gpbackend.modules.medgroup.event.listener;

import com.rhombuzz.gpbackend.modules.auth.service.UserService;
import com.rhombuzz.gpbackend.modules.communication.service.EmailTemplateService;
import com.rhombuzz.gpbackend.modules.communication.service.SMSTemplateService;
import com.rhombuzz.gpbackend.modules.medgroup.event.model.MedgroupRemoveEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class MedgroupEventListener {

    private final UserService userService;
    private final EmailTemplateService emailTemplateService;
    private final SMSTemplateService smsTemplateService;

    @EventListener
    public void handleMedgroupRemoval(MedgroupRemoveEvent event) {
        log.info("handleMedgroupDeletion called for group {}", event.groupId());

        userService.deleteUsers(event.groupId());
        emailTemplateService.removeEmailTemplatesAndAttributes(event.groupId());
        smsTemplateService.removeSMSTemplates(event.groupId());
    }
}
