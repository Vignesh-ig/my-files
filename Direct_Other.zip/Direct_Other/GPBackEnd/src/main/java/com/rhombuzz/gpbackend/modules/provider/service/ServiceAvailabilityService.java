package com.rhombuzz.gpbackend.modules.provider.service;

import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveServiceAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.ServiceAvailabilityResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

@Validated
public interface ServiceAvailabilityService {

    void saveServiceAvailability(
            @Valid SaveServiceAvailabilityRequest request
    );

    Map<DayOfWeek, List<ServiceAvailabilityResponse>> getServiceAvailabilities(
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    @Transactional
    void deleteServiceAvailability(
            @NotNull @Positive Long id,
            @NotNull @Positive Long providerId,
            @NotNull @Positive Long locationId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
