package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.rhombuzz.gpbackend.modules.communication.service.SecureEmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SecureEmailServiceImpl implements SecureEmailService {
}
