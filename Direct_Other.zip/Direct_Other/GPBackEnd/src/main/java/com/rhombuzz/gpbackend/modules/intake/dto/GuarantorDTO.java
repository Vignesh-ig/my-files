package com.rhombuzz.gpbackend.modules.intake.dto;

import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.RelationshipToPatient;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class GuarantorDTO {

    @NotBlank(message = "First Name cannot be blank")
    @Size(min = 1, max = 45, message = "First Name must be between 1 and 45 characters long")
    @Pattern(regexp = RegexPattern.NAME, message = "First Name must contain only letters")
    private String firstName;

    @NotBlank(message = "Last Name cannot be blank")
    @Size(max = 45, message = "Last Name must be between 1 and 45 characters long")
    @Pattern(regexp = RegexPattern.NAME, message = "Last Name must contain only letters")
    private String lastName;

    @NotNull(message = "Relationship to Patient cannot be null")
    private RelationshipToPatient relationshipToPatient;

    @NotBlank(message = "Address cannot be blank")
    @Size(max = 200, message = "Address must be up to 200 characters long")
    private String address;

    @NotBlank(message = "City cannot be blank")
    @Size(max = 45, message = "City must be up to 45 characters long")
    @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "City must contain only letters and spaces")
    private String city;

    @NotBlank(message = "State cannot be blank")
    @Size(max = 45, message = "State must be up to 45 characters long")
    @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "State must contain only letters and spaces")
    private String state;

    @NotBlank(message = "Zip Code cannot be blank")
    @Pattern(regexp = RegexPattern.FIVE_DIGITS, message = "Zip Code must be exactly 5 digits")
    private String zipCode;

    @NotBlank(message = "Cell Phone cannot be blank")
    @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone must be exactly 10 digits")
    private String cellPhone;

    @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Home Phone number must be exactly 10 digits")
    private String homePhone;

    @NotNull(message = "Date of Birth cannot be null")
    @PastOrPresent(message = "Date of Birth must be in the past or present")
    private LocalDate dob;

    @NotNull(message = "Gender cannot be null")
    private Gender gender;
}
