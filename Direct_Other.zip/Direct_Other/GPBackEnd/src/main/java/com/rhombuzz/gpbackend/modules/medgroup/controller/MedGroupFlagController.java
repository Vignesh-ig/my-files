package com.rhombuzz.gpbackend.modules.medgroup.controller;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.UpdateAdminFlagRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.UpdateDashboardFlagRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.AdminFlagResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.DashboardFlagResponse;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupFlagService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/med-group-flags")
@Validated
@PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
public class MedGroupFlagController {
    private final MedGroupFlagService medGroupFlagService;

    @GetMapping("/admin")
    @PreAuthorize("hasRole("+ AccessType.ADMIN +")")
    public ResponseEntity<AdminFlagResponse> getAdminFlags(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        AdminFlagResponse response = medGroupFlagService.getAdminFlag(groupId);
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/admin")
    @PreAuthorize("hasRole("+ AccessType.ADMIN +")")
    public ResponseEntity<Void> updateAdminFlag(@RequestBody @Valid UpdateAdminFlagRequest request) {
        medGroupFlagService.updateAdminFlag(request);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/dashboard/general")
    public ResponseEntity<DashboardFlagResponse> getDashboardFlags(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        DashboardFlagResponse response = medGroupFlagService.getDashboardFlag(groupId);
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/dashboard/general")
    public ResponseEntity<Void> updateDashboardFlag(@RequestBody @Valid UpdateDashboardFlagRequest request) {
        medGroupFlagService.updateDashboardFlag(request);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/telehealth")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Boolean>> getTelehealthFlags(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        AdminFlagResponse response = medGroupFlagService.getAdminFlag(groupId);
        return ResponseEntity.ok(Map.of("telehealthEnabled", response.isTelehealth()));
    }
}
