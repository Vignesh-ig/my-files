package com.rhombuzz.gpbackend.modules.appointment.repository.specification;

import com.rhombuzz.gpbackend.modules.appointment.dto.request.PendingRequestFilter;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class PendingRequestSpecification {

    public static Specification<Appointment> defaultSpecification(LocalDate currentDate) {
        return (root, query, cb) -> cb.and(
                cb.greaterThanOrEqualTo(root.get("scheduledDate"), currentDate),
                cb.equal(root.get("isCancelRequested"), false),
                cb.equal(root.get("isDoNotShow"), false),
                cb.equal(root.get("isProviderConfirmed"), false)
        );
    }

    public static Specification<Appointment> hasGroupId(String groupId) {
        return (root, query, cb) ->
                cb.equal(root.get("medGroup").get("groupId"), groupId);
    }

    public static Specification<Appointment> hasFilter(PendingRequestFilter filter) {
        return (root, query, cb) -> {
            if (filter == null) {
                return cb.conjunction();
            }

            Set<PendingRequestFilter.FilterType> filters = filter.getFilters();
            if (filters == null || filters.isEmpty()) {
                return cb.conjunction();
            }

            List<Predicate> predicates = new ArrayList<>();

            if (filters.contains(PendingRequestFilter.FilterType.PROVIDER)) {
                Predicate provider = cb.equal(root.get("provider").get("id"), filter.getProviderId());
                predicates.add(provider);
            }
            if (filters.contains(PendingRequestFilter.FilterType.LOCATION)) {
                Predicate location = cb.equal(root.get("location").get("id"), filter.getLocationId());
                predicates.add(location);
            }
            if (filters.contains(PendingRequestFilter.FilterType.SERVICE)) {
                Predicate service = cb.equal(root.get("service").get("id"), filter.getServiceId());
                predicates.add(service);
            }

            return predicates.isEmpty() ? cb.conjunction() : cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
