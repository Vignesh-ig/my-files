package com.rhombuzz.gpbackend.modules.provider.repository;

import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.provider.entity.ProviderOffering;
import com.rhombuzz.gpbackend.modules.provider.entity.id.ProviderOfferingId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface ProviderOfferingRepository extends JpaRepository<ProviderOffering, ProviderOfferingId> {

    @Query("SELECT po.id.service.id, po.disabled FROM ProviderOffering po WHERE po.id.provider.id = ?1 " +
            "AND po.id.medGroup.groupId = ?2")
    List<Object[]> findServiceIdsByProviderId(Long providerId, String groupId);

    @Query("SELECT po FROM ProviderOffering po WHERE po.id.provider.id = ?1 " +
            "AND po.id.medGroup.groupId = ?2 AND po.id.service.id IN ?3")
    List<ProviderOffering> findByProviderAndServiceIds(Long providerId, String groupId, Set<Long> enabledIds);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO(s.id, s.serviceName) " +
            "FROM Service s " +
            "LEFT JOIN ProviderOffering po ON po.id.service.id = s.id " +
            "AND po.id.provider.id = ?1 " +
            "AND po.id.medGroup.groupId = s.medGroup.groupId " +
            "WHERE s.medGroup.groupId = ?2 " +
            "AND (po.id IS NULL OR po.disabled = false)")
    List<ServiceDTO> findServiceNamesByProviderId(Long providerId, String groupId);

    @Query("SELECT po.disabled FROM ProviderOffering po WHERE po.id.provider.id = ?1 " +
            "AND po.id.service.id = ?2 AND po.id.medGroup.groupId = ?3")
    Optional<Boolean> getDisabledStatus(Long providerId, Long serviceId, String groupId);

    @Query("""
            SELECT new com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO(
                s.id, s.serviceName
            )
            FROM Service s
            LEFT JOIN ProviderOffering po
                ON po.id.service.id = s.id
                AND po.id.provider.id = ?1
                AND po.id.medGroup.groupId = ?2
            WHERE (po.id IS NULL OR po.disabled = false)
              AND (
                    ?3 = 'BOTH'
                    OR (
                        COALESCE(po.visitType, s.visitType) = ?3
                        OR COALESCE(po.visitType, s.visitType) = 'BOTH'
                      )
              )
              AND s.medGroup.groupId = ?2
            """)
    List<ServiceDTO> findServiceNamesByVisitType(Long providerId, String groupId, Service.VisitType visitType);

    @Query("SELECT po FROM ProviderOffering po WHERE po.id.provider.id = ?1 " +
            "AND po.id.service.id = ?2 AND po.id.medGroup.groupId = ?3 AND po.disabled = false")
    Optional<ProviderOffering> getProviderOffering(Long providerId, Long serviceId, String groupId);
}
