package com.rhombuzz.gpbackend.modules.communication.dto;

import com.fasterxml.jackson.databind.JsonNode;

public record EmailTemplateDTO(
        String templateName,
        JsonNode jsonContent,
        JsonNode attributeContent,
        JsonNode attributeStyle,
        String subject,
        String templateUsage
) {
}
