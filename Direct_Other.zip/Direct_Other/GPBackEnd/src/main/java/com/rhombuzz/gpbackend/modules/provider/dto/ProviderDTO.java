package com.rhombuzz.gpbackend.modules.provider.dto;

import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class ProviderDTO {
    private Long id;
    private String name;
    private String specialist;

    public ProviderDTO (Long id,String name) {
        this.id = id;
        this.name = name;
    }

    public static ProviderDTO fromEntity(Provider provider) {
        return ProviderDTO.builder()
                .id(provider.getId())
                .name(provider.getName())
                .specialist(provider.getSpecialist())
                .build();
    }
}
