package com.rhombuzz.gpbackend.exception.domain;

public class InternalServerErrorException extends RuntimeException {
    public InternalServerErrorException(String message) {
        super(message);
    }
}
