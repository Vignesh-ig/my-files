package com.rhombuzz.gpbackend.enums;

public enum Gender {

    MALE,
    FEMALE,
    OTHER

}
