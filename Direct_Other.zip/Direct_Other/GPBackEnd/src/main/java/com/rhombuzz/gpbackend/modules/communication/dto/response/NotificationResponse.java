package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.rhombuzz.gpbackend.modules.communication.entity.Notification;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Builder
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationResponse {
    private Long id;
    private String message;
    private Notification.Priority priority;
    private LocalDateTime dateTime;
    private Boolean isHidden;
    private boolean isSeen;

    public static NotificationResponse fromEntity(Notification notification) {
        return NotificationResponse.builder()
                .id(notification.getId())
                .message(notification.getMessage())
                .priority(notification.getPriority())
                .dateTime(notification.getDateTime())
                .isHidden(notification.isHidden())
                .isSeen(notification.isSeen())
                .build();
    }
}
