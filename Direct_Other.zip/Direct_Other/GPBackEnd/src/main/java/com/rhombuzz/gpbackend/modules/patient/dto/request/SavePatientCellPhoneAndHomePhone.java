package com.rhombuzz.gpbackend.modules.patient.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.Pattern;

public record SavePatientCellPhoneAndHomePhone(
        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone number must be exactly 10 digits")
        String cellPhone,

        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Home phone number must be exactly 10 digits")
        String homePhone
) {
}
