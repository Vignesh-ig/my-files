package com.rhombuzz.gpbackend.modules.task.controller;

import com.rhombuzz.gpbackend.modules.task.dto.response.ActivityResponse;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/activities")
@Validated
public class ActivityController {
    private final ActivityService activityService;

    @GetMapping
    public ResponseEntity<Page<ActivityResponse>> getActivities(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<ActivityResponse> activities = activityService.getActivities(groupId, pageable);
        return ResponseEntity.ok(activities);
    }

    @GetMapping("/patients/{patientId}")
    public ResponseEntity<Page<ActivityResponse>> getPatientActivities(
            @PathVariable @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<ActivityResponse> patientActivities = activityService.getPatientActivities(patientId, groupId, pageable);
        return ResponseEntity.ok(patientActivities);
    }
}
