package com.rhombuzz.gpbackend.modules.task.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "activities", indexes = {
        @Index(name = "idx_activity_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_activity_patient_id", columnList = "patient_id"),
        @Index(name = "idx_activity_provider_id", columnList = "provider_id")
})
public class Activity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "provider_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Provider provider;

    @Column(name = "date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime dateTime;

    @Column(name = "type", nullable = false, length = 100)
    private String type;

    @Column(name = "description", nullable = false, length = 500)
    private String description;

    @Lob
    @Column(name = "content", columnDefinition = "TEXT")
    private String content;

    public static Activity fromRequest(ActivityRequest request) {
        return Activity.builder()
                .patient(request.getPatient())
                .provider(request.getProvider())
                .type(request.getActivityType())
                .description(request.getActivityDescription())
                .content(request.getContent())
                .build();
    }
}
