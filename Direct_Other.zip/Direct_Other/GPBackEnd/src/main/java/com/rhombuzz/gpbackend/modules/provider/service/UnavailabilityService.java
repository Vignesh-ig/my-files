package com.rhombuzz.gpbackend.modules.provider.service;

import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveUnavailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.UnavailabilityResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
public interface UnavailabilityService {

    void saveUnavailability(
            @Valid SaveUnavailabilityRequest request
    );

    List<UnavailabilityResponse> getUnavailabilities(
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    @Transactional
    void deleteUnavailability(
            @NotNull @Positive Long id,
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
