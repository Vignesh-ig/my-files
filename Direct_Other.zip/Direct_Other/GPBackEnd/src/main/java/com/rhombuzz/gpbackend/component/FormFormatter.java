package com.rhombuzz.gpbackend.component;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class FormFormatter {
    public String formatPhone(String phone) {
        if (phone == null || phone.length() != 10) return phone;
        return String.format("(%s) %s-%s",
                phone.substring(0, 3),
                phone.substring(3, 6),
                phone.substring(6));
    }

    public String formatDate(String dateStr) {
        try {
            LocalDate date = LocalDate.parse(dateStr); // Assumes yyyy-MM-dd
            return date.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        } catch (Exception e) {
            return dateStr;
        }
    }

    public String formatSSN(String ssn){
        if (ssn == null || ssn.length() != 9) return ssn;
        return String.format("%s-%s-%s",
                ssn.substring(0, 3),
                ssn.substring(3, 5),
                ssn.substring(5));
    }
}
