package com.rhombuzz.gpbackend.modules.provider.controller;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveServiceRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.UpdateServiceRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.ServiceResponse;
import com.rhombuzz.gpbackend.modules.medgroup.service.ServiceManagement;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/services")
@Validated
@PreAuthorize("hasAnyRole("+ AccessType.SUPER_USER +")")
public class ServiceController {
    private final ServiceManagement serviceManagement;

    @PostMapping
    public ResponseEntity<Void> saveService(@RequestBody @Valid SaveServiceRequest request) {
        serviceManagement.saveService(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<Page<ServiceResponse>> getServices(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<ServiceResponse> services = serviceManagement.getServices(groupId, pageable);
        return ResponseEntity.ok(services);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Void> updateService(
            @PathVariable @NotNull Long id,
            @RequestBody @Valid UpdateServiceRequest request
    ) {
        serviceManagement.updateService(id, request);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteService(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        serviceManagement.deleteService(id, groupId);
        return ResponseEntity.noContent().build();
    }
}
