package com.rhombuzz.gpbackend.modules.intake.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotNull;
import org.springframework.validation.annotation.Validated;

@Validated
public interface IntakeService {

    void saveIntakeForm(
            @NotNull JsonNode request
    ) throws JsonProcessingException;
}
