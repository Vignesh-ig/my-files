package com.rhombuzz.gpbackend.modules.communication.dto.request;

public record PatientMessageRequest(
        String from,
        String to,
        String text,
        String messageUUID
) {
}
