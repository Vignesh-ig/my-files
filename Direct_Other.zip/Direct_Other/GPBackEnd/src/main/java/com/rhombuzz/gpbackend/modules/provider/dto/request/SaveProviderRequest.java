package com.rhombuzz.gpbackend.modules.provider.dto.request;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

public record SaveProviderRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @Min(value = 1, message = "Provider order must be at least 1")
        int order,

        Provider.Prefix prefix,

        @Pattern(regexp = RegexPattern.NAME, message = "only alphabets, spaces, commas, dots, parenthesis, and hyphen are allowed.")
        @NotBlank(message = "The first name cannot be blank.")
        @Size(max = 45, message = "First name cannot exceed 45 characters")
        String firstName,

        @Pattern(regexp = RegexPattern.NAME, message = "only alphabets, spaces, commas, dots, parenthesis, and hyphen are allowed.")
        @NotBlank(message = "The last name cannot be blank.")
        @Size(max = 45, message = "Last name cannot exceed 45 characters")
        String lastName,

        @Pattern(regexp = RegexPattern.PROVIDER_SUFFIX, message = "Suffix can only contain alphabets, spaces, commas, dots, and parenthesis")
        @Size(max = 45, message = "Suffix cannot exceed 45 characters")
        String suffix,

        @NotBlank(message = "Specialist cannot be blank")
        @Size(max = 45, message = "Specialist cannot exceed 45 characters")
        String specialist,

        @Pattern(regexp = RegexPattern.NO_WHITESPACE, message = "Provider reference cannot contain whitespace")
        @Size(max = 45, message = "Provider reference cannot exceed 45 characters")
        String reference,

        @Email(message = "Email should be valid")
        @Size(max = 45, message = "Email cannot exceed 45 characters")
        String email,

        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone must be a valid 10-digit number")
        String cellPhone,

        ContactMethod preferredContactMethod
) {
}