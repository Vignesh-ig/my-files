package com.rhombuzz.gpbackend.modules.communication.controller;

import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.UpdateSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MultilingualSMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSTemplate;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import com.rhombuzz.gpbackend.modules.communication.service.SMSTemplateService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/sms-templates")
@Validated
@PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
public class SMSTemplateController {
    private final SMSTemplateService smsTemplateService;

    @PostMapping
    public ResponseEntity<Void> saveSMSTemplate(
            @RequestBody @Valid SaveSMSTemplateRequest request
    ) {
        smsTemplateService.saveSMSTemplate(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<Map<SMSTemplate.TemplateGroup, List<SMSTemplateIdResponse>>> getSMSTemplates(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Map<SMSTemplate.TemplateGroup, List<SMSTemplateIdResponse>> templates = smsTemplateService.getSMSTemplates(groupId);
        return ResponseEntity.ok(templates);
    }

    @GetMapping("/{templateId}")
    public ResponseEntity<MultilingualSMSTemplateResponse> getSMSTemplate(
            @PathVariable @NotBlank String templateId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        MultilingualSMSTemplateResponse template = smsTemplateService.getSMSTemplate(templateId, groupId);
        return ResponseEntity.ok(template);
    }

    @PutMapping("/{templateId}")
    public ResponseEntity<Void> updateSMSTemplate(
            @PathVariable @NotBlank String templateId,
            @RequestBody @Valid UpdateSMSTemplateRequest request
    ) {
        smsTemplateService.updateSMSTemplate(templateId, request);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/external")
    public ResponseEntity<List<SMSTemplateIdResponse>> getExternalSMSTemplates(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<SMSTemplateIdResponse> templates = smsTemplateService.getSMSTemplates(groupId, TemplateType.EXTERNAL);
        return ResponseEntity.ok(templates);
    }

    @GetMapping("/{templateId}/patients/{patientId}")
    public ResponseEntity<SMSTemplateResponse> getSMSTemplateForPatient(
            @PathVariable @NotBlank String templateId,
            @PathVariable @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        SMSTemplateResponse template = smsTemplateService.getSMSTemplateByPatientId(templateId, patientId, groupId);
        return ResponseEntity.ok(template);
    }
}
