package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import lombok.*;

@Builder
@Getter
@Setter
public class MultilingualEmailTemplateResponse {
    private String templateName;
    private String subject;
    private String englishContent;
    private String spanishContent;
    private String templateUsage;

    public static MultilingualEmailTemplateResponse fromEntity( EmailTemplate emailTemplate) {
        return MultilingualEmailTemplateResponse.builder()
                .templateName(emailTemplate.getName())
                .subject(emailTemplate.getSubject())
                .templateUsage(emailTemplate.getTemplateUsage())
                .build();
    }

    public String getContent(PreferredLanguage language) {
        return language == PreferredLanguage.SPANISH ? spanishContent : englishContent;
    }
}
