package com.rhombuzz.gpbackend.modules.communication.entity.enums;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum MessageStatus {

    SENT,
    DELIVERED,
    FAILED,
    UNDELIVERED,
    QUEUED,

    RECEIVED;

    public static MessageStatus fromString(String value) {
        for (MessageStatus status : MessageStatus.values()) {
            if (status.name().equalsIgnoreCase(value)) {
                return status;
            }
        }
        log.warn("Unknown message status: {}", value);
        return null;
    }
}
