package com.rhombuzz.gpbackend.modules.task.dto.response;

import com.rhombuzz.gpbackend.modules.task.entity.TodoList;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TodoListResponse {
    private Long id;
    private Long patientId;
    private Long appointmentId;
    private String title;
    private String detail;
    private TodoList.Priority priority;
    private LocalDateTime dateTime;
    private List<TodoListHistoryResponse> todoListHistories;

    public static TodoListResponse fromEntity(TodoList todoList) {
        return TodoListResponse.builder()
                .id(todoList.getId())
                .patientId(getPatientId(todoList))
                .appointmentId(getAppointmentId(todoList))
                .title(todoList.getTitle())
                .detail(todoList.getDetail())
                .priority(todoList.getPriority())
                .dateTime(todoList.getDateTime())
                .todoListHistories(getTodoListHistories(todoList))
                .build();
    }

    private static Long getPatientId(TodoList todoList) {
        log.info("Getting patient ID from TodoList: {}", todoList.getId());
        if (todoList.getPatient() == null) {
            return null;
        }

        return todoList.getPatient().getId();
    }

    private static Long getAppointmentId(TodoList todoList) {
        log.info("Getting appointment ID from TodoList: {}", todoList.getId());
        if (todoList.getAppointment() == null) {
            return null;
        }

        return todoList.getPatient().getId();
    }

    private static List<TodoListHistoryResponse> getTodoListHistories(TodoList todoList) {
        return todoList.getTodoListHistories().stream()
                .map(response -> TodoListHistoryResponse.builder()
                        .dateTime(response.getDateTime())
                        .actionDetail(response.getActionDetail())
                        .build()
                ).toList();
    }
}