package com.rhombuzz.gpbackend.modules.patient.dto.request;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.Set;

public record RequestSubmissionRequest(
        @NotEmpty(message = "Patient IDs cannot be empty")
        Set<@NotNull(message = "Patient ID cannot be null")
                        Long> patientIds,

        @NotBlank(message = "Group Id cannot be blank")
        @Size(min = 10, max = 10, message = "Group Id must be exactly 10 characters long")
        String groupId,

        @NotNull(message = "Request type cannot be null")
        ContactMethod requestMethod
) {
}
