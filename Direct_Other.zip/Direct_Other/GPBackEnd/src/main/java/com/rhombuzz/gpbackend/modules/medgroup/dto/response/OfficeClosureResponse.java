package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.entity.OfficeClosure;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class OfficeClosureResponse {

    private Long id;
    private String groupId;
    private LocalDate closeDate;
    private String reason;

    public static OfficeClosureResponse fromEntity(OfficeClosure officeClosure) {
        return OfficeClosureResponse.builder()
                .id(officeClosure.getId())
                .groupId(officeClosure.getMedGroup().getGroupId())
                .closeDate(officeClosure.getCloseDate())
                .reason(officeClosure.getReason())
                .build();
    }

}
