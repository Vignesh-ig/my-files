package com.rhombuzz.gpbackend.modules.communication.event.publisher.impl;

import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionEmailEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionSMSEvent;
import com.rhombuzz.gpbackend.modules.communication.event.publisher.RequestSubmissionsEventPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class RequestSubmissionsEventPublisherImpl implements RequestSubmissionsEventPublisher {
    private final ApplicationEventPublisher eventPublisher;

    @Override
    public void publishRequestSubmissionEvents(List<RequestSubmissionSMSEvent> events) {
        events.forEach(eventPublisher::publishEvent);
    }

    @Override
    public void publishRequestSubmissionEvent(List<RequestSubmissionEmailEvent> events) {
        events.forEach(eventPublisher::publishEvent);
    }
}
