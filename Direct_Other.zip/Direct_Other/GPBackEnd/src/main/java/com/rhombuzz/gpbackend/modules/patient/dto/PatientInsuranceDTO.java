package com.rhombuzz.gpbackend.modules.patient.dto;

import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.RelationshipToPatient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PatientInsuranceDTO {

    private RelationshipToPatient policyholderRelationship;
    private String policyholderFN;
    private String policyholderLN;
    private LocalDate policyholderDob;
    private Gender policyholderGender;
    private String companyName;
    private String companyCode;
    private String insGroupId;
    private String insId;

    private static boolean isNotBlank(String str) {
        return str != null && !str.isBlank();
    }

    private static boolean isValidDate(LocalDate date) {
        return date != null && !date.isAfter(LocalDate.now());
    }

    public boolean isValid() {
        if (policyholderRelationship == null) return false;

        return (policyholderRelationship == RelationshipToPatient.SELF || policyholderRelationship ==  RelationshipToPatient.GUARANTOR)
                ? isNotBlank(companyName) && isNotBlank(companyCode) && isNotBlank(insId)
                : isNotBlank(companyName) && isNotBlank(companyCode) && isNotBlank(insId)
                && isNotBlank(policyholderFN) && isNotBlank(policyholderLN) && isValidDate(policyholderDob);
    }

}
