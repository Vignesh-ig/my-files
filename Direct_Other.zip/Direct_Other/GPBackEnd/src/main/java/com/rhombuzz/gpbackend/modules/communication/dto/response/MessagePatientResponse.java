package com.rhombuzz.gpbackend.modules.communication.dto.response;

public interface MessagePatientResponse {
   Long getPatientId();
    String getPatientName();
    String getCellPhone();
    Integer getUnreadCount();
}
