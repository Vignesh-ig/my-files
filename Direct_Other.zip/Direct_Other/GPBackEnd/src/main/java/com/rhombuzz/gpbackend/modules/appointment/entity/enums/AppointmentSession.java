package com.rhombuzz.gpbackend.modules.appointment.entity.enums;

public enum AppointmentSession {
    MORNING,
    AFTERNOON,
}
