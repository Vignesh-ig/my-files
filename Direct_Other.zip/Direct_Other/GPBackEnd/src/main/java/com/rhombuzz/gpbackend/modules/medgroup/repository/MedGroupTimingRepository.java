package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupTiming;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface MedGroupTimingRepository extends JpaRepository<MedGroupTiming, Long> {

    @Query("SELECT m FROM MedGroupTiming m WHERE m.medGroup.groupId = ?1")
    Optional<MedGroupTiming> findByGroupId(String groupId);
}
