package com.rhombuzz.gpbackend.modules.patient.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.dto.PatientInsuranceDTO;
import com.rhombuzz.gpbackend.modules.patient.dto.request.SavePatientInsuranceRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientInsuranceResponse;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.entity.PatientInsurance;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.RelationshipToPatient;
import com.rhombuzz.gpbackend.modules.patient.repository.PatientInsuranceRepository;
import com.rhombuzz.gpbackend.modules.patient.service.PatientInsuranceService;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
@Slf4j
public class PatientInsuranceServiceImpl implements PatientInsuranceService {
    private final PatientInsuranceRepository patientInsuranceRepository;
    private final MedGroupService medGroupService;
    private final PatientService patientService;

    @Override
    public void savePatientInsurance(SavePatientInsuranceRequest request) {
        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Patient patient = patientService.getPatientById(request.patientId(), request.groupId());

        PatientInsurance patientInsurance = patientInsuranceRepository.findByPatientId(patient.getId(), request.groupId())
                .map(existingInsurance -> {
                    log.info("Updating existing Insurance for patient: {}", patient.getId());
                    updatePatientInsurance(existingInsurance, request);
                    return existingInsurance;
                })
                .orElseGet(() -> {
                    log.info("Creating new Insurance for patient: {}", patient.getId());
                    PatientInsurance newInsurance = PatientInsurance.fromRequest(request);
                    newInsurance.setMedGroup(medGroup);
                    newInsurance.setPatient(patient);
                    return newInsurance;
                });

        patientInsuranceRepository.save(patientInsurance);
    }

    @Override
    public PatientInsuranceResponse getPatientInsurance(Long patientId, String groupId) {
        log.info("Fetching insurance for patient {}: ", patientId);
        return patientInsuranceRepository.findByPatientId(patientId, groupId)
                .map(PatientInsuranceResponse::fromEntity)
                .orElseThrow(() -> {
                    log.error("Insurance not exists for patient: {} ", patientId);
                    return new NotFoundException("Insurance not found for the patient");
                });
    }

    private void updatePatientInsurance(PatientInsurance patientInsurance, SavePatientInsuranceRequest request) {
        patientInsurance.setHaveInsurance(request.haveInsurance());
        patientInsurance.setHaveSecIns(request.haveSecIns());

        if (!request.haveInsurance()) {
            log.info("No insurance found. Clearing all primary and secondary insurance fields.");
            clearAllInsuranceFields(patientInsurance);
            return;
        }

        setPrimaryInsurance(patientInsurance, request.primaryInsurance());

        if (request.haveSecIns()) {
            setSecondaryInsurance(patientInsurance, request.secondaryInsurance());
        } else {
            log.info("No secondary insurance found. Clearing secondary insurance fields.");
            clearSecondaryInsuranceFields(patientInsurance);
        }
    }

    private void setPrimaryInsurance(PatientInsurance patientInsurance, PatientInsuranceDTO primaryInsurance) {
        log.info("Updating primary insurance fields.");

        patientInsurance.setPriInsPolicyholderRelationship(primaryInsurance.getPolicyholderRelationship());
        patientInsurance.setPriInsCompanyName(primaryInsurance.getCompanyName());
        patientInsurance.setPriInsCompanyCode(primaryInsurance.getCompanyCode());
        patientInsurance.setPriInsGroupId(primaryInsurance.getInsGroupId());
        patientInsurance.setPriInsId(primaryInsurance.getInsId());

        if (primaryInsurance.getPolicyholderRelationship() == RelationshipToPatient.SELF) {
            log.info("Primary insurance policyholder is SELF. Clearing policyholder details.");
            clearPrimaryPolicyholderFields(patientInsurance);
        } else {
            patientInsurance.setPriInsPolicyholderFN(primaryInsurance.getPolicyholderFN());
            patientInsurance.setPriInsPolicyholderLN(primaryInsurance.getPolicyholderLN());
            patientInsurance.setPriInsPolicyholderDob(primaryInsurance.getPolicyholderDob());
            patientInsurance.setPriInsPolicyholderGender(primaryInsurance.getPolicyholderGender());
        }
    }

    private void setSecondaryInsurance(PatientInsurance patientInsurance, PatientInsuranceDTO secondaryInsurance) {
        log.info("Updating secondary insurance fields.");

        patientInsurance.setSecInsPolicyholderRelationship(secondaryInsurance.getPolicyholderRelationship());
        patientInsurance.setSecInsCompanyName(secondaryInsurance.getCompanyName());
        patientInsurance.setSecInsCompanyCode(secondaryInsurance.getCompanyCode());
        patientInsurance.setSecInsGroupId(secondaryInsurance.getInsGroupId());
        patientInsurance.setSecInsId(secondaryInsurance.getInsId());

        if (secondaryInsurance.getPolicyholderRelationship() == RelationshipToPatient.SELF) {
            log.info("Secondary insurance policyholder is SELF. Clearing policyholder details.");
            clearSecondaryPolicyholderFields(patientInsurance);
        } else {
            patientInsurance.setSecInsPolicyholderFN(secondaryInsurance.getPolicyholderFN());
            patientInsurance.setSecInsPolicyholderLN(secondaryInsurance.getPolicyholderLN());
            patientInsurance.setSecInsPolicyholderDob(secondaryInsurance.getPolicyholderDob());
            patientInsurance.setSecInsPolicyholderGender(secondaryInsurance.getPolicyholderGender());
        }
    }

    private void clearAllInsuranceFields(PatientInsurance patientInsurance) {
        log.info("Clearing all insurance fields for patientId: {}", patientInsurance.getPatient().getId());
        clearPrimaryInsuranceFields(patientInsurance);
        clearSecondaryInsuranceFields(patientInsurance);
        patientInsurance.setHaveSecIns(false);
    }

    private void clearPrimaryInsuranceFields(PatientInsurance patientInsurance) {
        log.info("Clearing primary insurance fields.");
        patientInsurance.setPriInsPolicyholderRelationship(null);
        patientInsurance.setPriInsCompanyName(null);
        patientInsurance.setPriInsCompanyCode(null);
        patientInsurance.setPriInsGroupId(null);
        patientInsurance.setPriInsId(null);
        clearPrimaryPolicyholderFields(patientInsurance);
    }

    private void clearPrimaryPolicyholderFields(PatientInsurance patientInsurance) {
        log.info("Clearing primary insurance policyholder fields.");
        patientInsurance.setPriInsPolicyholderFN(null);
        patientInsurance.setPriInsPolicyholderLN(null);
        patientInsurance.setPriInsPolicyholderDob(null);
        patientInsurance.setPriInsPolicyholderGender(null);
    }

    private void clearSecondaryInsuranceFields(PatientInsurance patientInsurance) {
        log.info("Clearing secondary insurance fields.");
        patientInsurance.setSecInsPolicyholderRelationship(null);
        patientInsurance.setSecInsCompanyName(null);
        patientInsurance.setSecInsCompanyCode(null);
        patientInsurance.setSecInsGroupId(null);
        patientInsurance.setSecInsId(null);
        clearSecondaryPolicyholderFields(patientInsurance);
    }

    private void clearSecondaryPolicyholderFields(PatientInsurance patientInsurance) {
        log.info("Clearing secondary insurance policyholder fields.");
        patientInsurance.setSecInsPolicyholderFN(null);
        patientInsurance.setSecInsPolicyholderLN(null);
        patientInsurance.setSecInsPolicyholderDob(null);
        patientInsurance.setSecInsPolicyholderGender(null);
    }
}
