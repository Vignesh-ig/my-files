package com.rhombuzz.gpbackend.util;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
public class CSVUtils {

    public static  <T> List<T> loadFromCsv(MultipartFile file, Class<T> entityClass) {
        validateFileNotEmpty(file);

        try (BufferedReader headerReader = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            String headerLine = headerReader.readLine();
            validateHeaderLine(headerLine);

            Set<String> csvColumns = parseCsvHeaders(headerLine);
            Set<String> requiredColumns = getRequiredColumns(entityClass);
            validateHeaders(csvColumns, requiredColumns);

            return parseCsvData(file, entityClass);
        } catch (Exception e) {
            log.error("Error parsing CSV: {}", e.getMessage());
            throw new InternalServerErrorException("Error parsing CSV: " + e.getMessage());
        }
    }

    private static void validateFileNotEmpty(MultipartFile file) {
        if (file.isEmpty()) {
            log.error("File is empty");
            throw new BadRequestException("File is empty");
        }
    }

    private static void validateHeaderLine(String headerLine) {
        if (headerLine == null || headerLine.trim().isEmpty()) {
            log.error("CSV file has no header");
            throw new BadRequestException("CSV file has no header");
        }
    }

    private static Set<String> parseCsvHeaders(String headerLine) {
        return Arrays.stream(headerLine.split(","))
                .map(String::trim)
                .collect(Collectors.toSet());
    }

    private static <T> List<T> parseCsvData(MultipartFile file, Class<T> entityClass) throws IOException {
        try (BufferedReader dataReader = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            HeaderColumnNameMappingStrategy<T> strategy = new HeaderColumnNameMappingStrategy<>();
            strategy.setType(entityClass);

            CsvToBean<T> csvToBean = new CsvToBeanBuilder<T>(dataReader)
                    .withMappingStrategy(strategy)
                    .withIgnoreLeadingWhiteSpace(true)
                    .withIgnoreEmptyLine(true)
                    .withQuoteChar('"')
                    .withSeparator(',')
                    .build();

            List<T> csvEntries = csvToBean.parse().parallelStream()
                    .peek(CSVUtils::trimFields)
                    .collect(Collectors.toList());

            log.info("CSV file parsed successfully with {} entries", csvEntries.size());
            return csvEntries;
        }
    }

    private static void validateHeaders(Set<String> csvColumns, Set<String> requiredColumns) {
        if (requiredColumns.isEmpty()) {
            return;
        }

        Set<String> missingColumns = requiredColumns.stream()
                .filter(column -> !csvColumns.contains(column))
                .collect(Collectors.toSet());

        if (!missingColumns.isEmpty()) {
            log.error("Required columns missing in CSV: {}", String.join(", ", missingColumns));
            throw new BadRequestException("Required columns missing in CSV: " + String.join(", ", missingColumns));
        }
    }

    private static <T> Set<String> getRequiredColumns(Class<T> entityClass) {
        return Arrays.stream(entityClass.getDeclaredFields())
                .filter(CSVUtils::isRequiredField)
                .map(field -> field.getAnnotation(CsvBindByName.class).column().trim())
                .collect(Collectors.toSet());
    }

    private static boolean isRequiredField(Field field) {
        return (field.isAnnotationPresent(NotNull.class) || field.isAnnotationPresent(NotBlank.class))
                && field.isAnnotationPresent(CsvBindByName.class);
    }

    private static <T> void trimFields(T entity) {
        Arrays.stream(entity.getClass().getDeclaredFields())
                .filter(field -> field.getType() == String.class)
                .forEach(field -> {
                    field.setAccessible(true);
                    try {
                        String value = (String) field.get(entity);
                        if (value != null) {
                            field.set(entity, value.trim());
                        }
                    } catch (IllegalAccessException e) {
                        log.error("Error trimming field: {}", e.getMessage());
                    }
                });
    }
}