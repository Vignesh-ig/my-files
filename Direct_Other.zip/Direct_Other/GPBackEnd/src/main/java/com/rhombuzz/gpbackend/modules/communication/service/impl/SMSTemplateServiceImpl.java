package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.UpdateSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MultilingualSMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSTemplate;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import com.rhombuzz.gpbackend.modules.communication.repository.SMSTemplateRepository;
import com.rhombuzz.gpbackend.modules.communication.service.SMSTemplateService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SMSTemplateServiceImpl implements SMSTemplateService {
    private static final String ACTIVITY_TYPE = "SMS TEMPLATE";

    private final SMSTemplateRepository smsTemplateRepository;
    private final MedGroupService medGroupService;
    private final ActivityService activityService;
    private final PatientService patientService;

    @Override
    public void saveSMSTemplate(SaveSMSTemplateRequest request) {
        log.info("Saving SMS template for groupId: {}", request.groupId());
        medGroupService.getMedGroup(request.groupId());

        String templateName = request.name().trim().replaceAll("\\s+", " ");

        if(smsTemplateRepository.existsByTemplateName(templateName, request.groupId())){
            log.error("SMS template with name {} already exists for groupId: {}", templateName, request.groupId());
            throw new BadRequestException("SMS template with name " + templateName + " already exists");
        }

        SMSTemplate smsTemplate = SMSTemplate.fromRequest(request);
        smsTemplateRepository.save(smsTemplate);
        log.info("SMS template saved successfully for groupId: {}", request.groupId());

        String description = String.format("The user (%s) created a new SMS template (%s)",
                Utils.getCurrentUsername(), templateName);
        saveActivity(request.groupId(), description);
    }

    @Override
    public Map<SMSTemplate.TemplateGroup, List<SMSTemplateIdResponse>> getSMSTemplates(String groupId) {
        log.info("Retrieving SMS templates for groupId: {}", groupId);
        return smsTemplateRepository.findTemplateGroups(groupId).stream()
                .collect(Collectors.groupingBy(
                        SMSTemplateIdResponse::getTemplateGroup,
                        Collectors.toList()
                ));
    }

    @Override
    public SMSTemplateResponse getSMSTemplate(String templateId, String groupId, PreferredLanguage language) {
        log.info("Retrieving {} SMS template with id {} for groupId: {}", language, templateId, groupId);
        return smsTemplateRepository.getSMSTemplate(templateId, groupId,
                        null == language ? null : language.name())
                .orElseThrow(() -> {
                    smsTemplateNotFoundLog(templateId, groupId);
                    return new NotFoundException("SMS template not found");
                });
    }

    @Override
    public MultilingualSMSTemplateResponse getSMSTemplate(String templateId, String groupId) {
        log.info("Retrieving SMS template with id {} for groupId: {}", templateId, groupId);
        return smsTemplateRepository.getSMSTemplate(templateId, groupId)
                .orElseThrow(() -> {
                    smsTemplateNotFoundLog(templateId, groupId);
                    return new NotFoundException("SMS template not found");
                });
    }

    @Override
    public void updateSMSTemplate(String templateId, UpdateSMSTemplateRequest request) {
        log.info("Updating SMS template with id {} for groupId: {}", templateId, request.groupId());
        SMSTemplate smsTemplate = getSMSTemplateById(templateId, request.groupId());

        smsTemplate.setEnglishContent(request.englishContent());
        smsTemplate.setSpanishContent(request.spanishContent());
        smsTemplate.setTemplateUsage(request.templateUsage());

        smsTemplateRepository.save(smsTemplate);
        log.info("SMS template updated successfully for groupId: {}", request.groupId());

        String description = String.format("The user (%s) updated the SMS template (%s)",
                Utils.getCurrentUsername(), smsTemplate.getName());
        saveActivity(request.groupId(), description);
    }

    @Override
    public boolean isTemplateRestricted(String templateId, String groupId) {
        log.info("Checking if SMS template with id {} is restricted for groupId: {}", templateId, groupId);
        return smsTemplateRepository.isTemplateRestricted(templateId, groupId)
                .orElseThrow(() -> {
                    smsTemplateNotFoundLog(templateId, groupId);
                    return new BadRequestException("SMS template not found");
                });
    }

    @Override
    public List<SMSTemplateIdResponse> getSMSTemplates(String groupId, TemplateType templateType) {
        log.info("Retrieving SMS templates of type {} for groupId: {}", templateType, groupId);
        return smsTemplateRepository.findByGroupIdAndTemplateType(groupId, templateType);
    }

    @Override
    public SMSTemplateResponse getSMSTemplateByPatientId(String templateId, Long patientId, String groupId) {
        log.info("Retrieving SMS template for patient id {} and template id {} for groupId: {}", patientId, templateId, groupId);
        return getSMSTemplate(templateId, groupId, patientService.getPreferredLanguage(patientId, groupId));
    }

    @Override
    @Transactional
    public void removeSMSTemplates(String groupId) {
        log.info("removeSMSTemplates called for group {}", groupId);
        try {
            medGroupService.getMedGroup(groupId);
            smsTemplateRepository.deleteByGroupId(groupId);
        } catch (Exception e) {
            log.error("Error removing sms templates for medgroup : {}", groupId, e);
        }
    }

    private void saveActivity(String groupId, String description) {
        ActivityRequest request = new ActivityRequest(groupId, ACTIVITY_TYPE, description, null, null, null);
        activityService.saveActivity(request);
    }

    private void smsTemplateNotFoundLog(String templateId, String groupId) {
        log.error("SMS template with id {} not found for groupId: {}", templateId, groupId);
    }

    private SMSTemplate getSMSTemplateById(String templateId, String groupId) {
        return smsTemplateRepository.findByTemplateId(templateId, groupId)
                .orElseThrow(() -> {
                    smsTemplateNotFoundLog(templateId, groupId);
                    return new NotFoundException("SMS template not found");
                });
    }
}
