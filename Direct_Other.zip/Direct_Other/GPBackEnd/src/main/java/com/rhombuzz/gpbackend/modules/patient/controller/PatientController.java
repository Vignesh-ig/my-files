package com.rhombuzz.gpbackend.modules.patient.controller;

import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import com.rhombuzz.gpbackend.modules.patient.dto.request.*;
import com.rhombuzz.gpbackend.modules.patient.dto.response.DocumentStatusResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientMessageResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponseList;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/patients")
@PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
@Validated
public class PatientController {
    private final PatientService patientService;

    @GetMapping
    public ResponseEntity<Page<PatientResponseList>> getPatients(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<PatientResponseList> patients = patientService.getPatients(groupId, pageable);
        return ResponseEntity.ok(patients);
    }

    @PostMapping
    public ResponseEntity<Void> savePatient(@RequestBody @Valid SaveManualPatientRequest request) {
        patientService.saveManualPatient(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PatientResponse> getPatient(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        PatientResponse response = patientService.getPatient(id, groupId);
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Void> updatePatient(
            @PathVariable @NotNull Long id,
            @RequestBody @Valid UpdatePatientRequest request
    ) {
        patientService.updatePatient(id, request);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole(" + AccessType.ADMIN + ")")
    public ResponseEntity<Void> deletePatient(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        patientService.deletePatient(id, groupId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/import/csv")
//    @PreAuthorize("hasAnyRole(" + AccessType.ADMIN_AND_GROUP + ")")
    @PreAuthorize("denyAll()") // Temporarily disabled for security reasons
    public ResponseEntity<Void> loadFromCSV(
            @ValidFile(contentTypes = "text/csv", extensions = "csv")
            @RequestPart(name = "patients.csv") MultipartFile file,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        patientService.loadPatientsFromCsv(file, groupId);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PostMapping("/{id}/documents")
    public ResponseEntity<Void> uploadDocument(
            @PathVariable @NotNull Long id,
            @RequestPart List<
                    @ValidFile(
                            contentTypes = {
                                    "application/pdf",
                                    "text/plain",
                                    "application/msword",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "image/png",
                                    "application/vnd.ms-excel",
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "text/csv",
                                    "image/jpeg",
                                    "image/jpg"
                            },
                            extensions = {"pdf", "txt", "doc", "docx", "png", "xls", "xlsx", "csv", "jpg", "jpeg"}
                    ) MultipartFile> files,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        patientService.uploadDocuments(files, id, groupId);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/{id}/documents")
    public ResponseEntity<DocumentStatusResponse> getDocuments(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        DocumentStatusResponse documents = patientService.getDocuments(id, groupId);
        return ResponseEntity.ok(documents);
    }

    @GetMapping("/{id}/documents/{folderName}/{filename}")
    public ResponseEntity<Resource> downloadFile(
            @PathVariable @NotNull Long id,
            @PathVariable @NotBlank String filename,
            @PathVariable @NotBlank String folderName,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Resource file = patientService.downloadDocument(id, filename, folderName, groupId);
        String headerValue = "attachment; filename=\"%s\""
                .formatted(filename);

        return ResponseEntity.ok()
                .header("Content-Disposition", headerValue)
                .header("Content-Type", "application/pdf")
                .body(file);
    }

    @DeleteMapping("/{id}/documents/{folderName}/{filename}")
    public ResponseEntity<Void> deleteDocument(
            @PathVariable @NotNull Long id,
            @PathVariable @NotBlank String filename,
            @PathVariable @NotBlank String folderName,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        patientService.deleteDocument(id, filename, folderName, groupId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/merge")
//    @PreAuthorize("hasAnyRole(" + AccessType.ADMIN_AND_SUPER + ")")
    @PreAuthorize("denyAll()") // Temporarily disabled for security reasons
    public ResponseEntity<Void> mergePatients(@RequestBody @Valid MergePatientRequest request) {
        patientService.mergePatient(request);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/merge")
//    @PreAuthorize("hasAnyRole(" + AccessType.ADMIN_AND_SUPER + ")")
    @PreAuthorize("denyAll()") // Temporarily disabled for security reasons
    public ResponseEntity<List<Map<Long, PatientResponseList>>> getMergePatients(
            @Valid MergePatientRequest request
    ) {
        List<Map<Long, PatientResponseList>> response = patientService.getMergePatients(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/exists")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> patientExists(@RequestBody @Valid PatientExistsRequest request) {
        Map<String, Object> patientExists = patientService.isPatientExists(request);
        return ResponseEntity.ok(patientExists);
    }

    @PatchMapping("/{id}/homephone")
    public ResponseEntity<Void> updatePatientHomePhone(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestBody @Valid SavePatientCellPhoneAndHomePhone request
    ) {
        patientService.updatePatientHomePhoneByIdAndGroupId(id, groupId, request.homePhone());
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/cellphone")
    public ResponseEntity<Void> updatePatientCellphone(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestBody @Valid SavePatientCellPhoneAndHomePhone request
    ) {
        patientService.updatePatientCellPhoneByIdAndGroupId(id, groupId, request.cellPhone());
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/messages-details")
    public ResponseEntity<PatientMessageResponse> getPatients(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        PatientMessageResponse patientMessageResponse = patientService.getPatientAndApptDetails(groupId, id);
        return ResponseEntity.ok(patientMessageResponse);
    }
}
