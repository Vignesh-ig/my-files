package com.rhombuzz.gpbackend.modules.provider.dto.response;

import com.rhombuzz.gpbackend.modules.provider.entity.Unavailability;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Builder
@Data
public class UnavailabilityResponse {
    private Long id;
    private Long providerId;
    private LocalDate date;
    private String reason;

    public static UnavailabilityResponse fromEntity(Unavailability unavailability) {
        return UnavailabilityResponse.builder()
                .id(unavailability.getId())
                .providerId(unavailability.getProvider().getId())
                .date(unavailability.getExceptionDate())
                .reason(unavailability.getReason())
                .build();
    }
}
