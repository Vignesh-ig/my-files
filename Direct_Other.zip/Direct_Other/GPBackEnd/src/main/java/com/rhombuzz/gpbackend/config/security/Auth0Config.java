package com.rhombuzz.gpbackend.config.security;

import com.auth0.client.auth.AuthAPI;
import com.auth0.client.mgmt.ManagementAPI;
import com.rhombuzz.gpbackend.component.CredentialsFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class Auth0Config {
    private static final String AUTH0_CONFIG_TYPE = "AUTH0";

    private final CredentialsFactory credentialsFactory;
    private final String auth0Domain;

    public Auth0Config(CredentialsFactory credentialsFactory) {
        this.credentialsFactory = credentialsFactory;
        this.auth0Domain = credentialsFactory.getValue("AUTH0_DOMAIN", AUTH0_CONFIG_TYPE, "DOMAIN");
    }

    @Bean
    public AuthAPI authAPI() {
        final var clientId = credentialsFactory.getValue("AUTH0_MANAGEMENT_API_CLIENT_ID", AUTH0_CONFIG_TYPE, "CLIENT_ID");
        final var clientSecret = credentialsFactory.getValue("AUTH0_MANAGEMENT_API_CLIENT_SECRET", AUTH0_CONFIG_TYPE, "CLIENT_SECRET");

        return AuthAPI.newBuilder(auth0Domain, clientId, clientSecret)
                .build();
    }

    @Bean
    public ManagementAPI managementAPI() {
        String token = credentialsFactory.getValue("AUTH0_MANAGEMENT_TOKEN", AUTH0_CONFIG_TYPE, "TOKEN");
        return ManagementAPI.newBuilder(auth0Domain, token)
                .build();
    }

    @Bean(name = "auth0Database")
    public String auth0Database() {
        return credentialsFactory.getValue("AUTH0_DATABASE", "AUTH0", "AUTH0_DATABASE");
    }
}
