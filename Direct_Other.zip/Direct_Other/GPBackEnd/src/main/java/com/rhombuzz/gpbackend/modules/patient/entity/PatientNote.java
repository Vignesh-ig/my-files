package com.rhombuzz.gpbackend.modules.patient.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.dto.request.PatientNoteRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "patient_notes", indexes = {
        @Index(name = "idx_patient_note_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_patient_note_patient_id", columnList = "patient_id")
})
public class PatientNote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @Column(name = "patient_note", length = 500, nullable = false)
    private String patientNote;

    @Column(name = "user_name", length = 45, nullable = false)
    private String userName;

    @Column(name = "note_type", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private NoteType noteType;

    @Column(name = "current_date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime currentDateTime;

    public static PatientNote fromRequest(PatientNoteRequest request) {
        return PatientNote.builder()
                .noteType(request.noteType())
                .patientNote(request.patientNote())
                .build();
    }

    public enum NoteType {
        GENERAL_NOTE,
        CONSULTATION_NOTE,
        PROCEDURE_NOTE,
        PROGRESS_NOTE,
        REFERRAL_NOTE,
        SURGICAL_OPERATION_NOTE
    }
}
