package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.medgroup.entity.InsuranceCompany;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface InsuranceCompanyRepository extends JpaRepository<InsuranceCompany, Long> {

    @Query("SELECT ic FROM InsuranceCompany ic WHERE ic.medGroup.groupId = ?1")
    Page<InsuranceCompany> findByGroupId(String groupId, Pageable pageable);

    @Query("SELECT ic FROM InsuranceCompany ic WHERE ic.medGroup.groupId = ?1")
    List<InsuranceCompany> findByGroupId(String groupId);

    @Modifying
    @Query("DELETE FROM InsuranceCompany ic WHERE ic.id = ?1 AND ic.medGroup.groupId = ?2")
    void deleteById(Long id, String groupId);

    @Query("SELECT ic FROM InsuranceCompany ic WHERE ic.id = ?1 AND ic.medGroup.groupId = ?2")
    Optional<InsuranceCompany> findById(Long id, String groupId);
}
