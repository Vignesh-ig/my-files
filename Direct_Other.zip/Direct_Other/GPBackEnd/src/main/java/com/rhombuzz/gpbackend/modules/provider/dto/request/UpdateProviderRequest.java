package com.rhombuzz.gpbackend.modules.provider.dto.request;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

public record UpdateProviderRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @Pattern(regexp = RegexPattern.PROVIDER_SUFFIX, message = "Suffix can only contain alphabets, spaces, commas, and dots")
        @Size(max = 45, message = "Suffix must not exceed 45 characters")
        String suffix,

        @Size(min = 10, max = 10, message = "Cell Phone number must be exactly 10 digits long")
        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone must be a valid 10-digit number")
        String cellPhone,

        @Email(message = "Email must be a valid email address")
        @Size(max = 45, message = "Email must not exceed 45 characters")
        String email,

        @Size(max = 45, message = "Provider reference must not exceed 45 characters")
        String reference,

        Provider.Prefix prefix,
        ContactMethod preferredContactMethod

) {
}
