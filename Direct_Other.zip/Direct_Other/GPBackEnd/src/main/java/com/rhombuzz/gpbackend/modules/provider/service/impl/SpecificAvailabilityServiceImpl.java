package com.rhombuzz.gpbackend.modules.provider.service.impl;

import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.LocationService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveSpecificAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.UpdateSpecificAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.SpecificAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.provider.entity.SpecificAvailability;
import com.rhombuzz.gpbackend.modules.provider.repository.SpecificAvailabilityRepository;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import com.rhombuzz.gpbackend.modules.provider.service.SpecificAvailabilityService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class SpecificAvailabilityServiceImpl implements SpecificAvailabilityService {
    private static final String ACTIVITY_TYPE = "SERVICE AVAILABILITY";

    private final SpecificAvailabilityRepository specificAvailabilityRepository;
    private final MedGroupService medGroupService;
    private final ProviderService providerService;
    private final LocationService locationService;
    private final ActivityService activityService;

    @Override
    public void saveSpecificAvailability(SaveSpecificAvailabilityRequest request) {
        log.info("Saving specific availability for group: {}", request.groupId());

        validateOrder(request.groupId(), request.date(), request.startTime(), request.endTime());

        if (!medGroupService.isMedGroupExists(request.groupId())) {
            throw new BadRequestException("MedGroup does not exist");
        }

        if (!providerService.isProviderExists(request.providerId(), request.groupId())) {
            throw new BadRequestException("Provider does not exist");
        }

        if (!locationService.isLocationExists(request.locationId(), request.groupId())) {
            throw new BadRequestException("Location does not exist");
        }

        MedGroup medGroup = new MedGroup(request.groupId());
        Provider provider = new Provider(request.providerId());
        Location location = new Location(request.locationId());

        SpecificAvailability specificAvailability = SpecificAvailability.fromRequest(request);
        specificAvailability.setMedGroup(medGroup);
        specificAvailability.setProvider(provider);
        specificAvailability.setLocation(location);

        specificAvailabilityRepository.findLatestByProviderId(request.providerId(), request.groupId())
                .ifPresent(latest -> {
                    if (latest.getScheduleDate().isAfter(request.date()) ||
                            (latest.getScheduleDate().isEqual(request.date()) && latest.getEndTime().isAfter(request.startTime()))) {
                        log.error("New specific availability overlaps with existing availability for provider: {}", request.providerId());
                        throw new ConflictException("New specific availability overlaps with existing availability");
                    }
                });

        specificAvailabilityRepository.save(specificAvailability);
        log.info("Specific availability saved successfully for provider: {}", request.providerId());

        String description = String.format("The user (%s) has added the specific availability for provider `%s` on %s",
                Utils.getCurrentUsername(), provider.getName(), request.date());
        saveActivity(request.groupId(), description, provider);

        //Todo: Notify waiting list patients.
    }

    @Override
    public List<SpecificAvailabilityResponse> getSpecificAvailabilities(Long providerId, String groupId) {
        log.info("Getting specific availability for group: {}", providerId);
        return specificAvailabilityRepository.findByProviderId(providerId, groupId);
    }

    @Override
    public void updateSpecificAvailability(Long id, UpdateSpecificAvailabilityRequest request) {
        log.info("Updating specific availability for ID: {}", id);

        SpecificAvailability specificAvailability = getSpecificAvailability(id, request.providerId(), request.oldLocationId(), request.groupId());

        validateOrder(specificAvailability.getMedGroup().getGroupId(), request.date(), request.startTime(), request.endTime());

        specificAvailability.setStartTime(request.startTime());
        specificAvailability.setEndTime(request.endTime());

        if (!request.newLocationId().equals(specificAvailability.getLocation().getId())) {
            Location location = locationService.getLocationById(request.newLocationId(), request.groupId());
            specificAvailability.setLocation(location);
        }

        specificAvailabilityRepository.save(specificAvailability);
        log.info("Specific availability updated successfully");

        String description = String.format("The user (%s) has updated the specific availability for provider `%s` on %s",
                Utils.getCurrentUsername(), specificAvailability.getProvider().getName(), request.date());
        saveActivity(request.groupId(), description, specificAvailability.getProvider());
    }

    @Override
    @Transactional
    public void deleteSpecificAvailability(Long id, Long providerId, Long locationId, String groupId) {
        log.info("Deleting specific availability for provider: {}", id);
        SpecificAvailability specificAvailability = getSpecificAvailability(id, providerId, locationId, groupId);

        specificAvailabilityRepository.deleteById(id, providerId, locationId, groupId);
        log.info("Specific availability deleted successfully");

        String description = String.format("The user (%s) has deleted the specific availability for provider `%s` on %s",
                Utils.getCurrentUsername(), specificAvailability.getProvider().getName(), specificAvailability.getScheduleDate());
        saveActivity(groupId, description, specificAvailability.getProvider());
    }

    private SpecificAvailability getSpecificAvailability(Long id, Long providerId, Long locationId, String groupId) {
        return specificAvailabilityRepository.findById(id, providerId, locationId, groupId)
                .orElseThrow(() -> {
                    log.error("Specific availability not found for provider: {}", id);
                    return new NotFoundException("Specific availability not found");
                });
    }

    private void saveActivity(String groupId, String description, Provider provider) {
        ActivityRequest activityRequest = new ActivityRequest() {{
            setGroupId(groupId);
            setProvider(provider);
            setActivityDescription(description);
            setActivityType(ACTIVITY_TYPE);
        }};

        activityService.saveActivity(activityRequest);
    }

    private void validateOrder(String groupId, LocalDate date, LocalTime startTime, LocalTime endTime) {
        log.info("Getting current date and time from medGroup service");
        LocalDateTime currentDateTime = medGroupService.getCurrentDateTime(groupId).withSecond(0);
        log.info("Current date and time: {}", currentDateTime);

        log.info("Checking if date is in the future");
        if (date.isBefore(currentDateTime.toLocalDate())) {
            log.error("Date is not in the future");
            throw new ConflictException("Date must be in the future: " + date);
        }

        LocalDateTime startDateTime = LocalDateTime.of(date, startTime);
        log.info("Start date and time: {}", startDateTime);

        log.info("Checking if time is in the future");
        if (!startDateTime.isAfter(currentDateTime)) {
            log.error("Time is not in the future");
            throw new ConflictException("Time must be in the future: " + startTime);
        }

        log.info("Checking if start time is before end time");
        if (!startTime.isBefore(endTime)) {
            log.error("Start time is not before end time");
            throw new ConflictException("Start time must be before end time");
        }
    }

}
