package com.rhombuzz.gpbackend.modules.provider.entity;

import com.fasterxml.jackson.annotation.JsonValue;
import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Slf4j
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "providers", indexes = {
        @Index(name = "idx_provider_med_group_id", columnList = "med_group_id"),
})
public class Provider {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "provider_order")
    private int order;

    @Column(name = "prefix", length = 45)
    @Enumerated(EnumType.STRING)
    private Prefix prefix;

    @Column(name = "name", length = 90, nullable = false)
    private String name;

    @Column(name = "suffix", length = 45)
    private String suffix;

    @Column(name = "specialist", length = 45, nullable = false)
    private String specialist;

    @Lob
    @Column(name = "image", columnDefinition = "LONGBLOB")
    private byte[] image;

    @Column(name = "image_name", length = 150)
    private String imageName;

    @Column(name = "date_submitted")
    private LocalDate dateSubmitted;

    @Column(name = "reference", length = 45)
    private String reference;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "booking_type", length = 45)
    @Enumerated(EnumType.STRING)
    private BookingType bookingType;

    @Column(name = "booking_per_slot")
    private int bookingPerSlot;

    @Column(name = "booking_per_day")
    private int bookingPerDay;

    @Column(name = "default_appt_duration")
    private int defaultApptDuration;

    @Column(name = "is_primary")
    private boolean isPrimary;

    @Column(name = "column_id")
    private Integer columnId;

    @Column(name = "column_code", length = 45)
    private String columnCode;

    @Column(name = "email", length = 60)
    private String email;

    @Column(name = "cell_phone", length = 14)
    private String cellPhone;

    @Column(name = "preferred_contact_method")
    @Enumerated(EnumType.STRING)
    private ContactMethod preferredContactMethod;

    @Column(name = "organizer_key", length = 60)
    private String organizerKey;

    @Column(name = "created_at", updatable = false, nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    public Provider(Long id) {
        this.id = id;
    }

    @PrePersist
    private void setDefaultValue() {
        this.isActive = true;
        this.bookingType = BookingType.SINGLE;
        this.bookingPerDay = 60;
        this.defaultApptDuration = 15;
        this.createdAt = LocalDateTime.now(this.medGroup.getTimeZone().toZoneId());
        this.updatedAt = LocalDateTime.now(this.medGroup.getTimeZone().toZoneId());
    }

    @PreUpdate
    private void onUpdate() {
        this.updatedAt = LocalDateTime.now(this.medGroup.getTimeZone().toZoneId());
    }

    public enum BookingType {

        SINGLE,
        DOUBLE,
        TRIPLE,
        MULTIPLE
    }

    @RequiredArgsConstructor
    @Getter
    public enum Prefix {

        MR("Mr."),
        MRS("Mrs."),
        MS("Ms."),
        DR("Dr."),
        PROF("Prof."),
        PROF_DR("Prof. Dr."),
        REV_DR("Rev. Dr."),
        COL_DR("Col. Dr.");

        @JsonValue
        private final String label;

    }

}
