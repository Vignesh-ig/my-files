package com.rhombuzz.gpbackend.modules.patient.dto.response;

public record PatientCellphoneAndEmailResponse(
        String cellPhone,
        String email
) {
}
