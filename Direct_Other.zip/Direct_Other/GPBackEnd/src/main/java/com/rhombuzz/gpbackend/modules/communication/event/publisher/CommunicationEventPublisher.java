package com.rhombuzz.gpbackend.modules.communication.event.publisher;

import com.rhombuzz.gpbackend.modules.communication.event.model.generic.EmailCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.generic.SMSCommunicationEvent;

import java.util.List;

public interface CommunicationEventPublisher {
    void publishSMSEvent(SMSCommunicationEvent event);

    void publishEmailEvent(EmailCommunicationEvent event);

    void publishSMSEvent(List<SMSCommunicationEvent> events);

    void publishEmailEvent(List<EmailCommunicationEvent> events);
}
