package com.rhombuzz.gpbackend.modules.provider.service;

import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.ServiceResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderOfferingRequest;
import com.rhombuzz.gpbackend.modules.provider.entity.ProviderOffering;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
public interface ProviderOfferingService {

    void saveProviderOffering(
            @Valid ProviderOfferingRequest request
    );

    void disableProviderOffering(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long providerId,
            @NotNull @Positive Long serviceId
    );

    void enableProviderOffering(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long providerId,
            @NotNull @Positive Long serviceId
    );

    Page<ServiceResponse> getProviderOfferings(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long providerId,
            Pageable pageable
    );

    List<ServiceDTO> getServiceNames(
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    boolean isProviderOfferingDisabled(
            @NotNull @Positive Long providerId,
            @NotNull @Positive Long serviceId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<ServiceDTO> getServiceByVisitType(
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull Service.VisitType visitType
    );

    ProviderOffering getProviderOffering(
            @NotNull @Positive Long providerId,
            @NotNull @Positive Long serviceId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
