package com.rhombuzz.gpbackend.modules.support.entity;

import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "quick_surveys", indexes = {
        @Index(name = "idx_quick_survey_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_quick_survey_patient_id", columnList = "patient_id"),
        @Index(name = "idx_quick_survey_appointment_id", columnList = "appointment_id"),
        @Index(name = "idx_quick_survey_secret_id", columnList = "secret_id")
})
public class QuickSurvey {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @OneToOne
    @JoinColumn(name = "appointment_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Appointment appointment;

    @Column(name = "secret_id", length = 10)
    private String secretId;

    @Column(name = "score")
    private int score;

    @Column(name = "reason", length = 500)
    private String reason;

    @Column(name = "is_google_review_intent")
    private boolean isGoogleReviewIntent;

    @Column(name = "requested_date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime requestedDateTime;

    @Column(name = "received_date_time", columnDefinition = "DATETIME(0)")
    private LocalDateTime receivedDateTime;

    @Column(name = "google_review_status")
    private boolean googleReviewStatus;

}
