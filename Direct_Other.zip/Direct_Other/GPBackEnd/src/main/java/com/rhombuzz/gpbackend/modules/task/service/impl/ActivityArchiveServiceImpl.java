package com.rhombuzz.gpbackend.modules.task.service.impl;

import com.rhombuzz.gpbackend.modules.task.service.ActivityArchiveService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ActivityArchiveServiceImpl implements ActivityArchiveService {
}
