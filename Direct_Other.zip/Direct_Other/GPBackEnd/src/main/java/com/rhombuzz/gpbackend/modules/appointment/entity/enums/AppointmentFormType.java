package com.rhombuzz.gpbackend.modules.appointment.entity.enums;

public enum AppointmentFormType {
    PATIENT,
    STAFF
}
