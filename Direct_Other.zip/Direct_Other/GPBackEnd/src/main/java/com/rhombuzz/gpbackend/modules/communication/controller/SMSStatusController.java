package com.rhombuzz.gpbackend.modules.communication.controller;

import com.plivo.api.Plivo;
import com.plivo.api.util.Utils;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSStatusRequest;
import com.rhombuzz.gpbackend.modules.communication.service.SMSStatusService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/sms-status")
public class SMSStatusController {
    private final SMSStatusService smsStatusService;

    @PostMapping
    public ResponseEntity<Void> saveSMSStatus(
            SMSStatusRequest request,
            @RequestHeader("X-Plivo-Signature-V2") String signature,
            @RequestHeader("X-Plivo-Signature-V2-Nonce") String nonce
    ) throws MalformedURLException, UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
        String url = ServletUriComponentsBuilder.fromCurrentRequest()
                .build()
                .toUriString();
        String authToken = Plivo.getClient().getAuthToken();

        if (!Utils.validateSignature(url, nonce, signature, authToken)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        smsStatusService.saveSMSStatus(request);
        return ResponseEntity.ok().build();
    }
}
