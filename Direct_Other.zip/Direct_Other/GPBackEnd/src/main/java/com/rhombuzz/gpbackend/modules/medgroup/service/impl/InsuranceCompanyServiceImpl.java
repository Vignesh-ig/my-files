package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.InsuranceRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.InsuranceCompanyResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.InsuranceCompany;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.repository.InsuranceCompanyRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.InsuranceCompanyService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class InsuranceCompanyServiceImpl implements InsuranceCompanyService {

    private static final String ACTIVITY_TYPE = "MANAGE INSURANCE";

    private final InsuranceCompanyRepository insuranceCompanyRepository;
    private final MedGroupService medGroupService;
    private final ActivityService activityService;

    @Override
    public Page<InsuranceCompanyResponse> getInsuranceCompanies(String groupId, Pageable pageable) {
        log.info("Fetching insurance companies for group: {}", groupId);
        return insuranceCompanyRepository.findByGroupId(groupId, pageable)
                .map(InsuranceCompanyResponse::fromEntity);
    }

    @Override
    public void saveInsuranceCompany(InsuranceRequest request) {

        log.info("Save insurance company: {} for group: {}", request.insuranceName(), request.groupId());

        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        InsuranceCompany insuranceCompany = InsuranceCompany.builder()
                .medGroup(medGroup)
                .insuranceName(request.insuranceName())
                .insuranceCode(request.insuranceCode())
                .build();

        if (insuranceCompanyRepository.exists(Example.of(insuranceCompany))) {
            log.error("Insurance company: {} for group: {} is already exists.", request.insuranceName(), request.groupId());
            throw new ConflictException("Insurance company already exists");
        }

        insuranceCompanyRepository.save(insuranceCompany);
        log.info("Insurance company {} for group {} is saved.", request.insuranceName(), request.groupId());

        String description = String.format("Insurance company %s added by %s", request.insuranceName(), Utils.getCurrentUsername());
        saveActivity(request.groupId(), description);

    }

    @Override
    @Transactional
    public void deleteInsuranceCompany(Long id, String groupId) {
        log.info("Deleting insurance company with ID {}", id);
        InsuranceCompany insuranceCompany = getInsuranceCompany(id, groupId);

        insuranceCompanyRepository.deleteById(id, groupId);
        log.info("Insurance company with ID {} deleted", id);

        String description = String.format("Insurance company %s removed by %s", insuranceCompany.getInsuranceName(), Utils.getCurrentUsername());
        saveActivity(groupId, description);
    }

    @Override
    public void updateInsuranceCompany(Long id, InsuranceRequest request) {
        log.info("Updating insurance company with ID: {}", id);
        InsuranceCompany insuranceCompany = getInsuranceCompany(id, request.groupId());

        insuranceCompany.setInsuranceName(request.insuranceName());
        insuranceCompany.setInsuranceCode(request.insuranceCode());

        if (insuranceCompanyRepository.exists(Example.of(insuranceCompany))) {
            log.error("Insurance company already exists");
            throw new ConflictException("Insurance company already exists");
        }

        insuranceCompanyRepository.save(insuranceCompany);
        log.info("Insurance company with ID: {} updated", id);

        String description = String.format("The user %s updated the insurance company %s to %s",
                Utils.getCurrentUsername(), insuranceCompany.getInsuranceName(), request.insuranceName());
        saveActivity(request.groupId(), description);
    }

    @Override
    public Map<String, String> getInsuranceCompaniesForForms(String groupId) {
        log.info("Fetching insurance companies for forms: {}", groupId);
        return insuranceCompanyRepository.findByGroupId(groupId)
                .stream().collect(Collectors.toMap(
                        InsuranceCompany::getInsuranceName,
                        InsuranceCompany::getInsuranceCode
                ));
    }

    private InsuranceCompany getInsuranceCompany(Long id, String groupId) {
        return insuranceCompanyRepository.findById(id, groupId)
                .orElseThrow(() -> new NotFoundException("Insurance company not found with ID: " + id));
    }

    private void saveActivity(String groupId, String description) {
        ActivityRequest activityRequest = new ActivityRequest();
        activityRequest.setGroupId(groupId);
        activityRequest.setActivityType(ACTIVITY_TYPE);
        activityRequest.setActivityDescription(description);

        activityService.saveActivity(activityRequest);
    }
}
