package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.rhombuzz.gpbackend.modules.communication.dto.EmailTemplateDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class EmailTemplateResponse {
    private String templateName;
    private String subject;
    private String content;
    private String templateUsage;

    public static EmailTemplateResponse fromDTO(EmailTemplateDTO dto) {
        return new EmailTemplateResponse(
                dto.templateName(),
                dto.subject(),
                null,
                dto.templateUsage()
        );
    }
}