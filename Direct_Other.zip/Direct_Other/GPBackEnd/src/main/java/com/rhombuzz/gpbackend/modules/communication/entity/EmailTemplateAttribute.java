package com.rhombuzz.gpbackend.modules.communication.entity;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Table(name = "email_template_attributes")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmailTemplateAttribute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "group_id", length = 10, nullable = false)
    private String groupId;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "english_header_footer", nullable = false, columnDefinition = "JSON")
    private JsonNode englishHeaderFooter;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "spanish_header_footer", nullable = false, columnDefinition = "JSON")
    private JsonNode spanishHeaderFooter;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "style", nullable = false, columnDefinition = "JSON")
    private JsonNode style;

}

