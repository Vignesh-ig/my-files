package com.rhombuzz.gpbackend.modules.communication.dto.request;

import com.fasterxml.jackson.databind.JsonNode;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record UpdateEmailTemplateRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Template subject cannot be blank")
        @Size(max = 100, message = "Template subject must be at most 100 characters long")
        String subject,

        @NotNull(message = "English email template cannot be null")
        JsonNode englishEmailTemplate,

        @NotNull(message = "Spanish email template cannot be null")
        JsonNode spanishEmailTemplate,

        String templateUsage
) {
}
