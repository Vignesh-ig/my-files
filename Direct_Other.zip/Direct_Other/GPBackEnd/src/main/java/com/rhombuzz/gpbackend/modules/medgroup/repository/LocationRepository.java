package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.LocationResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface LocationRepository extends JpaRepository<Location, Long> {

    Page<LocationResponse> findByMedGroup_GroupId(String groupId, Pageable pageable);

    @Query("SELECT l FROM Location l WHERE l.id = ?1 AND l.medGroup.groupId = ?2")
    Optional<Location> findById(Long id, String groupId);

    @Query("SELECT COUNT(l) > 0 FROM Location l WHERE l.id = ?1 AND l.medGroup.groupId = ?2")
    boolean existsById(Long id, String groupId);

    @Modifying
    @Query("DELETE FROM Location l WHERE l.id = ?1 AND l.medGroup.groupId = ?2")
    void deleteById(Long id, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO(l.id, l.name) " +
            "FROM Location l WHERE l.medGroup.groupId = ?1")
    List<LocationDTO> findLocationNamesByGroupId(String groupId);

    @Query("SELECT DISTINCT new com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO(l.id, l.name) " +
            "FROM Location l " +
            "JOIN RecurringAvailability ra " +
            "ON ra.location = l " +
            "WHERE ra.provider.id = ?1 AND l.medGroup.groupId = ?2")
    List<LocationDTO> findLocationsByProviderIdAndGroupId(Long providerId, String groupId);
}
