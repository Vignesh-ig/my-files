package com.rhombuzz.gpbackend.modules.patient.controller;

import com.rhombuzz.gpbackend.modules.patient.dto.request.PatientNoteRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientNoteResponse;
import com.rhombuzz.gpbackend.modules.patient.service.PatientNoteService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/patient-notes")
@Validated
public class PatientNoteController {
    private final PatientNoteService patientNoteService;

    @GetMapping("/patients/{patientId}")
    public ResponseEntity<Page<PatientNoteResponse>> getPatientNotes(
            @PathVariable @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<PatientNoteResponse> patientNotes = patientNoteService.getPatientNotes(patientId, groupId, pageable);
        return ResponseEntity.ok(patientNotes);
    }

    @PostMapping
    public ResponseEntity<Void> savePatientNote(@RequestBody @Valid PatientNoteRequest request) {
        patientNoteService.savePatientNote(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
