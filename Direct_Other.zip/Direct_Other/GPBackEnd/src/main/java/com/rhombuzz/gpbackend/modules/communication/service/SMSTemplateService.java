package com.rhombuzz.gpbackend.modules.communication.service;

import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.UpdateSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MultilingualSMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSTemplate;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Map;

@Validated
public interface SMSTemplateService {

    void saveSMSTemplate(
            @Valid SaveSMSTemplateRequest saveSmsTemplateRequest
    );

    Map<SMSTemplate.TemplateGroup, List<SMSTemplateIdResponse>> getSMSTemplates(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    SMSTemplateResponse getSMSTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            PreferredLanguage language
    );

    MultilingualSMSTemplateResponse getSMSTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateSMSTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @Valid UpdateSMSTemplateRequest request
    );

    boolean isTemplateRestricted(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<SMSTemplateIdResponse> getSMSTemplates(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull TemplateType templateType
    );

    SMSTemplateResponse getSMSTemplateByPatientId(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotNull Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void removeSMSTemplates(@NotBlank @Size(min = 10, max = 10) String groupId);
}
