package com.rhombuzz.gpbackend.modules.task.dto.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Builder
@Data
public class TodoListHistoryResponse {
    private LocalDateTime dateTime;
    private String actionDetail;
}
