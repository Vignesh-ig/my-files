package com.rhombuzz.gpbackend.modules.patient.repository;

import com.rhombuzz.gpbackend.modules.patient.entity.WaitingList;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface WaitingListRepository extends JpaRepository<WaitingList, Long> {

    @Query("SELECT COUNT(w) > 0 FROM WaitingList w WHERE w.patient.id = ?1 AND w.medGroup.groupId = ?2")
    boolean existsByPatientId(Long patientId, String groupId);

    @Query("SELECT w FROM WaitingList w WHERE w.patient.id = ?1 AND w.medGroup.groupId = ?2")
    Optional<WaitingList> findByPatientId(Long patientId, String groupId);

    @Query("SELECT w FROM WaitingList w WHERE w.medGroup.groupId = ?1")
    Page<WaitingList> findByGroupId(String groupId, Pageable pageable);

    @Query("SELECT COUNT(w) > 0 FROM WaitingList w WHERE w.id=?1 AND w.patient.id = ?2 AND w.medGroup.groupId = ?3")
    boolean existsById(Long id, Long patientId, String groupId);

    @Modifying
    @Query("DELETE FROM WaitingList w WHERE w.id = ?1 AND w.patient.id = ?2 AND w.medGroup.groupId = ?3")
    void deleteById(Long id, Long patientId, String groupId);

}
