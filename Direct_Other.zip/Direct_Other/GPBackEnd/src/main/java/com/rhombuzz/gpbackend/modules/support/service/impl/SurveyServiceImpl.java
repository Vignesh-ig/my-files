package com.rhombuzz.gpbackend.modules.support.service.impl;

import com.rhombuzz.gpbackend.modules.support.service.SurveyService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SurveyServiceImpl implements SurveyService {
}
