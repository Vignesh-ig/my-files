package com.rhombuzz.gpbackend.modules.provider.controller;

import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveSpecificAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.UpdateSpecificAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.SpecificAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.service.SpecificAvailabilityService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/specific-availabilities")
@Validated
@PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
public class SpecificAvailabilityController {
    private final SpecificAvailabilityService specificAvailabilityService;

    @GetMapping("/providers/{providerId}")
    public ResponseEntity<List<SpecificAvailabilityResponse>> getSpecificAvailabilities(
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<SpecificAvailabilityResponse> specificAvailabilities = specificAvailabilityService.getSpecificAvailabilities(providerId, groupId);
        return ResponseEntity.ok(specificAvailabilities);
    }

    @PostMapping
    public ResponseEntity<Void> saveSpecificAvailability(@RequestBody @Valid SaveSpecificAvailabilityRequest request) {
        specificAvailabilityService.saveSpecificAvailability(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Void> updateSpecificAvailability(
            @PathVariable @NotNull Long id,
            @RequestBody @Valid UpdateSpecificAvailabilityRequest request
    ) {
        specificAvailabilityService.updateSpecificAvailability(id, request);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}/providers/{providerId}")
    public ResponseEntity<Void> deleteSpecificAvailability(
            @PathVariable @NotNull Long id,
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotNull Long locationId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        specificAvailabilityService.deleteSpecificAvailability(id, providerId, locationId, groupId);
        return ResponseEntity.noContent().build();
    }

}
