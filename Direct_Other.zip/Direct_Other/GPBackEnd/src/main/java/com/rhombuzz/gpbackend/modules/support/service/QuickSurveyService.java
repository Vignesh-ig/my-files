package com.rhombuzz.gpbackend.modules.support.service;

import com.rhombuzz.gpbackend.modules.support.dto.request.SaveQuickSurveyRequest;
import com.rhombuzz.gpbackend.modules.support.dto.request.UpdateQuickSurveyRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.validation.annotation.Validated;

@Validated
public interface QuickSurveyService {

    void saveQuickSurvey(
            @Valid SaveQuickSurveyRequest request
    );

    void updateQuickSurvey(
            @NotBlank String secretId,
            @Valid UpdateQuickSurveyRequest request
    );
}
