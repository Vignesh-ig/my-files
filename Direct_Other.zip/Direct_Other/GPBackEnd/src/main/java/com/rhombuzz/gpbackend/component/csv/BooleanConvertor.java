package com.rhombuzz.gpbackend.component.csv;

import com.opencsv.bean.AbstractBeanField;
import com.rhombuzz.gpbackend.exception.domain.BadRequestException;

public class BooleanConvertor extends AbstractBeanField<Boolean, String> {
    @Override
    protected Object convert(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }

        try {
            return Boolean.parseBoolean(value.trim());
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Invalid boolean value. Expected 'true' or 'false'");
        }
    }
}
