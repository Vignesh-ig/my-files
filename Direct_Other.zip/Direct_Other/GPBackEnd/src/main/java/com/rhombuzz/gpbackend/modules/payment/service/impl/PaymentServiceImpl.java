package com.rhombuzz.gpbackend.modules.payment.service.impl;

import com.rhombuzz.gpbackend.modules.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {
}
