package com.rhombuzz.gpbackend.modules.patient.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public record PatientExistsRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Patient ID cannot be blank")
        @Size(max = 45, message = "Patient first name must be at most 45 characters long")
        @Pattern(regexp = RegexPattern.NAME, message = "Patient ID must contain only letters")
        String firstName,

        @NotBlank(message = "Last Name cannot be blank")
        @Size(max = 45, message = "Patient last name must be at most 45 characters long")
        @Pattern(regexp = RegexPattern.NAME, message = "Last Name must contain only letters")
        String lastName,

        @NotNull(message = "Date of Birth cannot be null")
        @PastOrPresent(message = "Date of Birth must be in the past or present")
        LocalDate dob,

        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone number must be exactly 10 digits")
        @NotBlank(message = "Cell Phone number cannot be blank")
        String cellPhone,

        @NotNull(message = "Email cannot be null")
        @Email(message = "Email should be valid")
        @Size(max = 45, message = "Email must be at most 45 characters long")
        String email
) {
}
