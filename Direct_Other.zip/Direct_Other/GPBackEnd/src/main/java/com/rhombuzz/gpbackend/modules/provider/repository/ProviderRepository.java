package com.rhombuzz.gpbackend.modules.provider.repository;

import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.response.BookingTypeResponse;
import com.rhombuzz.gpbackend.modules.provider.dto.response.ProviderResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ProviderRepository extends JpaRepository<Provider, Long> {

    Page<ProviderResponse> findByMedGroup_GroupIdAndIsActiveTrue(String groupId, Pageable pageable);

    @Query("SELECT COUNT(d) > 0 FROM Provider d WHERE d.name = ?1 AND d.medGroup.groupId = ?2")
    boolean existsByName(String providerName, String groupId);

    @Query("SELECT d FROM Provider d WHERE d.id = ?1 AND d.medGroup.groupId = ?2 AND d.isActive = true")
    Optional<Provider> findById(Long id, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO(p.id, p.name, p.specialist) " +
            "FROM Provider p WHERE p.medGroup.groupId = ?1 AND p.isActive = true")
    List<ProviderDTO> findByGroupId(String groupId);

    @Query("SELECT p.defaultApptDuration FROM Provider p WHERE p.id = ?1 AND p.medGroup.groupId = ?2 " +
            "AND p.isActive = true")
    Optional<Integer> findDefaultApptDuration(Long providerId, String groupId);

    @Query("SELECT COUNT(p) > 0 FROM Provider p WHERE p.id = ?1 AND p.medGroup.groupId = ?2 AND p.isActive = true")
    boolean existsById(Long id, String groupId);

    default Page<ProviderResponse> findByGroupId(String groupId, Pageable pageable) {
        return findByMedGroup_GroupIdAndIsActiveTrue(groupId, pageable);
    }

    @Query("SELECT new com.rhombuzz.gpbackend.modules.provider.dto.response.BookingTypeResponse(" +
            "p.bookingType, p.bookingPerSlot, p.bookingPerDay) " +
            "FROM Provider p WHERE p.id = ?1 AND p.medGroup.groupId = ?2 AND p.isActive = true")
    Optional<BookingTypeResponse> findBookingTypeDetailsByIdAndGroupId(Long providerId, String groupId);

    @Modifying
    @Query("UPDATE Provider p SET p.bookingPerDay = ?5, p.bookingPerSlot = ?4, p.bookingType = ?3, p.updatedAt = ?6 " +
            "WHERE p.id = ?1 AND p.medGroup.groupId = ?2 AND p.isActive = true")
    void updateBookingTypeDetailsByIdAndGroupId(Long id, String groupId, Provider.BookingType bookingType, int bookingPerSlot, int bookingPerDay, LocalDateTime updatedAt);
}
