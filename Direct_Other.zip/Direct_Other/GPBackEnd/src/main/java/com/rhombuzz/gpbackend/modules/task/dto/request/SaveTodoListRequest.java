package com.rhombuzz.gpbackend.modules.task.dto.request;

import com.rhombuzz.gpbackend.modules.task.entity.TodoList;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

public record SaveTodoListRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Title cannot be blank")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Title must contain only letters")
        @Size(max = 45, message = "Title must be at most 45 characters long")
        String title,

        @NotBlank(message = "Detail cannot be blank")
        @Size(max = 100, message = "Detail must be at most 100 characters long")
        String detail,

        @NotNull(message = "Priority cannot be null")
        TodoList.Priority priority,

        @NotBlank(message = "Assign To cannot be blank")
        String assignTo,

        @Positive(message = "Patient ID must be a positive number")
        Long patientId,

        @NotNull(message = "Appointment ID cannot be null")
        Long appointmentId
) {
}
