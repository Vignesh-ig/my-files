package com.rhombuzz.gpbackend.modules.patient.repository.specification;

import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import org.springframework.data.jpa.domain.Specification;

public class ReceivedSpecification {

    public static Specification<Patient> hasGroupId(String groupId) {
        return (root, query, cb) ->
                cb.equal(root.get("medGroup").get("groupId"), groupId);
    }

    public static Specification<Patient> defaultSpecification() {
        return (root, query, cb) ->
                cb.isTrue(root.get("submissionFlag"));
    }

    public static Specification<Patient> hasFilter(ReceivedFilter receivedFilter, String claimedBy) {
        return (root, query, cb) -> {
            if (receivedFilter == null) {
                return cb.conjunction();
            }

            return switch (receivedFilter) {
                case UNCLAIMED ->  cb.isNull(root.get("claimedBy"));
                case CLAIMED_BY -> cb.equal(root.get("claimedBy"), claimedBy);
            };
        };
    }

    public enum ReceivedFilter {
        UNCLAIMED,
        CLAIMED_BY
    }
}
