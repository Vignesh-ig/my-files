package com.rhombuzz.gpbackend.modules.communication.event.model.generic;

import lombok.Getter;

@Getter
public class EmailCommunicationEvent extends  CommunicationEvent {
    private final String fromEmail;
    private final String toEmail;
    private final String subject;
    private final String content;

    public EmailCommunicationEvent(String groupId, Long patientId, String fromEmail, String toEmail, String subject, String content) {
        super(groupId, patientId);
        this.fromEmail = fromEmail;
        this.toEmail = toEmail;
        this.subject = subject;
        this.content = content;
    }
}
