package com.rhombuzz.gpbackend.modules.communication.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public record EmailRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        String groupId,

        @NotNull(message = "Patient ID cannot be null")
        @Positive(message = "Patient ID must be a positive number")
        Long patientId,

        @NotBlank(message = "Email Subject cannot be blank")
        String subject,

        @NotBlank(message = "Email content cannot be blank")
        String content
) {
}
