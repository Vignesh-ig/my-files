package com.rhombuzz.gpbackend.modules.communication.entity;

import com.rhombuzz.gpbackend.modules.communication.entity.enums.MessageStatus;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_statuses", indexes = {
        @Index(name = "idx_sms_status_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_sms_status_patient_id", columnList = "patient_id")
})
public class SMSStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @Column(name = "message_uuid", length = 45, nullable = false, unique = true)
    private String messageUUID;

    @Column(name = "message_status", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private MessageStatus messageStatus;

    @Column(name = "sms_date", nullable = false)
    private LocalDate smsDate;

}
