package com.rhombuzz.gpbackend.modules.task.repository;

import com.rhombuzz.gpbackend.modules.task.entity.ActivityArchive;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActivityArchiveRepository extends JpaRepository<ActivityArchive, Long> {
}
