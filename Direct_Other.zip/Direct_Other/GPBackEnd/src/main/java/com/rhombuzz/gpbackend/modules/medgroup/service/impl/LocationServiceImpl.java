package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveLocationRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.LocationResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.repository.LocationRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.LocationService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class LocationServiceImpl implements LocationService {

    private final LocationRepository locationRepository;
    private final MedGroupService medGroupService;

    @Override
    public void saveLocation(SaveLocationRequest saveLocationRequest) {
        log.info("Save location: {} for group: {}", saveLocationRequest.name(), saveLocationRequest.groupId());

        MedGroup medGroup = medGroupService.getMedGroup(saveLocationRequest.groupId());
        Location location = Location.builder()
                .medGroup(medGroup)
                .name(saveLocationRequest.name())
                .build();

        if (locationRepository.exists(Example.of(location))) {
            log.error("Location {} already exists for group {}", saveLocationRequest.name(), saveLocationRequest.groupId());
            throw new ConflictException("Location already exists");
        }

        location.setAddress(saveLocationRequest.address());
        location.setLocationReference(saveLocationRequest.locationReference());
        location.setGooglePlaceId(saveLocationRequest.googlePlaceId());
        location.setGooglePlaceId(saveLocationRequest.googlePlaceId());

        locationRepository.save(location);
        log.info("The Location {} for group {} is saved.", saveLocationRequest.name(), saveLocationRequest.groupId());
    }

    @Override
    public Page<LocationResponse> getLocations(String groupId, Pageable pageable) {
        log.info("Fetching locations for group {}", groupId);
        return locationRepository.findByMedGroup_GroupId(groupId, pageable);
    }

    @Override
    @Transactional
    public void deleteLocation(Long id, String groupId) {
        log.info("Delete location with ID: {}", id);

        if (!locationRepository.existsById(id, groupId)) {
            locationNotFoundLog(id, groupId);
            throw new NotFoundException("Location not found");
        }

        locationRepository.deleteById(id, groupId);
        log.info("Location with ID {} deleted", id);
    }

    @Override
    public void updateLocation(Long id, SaveLocationRequest saveLocationRequest) {
        log.info("Update location with ID: {}", id);

        Location location = getLocationById(id, saveLocationRequest.groupId());

        location.setName(saveLocationRequest.name());
        location.setAddress(saveLocationRequest.address());
        location.setLocationReference(saveLocationRequest.locationReference());
        location.setGooglePlaceId(saveLocationRequest.googlePlaceId());

        locationRepository.save(location);
        log.info("Location with ID {} updated", id);
    }

    @Override
    public Location getLocationById(Long id, String groupId) {
        log.info("Get location with ID: {}", id);
        return locationRepository.findById(id, groupId).orElseThrow(() -> {
            locationNotFoundLog(id, groupId);
            return new NotFoundException("Location not found with ID " + id);
        });
    }

    @Override
    public List<LocationDTO> getLocationNames(String groupId) {
        log.info("Fetching location names for group {}", groupId);
        return locationRepository.findLocationNamesByGroupId(groupId);
    }

    @Override
    public boolean isLocationExists(Long id, String groupId) {
        log.info("Check if location exists with ID: {}", id);
        return locationRepository.existsById(id, groupId);
    }

    @Override
    public List<LocationDTO> getProviderLocations(Long providerId, String groupId) {
        log.info("Fetching location names for provider {} in group {}", providerId, groupId);
        return locationRepository.findLocationsByProviderIdAndGroupId(providerId, groupId);
    }

    private void locationNotFoundLog(Long id, String groupId) {
        log.error("Location with ID {} not found for group {}", id, groupId);
    }
}
