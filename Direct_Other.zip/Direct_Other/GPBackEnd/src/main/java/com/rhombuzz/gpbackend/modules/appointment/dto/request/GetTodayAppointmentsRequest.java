package com.rhombuzz.gpbackend.modules.appointment.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public record GetTodayAppointmentsRequest(
        @NotBlank @Size(min = 10, max = 10) String groupId,
        @Positive Long providerId,
        @Positive Long locationId,
        @Positive Long serviceId
) {
}
