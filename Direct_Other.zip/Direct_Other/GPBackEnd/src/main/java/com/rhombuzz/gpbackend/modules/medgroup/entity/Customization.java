package com.rhombuzz.gpbackend.modules.medgroup.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.math.BigDecimal;
import java.time.LocalTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "customizations", indexes = {
        @Index(name = "idx_customization_med_group_id", columnList = "med_group_id")
})
public class Customization {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "address_flag")
    private boolean addressFlag;

    @Column(name = "reason_for_visit_flag")
    private boolean reasonForVisitFlag;

    @Column(name = "preferred_contact_flag")
    private boolean preferredContactFlag;

    @Column(name = "insurance_company_flag")
    private boolean insuranceCompanyFlag;

    @Column(name = "insurance_id_flag")
    private boolean insuranceIdFlag;

    @Column(name = "insurance_group_id_Flag")
    private boolean insuranceGroupIdFlag;

    @Column(name = "patient_update_form_flag")
    private boolean patientUpdateFormFlag;

    @Column(name = "forms_packet_link", length = 200)
    private String formsPacketLink;

    @Column(name = "appt_thank_you_page_content", length = 500)
    private String apptThankYouPageContent;

    @Column(name = "appt_request_popup_content", length = 500)
    private String apptRequestPopupContent;

    @Column(name = "medgroup_work_flow", length = 100)
    private String medgroupWorkFlow;

    @Column(name = "booking_fee_switch")
    private boolean bookingFeeSwitch;

    @Column(name = "default_booking_fee", precision = 10, scale = 2)
    private BigDecimal defaultBookingFee;

    @Column(name = "booking_lead_time_in_minutes")
    private int bookingLeadTimeInMinutes;

    @Column(name = "booking_prevention_switch")
    private boolean bookingPreventionSwitch;

    @Column(name = "booking_preventions_start_time", columnDefinition = "TIME(0)")
    private LocalTime bookingPreventionsStartTime;

    @Column(name = "notify_waitlist_patient_switch")
    private boolean notifyWaitlistPatientSwitch;

    @Column(name = "notify_waitlist_patient_limit")
    private int notifyWaitlistPatientLimit;

    @Column(name = "appt_cancel_restriction_period")
    private int apptCancelRestrictionPeriod; // 24, 48, 72, 98. -1 means cancellation not allowed. 0 means no restriction

    @Column(name = "appt_reschedule_restriction_period")
    private int apptRescheduleRestrictionPeriod; // 24, 48, 72, 98. -1 means reschedule not allowed. 0 means no restriction

    @PrePersist
    public void beforePersist() {
        this.notifyWaitlistPatientLimit = 1;
    }

    @Getter
    public enum Type {
        ADDRESS_FLAG("addressFlag"),
        REASON_FOR_VISIT_FLAG("reasonForVisitFlag"),
        PREFERRED_CONTACT_FLAG("preferredContactFlag"),
        INSURANCE_COMPANY_FLAG("insuranceCompanyFlag"),
        INSURANCE_ID_FLAG("insuranceIdFlag"),
        INSURANCE_GROUP_ID_FLAG("insuranceGroupIdFlag"),
        PATIENT_UPDATE_FORM_FLAG("patientUpdateFormFlag"),
        FORMS_PACKET_LINK("formsPacketLink"),
        APPT_THANK_YOU_PAGE_CONTENT("apptThankYouPageContent"),
        APPT_REQUEST_POPUP_CONTENT("apptRequestPopupContent"),
        MEDGROUP_WORK_FLOW("medgroupWorkFlow"),
        BOOKING_FEE_SWITCH("bookingFeeSwitch"),
        DEFAULT_BOOKING_FEE("defaultBookingFee"),
        BOOKING_LEAD_TIME_IN_MINUTES("bookingLeadTimeInMinutes"),
        BOOKING_PREVENTION_SWITCH("bookingPreventionSwitch"),
        BOOKING_PREVENTIONS_START_TIME("bookingPreventionsStartTime"),
        NOTIFY_WAITLIST_PATIENT_SWITCH("notifyWaitlistPatientSwitch"),
        NOTIFY_WAITLIST_PATIENT_LIMIT("notifyWaitlistPatientLimit"),
        APPT_CANCEL_RESTRICTION_PERIOD("apptCancelRestrictionPeriod"),
        APPT_RESCHEDULE_RESTRICTION_PERIOD("apptRescheduleRestrictionPeriod");

        private final String columnName;

        Type(String columnName) {
            this.columnName = columnName;
        }
    }
}
