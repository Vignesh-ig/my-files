package com.rhombuzz.gpbackend.modules.communication.service;

import com.rhombuzz.gpbackend.modules.communication.dto.SMSMessageDTO;
import com.rhombuzz.gpbackend.modules.communication.dto.request.MessageRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSSendRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.MessagePatientResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSSendResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

@Validated
public interface SMSService {
    SMSSendResponse sendSMS(
            @Valid SMSSendRequest smsSendRequest
    );

    void sendDirectSMS(
            @Valid MessageRequest request
    );

    Page<MessagePatientResponse> getPatientsWithUnreadCount(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Long locationId,
            @NotNull Boolean unreadOnly,
            Pageable pageable
    );

    Page<MessagePatientResponse> searchPatientsWithUnreadCount(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Long locationId,
            @NotBlank String searchTerm,
            Pageable pageable
    );

    Page<SMSMessageDTO> getSMSMessagesByPatientId(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull Long patientId,
            @NotNull Integer unReadCount,
            Pageable pageable
    );
}
