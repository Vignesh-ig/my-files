package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rhombuzz.gpbackend.enums.Gender;

import java.time.LocalDate;

public interface AwaitingSubmissionResponse {
    Long getId();
    String getFirstName();
    String getLastName();
    LocalDate getDob();
    String getCellPhone();
    Gender getGender();

    @JsonProperty("requestFormStatus")
    boolean isRequestFormFlag();
}
