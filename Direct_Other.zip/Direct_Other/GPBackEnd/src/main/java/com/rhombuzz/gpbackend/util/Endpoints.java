package com.rhombuzz.gpbackend.util;

public class Endpoints {
    public static final String[] V1_PUBLIC_APIs = {
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/swagger-ui.html",
            "/swagger-resources/**",
            "/webjars/**",
            "/api/v1/med-groups/{groupId}/exists",
            "/api/v1/patients/exists",
            "/api/v1/intake/**",
            "/api/v1/subform/**",
            "/api/v1/sms-status",
            "/api/v1/insurance-companies/names",
            "/api/v1/appointments/form/**",
            "/api/v1/providers/names",
            "/api/v1/providers/{providerId}/image",
            "/api/v1/provider-services/{providerId}/services/visit-type",
            "/api/v1/locations/names/providers/{providerId}",
            "/api/v1/customizations/thank-you-page-content",
            "/api/v1/appointments/{id}/reschedule",
            "/api/v1/appointments/{id}/cancel",
            "/api/v1/appointments/form/patients/{patientId}",
            "/api/v1/sms/callback"
    };

    public static final String[] DENIED_APIs = {
            "/api/v1/notifications/**",
            "/api/v1/insurance-companies/**",
            "/api/v1/med-group-timings/**",
            "/api/v1/office-closures/**",
            "/api/v1/guarantors/**",
            "/api/v1/patient-insurances/**",
            "/api/v1/waiting-lists/**",
            "/api/v1/quick-surveys/**",
            "/api/v1/supports/**",
            "/api/v1/activities/**",
            "/api/v1/todo-lists/**"
    };
}

