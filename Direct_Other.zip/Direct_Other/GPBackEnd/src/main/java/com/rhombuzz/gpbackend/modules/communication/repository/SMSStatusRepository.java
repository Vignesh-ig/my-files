package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.entity.SMSStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SMSStatusRepository extends JpaRepository<SMSStatus, Long> {
}
