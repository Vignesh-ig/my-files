package com.rhombuzz.gpbackend.modules.intake.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Validated
public interface SubformService {
    void saveSubform(
            @NotNull JsonNode request
    );

    void saveAttachments(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull List<
                    @ValidFile(
                            contentTypes = {
                                    "application/pdf", "text/plain", "application/msword",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "image/png", "application/vnd.ms-excel", "text/csv",
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "image/jpeg", "image/jpg"
                            },
                            extensions = {"pdf", "txt", "doc", "docx", "png", "xls", "xlsx", "csv", "jpg", "jpeg"}
                    ) MultipartFile> files

    );
}
