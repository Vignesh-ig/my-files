package com.rhombuzz.gpbackend.modules.auth.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserExistsResponse {
    private boolean isEmailExists;
    private boolean isUsernameExists;
}
