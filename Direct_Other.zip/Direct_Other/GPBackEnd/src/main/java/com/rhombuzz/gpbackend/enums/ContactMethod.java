package com.rhombuzz.gpbackend.enums;

public enum ContactMethod {

    EMAIL,
    SMS,
    BOTH
}
