package com.rhombuzz.gpbackend.modules.appointment.dto.response;

import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentStatus;
import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.patient.dto.InsuranceDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDate;
import java.time.LocalTime;

@AllArgsConstructor
@Getter
public class PatientAppointmentResponse {
    private Long id;
    private AppointmentStatus status;
    private LocalDate scheduledDate;
    private LocalTime scheduledTime;
    private boolean isTelehealth;
    private String reason;

    private ProviderDTO provider;
    private ServiceDTO service;
    private LocationDTO location;
    private InsuranceDTO insurance;

    public PatientAppointmentResponse(Long id, LocalDate scheduledDate, LocalTime scheduledTime, ProviderDTO provider, LocationDTO location, ServiceDTO service, AppointmentStatus status) {
        this.id = id;
        this.scheduledDate = scheduledDate;
        this.scheduledTime = scheduledTime;
        this.provider = provider;
        this.location = location;
        this.service = service;
        this.status = status;
    }
}
