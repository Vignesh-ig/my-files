package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.patient.dto.PatientDTO;
import com.rhombuzz.gpbackend.modules.patient.entity.WaitingList;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class WaitingListResponse {

    private Long id;
    private PatientDTO patient;
    private ProviderDTO provider;
    private LocationDTO location;
    private ServiceDTO service;
    private LocalDate date;
    private WaitingList.Type waitlistType;

    public static WaitingListResponse fromEntity(WaitingList waitingList) {
        return WaitingListResponse.builder()
                .id(waitingList.getId())
                .patient(PatientDTO.fromEntity(waitingList.getPatient()))
                .provider(ProviderDTO.fromEntity(waitingList.getProvider()))
                .location(LocationDTO.fromEntity(waitingList.getLocation()))
                .service(ServiceDTO.fromEntity(waitingList.getService()))
                .date(waitingList.getDate())
                .waitlistType(waitingList.getWaitlistType())
                .build();
    }
}
