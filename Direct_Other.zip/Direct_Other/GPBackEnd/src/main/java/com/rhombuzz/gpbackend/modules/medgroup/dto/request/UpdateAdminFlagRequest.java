package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupFlag;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record UpdateAdminFlagRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Flag type cannot be null")
        MedGroupFlag.AdminFlag flag,

        @NotNull(message = "Flag value cannot be null")
        Boolean value
) {
}
