package com.rhombuzz.gpbackend.modules.communication.dto.response;

public record SMSSendResponse(
        boolean success,
        String messageUuid
) {

}
