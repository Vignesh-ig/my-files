package com.rhombuzz.gpbackend.modules.medgroup.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MedGroupDTO {
    private String groupId;
    private String groupName;
}
