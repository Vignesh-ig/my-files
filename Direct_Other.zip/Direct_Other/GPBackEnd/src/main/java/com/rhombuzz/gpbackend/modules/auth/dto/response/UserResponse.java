package com.rhombuzz.gpbackend.modules.auth.dto.response;

import com.auth0.json.mgmt.users.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserResponse {
    private String id;
    private Role role;
    private String groupId;
    private String username;
    private String email;
    private String firstName;
    private String lastName;
    private boolean blocked;

    @Data
    @AllArgsConstructor
    @Builder
    public static class Role {
        private String id;
        private com.rhombuzz.gpbackend.enums.Role name;
    }

    public static UserResponse fromEntity(User user) {
        String[] fullName = user.getName().split(" ");
        return UserResponse.builder()
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .firstName(fullName[0])
                .lastName(fullName[1])
                .groupId((String) user.getUserMetadata().get("groupId"))
                .blocked(Boolean.TRUE.equals(user.isBlocked()))
                .build();
    }
}
