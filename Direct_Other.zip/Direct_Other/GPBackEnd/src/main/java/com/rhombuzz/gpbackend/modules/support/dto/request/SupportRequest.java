package com.rhombuzz.gpbackend.modules.support.dto.request;

import com.rhombuzz.gpbackend.modules.support.entity.Support;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record SupportRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Problem cannot be null")
        Support.Problem problem,

        @NotBlank(message = "Summary cannot be blank")
        @Size(min = 10, max = 500, message = "Summary must be between 10 and 500 characters long")
        String summary,

        @NotBlank(message = "Description cannot be blank")
        @Size(max = 200, message = "Description must be between 20 and 200 characters long")
        String description
) {
}
