package com.rhombuzz.gpbackend.modules.medgroup.event.model;

public record MedgroupRemoveEvent(String groupId) {

}
