package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record InsuranceRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Insurance name cannot be blank")
        @Size(max = 50, message = "Insurance name must be at most 50 characters long")
        String insuranceName,

        @NotBlank(message = "Insurance code cannot be blank")
        @Size(max = 50, message = "Insurance code must be at most 50 characters long")
        String insuranceCode
) {
}
