package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record SaveInsightsRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Source name cannot be blank")
        @Pattern(regexp = RegexPattern.CAMEL_CASE, message = "Source name must be in camel case format")
        String sourceName,

        @Min(value = 1, message = "Count must be at least 1")
        int count
) {
}
