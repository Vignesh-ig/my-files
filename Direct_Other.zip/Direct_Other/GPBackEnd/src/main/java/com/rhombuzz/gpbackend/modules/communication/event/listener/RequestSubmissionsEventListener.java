package com.rhombuzz.gpbackend.modules.communication.event.listener;

import com.rhombuzz.gpbackend.modules.communication.dto.request.EmailSendRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSSendRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSSendResponse;
import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionEmailEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionSMSEvent;
import com.rhombuzz.gpbackend.modules.communication.service.EmailService;
import com.rhombuzz.gpbackend.modules.communication.service.SMSService;
import com.rhombuzz.gpbackend.modules.patient.service.SubmissionService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class RequestSubmissionsEventListener {
    private final EmailService emailService;
    private final SMSService smsService;
    private final SubmissionService submissionService;

    @EventListener
    @Async
    public void handleRequestSubmissionSMSEvents(RequestSubmissionSMSEvent event) {
        SMSSendResponse response = smsService.sendSMS(new SMSSendRequest(
                event.getGroupId(),
                event.getPatientId(),
                event.getFromNumber(),
                event.getToNumber(),
                event.getContent(),
                Utils.getCurrentUsername()
        ));

        submissionService.updateSubmissionStatus(event.getGroupId(), event.getPatientId(), response.success());
    }

    @EventListener
    @Async
    public void handleRequestSubmissionEmailEvents(RequestSubmissionEmailEvent event) {
        EmailResponse response = emailService.sendEmail(new EmailSendRequest(
                event.getGroupId(),
                event.getPatientId(),
                event.getFromEmail(),
                event.getToEmail(),
                event.getSubject(),
                event.getContent()
        ));

        submissionService.updateSubmissionStatus(event.getGroupId(), event.getPatientId(), response.isSuccess());
    }
}
