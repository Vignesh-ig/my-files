DROP PROCEDURE IF EXISTS missed_appointment_follow_up;

create procedure missed_appointment_follow_up() reads sql data
BEGIN
    DECLARE counter_1, counter_2, i, j, z INT;
    DECLARE v_patient_id, v_appt_id, v_provider_id, v_location_id bigint;
    DECLARE v_schedule_date_time datetime;
    DECLARE v_group_id, v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang varchar(255);

    DROP TABLE IF EXISTS `Temp1`;
    CREATE TEMPORARY TABLE Temp1
    (
        phone_number  varchar(255),
        email         varchar(255),
        first_name    varchar(255),
        last_name     varchar(255),
        perf_lang     varchar(255),
        patient_id    bigint,
        appt_id       bigint,
        group_id      varchar(255),
        provider_id   bigint,
        meeting_time  time,
        schedule_date date,
        location_id   bigint
    );

    SELECT COUNT(*) INTO counter_1 FROM grow_practice.med_group_flags WHERE missed_appt_follow_up = 1;


    SET i = 0;
    SET z = 0;

    WHILE(i < counter_1)
        DO
            SELECT mg.group_id
            INTO v_group_id
            FROM grow_practice.med_groups mg
                     JOIN grow_practice.med_group_flags mgf ON mg.group_id = mgf.med_group_id
            WHERE mgf.missed_appt_follow_up = 1
            limit z,1;
            SELECT COUNT(*)
            INTO counter_2
            FROM grow_practice.appointments a
                     JOIN grow_practice.patients p ON (a.patient_id = p.id) AND
                                                      DATE(a.scheduled_date_time) =
                                                      DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND
                                                      a.status = 'NO_SHOW' AND a.is_provider_confirmed = 1 AND
                                                      a.med_group_id = `v_group_id`;

            SET j = 0;
            WHILE (j < counter_2)
                DO
                    SELECT p.phone_number,
                           p.email,
                           p.first_name,
                           p.last_name,
                           p.preferred_language,
                           a.patient_id,
                           a.id,
                           a.med_group_id,
                           a.provider_id,
                           a.scheduled_date_time,
                           a.location_id
                    INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_location_id
                    FROM grow_practice.appointments a
                             INNER JOIN grow_practice.patients p ON (a.patient_id = p.id) AND
                                                                    DATE(a.scheduled_date_time) =
                                                                    DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND
                                                                    a.status = 'NO_SHOW' AND
                                                                    a.is_provider_confirmed = '1' AND
                                                                    a.med_group_id = `v_group_id`
                    limit j,1;
                    INSERT INTO Temp1
                    VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`, `v_patient_id`,
                            `v_appt_id`,
                            `v_group_id`,
                            `v_provider_id`, TIME(v_schedule_date_time), DATE(v_schedule_date_time), `v_location_id`);
                    SET j = j + 1;
                END WHILE;
            SET i = i + 1;
            SET z = z + 1;
        END WHILE;

    SELECT * FROM Temp1;
END;
