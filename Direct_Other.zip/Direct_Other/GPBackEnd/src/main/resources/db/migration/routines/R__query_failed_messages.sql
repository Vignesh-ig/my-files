DROP PROCEDURE IF EXISTS query_failed_messages;

create procedure query_failed_messages(IN type varchar(45), IN start_date date, IN end_date date,
                                                             IN group_id varchar(45), IN p int) reads sql data
BEGIN
    if type = 'SMS' then
        SELECT COUNT(*)
        FROM grow_practice.sms_statuses
        WHERE ((grow_practice.sms_statuses.message_status = 'FAILED' OR
                grow_practice.sms_statuses.message_status = 'UNDELIVERED') AND
               (grow_practice.sms_statuses.sms_date >= start_date AND grow_practice.sms_statuses.sms_date <= end_date))
          AND (grow_practice.sms_statuses.med_group_id = group_id);
        SELECT grow_practice.sms_statuses.patient_id,
               grow_practice.patients.first_name,
               grow_practice.patients.last_name,
               grow_practice.patients.dob,
               grow_practice.patients.phone_number,
               grow_practice.patients.email,
               grow_practice.sms_statuses.sms_date
        FROM grow_practice.sms_statuses
                 INNER JOIN grow_practice.patients ON grow_practice.sms_statuses.patient_id = grow_practice.patients.id
        WHERE ((grow_practice.sms_statuses.message_status = 'FAILED' OR
                grow_practice.sms_statuses.message_status = 'UNDELIVERED') AND
               (grow_practice.sms_statuses.sms_date >= start_date AND grow_practice.sms_statuses.sms_date <= end_date))
          AND (grow_practice.sms_statuses.med_group_id = group_id)
        LIMIT 10 OFFSET p;
    elseif type = 'EMAIL' then
        SELECT COUNT(*)
        FROM grow_practice.emails
        WHERE (
            (grow_practice.emails.message_status = 'FAILED' OR grow_practice.emails.message_status = 'UNDELIVERED') AND
            (DATE(grow_practice.emails.date_time) >= start_date AND DATE(grow_practice.emails.date_time) <= end_date))
          AND (grow_practice.emails.med_group_id = group_id);
        SELECT grow_practice.emails.patient_id,
               grow_practice.patients.first_name,
               grow_practice.patients.last_name,
               grow_practice.patients.dob,
               grow_practice.patients.phone_number,
               grow_practice.patients.email,
               DATE(grow_practice.emails.date_time)
        FROM grow_practice.emails
                 INNER JOIN grow_practice.patients ON grow_practice.emails.patient_id = grow_practice.patients.id
        WHERE (
            (grow_practice.emails.message_status = 'FAILED' OR grow_practice.emails.message_status = 'UNDELIVERED') AND
            (DATE(grow_practice.emails.date_time) >= start_date AND DATE(grow_practice.emails.date_time) <= end_date))
          AND (grow_practice.emails.med_group_id = group_id)
        LIMIT 10 OFFSET p;
    elseif type = 'BOTH' then

        SELECT (SELECT COUNT(*)
                FROM grow_practice.sms_statuses
                WHERE ((grow_practice.sms_statuses.message_status = 'FAILED' OR
                        grow_practice.sms_statuses.message_status = 'UNDELIVERED') AND
                       (grow_practice.sms_statuses.sms_date >= start_date AND
                        grow_practice.sms_statuses.sms_date <= end_date))
                  AND (grow_practice.sms_statuses.med_group_id = group_id)) + (SELECT COUNT(*)
                                                                               FROM grow_practice.emails
                                                                               WHERE (
                                                                                   (grow_practice.emails.message_status =
                                                                                    'FAILED' OR
                                                                                    grow_practice.emails.message_status =
                                                                                    'UNDELIVERED') AND
                                                                                   (DATE(grow_practice.emails.date_time) >=
                                                                                    start_date AND
                                                                                    DATE(grow_practice.emails.date_time) <=
                                                                                    end_date))
                                                                                 AND (grow_practice.emails.med_group_id = group_id)) as sumCount;

        SELECT grow_practice.sms_statuses.patient_id,
               grow_practice.patients.first_name,
               grow_practice.patients.last_name,
               grow_practice.patients.dob,
               grow_practice.patients.phone_number,
               grow_practice.patients.email,
               grow_practice.sms_statuses.sms_date as theDate
        FROM grow_practice.sms_statuses
                 INNER JOIN
             grow_practice.patients ON grow_practice.sms_statuses.patient_id = grow_practice.patients.id
        WHERE ((grow_practice.sms_statuses.message_status = 'FAILED'
            OR grow_practice.sms_statuses.message_status = 'UNDELIVERED')
            AND (grow_practice.sms_statuses.sms_date >= start_date
                AND grow_practice.sms_statuses.sms_date <= end_date))
          AND (grow_practice.sms_statuses.med_group_id = group_id)

        UNION ALL
        SELECT grow_practice.emails.patient_id,
               grow_practice.patients.first_name,
               grow_practice.patients.last_name,
               grow_practice.patients.dob,
               grow_practice.patients.phone_number,
               grow_practice.patients.email,
               DATE(grow_practice.emails.date_time) as theDate
        FROM grow_practice.emails
                 INNER JOIN
             grow_practice.patients ON grow_practice.emails.patient_id = grow_practice.patients.id
        WHERE ((grow_practice.emails.message_status = 'FAILED'
            OR grow_practice.emails.message_status = 'UNDELIVERED')
            AND (DATE(grow_practice.emails.date_time) >= start_date
                AND DATE(grow_practice.emails.date_time) <= end_date))
          AND (grow_practice.emails.med_group_id = group_id)
        ORDER BY theDate
        LIMIT 10 OFFSET P;

    else
        SELECT CONCAT('INVALID TYPE: ', type, ' - VALID TYPES: SMS, EMAIL, BOTH') as error_message;

    end if;

END;
