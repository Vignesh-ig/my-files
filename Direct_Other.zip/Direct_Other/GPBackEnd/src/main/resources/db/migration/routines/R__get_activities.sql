DROP PROCEDURE IF EXISTS get_activities;

create procedure get_activities(IN term varchar(255), IN p int, IN group_id varchar(255),
                                                      IN provider_id int)
BEGIN
    IF provider_id != '' THEN
        SET provider_id = provider_id;
    ELSE
        SET provider_id = '%';
    END IF;

    IF term = '' THEN
        SELECT date_time, type, description, content
        FROM grow_practice.activities
        WHERE (med_group_id = group_id AND (activities.provider_id IS NULL OR activities.provider_id LIKE provider_id))
        order by DATE(date_time) DESC, TIME(date_time) DESC
        LIMIT 100 OFFSET p;
    END IF;
    IF term != '' THEN
        SELECT date_time, type, description, content
        FROM grow_practice.activities
        WHERE (type = term AND med_group_id = group_id AND
               (activities.provider_id is null OR activities.provider_id LIKE provider_id))
        ORDER BY DATE(date_time) DESC, TIME(date_time) DESC
        LIMIT 100 OFFSET p;
    END IF;
END;
