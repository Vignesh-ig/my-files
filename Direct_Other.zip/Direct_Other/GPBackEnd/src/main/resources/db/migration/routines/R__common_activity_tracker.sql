DROP PROCEDURE IF EXISTS common_activity_tracker;

CREATE PROCEDURE common_activity_tracker(IN group_id VARCHAR(255))
    READS SQL DATA
BEGIN
    DECLARE v_sms_count, v_email_count INT;
    DECLARE counter, counter2 INT;

    SET counter = 0;
    SET counter2 = 30;

    DROP TABLE IF EXISTS `Temp`;
    CREATE TEMPORARY TABLE Temp (
                                    sms_count INT,
                                    email_count INT
    );

    WHILE (counter < 31) DO
            SELECT COUNT(*)
            INTO v_sms_count
            FROM grow_practice.sms_statuses
            WHERE med_group_id = group_id
              AND sms_date = DATE_SUB(CURDATE(), INTERVAL counter2 DAY)
              AND (message_status = 'SENT' OR message_status = 'DELIVERED');

            SELECT COUNT(*)
            INTO v_email_count
            FROM grow_practice.emails
            WHERE med_group_id = group_id
              AND DATE(date_time) = DATE_SUB(CURDATE(), INTERVAL counter2 DAY)
              AND (message_status = 'SENT' OR message_status = 'DELIVERED');

            INSERT INTO Temp VALUES (v_sms_count, v_email_count);

            SET counter = counter + 1;
            SET counter2 = counter2 - 1;
        END WHILE;

    SELECT * FROM Temp;
END;