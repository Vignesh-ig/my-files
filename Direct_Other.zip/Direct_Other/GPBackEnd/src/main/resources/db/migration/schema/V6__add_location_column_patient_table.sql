-- Add a new nullable foreign key column 'preferred_location_id' to the 'patients' table
-- that references the 'id' column in the 'locations' table.

ALTER TABLE patients
    ADD preferred_location_id BIGINT NULL;

ALTER TABLE patients
    ADD CONSTRAINT fk_patients_on_preferred_location FOREIGN KEY (preferred_location_id) REFERENCES locations (id) ON DELETE SET NULL;

CREATE INDEX idx_patient_preferred_location_id ON patients (preferred_location_id);