-- Drop the 'type' column from the 'sms_email_template' table
-- Add 'template_usage' column in both 'sms_templates' and 'email_templates' tables

ALTER TABLE sms_templates
    DROP COLUMN type;

ALTER TABLE sms_templates
    ADD COLUMN template_usage TEXT NULL;

    ALTER TABLE email_templates
        ADD COLUMN template_usage TEXT NULL;