-- Add med_group_id column and index to users table

ALTER TABLE grow_practice.users
ADD COLUMN med_group_id VARCHAR(10) NOT NULL AFTER user_name;

ALTER TABLE grow_practice.users
ADD INDEX idx_users_med_group_id (med_group_id ASC) VISIBLE;
