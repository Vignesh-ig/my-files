-- Default SMS Templates
-- Default Manual Appointment Confirmed SMS Template
INSERT INTO sms_templates
(english_content, group_id, name, spanish_content, template_group, template_id, template_type, template_usage)
VALUES
('We have scheduled an appointment for {{FirstName}} {{LastName}} with {{ApptProviderName}} on {{ApptDate}} at {{ApptTime}}',
'default',
'Manual Appointment Confirmed',
'Nosotras hemos programado una cita para {{FirstName}} {{LastName}} con {{ApptProviderName}} en {{ApptDate}} en {{ApptTime}}',
'APPOINTMENT_CONFIRMATION',
'MANUAL_APPOINTMENT_CONFIRMED',
'INTERNAL',
'This SMS template is used to notify patients that the office staff has scheduled an appointment on their behalf.');

-- Default Appointment Confirmed SMS Template
INSERT INTO sms_templates
(`english_content`, `group_id`, `name`, `spanish_content`, `template_group`, `template_id`, `template_type`, `template_usage`)
VALUES
('Your appointment is now confirmed. The address of the office is here: {{ApptLocation}}. Thank you.',
'default',
'Appointment Confirmed',
'Su cita ya está confirmada. La dirección de la oficina está aquí: {{ApptLocation}}. Gracias.',
'APPOINTMENT_INTERACTION',
'APPOINTMENT_CONFIRMED',
'INTERNAL',
'This SMS template is used to confirm a patient\'s appointment after they reply to the reminder message we sent earlier.');

-- Default Appointment Cancellation SMS Template
INSERT INTO sms_templates
(`english_content`, `group_id`, `name`, `spanish_content`, `template_group`, `template_id`, `template_type`, `template_usage`)
VALUES
('We have canceled your appointment. If you would like to schedule again, click here: {{ApptLink}}',
'default',
'Appointment Cancellation',
'Hemos cancelado su cita. Si desea programar nuevamente, haga clic aquí: {{ApptLink}}',
'APPOINTMENT_INTERACTION',
'APPOINTMENT_CANCELLATION',
'INTERNAL',
'This SMS template is used to inform the patient about their appointment was cancelled.');

-- Default Appointment Cancellation Requested SMS Template
INSERT INTO sms_templates
(`english_content`, `group_id`, `name`, `spanish_content`, `template_group`, `template_id`, `template_type`, `template_usage`)
VALUES
('Hi {{FirstName}} {{LastName}}, We have received your appointment cancellation request. Our office staff will review the request and will follow up with you shortly. The following appointment with {{ApptProviderName}} that was scheduled for {{ApptDate}} at {{ApptTime}}.',
'default',
'Appointment Cancellation Requested',
'Hola {{FirstName}} {{LastName}}, Hemos recibido su solicitud de cancelación de cita. Nuestro personal de oficina revisará la solicitud y se comunicará con usted en breve. La siguiente cita con el {{ApptProviderName}} que estaba programada para el {{ApptDate}} a las {{ApptTime}}.',
'APPOINTMENT_CANCELED',
'APPOINTMENT_CANCELLATION_REQUESTED',
'INTERNAL',
'This SMS template is used to inform patients that the office has received their appointment cancellation request.');

-- Default Appointment Rescheduled SMS Template
INSERT INTO sms_templates
(`english_content`, `group_id`, `name`, `spanish_content`, `template_group`, `template_id`, `template_type`, `template_usage`)
VALUES
('Hi {{FirstName}} {{LastName}}, we have rescheduled your appointment with {{ApptProviderName}} to {{ApptDate}} at {{ApptTime}}. To make another appointment, click here: {{ApptLink}}',
'default',
'Appointment Rescheduled',
'Hola, {{FirstName}} {{LastName}}, hemos reprogramado su cita con el {{ApptProviderName}} para {{ApptDate}} a las {{ApptTime}}. Para hacer otra cita, haga clic aqu?: {{ApptLink}}',
'APPOINTMENT_RESCHEDULED',
'APPOINTMENT_RESCHEDULED',
'INTERNAL',
'This SMS template is used to notify patients that their appointment has been rescheduled by the staff.');

-- Default Link to All Forms SMS Template
INSERT INTO sms_templates
(`english_content`, `group_id`, `name`, `spanish_content`, `template_group`, `template_id`, `template_type`, `template_usage`)
VALUES
('Hi {{FirstName}}, here is the link to fill all the required forms before the appointment: {{IntakeLink}}',
'default',
'Link to All Forms',
'Hola {{FirstName}}, aquí está el enlace para completar todos los formularios requeridos antes de la cita: {{IntakeLink}}',
'CUSTOM',
'LINK_TO_ALL_FORMS',
'EXTERNAL',
'This SMS template is used when staff request a patient from the Awaiting tab in the dashboard to submit their medical forms.');

-- Default Unknow contact workflow
INSERT INTO sms_templates
(`english_content`, `group_id`, `name`, `spanish_content`, `template_group`, `template_id`, `template_type`, `template_usage`)
VALUES
('Hi, We do not recognize your phone number in our system. Please click on this link to proceed further: {{UnknownContactWorkflowLink}}',
'default',
'Unknow contact workflow',
'Hola, no reconocemos tu número de teléfono en nuestro sistema. Por favor haga clic en este enlace para continuar: {{UnknownContactWorkflowLink}}',
'WORKFLOW',
'UNKNOW_CONTACT_WORKFLOW',
'INTERNAL',
'When an unknown patient sends an SMS to the office, a new patient profile is created with temporary details, and they are asked to register with Medgroup.');

-- Default Auto Reply Text Message SMS Template
INSERT INTO sms_templates
(`english_content`, `group_id`, `name`, `spanish_content`, `template_group`, `template_id`, `template_type`, `template_usage`)
VALUES
('Our office is currently closed. If this is an emergency, please contact 911. Otherwise, we would respond to your SMS message during our office hours.',
'default',
'Auto Reply Text Message',
'uestra oficina est&aacute; actualmente cerrada. Si se trata de una emergencia, comuníquese con el 911. De lo contrario, responderemos a su mensaje SMS durante nuestro horario de oficina.',
'APPOINTMENT_INTERACTION',
'AUTO_REPLY_TEXT_MESSAGE',
'INTERNAL',
'This SMS template is used to inform patients that the office is currently closed when they send a message outside of business hours.');

-- Default Appointment Request Cancellation SMS Template
INSERT INTO sms_templates
(`english_content`, `group_id`, `name`, `spanish_content`, `template_group`, `template_id`, `template_type`, `template_usage`)
VALUES
('We are unable to confirm your appointment request with {{ApptProviderName}}.',
'default',
'Appointment Request Cancellation',
'No podemos confirmar su solicitud de cita con el {{ApptProviderName}}.',
'APPOINTMENT_CANCELED',
'APPOINTMENT_REQUEST_CANCELLATION',
'INTERNAL',
'This SMS template is used to notify patients when their appointment request has been canceled by the office staff.');

-- Default Email Template Attributes
INSERT INTO `grow_practice`.`email_template_attributes`(
`english_header_footer`,
`group_id`,
`spanish_header_footer`,
`style`)
VALUES(
'{\"footer\": {\"content\": [\"<p style=\\\"font-weight: bold;\\\">{{OfficeName}}</p>\", \"<p style=\\\"font-weight: bold;\\\">Main Address: {{OfficeAddress}}</p>\", \"<p style=\\\"font-weight: bold;\\\">Phone: {{OfficePhone}}</p>\"]}, \"header\": {\"content\": [\"<h1 style=\\\"color: #333; font-family: Arial, sans-serif;text-align: center;\\\">{{OfficeName}}</h1>\"]}}',
'default',
'{\"footer\": {\"content\": [\"<p style=\\\"font-weight: bold;\\\">{{OfficeName}}</p>\", \"<p style=\\\"font-weight: bold;\\\">Main Address: {{OfficeAddress}}</p>\", \"<p style=\\\"font-weight: bold;\\\">Phone: {{OfficePhone}}</p>\"]}, \"header\": {\"content\": [\"<h1 style=\\\"color: #333; font-family: Arial, sans-serif;text-align: center;\\\">{{OfficeName}}</h1>\"]}}',
'{\"body\": \"word-wrap: break-word; overflow-wrap: break-word; white-space: pre-wrap; text-align: left;\", \"footer\": \"\", \"header\": \"\"}');

-- Attribute Id
SET @a_id = LAST_INSERT_ID();

-- Default Manual Appointment Confirmed Email Template
INSERT INTO `grow_practice`.`email_templates`
(`english_content`, `group_id`, `name`, `spanish_content`, `subject`, `template_group`, `template_id`, `template_type`, `template_usage`, `attribute_id`, `is_restricted`)
VALUES (
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hi {{FirstName}},</p>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"font-size: 0.875rem;\\\">            </span><span style=\\\"white-space-collapse: collapse; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center;\\\">Your appointment listed below is now confirmed.</span></div>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"white-space-collapse: collapse; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center;\\\"><br></span></div>\", \"<div style=\\\"text-align: center;\\\"><span style=\\\"white-space: normal; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px;\\\">Provider Name:&nbsp;&nbsp;</span><font color=\\\"#153643\\\" face=\\\"sans-serif\\\"><span style=\\\"font-size: 16px; text-wrap-mode: wrap;\\\"><span style=\\\"text-align: center;\\\"></span><span style=\\\"text-align: left;\\\">{{ApptProviderName}}</span></span></font></div>\", \"<div style=\\\"text-align: center;\\\"><span style=\\\"white-space: normal; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px;\\\">Appointment Date:&nbsp;</span><span style=\\\"text-align: left; font-size: 16px; text-wrap-mode: wrap;\\\"><font color=\\\"#153643\\\" face=\\\"sans-serif\\\">{{ApptDate}}</font></span></div>\", \"<div style=\\\"text-align: center;\\\"><span style=\\\"white-space: normal; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px;\\\">Appointment Time:&nbsp;</span><span style=\\\"text-align: left; font-size: 16px; text-wrap-mode: wrap;\\\"><font color=\\\"#153643\\\" face=\\\"sans-serif\\\">{{ApptTime}}</font></span></div>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"white-space-collapse: collapse; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center;\\\"><br></span></div>\", \"<div style=\\\"white-space: pre-wrap; text-align: right;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center; white-space-collapse: collapse;\\\">&nbsp;</span></div>\"]}',
'default',
'Manual Appointment Confirmed',
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hola {{FirstName}},</p>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"font-size: 0.875rem;\\\">  Su cita que aparece a continuación ya está confirmada.</span></div>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"font-size: 0.875rem;\\\"><br></span></div>\", \"<div style=\\\"text-align: center;\\\"><span style=\\\"white-space: normal; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px;\\\">Nombre del proveedor:</span><span style=\\\"text-align: left; font-size: 16px; text-wrap-mode: wrap;\\\"><font color=\\\"#153643\\\" face=\\\"sans-serif\\\"> {{ApptProviderName}}</font></span></div>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; white-space-collapse: collapse;\\\">Día de la cita: {{ApptDate}}</span><br style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; white-space-collapse: collapse;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; white-space-collapse: collapse;\\\">Hora de la cita: {{ApptTime}}</span><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; white-space-collapse: collapse;\\\"></span></div>\"]}',
'Your appointment with the doctor is confirmed...',
'APPOINTMENT_CONFIRMATION',
'MANUAL_APPOINTMENT_CONFIRMED',
'INTERNAL',
'This email template is used to inform the patient when a staff schedules an appointment on their behalf through an external system.',
@a_id,
0);

-- Default Appointed Confirmed Email Template
INSERT INTO `grow_practice`.`email_templates`
(`english_content`, `group_id`, `name`, `spanish_content`, `subject`, `template_group`, `template_id`, `template_type`, `template_usage`, `attribute_id`, `is_restricted`)
VALUES (
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hi {{FirstName}},</p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><br></p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center; white-space-collapse: collapse;\\\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Your appointment request listed below is now confirmed.</span></p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center; white-space-collapse: collapse;\\\"><br></span></p>\", \"<p style=\\\"text-align: left;\\\"><span style=\\\"white-space: normal; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center;\\\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span><span style=\\\"white-space: normal; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center;\\\">Provider Name:&nbsp;</span><font color=\\\"#153643\\\" face=\\\"sans-serif\\\"><span style=\\\"font-size: 16px; text-wrap-mode: wrap;\\\">{{ApptProviderName}}</span></font></p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-align: center; white-space-collapse: collapse;\\\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Appointment Date: {{ApptDate}}</span></p>\", \"<div style=\\\"text-align: center;\\\"><span style=\\\"font-family: sans-serif;\\\">         Appointment Time: {{ApptTime}</span><span style=\\\"text-align: left; white-space-collapse: preserve; color: rgb(0, 0, 0); font-size: 0.875rem;\\\">}           </span></div>\"]}',
'default',
'Appointed Confirmed',
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hola {{FirstName}},</p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><br></p>\", \"<div style=\\\"text-align: center; white-space: pre-wrap;\\\"><span style=\\\"font-size: 0.875rem;\\\">            Su solicitud de cita que aparece a continuación ya está confirmada.</span></div>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"font-size: 0.875rem;\\\"><br></span></div>\", \"<div style=\\\"text-align: center;\\\"><span style=\\\"white-space: normal; color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px;\\\">Nombre del proveedor:&nbsp;</span><span style=\\\"text-align: left; font-size: 16px; text-wrap-mode: wrap;\\\"><font color=\\\"#153643\\\" face=\\\"sans-serif\\\">{{ApptProviderName}}</font></span></div>\", \"<div style=\\\"text-align: center; white-space: pre-wrap;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; white-space-collapse: collapse;\\\">Día de la cita: {{ApptDate}}</span><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; white-space-collapse: collapse;\\\"></span></div>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; white-space-collapse: collapse;\\\">Hora de la cita: {{ApptTime}}</span><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; white-space-collapse: collapse;\\\"></span></div>\"]}',
'Your appointment with the doctor is confirmed...',
'APPOINTMENT_CONFIRMATION',
'APPOINTMENT_CONFIRMED',
'INTERNAL',
'This email template is used to inform the patient when a staff schedules an appointment on their behalf through an external system.',
@a_id,
0);

-- Default Appointment Cancelled Email Template
INSERT INTO `grow_practice`.`email_templates`
(`english_content`, `group_id`, `name`, `spanish_content`, `subject`, `template_group`, `template_id`, `template_type`, `template_usage`, `attribute_id`, `is_restricted`)
VALUES (
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hi {{FirstName}},</p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><br></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Sorry, the following appointment got canceled.</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Provider Name: </span><span style=\\\"text-align: left; white-space: pre-wrap;\\\">{{ApptProviderName}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\">Appointment Date: {{ApptDate}}</span></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\">Appointment Time: {{ApptTime}}</span></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\">Please schedule a new appointment using the following link:</span></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"color: rgb(21, 54, 67); font-family: sans-serif; font-size: 16px; text-wrap-mode: wrap;\\\">{ApptLink}</span><span style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\"></span></span></p>\"]}',
'default',
'Appointment Cancelled',
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hola {{FirstName}},</p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><br></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Lo sentimos, la siguiente cita fue cancelada.</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Nombre del proveedor: </span><span style=\\\"text-align: left; white-space: pre-wrap;\\\">{{ApptProviderName}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Día de la cita: {{ApptDate}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Hora de la cita: {{ApptTime}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Programe una nueva cita utilizando el siguiente enlace:</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">{{ApptLink}}</span></p>\"]}',
'Appointment cancelled',
'APPOINTMENT_CANCELED',
'APPOINTMENT_CANCELLED',
'INTERNAL',
'This email template is used to notify patients that their appointment has been cancelled.',
 @a_id,
 0);

-- Default Appointment Cancellation Requested Email Template
INSERT INTO `grow_practice`.`email_templates` (`english_content`, `group_id`, `name`, `spanish_content`, `subject`, `template_group`, `template_id`, `template_type`, `template_usage`, `attribute_id`, `is_restricted`)
VALUES (
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hi {{FirstName}},</p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><br></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">We have received your appointment cancellation request. Our office staff will review the request and will follow up with you shortly.</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Provider Name: </span><span style=\\\"text-align: left; white-space: pre-wrap;\\\">{{ApptProviderName}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Requested Date: {{ApptDate}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Requested Time: {{ApptTime}}</span></p>\"]}',
'default',
'Appointment Cancellation Requested',
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hola {FirstName},</p>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"font-size: 0.875rem;\\\">            Hemos recibido su solicitud de cancelación de cita. Nuestro personal la revisará y se pondrá en contacto con usted en breve.</span></div>\", \"<div style=\\\"white-space: pre-wrap; text-align: center;\\\"><span style=\\\"font-size: 0.875rem;\\\"><br></span></div>\", \"<div style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Nombre del proveedor: {{ApptProviderName}}\\nFecha solicitada: {{ApptDate}}\\nHora solicitada: {{ApptTime}}</span></div>\"]}',
'Appointment cancellation request',
'APPOINTMENT_CANCELED',
'APPOINTMENT_CANCELLATION_REQUESTED',
'INTERNAL',
'This email template is used to notify patients that their appointment cancellation request has been received by the office.',
@a_id,
0);

-- Default Appointment Rescheduled Email Template
INSERT INTO `grow_practice`.`email_templates`
(`english_content`, `group_id`, `name`, `spanish_content`, `subject`, `template_group`, `template_id`, `template_type`, `attribute_id`, `template_usage`, `is_restricted`)
VALUES (
'{\"content\": [\"<p style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\">Hi {{FirstName}},</span></p>\", \"<p style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Your appointment had been rescheduled.</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Provider Name: </span><span style=\\\"text-align: left; white-space: pre-wrap;\\\">{{ApptProviderName}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Appointment Date:</span><span style=\\\"text-align: left; white-space: pre-wrap;\\\">&nbsp;{{ApptDate}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Appointment Time: </span><span style=\\\"text-align: left; white-space: pre-wrap;\\\">{{ApptTime}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">If you have any questions, please give us a call at {{</span><span style=\\\"text-align: left; white-space: pre-wrap;\\\">OfficePhone</span><span style=\\\"white-space: pre-wrap; font-size: 0.875rem;\\\">}}.</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap; font-size: 0.875rem;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">If you would like to modify the appointment, please click on this link</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">{{ApptLink}}</span></p>\"]}',
'default',
'Appointment Rescheduled',
'{\"content\": [\"<p style=\\\"text-align: left;\\\">Hola&nbsp;{{FirstName}},</p>\", \"<p style=\\\"text-align: left;\\\"><br></p>\", \"<p style=\\\"text-align: center;\\\">Su cita ha sido reprogramada.</p>\", \"<p style=\\\"text-align: center;\\\">Nombre del proveedor:<span style=\\\"text-align: left;\\\">&nbsp;{{ApptProviderName}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\">Día de la cita:&nbsp;</span><span style=\\\"text-align: left;\\\">{{ApptDate}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\">Hora de la cita:&nbsp;</span><span style=\\\"text-align: left;\\\">{{ApptTime}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\">Si tiene alguna pregunta, llámenos al {{</span><span style=\\\"white-space: pre-wrap; text-align: left; font-size: 0.875rem;\\\">OfficePhone</span><span style=\\\"text-align: left; font-size: 0.875rem;\\\">}}</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left; font-size: 0.875rem;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\">Si desea modificar la cita, haga clic en este enlace</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"text-align: left;\\\">{{ApptLink}}</span></p>\"]}',
'Appointment rescheduled',
'APPOINTMENT_RESCHEDULED',
'APPOINTMENT_RESCHEDULED',
'INTERNAL',
@a_id,
'This email template is used to notify patients that their appointment has been rescheduled by the staff.',
0);

-- Default Link to ALL Forms Email Template
INSERT INTO `grow_practice`.`email_templates`
(`english_content`, `group_id`, `name`, `spanish_content`, `subject`, `template_group`, `template_id`, `template_type`, `attribute_id`, `template_usage`, `is_restricted`)
VALUES (
'{\"content\": [\"<p style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\">Hi {{FirstName}},</span></p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><br></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Here is the link to fill all the required forms:</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">{{</span><span style=\\\"text-align: left; white-space: pre-wrap;\\\">FormPacketLink</span><span style=\\\"white-space: pre-wrap; font-size: 0.875rem;\\\">}}</span></p>\"]}',
'default',
'Link to ALL Forms',
'{\"content\": [\"<p style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\">Hola {{FirstName}},</span></p>\", \"<p style=\\\"text-align: left;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Aquí está el enlace para completar todos los formularios requeridos:</span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\"><br></span></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"--tw-scale-x: 1; --tw-scale-y: 1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness: proximity; --tw-gradient-from-position: ; --tw-gradient-via-position: ; --tw-gradient-to-position: ; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width: 0px; --tw-ring-offset-color: #fff; --tw-ring-color: rgb(59 130 246 / 0.5); --tw-ring-offset-shadow: 0 0 #0000; --tw-ring-shadow: 0 0 #0000; --tw-shadow: 0 0 #0000; --tw-shadow-colored: 0 0 #0000; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; --tw-contain-size: ; --tw-contain-layout: ; --tw-contain-paint: ; --tw-contain-style: ; white-space: pre-wrap;\\\">{{</span><span style=\\\"--tw-scale-x: 1; --tw-scale-y: 1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness: proximity; --tw-gradient-from-position: ; --tw-gradient-via-position: ; --tw-gradient-to-position: ; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width: 0px; --tw-ring-offset-color: #fff; --tw-ring-color: rgb(59 130 246 / 0.5); --tw-ring-offset-shadow: 0 0 #0000; --tw-ring-shadow: 0 0 #0000; --tw-shadow: 0 0 #0000; --tw-shadow-colored: 0 0 #0000; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; --tw-contain-size: ; --tw-contain-layout: ; --tw-contain-paint: ; --tw-contain-style: ; text-align: left; white-space: pre-wrap;\\\">FormPacketLink</span><span style=\\\"--tw-scale-x: 1; --tw-scale-y: 1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness: proximity; --tw-gradient-from-position: ; --tw-gradient-via-position: ; --tw-gradient-to-position: ; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width: 0px; --tw-ring-offset-color: #fff; --tw-ring-color: rgb(59 130 246 / 0.5); --tw-ring-offset-shadow: 0 0 #0000; --tw-ring-shadow: 0 0 #0000; --tw-shadow: 0 0 #0000; --tw-shadow-colored: 0 0 #0000; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; --tw-contain-size: ; --tw-contain-layout: ; --tw-contain-paint: ; --tw-contain-style: ; font-size: 0.875rem; white-space: pre-wrap;\\\">}}</span><span style=\\\"white-space: pre-wrap;\\\"></span></p>\"]}',
'Link to ALL Forms',
'CUSTOM',
'LINK_TO_ALL_FORMS',
'EXTERNAL',
@a_id,
'This email template is used when staff request a patient from the Awaiting tab in the dashboard to submit their medical forms.',
0);

-- Default Appointment Request Cancellation Email Template
INSERT INTO `grow_practice`.`email_templates`
(`english_content`, `group_id`, `is_restricted`, `name`, `spanish_content`, `subject`, `template_group`, `template_id`, `template_type`, `attribute_id`, `template_usage`)
VALUES (
'{\"content\": [\"<p style=\\\"white-space: pre-wrap; text-align: left;\\\">Hi {{FirstName}},</p>\", \"<p style=\\\"white-space: pre-wrap; text-align: left;\\\"><br></p>\", \"<p style=\\\"text-align: center;\\\"><span style=\\\"white-space: pre-wrap;\\\">Sorry, we are unable to accommodate your appointment request. If you have any questions, please give us a call at {{OfficePhone}}.</span></p>\"]}',
'default',
0,
'Appointment Request Cancellation',
'{\"content\": [\"<p style=\\\"text-align: left;\\\">Hi {{FirstName}},</p>\", \"<p style=\\\"text-align: left;\\\"><br></p>\", \"<div style=\\\"text-align: center;\\\"><span style=\\\"font-size: 0.875rem;\\\">Lo sentimos, no podemos atender su solicitud de cita. Si tiene alguna pregunta, por favor llámenos al {{OfficePhone}}.</span></div>\"]}',
'Pending appointment request canceled',
'APPOINTMENT_CANCELED',
'APPOINTMENT_REQUEST_CANCELLATION',
'INTERNAL',
@a_id,
'This email template is used to inform patients that their appointment request has been cancelled.');

-- SMS
INSERT INTO grow_practice.sms_templates
(
    english_content,
    spanish_content,
    group_id,
    is_restricted,
    name,
    template_group,
    template_type,
    template_usage,
    template_id
)
SELECT
    s.english_content,
    s.spanish_content,
    m.group_id,
    s.is_restricted,
    s.name,
    s.template_group,
    s.template_type,
    s.template_usage,
    s.template_id
FROM grow_practice.med_groups m
CROSS JOIN grow_practice.sms_templates s
WHERE s.group_id = 'default'
  AND NOT EXISTS (
      SELECT 1
      FROM grow_practice.sms_templates st
      WHERE st.group_id = m.group_id
      AND st.name = s.name
  );

-- This stored procedure takes the default email templates and copies them to all medgroups that do not have them yet.
DROP PROCEDURE IF EXISTS copy_default_email_templates;

CREATE PROCEDURE copy_default_email_templates()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE grp_id varchar(10);
    DECLARE default_attr_id BIGINT;
    DECLARE new_attr_id BIGINT;
    DECLARE grp_cursor CURSOR FOR SELECT group_id FROM med_groups;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    main_block: BEGIN

        SELECT id INTO default_attr_id
        FROM email_template_attributes
        WHERE group_id = 'default'
        LIMIT 1;

        IF default_attr_id IS NULL THEN
            SELECT 'No default attribute found!' AS message;
            LEAVE main_block;
        END IF;

        OPEN grp_cursor;

        read_loop: LOOP
            FETCH grp_cursor INTO grp_id;
            IF done THEN
                LEAVE read_loop;
            END IF;

            IF NOT EXISTS (
                SELECT 1
                FROM email_template_attributes
                WHERE group_id = grp_id
            ) THEN
                INSERT INTO email_template_attributes (english_header_footer, spanish_header_footer, style, group_id)
                SELECT english_header_footer, spanish_header_footer, style, grp_id
                FROM email_template_attributes
                WHERE id = default_attr_id;

                SET new_attr_id = LAST_INSERT_ID();
            ELSE
                SELECT id INTO new_attr_id
                FROM email_template_attributes
                WHERE group_id = grp_id
                LIMIT 1;
            END IF;

            INSERT INTO email_templates
            (
                english_content,
                spanish_content,
                group_id,
                is_restricted,
                name,
                subject,
                template_group,
                template_type,
                attribute_id,
                template_usage,
                template_id
            )
            SELECT
                et_default.english_content,
                et_default.spanish_content,
                grp_id,
                et_default.is_restricted,
                et_default.name,
                et_default.subject,
                et_default.template_group,
                et_default.template_type,
                new_attr_id,
                et_default.template_usage,
                et_default.template_id
            FROM email_templates et_default
            WHERE et_default.group_id = 'default'
              AND NOT EXISTS (
                  SELECT 1
                  FROM email_templates et
                  WHERE et.group_id = grp_id
                  AND et.name = et_default.name
              );

        END LOOP;

        CLOSE grp_cursor;

        SELECT 'Default email templates copied successfully for all medgroups.' AS message;

    END main_block;
END;

CALL copy_default_email_templates();

DROP PROCEDURE copy_default_email_templates;