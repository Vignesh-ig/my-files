-- Drop integration_api_key table and added integrations, integration_config and integration_resources table for integration setup

DROP TABLE grow_practice.integration_api_keys;

CREATE TABLE integrations (
  id bigint NOT NULL AUTO_INCREMENT,
  integration_name varchar(45) NOT NULL,
  med_group_id varchar(10) NOT NULL,
  integration_type varchar(45) NOT NULL,
  PRIMARY KEY (id),
  KEY idx_integrations_med_group_id (med_group_id),
  CONSTRAINT FKc7w170lsgk19s1mn2s36gaxkl FOREIGN KEY (med_group_id) REFERENCES med_groups (group_id) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE integration_config (
  id bigint NOT NULL AUTO_INCREMENT,
  config_name varchar(45) NOT NULL,
  config_value varchar(2000) NOT NULL,
  integrates_with varchar(45) NOT NULL,
  med_group_id varchar(10) NOT NULL,
  PRIMARY KEY (id),
  KEY idx_integration_config_med_group_id (med_group_id),
  CONSTRAINT FKt8fnlhj0q2dvwdgrdw39yffc2 FOREIGN KEY (med_group_id) REFERENCES med_groups (group_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE integration_resources (
  id bigint NOT NULL AUTO_INCREMENT,
  actions json NOT NULL,
  integration_name varchar(45) NOT NULL,
  integration_resource enum('APPOINTMENT','DOCUMENT','INSURANCE','PATIENT','POLLING','WEBHOOK') NOT NULL,
  med_group_id varchar(10) NOT NULL,
  PRIMARY KEY (id),
  KEY idx_ir_groupId_integration_resource (med_group_id,integration_name,integration_resource),
  CONSTRAINT FK3k9ml73uk4sh07p3m3or4mri7 FOREIGN KEY (med_group_id) REFERENCES med_groups (group_id) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
