-- This query inserts default values to 'is_restricted' column in 'sms_templates' table
UPDATE sms_templates SET is_restricted = 0;