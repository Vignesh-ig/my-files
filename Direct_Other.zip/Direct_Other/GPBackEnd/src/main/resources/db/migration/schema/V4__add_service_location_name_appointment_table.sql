-- Add location_name and service_name columns to appointments table and populate them with data from locations and services tables
-- Also add the same columns to canceled_appointments table and populate them with data from locations table

ALTER TABLE appointments
    ADD COLUMN location_name VARCHAR(45) NULL;

ALTER TABLE appointments
    ADD COLUMN service_name VARCHAR(45) NULL;

ALTER TABLE canceled_appointments
    ADD COLUMN location_name VARCHAR(45) NULL;

UPDATE appointments a
    JOIN locations l ON a.location_id = l.id
SET a.location_name = l.name;

UPDATE appointments a
    JOIN services s ON a.service_id = s.id
SET a.service_name = s.service_name;

UPDATE canceled_appointments ca
    JOIN locations l ON ca.location_id = l.id
SET ca.location_name = l.name;
