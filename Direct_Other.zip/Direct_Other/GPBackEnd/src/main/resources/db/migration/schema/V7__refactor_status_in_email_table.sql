-- UPDATE message_status column in email table, remove unnecessary values in enum

ALTER TABLE emails
    MODIFY COLUMN message_status ENUM ('SENT', 'UNSENT') NOT NULL;