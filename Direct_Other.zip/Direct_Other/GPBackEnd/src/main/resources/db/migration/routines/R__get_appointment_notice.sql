DROP PROCEDURE IF EXISTS get_appointment_notice;

CREATE PROCEDURE get_appointment_notice(
    IN group_id VARCHAR(255),
    IN reminder_day INT
)
    READS SQL DATA
BEGIN
    DROP TABLE IF EXISTS `Temp1`;
    CREATE TEMPORARY TABLE Temp1 (
                                     cell_phone VARCHAR(255),
                                     patient_id VARCHAR(255),
                                     appointment_id VARCHAR(255),
                                     group_id VARCHAR(255)
    );

    INSERT INTO Temp1 (cell_phone, patient_id, appointment_id, group_id)
    SELECT p.phone_number, a.patient_id, a.id, a.med_group_id
    FROM grow_practice.appointments AS a
             INNER JOIN grow_practice.patients AS p
                        ON a.patient_id = p.id
    WHERE DATE(a.scheduled_date_time) = DATE_ADD(CURDATE(), INTERVAL reminder_day DAY)
      AND a.is_provider_confirmed = 1
      AND a.med_group_id = group_id;

    SELECT * FROM Temp1;
END;