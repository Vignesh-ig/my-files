DROP PROCEDURE IF EXISTS clean_up_sms_table;

create procedure clean_up_sms_table()
BEGIN
    DECLARE current_uuid VARCHAR(255);
    DECLARE previous_uuid VARCHAR(255);

    DECLARE current_id INT;

    DECLARE done TINYINT DEFAULT FALSE;

    DECLARE cursor_1 CURSOR FOR SELECT a.id, a.message_uuid
                                FROM grow_practice.sms a
                                         JOIN (SELECT id,
                                                      date_time,
                                                      conversation_id,
                                                      message_uuid,
                                                      conversation_status,
                                                      conversation_depth,
                                                      conversation_type,
                                                      sms_type,
                                                      is_read,
                                                      COUNT(message_uuid)
                                               FROM grow_practice.sms
                                               GROUP BY message_uuid
                                               HAVING count(*) > 1) b ON a.message_uuid = b.message_uuid
                                ORDER BY a.message_uuid;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    SET previous_uuid = '';
    OPEN cursor_1;

    my_loop:
    LOOP
        FETCH cursor_1 INTO current_id, current_uuid;

        IF done THEN
            LEAVE my_loop;
        ELSE

            IF (current_uuid != previous_uuid) THEN

                SET previous_uuid = current_uuid;

            ELSE
                SET previous_uuid = current_uuid;
                UPDATE grow_practice.sms SET message_uuid = 'UNKNOWN' WHERE id = current_id;

            END IF;
        END IF;
    END LOOP;

    CLOSE cursor_1;

END;
