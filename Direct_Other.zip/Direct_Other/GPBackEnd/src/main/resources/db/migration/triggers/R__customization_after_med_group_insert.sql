DROP TRIGGER IF EXISTS customization_after_med_group_insert;
CREATE TRIGGER customization_after_med_group_insert
    AFTER INSERT
    ON grow_practice.med_groups
    FOR EACH ROW
BEGIN
    INSERT INTO grow_practice.customizations (address_flag,
                                              appt_cancel_restriction_period,
                                              appt_request_popup_content,
                                              appt_reschedule_restriction_period,
                                              appt_thank_you_page_content,
                                              booking_fee_switch,
                                              booking_lead_time_in_minutes,
                                              booking_prevention_switch,
                                              booking_preventions_start_time,
                                              default_booking_fee,
                                              forms_packet_link,
                                              insurance_company_flag,
                                              insurance_group_id_flag,
                                              insurance_id_flag,
                                              medgroup_work_flow,
                                              notify_waitlist_patient_limit,
                                              notify_waitlist_patient_switch,
                                              patient_update_form_flag,
                                              preferred_contact_flag,
                                              reason_for_visit_flag,
                                              med_group_id)
    VALUES (0, 0, NULL, 0, NULL, 0, 0, 0, NULL, NULL, NULL, 0, 0, 0, 0, 1, 0, 0, 0, 0, NEW.group_id);
END;