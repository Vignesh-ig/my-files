DROP FUNCTION IF EXISTS split;

create function split(str varchar(500), del varchar(2), x int) returns varchar(500)
    deterministic
    reads sql data
BEGIN
    RETURN SUBSTR(SUBSTRING_INDEX(str, del, x),
                  LENGTH(SUBSTRING_INDEX(str, del, x - 1)) + IF(x > 1, 2, 1));
END;

