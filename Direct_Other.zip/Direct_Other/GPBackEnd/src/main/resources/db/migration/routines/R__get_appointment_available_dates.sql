DROP PROCEDURE IF EXISTS get_appointment_available_dates;
CREATE PROCEDURE get_appointment_available_dates(
	IN group_id VARCHAR(10) ,
    IN provider_id BIGINT,
    IN location_id BIGINT,
    IN service_id BIGINT,
    IN current_date_time DATETIME
)
BEGIN

DECLARE cur_date, temp_today_date DATE;
DECLARE cur_time TIME;
DECLARE month_last_date DATE;
DECLARE days_left_in_month INT;

DECLARE available_dates JSON;
DECLARE available_slots JSON;

DECLARE service_duration, p_booking_per_slot, p_booking_per_day, p_default_appointment_duration INT;
DECLARE p_booking_type, day_of_week VARCHAR(15);

DECLARE unavailability_count, booked_appt_count, specific_avail_count, recurring_avail_count, specific_without_location_count, total_availability, available_slot_count, exiting_appt_count INT;
DECLARE i, j, k INT;

DECLARE available_start_time, available_end_time, slot_start_time, slot_end_time, j_start_time, j_end_time, exist_app_start_time, exist_app_end_time TIME;

DECLARE is_slot_unavailable, dummy BOOLEAN;
DECLARE slot_exist_count, exist_appt_duration INT;

SET cur_date = DATE(current_date_time);
SET cur_time = TIME(current_date_time);
SET month_last_date = LAST_DAY(cur_date);
SET days_left_in_month = DATEDIFF(month_last_date, cur_date);

SET temp_today_date = DATE(current_date_time);

SELECT duration INTO service_duration FROM grow_practice.services AS s WHERE s.med_group_id = group_id AND s.id = service_id;
SELECT booking_type, booking_per_slot, booking_per_day, default_appt_duration INTO p_booking_type, p_booking_per_slot, p_booking_per_day, p_default_appointment_duration FROM grow_practice.providers AS p WHERE p.med_group_id = group_id AND p.id = provider_id;

IF service_duration = 0 THEN
	SET service_duration = p_default_appointment_duration;
END IF;

IF p_booking_type = 'SINGLE' THEN
	SET p_booking_per_slot = 1;
ELSEIF p_booking_type = 'DOUBLE' THEN
	SET p_booking_per_slot = 2;
ELSEIF p_booking_type = 'TRIPLE' THEN
	SET p_booking_per_slot = 3;
END IF;

SET available_dates = JSON_ARRAY();

loop_to_eom:
WHILE (cur_date <= month_last_date) DO
	SELECT COUNT(exception_date) INTO unavailability_count FROM grow_practice.unavailabilities AS u WHERE u.med_group_id = group_id AND u.provider_id = provider_id AND u.exception_date = cur_date ;

	IF (unavailability_count = 0) THEN
		SELECT COUNT(scheduled_time) INTO booked_appt_count FROM grow_practice.appointments AS a WHERE a.med_group_id = group_id AND a.provider_id = provider_id AND a.location_id = location_id AND a.scheduled_date = cur_date;
        SELECT DAYNAME(cur_date) INTO day_of_week;

        IF (booked_appt_count < p_booking_per_day) THEN
			SELECT count(*) INTO specific_avail_count FROM grow_practice.specific_availabilities AS a WHERE a.med_group_id = group_id AND a.provider_id = provider_id AND a.location_id = location_id AND a.schedule_date = cur_date;
            SELECT count(*) INTO specific_without_location_count FROM grow_practice.specific_availabilities AS s WHERE s.med_group_id = group_id AND s.provider_id = provider_id AND s.location_id != location_id AND s.schedule_date = cur_date;
            SELECT count(*) INTO recurring_avail_count FROM grow_practice.recurring_availabilities AS r WHERE r.med_group_id = group_id AND r.provider_id = provider_id AND r.location_id = location_id AND r.day = day_of_week;

            IF(specific_avail_count > 0) THEN
				SET total_availability = specific_avail_count;
			ELSEIF(specific_avail_count= 0 AND specific_without_location_count > 0) THEN
				SET total_availability = 0;
			ELSE
				SET total_availability = recurring_avail_count;
			END IF;

            IF (total_availability != 0) THEN
				SET available_slots = JSON_ARRAY();

                SET i = 0;
                loop_to_get_available_slots: WHILE (i < total_availability) DO
					IF(specific_avail_count > 0) THEN
                        SELECT start_time, end_time INTO available_start_time, available_end_time FROM grow_practice.specific_availabilities AS s WHERE s.med_group_id = group_id AND s.provider_id = provider_id AND s.location_id = location_id AND s.schedule_date = cur_date ORDER BY DATE(s.start_time) LIMIT i,1;
                    ELSE
                        SELECT start_time, end_time INTO available_start_time, available_end_time FROM grow_practice.recurring_availabilities AS r WHERE r.med_group_id = group_id AND r.provider_id = provider_id AND r.location_id = location_id AND r.day = day_of_week ORDER BY DATE(r.start_time) LIMIT i,1;
                    END IF;

                    SET slot_start_time = available_start_time;
                    SET slot_end_time = TIME(DATE_ADD(slot_start_time, INTERVAL service_duration MINUTE));

                    WHILE (slot_end_time <= available_end_time) DO
						IF(cur_date = temp_today_date AND slot_start_time < cur_time) THEN
							SET slot_start_time = slot_end_time;
                            SET slot_end_time = TIME(DATE_ADD(slot_start_time, INTERVAL service_duration MINUTE));
                        ELSE
							SET available_slots = JSON_ARRAY_APPEND(
								available_slots,
                                ('$'),
                                JSON_OBJECT(
									'slotStartTime', slot_start_time,
                                    'slotEndTime', slot_end_time
                                )
                            );

                            SET slot_start_time = slot_end_time;
                            SET slot_end_time = TIME(DATE_ADD(slot_start_time, INTERVAL service_duration MINUTE));
                        END IF;
                    END WHILE;

                    SET i = i + 1;
                END WHILE loop_to_get_available_slots;

                SELECT JSON_LENGTH(available_slots) INTO available_slot_count;

                IF(available_slot_count != 0) THEN
					SET j = 0;
                    loop_available_slots : WHILE (j < available_slot_count) DO
						SET j_start_time = JSON_UNQUOTE(JSON_EXTRACT(available_slots, CONCAT('$[', j, '].slotStartTime')));
						SET j_end_time   = JSON_UNQUOTE(JSON_EXTRACT(available_slots, CONCAT('$[', j, '].slotEndTime')));

                        SET is_slot_unavailable = false;
						SET slot_exist_count = 0;

                        SELECT COUNT(scheduled_time) INTO exiting_appt_count FROM grow_practice.appointments AS a WHERE a.med_group_id = group_id AND a.provider_id = provider_id AND a.location_id = location_id AND a.scheduled_date = cur_date AND a.scheduled_time IS NOT NULL;
                        IF(exiting_appt_count = 0) THEN
							SET available_dates = JSON_ARRAY_APPEND(available_dates, '$', cur_date);

                            SELECT DATE_ADD(cur_date, INTERVAL 1 DAY) INTO cur_date;
							ITERATE loop_to_eom;
                        ELSE
							SET k = 0;
							check_overlap: WHILE k < exiting_appt_count DO
								SELECT scheduled_time, duration INTO exist_app_start_time, exist_appt_duration FROM grow_practice.appointments AS a WHERE a.med_group_id = group_id AND a.provider_id = provider_id AND a.location_id = location_id AND a.scheduled_date = cur_date AND a.scheduled_time IS NOT NULL LIMIT k,1;
                                SET exist_app_end_time = TIME(DATE_ADD(exist_app_start_time,Interval exist_appt_duration Minute));

                                IF ((j_start_time < exist_app_start_time AND (j_end_time <= exist_app_start_time))
									OR
									(j_start_time >= exist_app_end_time AND (j_end_time > exist_app_end_time))) THEN
									SET dummy = true;
								ELSE
									SET slot_exist_count = slot_exist_count + 1;
									IF(slot_exist_count >= p_booking_per_slot) THEN
										SET is_slot_unavailable = true;
									END IF;
								END IF;
							SET k = k+1;
                            END WHILE check_overlap;

                            IF (is_slot_unavailable = false) THEN
								SET available_dates = JSON_ARRAY_APPEND(available_dates, '$', cur_date);

								SELECT DATE_ADD(cur_date, INTERVAL 1 DAY) INTO cur_date;
								ITERATE loop_to_eom;
							END IF;
                        END IF;
					SET j = j+1;
                    END WHILE loop_available_slots;
                END IF;
            END IF;
        END IF;
    END IF;
	SET cur_date = DATE_ADD(cur_date, INTERVAL 1 DAY);
END WHILE loop_to_eom;
    SELECT dates FROM JSON_TABLE(available_dates, '$[*]' COLUMNS(dates DATE PATH '$')) AS jt;
END;