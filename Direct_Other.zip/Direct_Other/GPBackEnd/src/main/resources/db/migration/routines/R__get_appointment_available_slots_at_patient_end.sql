DROP PROCEDURE IF EXISTS get_appointment_available_slots_at_patient_end;

CREATE PROCEDURE get_appointment_available_slots_at_patient_end(IN group_id VARCHAR(10),
                                                    IN provider_id BIGINT,
                                                    IN appt_date DATE,
                                                    IN location_id BIGINT,
                                                    IN current_date_time DATETIME,
                                                    IN service_id BIGINT)
    READS SQL DATA
BEGIN

    DECLARE count_provider_ra, count_provider_spa, count_provider_other_spa, count_appt_time,
        booking_per_slot, booking_per_day, appt_interval, i, j, k, counter,
        service_interval, appt_duration, exist_appt_count, prepared_slot_count,
        specific_slot_exist_count, tps_count, p, count_managed_service_time, h, booking_lead_time,
        booking_prevention_switch INT;

    DECLARE date_now DATE;
    DECLARE specific_day_of_week, booking_type VARCHAR(25);

    DECLARE service_ids_to_check VARCHAR(255);
    DECLARE is_slot_unavailable, is_slot_available, tps_pass BOOLEAN;

    DECLARE time_now, available_start_time, available_end_time, appt_start_time,
        appt_end_time, slot_start_time, slot_end_time, prepared_slot_start_time,
        prepared_slot_end_time, tps_start_time, tps_end_time, ms_start_time,
        ms_end_time, prevented_current_time, booking_prevention_start_time TIME;

    DECLARE temp_prepared_slots JSON;
    DECLARE temp_prepared_slots2 JSON;
    DECLARE temp_available_slots JSON;

    SET date_now = DATE(current_date_time);
    SET time_now = TIME(current_date_time);

    SET specific_day_of_week = DAYNAME(appt_date);

    SET service_interval = 0, booking_per_slot = 0;

    SET temp_prepared_slots = JSON_ARRAY();
    SET temp_prepared_slots2 = JSON_ARRAY();
    SET temp_available_slots = JSON_ARRAY();

    SELECT c.booking_lead_time_in_minutes, c.booking_prevention_switch, c.booking_preventions_start_time
    INTO booking_lead_time, booking_prevention_switch, booking_prevention_start_time
    FROM grow_practice.customizations c
    WHERE c.med_group_id = group_id;

    SET prevented_current_time = TIME(DATE_ADD(time_now, INTERVAL booking_lead_time MINUTE));

    SELECT s.duration INTO service_interval FROM grow_practice.services s WHERE s.id = service_id;

    SELECT p.booking_type, p.booking_per_slot, p.booking_per_day, p.default_appt_duration
    INTO booking_type, booking_per_slot, booking_per_day, appt_interval
    FROM grow_practice.providers p
    WHERE p.med_group_id = group_id
      AND p.id = provider_id;

    SELECT COUNT(a.scheduled_time)
    INTO count_appt_time
    FROM grow_practice.appointments a
    WHERE a.provider_id = provider_id
      AND a.med_group_id = group_id
      AND a.scheduled_date = appt_date
      AND a.location_id = location_id;

    IF (count_appt_time < booking_per_day) THEN

        IF booking_type = 'SINGLE' THEN
            SET booking_per_slot = 1;
        ELSEIF booking_type = 'DOUBLE' THEN
            SET booking_per_slot = 2;
        ELSEIF booking_type = 'TRIPLE' THEN
            SET booking_per_slot = 3;
        END IF;

        IF service_interval = 0 THEN
            SET service_interval = appt_interval;
        END IF;

        SELECT COUNT(*)
        INTO count_provider_spa
        FROM grow_practice.specific_availabilities spa
        WHERE spa.schedule_date = appt_date
          AND spa.med_group_id = group_id
          AND spa.location_id = location_id
          AND spa.provider_id = provider_id;

        SELECT COUNT(*)
        INTO count_provider_other_spa
        FROM grow_practice.specific_availabilities spa
        WHERE spa.schedule_date = appt_date
          AND spa.med_group_id = group_id
          AND spa.location_id != location_id
          AND spa.provider_id = provider_id;

        SELECT COUNT(*)
        INTO count_provider_ra
        FROM grow_practice.recurring_availabilities ra
        WHERE ra.day = specific_day_of_week
          AND ra.med_group_id = group_id
          AND ra.location_id = location_id
          AND ra.provider_id = provider_id;

        IF (count_provider_spa > 0) THEN
            SET counter = count_provider_spa;
        ELSEIF (count_provider_spa = 0 AND count_provider_other_spa > 0) THEN
            SET counter = 0;
        ELSE
            SET counter = count_provider_ra;
        END IF;

        SET i = 0;

        loop1:
        WHILE i < counter
            DO

                IF (count_provider_spa > 0) THEN

                    SELECT spa.start_time, spa.end_time
                    INTO available_start_time,available_end_time
                    FROM grow_practice.specific_availabilities spa
                    WHERE spa.schedule_date = appt_date
                      AND spa.med_group_id = group_id
                      AND spa.location_id = location_id
                      AND spa.provider_id = provider_id
                    ORDER BY DATE(spa.start_time)
                    LIMIT i,1;

                ELSE

                    SELECT ra.start_time, ra.end_time
                    INTO available_start_time,available_end_time
                    FROM grow_practice.recurring_availabilities ra
                    WHERE ra.day = specific_day_of_week
                      AND ra.med_group_id = group_id
                      AND ra.location_id = location_id
                      AND ra.provider_id = provider_id
                    ORDER BY DATE(ra.start_time)
                    LIMIT i,1;

                END IF;

                SET slot_start_time = available_start_time;
                SET slot_end_time = TIME(DATE_ADD(slot_start_time, INTERVAL service_interval MINUTE));

                WHILE slot_end_time <= available_end_time
                    DO

                        IF ((appt_date = date_now AND slot_start_time < prevented_current_time) OR
                            (booking_prevention_switch = 1 AND appt_date = date_now AND
                             slot_start_time >= booking_prevention_start_time AND
                             time_now >= booking_prevention_start_time)) THEN

                            SET slot_start_time = slot_end_time;
                            SET slot_end_time =
                                    TIME(DATE_ADD(slot_end_time, INTERVAL service_interval MINUTE));

                        ELSE

                            SET temp_prepared_slots = JSON_ARRAY_APPEND(
                                    temp_prepared_slots,
                                    '$',
                                    JSON_OBJECT(
                                            'pre_slot_start_time', slot_start_time,
                                            'pre_slot_end_time', slot_end_time
                                    )
                                                      );

                            SET slot_start_time = slot_end_time;
                            SET slot_end_time =
                                    TIME(DATE_ADD(slot_end_time, INTERVAL service_interval MINUTE));

                        END IF;

                    END WHILE;

                SET i = i + 1;

            END WHILE loop1;

        SELECT JSON_LENGTH(temp_prepared_slots) INTO tps_count;

        SET p = 0;

        loop2:
        WHILE p < tps_count
            DO

                SET tps_start_time =
                        JSON_UNQUOTE(JSON_EXTRACT(temp_prepared_slots, CONCAT('$[', p, '].pre_slot_start_time')));
                SET tps_end_time =
                        JSON_UNQUOTE(JSON_EXTRACT(temp_prepared_slots, CONCAT('$[', p, '].pre_slot_end_time')));

                SET count_managed_service_time = 0;
                SELECT COUNT(*)
                INTO count_managed_service_time
                FROM grow_practice.service_availabilities sa
                WHERE sa.day = specific_day_of_week
                  AND sa.med_group_id = group_id
                  AND sa.location_id = location_id
                  AND sa.provider_id = provider_id;

                IF (count_managed_service_time = 0) THEN
                    SET temp_prepared_slots2 = JSON_ARRAY_APPEND(
                            temp_prepared_slots2,
                            '$',
                            JSON_OBJECT(
                                    'pre_slot_start_time2', tps_start_time,
                                    'pre_slot_end_time2', tps_end_time
                            )
                                               );
                END IF;

                SET h = 0;
                SET tps_pass = false;

                loop3:
                WHILE h < count_managed_service_time
                    DO

                        SELECT sa.start_time, sa.end_time, GROUP_CONCAT(sas.service_id) AS service_ids
                        INTO ms_start_time, ms_end_time, service_ids_to_check
                        FROM grow_practice.service_availabilities sa
                                 LEFT JOIN grow_practice.service_availability_services sas
                                           ON sa.id = sas.service_availability_id
                        WHERE sa.day = specific_day_of_week
                          AND sa.med_group_id = group_id
                          AND sa.location_id = location_id
                          AND sa.provider_id = provider_id
                        GROUP BY sa.id, sa.start_time, sa.end_time
                        ORDER BY DATE(sa.start_time)
                        LIMIT h,1;

                        IF (FIND_IN_SET(service_id, service_ids_to_check)) THEN
                            IF ((tps_start_time < ms_start_time AND tps_end_time <= ms_start_time) OR
                                (tps_start_time >= ms_end_time AND tps_end_time > ms_end_time)) THEN
                                SET tps_pass = true;
                            ELSE
                                SET tps_pass = false;
                                LEAVE loop3;
                            END IF;
                        ELSE
                            SET tps_pass = true;
                        END IF;

                        SET h = h + 1;

                    END WHILE loop3;

                IF (tps_pass = true) THEN

                    SET temp_prepared_slots2 = JSON_ARRAY_APPEND(
                            temp_prepared_slots2,
                            '$',
                            JSON_OBJECT(
                                    'pre_slot_start_time2', tps_start_time,
                                    'pre_slot_end_time2', tps_end_time
                            )
                                               );
                END IF;

                SET p = p + 1;

            END WHILE loop2;

        SELECT JSON_LENGTH(temp_prepared_slots2) INTO prepared_slot_count;

        SET j = 0;

        slot_checking_loop:
        WHILE j < prepared_slot_count
            DO

                SET prepared_slot_start_time =
                        JSON_UNQUOTE(JSON_EXTRACT(temp_prepared_slots2, CONCAT('$[', j, '].pre_slot_start_time2')));
                SET prepared_slot_end_time =
                        JSON_UNQUOTE(JSON_EXTRACT(temp_prepared_slots2, CONCAT('$[', j, '].pre_slot_end_time2')));

                SET is_slot_unavailable = false;
                SET specific_slot_exist_count = 0;

                SELECT COUNT(a.scheduled_time)
                INTO exist_appt_count
                FROM grow_practice.appointments a
                WHERE a.scheduled_date = appt_date
                  AND a.med_group_id = group_id
                  AND a.location_id = location_id
                  AND a.provider_id = provider_id
                  AND a.scheduled_time IS NOT NULL;
                SET k = 0;

                exist_appt_check_loop:
                WHILE k < exist_appt_count
                    DO

                        SELECT a.scheduled_time, a.duration
                        INTO appt_start_time, appt_duration
                        FROM grow_practice.appointments a
                        WHERE a.scheduled_date = appt_date
                          AND a.med_group_id = group_id
                          AND a.location_id = location_id
                          AND a.provider_id = provider_id
                          AND a.scheduled_time IS NOT NULL
                        LIMIT k,1;

                        SET appt_end_time = TIME(DATE_ADD(appt_start_time, INTERVAL appt_duration MINUTE));

                        IF ((prepared_slot_start_time < appt_start_time AND
                             (prepared_slot_end_time <= appt_start_time)) OR
                            (prepared_slot_start_time >= appt_end_time AND
                             (prepared_slot_end_time > appt_end_time))) THEN
                            SET is_slot_available = true; /*Not using this value*/
                        ELSE

                            SET specific_slot_exist_count = specific_slot_exist_count + 1;

                            IF (specific_slot_exist_count >= booking_per_slot) THEN
                                SET is_slot_unavailable = true;
                            END IF;

                        END IF;

                        SET k = k + 1;

                    END WHILE exist_appt_check_loop;

                IF is_slot_unavailable = false THEN
                    SET temp_available_slots =
                            JSON_ARRAY_APPEND(temp_available_slots, '$',
                                              TIME_FORMAT(prepared_slot_start_time, '%H:%i:%s'));
                END IF;

                SET j = j + 1;

            END WHILE slot_checking_loop;

        SELECT time FROM JSON_TABLE(temp_available_slots, '$[*]' COLUMNS (time TIME PATH '$')) AS jt ORDER BY time;
    ELSE
        SELECT time FROM JSON_TABLE(temp_available_slots, '$[*]' COLUMNS (time TIME PATH '$')) AS jt ORDER BY time;
    END IF;

END;