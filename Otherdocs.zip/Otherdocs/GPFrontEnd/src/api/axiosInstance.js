// axiosInstance.js
import axios from "axios";
import { store } from '../store/store';

export const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_BASE_API_URL, // Set your default fallback URL
  headers: {
    "Content-Type": "application/json",
  },
});

// Request interceptor
axiosInstance.interceptors.request.use(
  (config) => {
    const token = store.getState().userInfo.user.token;
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      console.error("Unauthorized access. Redirecting to login...");
      // Redirect logic can be added here
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;
