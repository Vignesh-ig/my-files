// api.js
import axiosInstance from './axiosInstance';

// Generic GET
export async function GET(endpoint) {
  try {
    const response = await axiosInstance.get(endpoint);
    return response;
  } catch (error) {
    console.error("GET error:", error);
    throw error;
  }
}

export async function GET_FILE(endpoint) {
  try {
    const response = await axiosInstance.get(endpoint, {
    responseType: 'blob', // ✅ critical for downloading files
    });
    return response;
  } catch (error) {
    console.error("GET error:", error);
    throw error;
  }
}

// Generic GETWITHTOKEN
export async function GETWITHTOKEN(endpoint, token) {
  try {
    const response = await axiosInstance.get(endpoint, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response;
  } catch (error) {
    console.error("GETWITHTOKEN error:", error.response || error.message);
    throw error;
  }
}

// Generic GETWITHOUTTOKEN
export async function GETWITHOUTTOKEN(endpoint) {
  try {
    const response = await axiosInstance.get(endpoint);
    return response;
  } catch (error) {
    console.error("GETWITHOUTTOKEN error:", error.response || error.message);
    throw error;
  }
}


// Generic POST
export async function POST(endpoint, data, config = {}) {
  try {
    const response = await axiosInstance.post(endpoint, data, config);
    return response;
  } catch (error) {
    console.error("POST error:", error);
    throw error;
  }
}

// ✅ Fixed: Generic POST with Bearer token
export async function POSTWITHTOKEN(endpoint, payload = {}, token) {
  try {
    const response = await axiosInstance.post(endpoint, payload, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response;
  } catch (error) {
    console.error("POSTWITHTOKEN error:", error.response || error.message);
    throw error;
  }
}

export async function POSTWITHOUTTOKEN(endpoint, payload = {},config={}) {
  try {
    const response = await axiosInstance.post(endpoint, payload,config);
    return response;
  } catch (error) {
    console.error("POSTWITHOUTTOKEN error:", error.response || error.message);
    throw error;
  }
}

// Generic PUT
export async function PUT(endpoint, id, data) {
  try {
    const response = await axiosInstance.put(`${endpoint}/${id}`, data);
    return response;
  } catch (error) {
    console.error("PUT error:", error);
    throw error;
  }
}

// PUT WITHOUT ID
export async function PUTWITHOUTID(endpoint, data) {
  try {
    const response = await axiosInstance.put(endpoint, data);
    return response;
  } catch (error) {
    console.error("PUT WITHOUT ID error:", error);
    throw error;
  }
}


// Generic PATCH
export async function PATCH(endpoint, id, data,config = {}) {
  try {
    const response = await axiosInstance.patch(`${endpoint}/${id}`, data,config);
    return response;
  } catch (error) {
    console.error("PATCH error:", error);
    throw error;
  }
}

// PATCH without ID
export async function PATCHWITHOUTID(endpoint, data) {
  try {
    const response = await axiosInstance.patch(endpoint, data);
    return response;
  } catch (error) {
    console.error("PATCH error:", error);
    throw error;
  }
}


// Generic DELETE
export async function DELETE(endpoint, id) {
  try {
    const response = await axiosInstance.delete(`${endpoint}/${id}`);
    return response;
  } catch (error) {
    console.error("DELETE error:", error);
    throw error;
  }
}

// Generic DELETE
export async function DELETE_DOCUMENT(endpoint) {
  try {
    const response = await axiosInstance.delete(`${endpoint}`);
    return response;
  } catch (error) {
    console.error("DELETE error:", error);
    throw error;
  }
}


