import { useState, useEffect, useRef } from "react";

import { twMerge } from "tailwind-merge";

import { HiChevronDown } from "react-icons/hi2";
import ErrorBoundary from "../error/ErrorBoundary";

/**
  * @author Prabudeva
  * 
  * Created Date : 03-20-2025
  */
const CategorySelect = ({ config = {}, setSelectedValue }) => {

    const { options = [], placeholder = "Enter", onBlur = () => { }, onSelect = () => { }, className = "", id = null, error = "" } = config || {}

    const [isOpen, setIsOpen] = useState(false);
    const [selectedOption, setSelectedOption] = useState(null);
    const dropdownRef = useRef(null);

    const handleToggle = () => {
        setIsOpen(!isOpen);
    };

    const handleSelect = (option) => {
        setSelectedOption(option);
        setSelectedValue(option)
        setIsOpen(false);
        if (onSelect) onSelect(option);
    };

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);


    return (
        <div id={id} onBlur={onBlur} className="relative w-full" ref={dropdownRef} tabIndex={0}>
            {/* Select Box */}
            <div
                className={twMerge(
                    "p-1.5 px-3 py-2 border rounded-md cursor-pointer flex justify-between items-center",
                    className,
                    error && "border-danger"
                )}
                onClick={handleToggle}
            >
                <span>{selectedOption === "No filter" ? placeholder : selectedOption || placeholder}</span>
                <ErrorBoundary><HiChevronDown /></ErrorBoundary>
            </div>

            {/* Dropdown Options with Categories */}
            {isOpen && (
                <div className="absolute z-[20] mt-1 p-2 w-full bg-white border border-gray-300 rounded-md shadow-lg flex flex-col gap-1 max-h-[500px] overflow-auto">
                    <div
                        className="p-2 pl-4 hover:text-primary hover:bg-secondary cursor-pointer rounded-md"
                        onClick={() => handleSelect("All")}
                    >
                        All
                    </div>
                    {options?.map((option, index) => (
                        // <div key={index} className={twMerge(`px-2 pt-2 `, (options.length - 1 === index) ? "pb-2" : "")} >
                        <div
                            key={index}
                            className="p-2 hover:text-primary hover:bg-secondary cursor-pointer pl-4 rounded-md"
                            onClick={() => handleSelect(option.activityType)}
                        >
                            {option.activityType}
                            {/* </div> */}
                        </div>
                    ))}
                </div>
            )}
            {/* {isOpen && (
                <div className="absolute z-[20] mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg max-h-[500px] overflow-auto">
                    {options?.map((group, index) => (
                        <div key={index} className={twMerge(`px-2 pt-2 `, (options.length - 1 === index) ? "pb-2" : "")} >
                            <div className="pb-1 mb-1 border-b border-secondary text-sm font-semibold text-secondaryExtraDark">{group.label}</div>
                            {group?.options?.map((option, idx) => (
                                <div
                                    key={idx}
                                    className="p-2 hover:text-primary hover:bg-secondary cursor-pointer pl-4 rounded-md"
                                    onClick={() => handleSelect(option)}
                                >
                                    {option.label}
                                </div>
                            ))}
                        </div>
                    ))}
                </div>
            )} */}
        </div>
    );
};

export default CategorySelect
