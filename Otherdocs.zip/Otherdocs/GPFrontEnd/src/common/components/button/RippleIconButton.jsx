import React, { useState, useEffect, useCallback, forwardRef } from "react"

import { twMerge } from "tailwind-merge"

import ErrorBoundary from "../../error/ErrorBoundary";

import "./Ripple.css"

/**
  * @author Dhinakaran
  * 
  * Created Date : 03-20-2025
  */
const RippleIconButton = forwardRef(({ icon: Icon, iconConfig, buttonConfig = {} }, ref) => {

    const { onClick = () => { }, buttonText = "Default Text", className = "", ...restConfig } = buttonConfig || {};

    // For make ripple effect to button
    const [coords, setCoords] = useState({ x: -1, y: -1 });
    const [isRippling, setIsRippling] = useState(false);

    useEffect(() => {
        if (coords.x !== -1 && coords.y !== -1) {
            setIsRippling(true);
            setTimeout(() => setIsRippling(false), 500); // Smooth fade-out duration
        }
    }, [coords]);

    //handle ripple onclick
    const handleClick = useCallback(
        (e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            setCoords({ x: e.clientX - rect.left, y: e.clientY - rect.top });
            if (onClick) onClick(e);
        },
        [onClick]
    );

    return (
        <button
            ref={ref}
            {...restConfig}
            className={twMerge(`relative flex items-center gap-2 overflow-hidden border px-3 py-1 rounded-small shadow-small active:opacity-80`, `${className}`)}
            onClick={handleClick}
        >
            {Icon &&
                <ErrorBoundary>
                    <Icon {...iconConfig} />
                </ErrorBoundary>
            }
            {isRippling && (
                <span
                    className="absolute bg-gray-300 rounded-full animate-ripple pointer-events-none"
                    style={{
                        left: coords.x,
                        top: coords.y,
                        transform: "translate(-50%, -50%) scale(0)",
                        animation: "rippleEffect 0.5s ease-out",
                    }}
                ></span>
            )}
            {buttonText}
        </button>
    );
});

export default RippleIconButton;
