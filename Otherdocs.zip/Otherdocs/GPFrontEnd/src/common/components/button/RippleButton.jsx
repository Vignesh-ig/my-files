import React, { useState, useEffect, useCallback, forwardRef } from "react"

import { twMerge } from "tailwind-merge"


import "./Ripple.css"

const RippleButton = forwardRef(({ buttonConfig = {} }, ref) => {

  const { onClick = () => { }, buttonText = "Default Text", className = "", textStyle = "", ...restConfig } = buttonConfig || {};

  // For make ripple effect to button
  const [coords, setCoords] = useState({ x: -1, y: -1 });
  const [isRippling, setIsRippling] = useState(false);

  useEffect(() => {
    if (coords.x !== -1 && coords.y !== -1) {
      setIsRippling(true);
      setTimeout(() => setIsRippling(false), 500); // Smooth fade-out duration
    }
  }, [coords]);


  //handle ripple onclick
  const handleClick = useCallback(
    (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      setCoords({ x: e.clientX - rect.left, y: e.clientY - rect.top });
      if (onClick) onClick(e);
    },
    [onClick]
  );

  return (
    <button
      ref={ref}
      {...restConfig}
      className={twMerge(`relative overflow-hidden border px-3 py-1.5 rounded-small shadow-small active:opacity-80`, `${className}`, textStyle)}
      onClick={handleClick}
    >
      {isRippling && (
        <span
          className="absolute bg-gray-300 rounded-full animate-ripple pointer-events-none"
          style={{
            left: coords.x,
            top: coords.y,
            transform: "translate(-50%, -50%) scale(0)",
            animation: "rippleEffect 0.5s ease-out",
          }}
        ></span>
      )}
      {buttonText}
    </button>
  );
});

export default RippleButton;
