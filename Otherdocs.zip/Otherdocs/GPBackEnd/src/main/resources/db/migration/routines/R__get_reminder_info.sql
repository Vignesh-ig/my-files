DROP PROCEDURE IF EXISTS get_reminder_info;

create procedure get_reminder_info() reads sql data
BEGIN
    DECLARE counter_1, counter_2, i, j, v_reminder_days, v_week_day int;
    DECLARE v_is_patient_confirmed, v_is_reminder_sent bit;
    DECLARE v_patient_id, v_appt_id, v_provider_id, v_location_id bigint;
    DECLARE v_group_id, v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_reminder_type varchar(255);
    DECLARE v_schedule_date_time datetime;
    DECLARE v_current_date date;

    DROP TABLE IF EXISTS `Temp1`;
    CREATE TEMPORARY TABLE Temp1
    (
        phone_number         varchar(255),
        email                varchar(255),
        first_name           varchar(255),
        last_name            varchar(255),
        perf_lang            varchar(255),
        patient_id           bigint,
        appt_id              bigint,
        group_id             varchar(255),
        provider_id          bigint,
        meeting_time         varchar(255),
        schedule_date        varchar(255),
        is_reminder_sent     VARCHAR(255),
        location_id          VARCHAR(255),
        is_patient_confirmed INT
    );

    SELECT COUNT(*) INTO counter_1 FROM grow_practice.med_group_flags WHERE reminder_days = 1;

    SET i = 0;

    WHILE(i < counter_1)
        DO
            SELECT mg.group_id, mg.reminder_days, mg.reminder_type
            INTO v_group_id, v_reminder_days, v_reminder_type
            FROM grow_practice.med_groups mg
                     JOIN grow_practice.med_group_flags mgf ON mg.group_id = mgf.med_group_id
            WHERE mgf.reminder_days = 1
            limit i,1;
            IF `v_reminder_type` = 'WEEK_DAYS' THEN
                SET `v_current_date` = CURDATE();
                SET `v_week_day` = WEEKDAY(v_current_date);
                CASE
                    WHEN `v_week_day` = 0 THEN CASE
                        WHEN `v_reminder_days` < 5
                            THEN SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 5
                            THEN SET `v_reminder_days` = 7;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        ELSE BEGIN
                        END;

                        END CASE;
                    WHEN `v_week_day` = 1 THEN CASE
                        WHEN `v_reminder_days` < 4
                            THEN SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 4
                            THEN SET `v_reminder_days` = 6;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 5
                            THEN SET `v_reminder_days` = 7;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        ELSE BEGIN
                        END;
                        END CASE;
                    WHEN `v_week_day` = 2 THEN CASE
                        WHEN `v_reminder_days` < 3
                            THEN SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 3
                            THEN SET `v_reminder_days` = 5;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 4
                            THEN SET `v_reminder_days` = 6;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 5
                            THEN SET `v_reminder_days` = 7;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        ELSE BEGIN
                        END;
                        END CASE;
                    WHEN `v_week_day` = 3 THEN CASE
                        WHEN `v_reminder_days` < 2
                            THEN SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 2
                            THEN SET `v_reminder_days` = 4;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 3
                            THEN SET `v_reminder_days` = 5;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 4
                            THEN SET `v_reminder_days` = 6;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 5
                            THEN SET `v_reminder_days` = 7;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        ELSE BEGIN
                        END;
                        END CASE;
                    WHEN `v_week_day` = 4 THEN CASE
                        WHEN `v_reminder_days` = 1
                            THEN SET `v_reminder_days` = 3;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 2
                            THEN SET `v_reminder_days` = 4;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 3
                            THEN SET `v_reminder_days` = 5;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 4
                            THEN SET `v_reminder_days` = 6;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        WHEN `v_reminder_days` = 5
                            THEN SET `v_reminder_days` = 7;
                                 SELECT COUNT(*)
                                 INTO counter_2
                                 FROM grow_practice.appointments a
                                          INNER JOIN grow_practice.patients p
                                                     ON (a.patient_id = p.id) AND
                                                        DATE(a.scheduled_date_time) =
                                                        DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                        a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                                 SET j = 0;
                                 WHILE (j < counter_2)
                                     DO
                                         SELECT p.phone_number,
                                                p.email,
                                                p.first_name,
                                                p.last_name,
                                                p.preferred_language,
                                                a.patient_id,
                                                a.id,
                                                a.med_group_id,
                                                a.provider_id,
                                                a.scheduled_date_time,
                                                a.is_reminder_sent,
                                                a.location_id,
                                                a.is_patient_confirmed
                                         INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                                         FROM grow_practice.appointments AS a
                                                  INNER JOIN grow_practice.patients AS p
                                                             ON (a.patient_id = p.id) AND
                                                                DATE(a.scheduled_date_time) =
                                                                DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                                                a.is_provider_confirmed = 1 AND
                                                                a.med_group_id = `v_group_id`
                                         limit j,1;
                                         INSERT INTO Temp1
                                         VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                                 `v_patient_id`,
                                                 `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                                 DATE(v_schedule_date_time),
                                                 `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                                         SET j = j + 1;
                                     END WHILE;
                        ELSE BEGIN
                        END;
                        END CASE;
                    ELSE BEGIN
                    END;
                    END CASE;

            ELSE
                SELECT COUNT(*)
                INTO counter_2
                FROM grow_practice.appointments a
                         INNER JOIN grow_practice.patients p
                                    ON (a.patient_id = p.id) AND
                                       DATE(a.scheduled_date_time) =
                                       DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                       a.is_provider_confirmed = 1 AND a.med_group_id = `v_group_id`;

                SET j = 0;
                WHILE (j < counter_2)
                    DO
                        SELECT p.phone_number,
                               p.email,
                               p.first_name,
                               p.last_name,
                               p.preferred_language,
                               a.patient_id,
                               a.id,
                               a.med_group_id,
                               a.provider_id,
                               a.scheduled_date_time,
                               a.is_reminder_sent,
                               a.location_id,
                               a.is_patient_confirmed
                        INTO v_phone_number, v_email, v_first_name, v_last_name, v_perf_lang, v_patient_id, v_appt_id, v_group_id, v_provider_id, v_schedule_date_time, v_is_reminder_sent,v_location_id,v_is_patient_confirmed
                        FROM grow_practice.appointments AS a
                                 INNER JOIN grow_practice.patients AS p
                                            ON (a.patient_id = p.id) AND
                                               DATE(a.scheduled_date_time) =
                                               DATE_ADD(CURDATE(), INTERVAL v_reminder_days DAY) AND
                                               a.is_provider_confirmed = 1 AND
                                               a.med_group_id = `v_group_id`
                        limit j,1;
                        INSERT INTO Temp1
                        VALUES (`v_phone_number`, `v_email`, `v_first_name`, `v_last_name`, `v_perf_lang`,
                                `v_patient_id`,
                                `v_appt_id`, `v_group_id`, `v_provider_id`, TIME(v_schedule_date_time),
                                DATE(v_schedule_date_time),
                                `v_is_reminder_sent`, `v_location_id`, `v_is_patient_confirmed`);
                        SET j = j + 1;
                    END WHILE;
            END IF;
            SET i = i + 1;
        END WHILE;
    SELECT * FROM Temp1;
END;
