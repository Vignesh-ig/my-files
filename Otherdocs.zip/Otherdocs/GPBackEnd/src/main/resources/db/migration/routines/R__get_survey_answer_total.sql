DROP PROCEDURE IF EXISTS get_survey_answer_total;

CREATE PROCEDURE get_survey_answer_total(
    IN group_id VARCHAR(255)
)
    READS SQL DATA
BEGIN
    DROP TABLE IF EXISTS `Temp`;
    CREATE TEMPORARY TABLE Temp
    (
        day_offset INT,
        q1A1       INT,
        q1A2       INT,
        q1A3       INT,
        q1A4       INT,
        q1A5       INT,
        q2A1       INT,
        q2A2       INT,
        q2A3       INT,
        q2A4       INT,
        q2A5       INT,
        q3A1       INT,
        q3A2       INT,
        q3A3       INT,
        q3A4       INT,
        q3A5       INT,
        q4A1       INT,
        q4A2       INT,
        q4A3       INT,
        q4A4       INT,
        q4A5       INT,
        q5A1       INT,
        q5A2       INT,
        q5A3       INT,
        q5A4       INT,
        q5A5       INT,
        q6A1       INT,
        q6A2       INT,
        q6A3       INT,
        q6A4       INT,
        q6A5       INT,
        q7A1       INT,
        q7A2       INT,
        q7A3       INT,
        q7A4       INT,
        q7A5       INT,
        q8A1       INT,
        q8A2       INT,
        q8A3       INT,
        q8A4       INT,
        q8A5       INT,
        q9A1       INT,
        q9A2       INT,
        q9A3       INT,
        q9A4       INT,
        q9A5       INT,
        q10A1      INT,
        q10A2      INT,
        q10A3      INT,
        q10A4      INT,
        q10A5      INT,
        q11A1      INT,
        q11A2      INT,
        q11A3      INT,
        q11A4      INT,
        q11A5      INT
    );

-- Insert data for each day (past 7 days)
    INSERT INTO Temp (day_offset,
                      q1A1, q1A2, q1A3, q1A4, q1A5,
                      q2A1, q2A2, q2A3, q2A4, q2A5,
                      q3A1, q3A2, q3A3, q3A4, q3A5,
                      q4A1, q4A2, q4A3, q4A4, q4A5,
                      q5A1, q5A2, q5A3, q5A4, q5A5,
                      q6A1, q6A2, q6A3, q6A4, q6A5,
                      q7A1, q7A2, q7A3, q7A4, q7A5,
                      q8A1, q8A2, q8A3, q8A4, q8A5,
                      q9A1, q9A2, q9A3, q9A4, q9A5,
                      q10A1, q10A2, q10A3, q10A4, q10A5,
                      q11A1, q11A2, q11A3, q11A4, q11A5)
    SELECT i.day_offset,

           SUM(IF(s.question1 = 1, 1, 0))  AS q1A1,
           SUM(IF(s.question1 = 2, 1, 0))  AS q1A2,
           SUM(IF(s.question1 = 3, 1, 0))  AS q1A3,
           SUM(IF(s.question1 = 4, 1, 0))  AS q1A4,
           SUM(IF(s.question1 = 5, 1, 0))  AS q1A5,

           SUM(IF(s.question2 = 1, 1, 0))  AS q2A1,
           SUM(IF(s.question2 = 2, 1, 0))  AS q2A2,
           SUM(IF(s.question2 = 3, 1, 0))  AS q2A3,
           SUM(IF(s.question2 = 4, 1, 0))  AS q2A4,
           SUM(IF(s.question2 = 5, 1, 0))  AS q2A5,

           SUM(IF(s.question3 = 1, 1, 0))  AS q3A1,
           SUM(IF(s.question3 = 2, 1, 0))  AS q3A2,
           SUM(IF(s.question3 = 3, 1, 0))  AS q3A3,
           SUM(IF(s.question3 = 4, 1, 0))  AS q3A4,
           SUM(IF(s.question3 = 5, 1, 0))  AS q3A5,

           SUM(IF(s.question4 = 1, 1, 0))  AS q4A1,
           SUM(IF(s.question4 = 2, 1, 0))  AS q4A2,
           SUM(IF(s.question4 = 3, 1, 0))  AS q4A3,
           SUM(IF(s.question4 = 4, 1, 0))  AS q4A4,
           SUM(IF(s.question4 = 5, 1, 0))  AS q4A5,

           SUM(IF(s.question5 = 1, 1, 0))  AS q5A1,
           SUM(IF(s.question5 = 2, 1, 0))  AS q5A2,
           SUM(IF(s.question5 = 3, 1, 0))  AS q5A3,
           SUM(IF(s.question5 = 4, 1, 0))  AS q5A4,
           SUM(IF(s.question5 = 5, 1, 0))  AS q5A5,

           SUM(IF(s.question6 = 1, 1, 0))  AS q6A1,
           SUM(IF(s.question6 = 2, 1, 0))  AS q6A2,
           SUM(IF(s.question6 = 3, 1, 0))  AS q6A3,
           SUM(IF(s.question6 = 4, 1, 0))  AS q6A4,
           SUM(IF(s.question6 = 5, 1, 0))  AS q6A5,

           SUM(IF(s.question7 = 1, 1, 0))  AS q7A1,
           SUM(IF(s.question7 = 2, 1, 0))  AS q7A2,
           SUM(IF(s.question7 = 3, 1, 0))  AS q7A3,
           SUM(IF(s.question7 = 4, 1, 0))  AS q7A4,
           SUM(IF(s.question7 = 5, 1, 0))  AS q7A5,

           SUM(IF(s.question8 = 1, 1, 0))  AS q8A1,
           SUM(IF(s.question8 = 2, 1, 0))  AS q8A2,
           SUM(IF(s.question8 = 3, 1, 0))  AS q8A3,
           SUM(IF(s.question8 = 4, 1, 0))  AS q8A4,
           SUM(IF(s.question8 = 5, 1, 0))  AS q8A5,

           SUM(IF(s.question9 = 1, 1, 0))  AS q9A1,
           SUM(IF(s.question9 = 2, 1, 0))  AS q9A2,
           SUM(IF(s.question9 = 3, 1, 0))  AS q9A3,
           SUM(IF(s.question9 = 4, 1, 0))  AS q9A4,
           SUM(IF(s.question9 = 5, 1, 0))  AS q9A5,

           SUM(IF(s.question10 = 1, 1, 0)) AS q10A1,
           SUM(IF(s.question10 = 2, 1, 0)) AS q10A2,
           SUM(IF(s.question10 = 3, 1, 0)) AS q10A3,
           SUM(IF(s.question10 = 4, 1, 0)) AS q10A4,
           SUM(IF(s.question10 = 5, 1, 0)) AS q10A5,

           SUM(IF(s.question11 = 1, 1, 0)) AS q11A1,
           SUM(IF(s.question11 = 2, 1, 0)) AS q11A2,
           SUM(IF(s.question11 = 3, 1, 0)) AS q11A3,
           SUM(IF(s.question11 = 4, 1, 0)) AS q11A4,
           SUM(IF(s.question11 = 5, 1, 0)) AS q11A5
    FROM (SELECT 0 AS day_offset
          UNION
          SELECT 1
          UNION
          SELECT 2
          UNION
          SELECT 3
          UNION
          SELECT 4
          UNION
          SELECT 5
          UNION
          SELECT 6) i
             LEFT JOIN
         grow_practice.surveys s ON DATE(s.date_time) = CURDATE() - INTERVAL i.day_offset DAY
             AND s.med_group_id = group_id
    GROUP BY i.day_offset;

    SELECT q1A1,
           q1A2,
           q1A3,
           q1A4,
           q1A5,
           q2A1,
           q2A2,
           q2A3,
           q2A4,
           q2A5,
           q3A1,
           q3A2,
           q3A3,
           q3A4,
           q3A5,
           q4A1,
           q4A2,
           q4A3,
           q4A4,
           q4A5,
           q5A1,
           q5A2,
           q5A3,
           q5A4,
           q5A5,
           q6A1,
           q6A2,
           q6A3,
           q6A4,
           q6A5,
           q7A1,
           q7A2,
           q7A3,
           q7A4,
           q7A5,
           q8A1,
           q8A2,
           q8A3,
           q8A4,
           q8A5,
           q9A1,
           q9A2,
           q9A3,
           q9A4,
           q9A5,
           q10A1,
           q10A2,
           q10A3,
           q10A4,
           q10A5,
           q11A1,
           q11A2,
           q11A3,
           q11A4,
           q11A5
    FROM Temp
    ORDER BY day_offset;
END;