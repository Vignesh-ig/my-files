DROP TRIGGER IF EXISTS flag_after_med_group_insert;
CREATE TRIGGER flag_after_med_group_insert
    AFTER INSERT
    ON grow_practice.med_groups
    FOR EACH ROW
BEGIN
    -- Med Group flag
    INSERT INTO grow_practice.med_group_flags (appt_request_email_alert,
                                               auto_request_payment,
                                               auto_request_quick_survey,
                                               auto_request_review,
                                               booking_fee,
                                               checkin,
                                               checkout,
                                               coverage,
                                               daily_summary,
                                               email_shutoff,
                                               form_submission_email_alert,
                                               documents,
                                               insurance,
                                               integration_appt_run_check,
                                               integration_patient_run_check,
                                               marketing_blast,
                                               missed_appt_follow_up,
                                               notify_payment_success,
                                               office_closed_auto_reply,
                                               online_intake,
                                               patient_checkin_alert,
                                               payment,
                                               pre_reminder,
                                               recall_appt_reminder,
                                               reminder,
                                               scheduling_actions,
                                               sms_shutoff,
                                               telehealth,
                                               today_appointment,
                                               med_group_id)
    VALUES (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, NEW.group_id);
END;