DROP PROCEDURE IF EXISTS get_next_10_search_waitlist_appointment;

create procedure get_next_10_search_waitlist_appointment(IN term varchar(255), IN p int,
                                                                               IN group_id varchar(255),
                                                                               IN provider_id bigint,
                                                                               IN currentDate date) reads sql data
BEGIN

    IF term = '' THEN
        SELECT CONCAT(p.first_name, ' ', p.last_name) AS patientName,
               w.provider_id,
               w.date,
               w.location_id,
               w.wait_list_type,
               w.id
        FROM grow_practice.patients AS p
                 INNER JOIN grow_practice.waiting_lists AS w ON p.id = w.patient_id
        WHERE (w.med_group_id = group_id AND (w.provider_id like provider_id) AND w.date >= currentDate)
        order by date(w.date) desc
        LIMIT 10 OFFSET p;
    END IF;
    IF term != '' THEN
        SELECT CONCAT(p.first_name, ' ', p.last_name) AS patientName,
               w.provider_id,
               w.date,
               w.location_id,
               w.wait_list_type,
               w.id
        FROM grow_practice.patients AS p
                 INNER JOIN grow_practice.waiting_lists AS w ON p.id = w.patient_id
        WHERE (w.wait_list_type = term AND w.med_group_id = group_id AND (w.provider_id like provider_id) AND
               w.date >= currentDate)
        order by date(w.date) desc
        LIMIT 10 OFFSET p;
    END IF;


END;
