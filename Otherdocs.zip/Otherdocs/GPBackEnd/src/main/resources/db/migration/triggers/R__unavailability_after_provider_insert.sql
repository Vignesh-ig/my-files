DROP TRIGGER IF EXISTS unavailability_after_provider_insert;
CREATE TRIGGER unavailability_after_provider_insert
    AFTER INSERT
    ON grow_practice.providers
    FOR EACH ROW
BEGIN
    -- Independence Day
    INSERT INTO grow_practice.unavailabilities (exception_date,
                                                reason,
                                                provider_id,
                                                med_group_id)
    VALUES (STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-07-04'), '%Y-%m-%d'), 'Independence Day', NEW.id, NEW.med_group_id);

    -- Christmas Day
    INSERT INTO grow_practice.unavailabilities (exception_date, reason, provider_id, med_group_id)
    VALUES (STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-12-25'), '%Y-%m-%d'), 'Christmas Day', NEW.id, NEW.med_group_id);

END;