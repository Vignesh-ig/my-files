DROP PROCEDURE IF EXISTS get_latest_appointments;

create procedure get_latest_appointments(IN date date) reads sql data
BEGIN
    SELECT patient_id, max(DATE(scheduled_date_time)) as latest_date
    FROM grow_practice.appointments
    WHERE DATE(scheduled_date_time) < date
    group by patient_id;

END;
