DROP PROCEDURE IF EXISTS get_next_10_search_activity;

create procedure get_next_10_search_activity(IN term varchar(255), IN p int,
                                                                   IN group_id varchar(255), IN provider_id bigint)
    reads sql data
BEGIN

    IF term = '' THEN
        SELECT DATE(date_time) AS date, TIME_FORMAT(TIME(date_time), '%H:%i') AS time, type, description, content
        FROM grow_practice.activities
        WHERE (med_group_id = group_id AND (activities.provider_id is null OR activities.provider_id like provider_id))
        order by date_time desc
        LIMIT 10 OFFSET p;
    END IF;
    IF term != '' THEN
        SELECT DATE(date_time) AS date, TIME_FORMAT(TIME(date_time), '%H:%i') AS time, type, description, content
        FROM grow_practice.activities
        WHERE (type = term AND med_group_id = group_id AND
               (activities.provider_id is null OR activities.provider_id like provider_id))
        order by date_time desc
        LIMIT 10 OFFSET p;
    END IF;

END;
