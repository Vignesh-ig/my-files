DROP PROCEDURE IF EXISTS get_next_10_search_entries1;

create procedure get_next_10_search_entries1(IN term varchar(255), IN p int, IN group_id varchar(255))
begin
    SELECT DISTINCT(id), first_name, last_name, home_phone, phone_number, dob
    FROM grow_practice.patients
    WHERE (
        id LIKE CONCAT('%', term, '%')
            OR first_name LIKE CONCAT('%', term, '%')
            OR last_name LIKE CONCAT('%', term, '%')
            OR CONCAT(first_name, ' ', last_name) LIKE CONCAT('%', term, '%')
            OR dob LIKE CONCAT('%', term, '%'))
      AND med_group_id = group_id
    LIMIT 10 OFFSET p;
end;
