DROP TRIGGER IF EXISTS todo_history_after_todo_insert;
CREATE TRIGGER todo_history_after_todo_insert
    AFTER INSERT
    ON grow_practice.todo_lists
    FOR EACH ROW
BEGIN
    INSERT INTO grow_practice.todo_list_histories (action_detail,
                                                   action_type,
                                                   assign_to,
                                                   created_by,
                                                   date_time,
                                                   med_group_id,
                                                   todo_list_id)
    VALUES (CONCAT('A new sticky note has been created by user (', NEW.created_by,
                   ') and it has been assigned to user (', NEW.assigned_to, ').'),
            'CREATE', NEW.assigned_to, NEW.created_by, NEW.date_time, NEW.med_group_id, NEW.id);
END;