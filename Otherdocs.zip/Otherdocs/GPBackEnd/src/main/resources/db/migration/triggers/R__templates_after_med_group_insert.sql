DROP TRIGGER IF EXISTS templates_after_med_group_insert;
CREATE TRIGGER templates_after_med_group_insert
    AFTER INSERT
    ON grow_practice.med_groups
    FOR EACH ROW
BEGIN
    -- Copy Email Templates
    INSERT INTO grow_practice.email_templates (english_content,
                                               is_restricted,
                                               name,
                                               spanish_content,
                                               subject,
                                               template_group,
                                               template_id,
                                               template_type,
                                               group_id)
    SELECT english_content,
           is_restricted,
           name,
           spanish_content,
           subject,
           template_group,
           template_id,
           template_type,
           NEW.group_id
    FROM grow_practice.email_templates
    WHERE email_templates.group_id = 'default';

    -- Copy SMS Templates
    INSERT INTO grow_practice.sms_templates (english_content,
                                             is_restricted,
                                             name,
                                             spanish_content,
                                             template_group,
                                             template_id,
                                             template_type,
                                             type,
                                             group_id)
    SELECT english_content,
           is_restricted,
           name,
           spanish_content,
           template_group,
           template_id,
           template_type,
           type,
           NEW.group_id
    FROM grow_practice.sms_templates
    WHERE sms_templates.group_id = 'default';
END;