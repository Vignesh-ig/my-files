DROP PROCEDURE IF EXISTS get_appointment_available_dates_at_patient_end;
CREATE PROCEDURE get_appointment_available_dates_at_patient_end(
	IN group_id VARCHAR(10) ,
    IN provider_id BIGINT,
    IN location_id BIGINT,
    IN service_id BIGINT,
    IN current_date_time DATETIME
)
BEGIN

DECLARE `$cur_date`, `$temp_today_date` DATE;
DECLARE `$cur_time` TIME;
DECLARE `$month_last_date` DATE;
DECLARE `$days_left_in_month` INT;

DECLARE `$available_dates` JSON;
DECLARE `$available_slots` JSON;
DECLARE `$available_slots_after_service_avail_filter` JSON;

DECLARE `$service_duration`, `$p_booking_per_slot`, `$p_booking_per_day`, `$p_default_appointment_duration` INT;
DECLARE `$p_booking_type`, `$day_of_week`, `$service_avail_ids` VARCHAR(15);

DECLARE `$unavailability_count`, `$booked_appt_count`, `$specific_avail_count`, `$recurring_avail_count`, `$specific_without_location_count`, `$total_availability`, `$available_slot_count`, `$exiting_appt_count`, `$available_slot_count_before_service_avail`, `$service_availability_count` INT;
DECLARE i, j, k, l, m INT;

DECLARE `$available_start_time`, `$available_end_time`, `$slot_start_time`, `$slot_end_time`, `$j_start_time`, `$j_end_time`, `$exist_app_start_time`, `$exist_app_end_time`, `$booking_prevention_startTime`, `$l_start_time`, `$l_end_time`, `$service_avail_start_time`, `$service_avail_end_time` TIME;

DECLARE `$is_slot_unavailable`, `$dummy` BOOLEAN;
DECLARE slot_exist_count, exist_appt_duration INT;

DECLARE `$booking_lead_in_minutes`, `$prevented_current_time` INT;
DECLARE `$has_booking_prevention`, `$is_service_availability` BOOLEAN;

SET `$cur_date` = DATE(current_date_time);
SET `$cur_time` = TIME(current_date_time);
SET `$month_last_date` = LAST_DAY(`$cur_date`);
SET `$days_left_in_month` = DATEDIFF(`$month_last_date`, `$cur_date`);

SET `$temp_today_date` = DATE(current_date_time);

SELECT duration INTO `$service_duration` FROM grow_practice.services AS s WHERE s.med_group_id = group_id AND s.id = service_id;
SELECT booking_type, booking_per_slot, booking_per_day, default_appt_duration INTO `$p_booking_type`, `$p_booking_per_slot`, `$p_booking_per_day`, `$p_default_appointment_duration` FROM grow_practice.providers AS p WHERE p.med_group_id = group_id AND p.id = provider_id;

SELECT booking_lead_time_in_minutes, booking_prevention_switch, booking_preventions_start_time INTO `$booking_lead_in_minutes`, `$has_booking_prevention`, `$booking_prevention_startTime` FROM grow_practice.customizations AS c WHERE c.med_group_id = group_id;
SET `$prevented_current_time` = TIME(DATE_ADD(`$cur_time`,Interval `$booking_lead_in_minutes` Minute));

IF `$service_duration` = 0 THEN
	SET `$service_duration` = `$p_default_appointment_duration`;
END IF;

IF `$p_booking_type` = 'SINGLE' THEN
	SET `$p_booking_per_slot` = 1;
ELSEIF `$p_booking_type` = 'DOUBLE' THEN
	SET `$p_booking_per_slot` = 2;
ELSEIF `$p_booking_type` = 'TRIPLE' THEN
	SET `$p_booking_per_slot` = 3;
END IF;

SET `$available_dates` = JSON_ARRAY();

loop_to_eom:
WHILE (`$cur_date` <= `$month_last_date`) DO
	SELECT COUNT(exception_date) INTO `$unavailability_count` FROM grow_practice.unavailabilities AS u WHERE u.med_group_id = group_id AND u.provider_id = provider_id AND u.exception_date = `$cur_date` ;

	IF (`$unavailability_count` = 0) THEN
		SELECT COUNT(scheduled_time) INTO `$booked_appt_count` FROM grow_practice.appointments AS a WHERE a.med_group_id = group_id AND a.provider_id = provider_id AND a.location_id = location_id AND a.scheduled_date = `$cur_date`;
        SELECT DAYNAME(`$cur_date`) INTO `$day_of_week`;

        IF (`$booked_appt_count` < `$p_booking_per_day`) THEN
			SELECT count(*) INTO `$specific_avail_count` FROM grow_practice.specific_availabilities AS a WHERE a.med_group_id = group_id AND a.provider_id = provider_id AND a.location_id = location_id AND a.schedule_date = `$cur_date`;
            SELECT count(*) INTO `$specific_without_location_count` FROM grow_practice.specific_availabilities AS s WHERE s.med_group_id = group_id AND s.provider_id = provider_id AND s.location_id != location_id AND s.schedule_date = `$cur_date`;
            SELECT count(*) INTO `$recurring_avail_count` FROM grow_practice.recurring_availabilities AS r WHERE r.med_group_id = group_id AND r.provider_id = provider_id AND r.location_id = location_id AND r.day = `$day_of_week`;

            IF(`$specific_avail_count` > 0) THEN
				SET `$total_availability` = `$specific_avail_count`;
			ELSEIF(`$specific_avail_count`= 0 AND `$specific_without_location_count` > 0) THEN
				SET `$total_availability` = 0;
			ELSE
				SET `$total_availability` = `$recurring_avail_count`;
			END IF;

            IF (`$total_availability` != 0) THEN
				SET `$available_slots` = JSON_ARRAY();

                SET i = 0;
                loop_to_get_available_slots: WHILE (i < `$total_availability`) DO
					IF(`$specific_avail_count` > 0) THEN
                        SELECT start_time, end_time INTO `$available_start_time`, `$available_end_time` FROM grow_practice.specific_availabilities AS s WHERE s.med_group_id = group_id AND s.provider_id = provider_id AND s.location_id = location_id AND s.schedule_date = `$cur_date` ORDER BY DATE(s.start_time) LIMIT i,1;
                    ELSE
                        SELECT start_time, end_time INTO `$available_start_time`, `$available_end_time` FROM grow_practice.recurring_availabilities AS r WHERE r.med_group_id = group_id AND r.provider_id = provider_id AND r.location_id = location_id AND r.day = `$day_of_week` ORDER BY DATE(r.start_time) LIMIT i,1;
                    END IF;

                    SET `$slot_start_time` = `$available_start_time`;
                    SET `$slot_end_time` = TIME(DATE_ADD(`$slot_start_time`, INTERVAL `$service_duration` MINUTE));

                    WHILE (`$slot_end_time` <= `$available_end_time`) DO
						IF((`$cur_date` = `$temp_today_date` AND `$slot_start_time` < `$prevented_current_time`) OR (`$has_booking_prevention` AND `$cur_date` = `$temp_today_date` AND `$slot_start_time` >= `$booking_prevention_startTime` AND `$cur_time` >= `$booking_prevention_startTime` ) ) THEN
							SET `$slot_start_time` = `$slot_end_time`;
                            SET `$slot_end_time` = TIME(DATE_ADD(`$slot_start_time`, INTERVAL `$service_duration` MINUTE));
                        ELSE
							SET `$available_slots` = JSON_ARRAY_APPEND(
								`$available_slots`,
                                ('$'),
                                JSON_OBJECT(
									'slotStartTime', `$slot_start_time`,
                                    'slotEndTime', `$slot_end_time`
                                )
                            );

                            SET `$slot_start_time` = `$slot_end_time`;
                            SET `$slot_end_time` = TIME(DATE_ADD(`$slot_start_time`, INTERVAL `$service_duration` MINUTE));
                        END IF;
                    END WHILE;

                    SET i = i + 1;
                END WHILE loop_to_get_available_slots;

                SET `$available_slots_after_service_avail_filter` = JSON_ARRAY();

                SET `$available_slot_count_before_service_avail` = 0;
                SELECT JSON_LENGTH(`$available_slots`) INTO `$available_slot_count_before_service_avail`;

                SET l = 0;
                loop_for_service_avail: WHILE (l < `$available_slot_count_before_service_avail`) DO
                    SET `$l_start_time` = JSON_UNQUOTE(JSON_EXTRACT(`$available_slots`, CONCAT('$[', l, '].slotStartTime')));
                    SET `$l_end_time`   = JSON_UNQUOTE(JSON_EXTRACT(`$available_slots`, CONCAT('$[', l, '].slotEndTime')));

                    SET `$service_availability_count` = 0;
                    SELECT count(*) INTO `$service_availability_count` FROM grow_practice.service_availabilities AS sa WHERE sa.day= `$day_of_week` AND sa.med_group_id = group_id AND sa.provider_id = provider_id AND sa.location_id = location_id;

                    IF(`$service_availability_count` = 0) THEN
                    SET `$available_slots_after_service_avail_filter` = JSON_ARRAY_APPEND(
                            `$available_slots_after_service_avail_filter`,
                            ('$'),
                            JSON_OBJECT(
                                'slotStartTime', `$l_start_time`,
                                'slotEndTime', `$l_end_time`
                            )
                        );
                    END IF;

                    SET m = 0;
                    SET `$is_service_availability` = false;
                    loop_available_service: WHILE (m < `$service_availability_count`) DO
                        SELECT sa.start_time, sa.end_time, GROUP_CONCAT(sas.service_id) AS service_ids INTO `$service_avail_start_time`, `$service_avail_end_time`, `$service_avail_ids`
                        FROM grow_practice.service_availabilities sa
                        LEFT JOIN grow_practice.service_availability_services sas ON sa.id = sas.service_availability_id
                        WHERE sa.day = `$day_of_week`
                          AND sa.med_group_id = group_id
                          AND sa.location_id = location_id
                          AND sa.provider_id = provider_id
                        GROUP BY sa.id, sa.start_time, sa.end_time
                        ORDER BY Date(sa.start_time)
                        LIMIT m,1;

                    IF (FIND_IN_SET(service_id, `$service_avail_ids`)) THEN
                        IF ((`$l_start_time` < `$service_avail_start_time` AND `$l_end_time` <= `$service_avail_start_time`) OR (`$l_start_time` >= `$service_avail_end_time` AND `$l_end_time` > `$service_avail_end_time`)) THEN
                             SET `$is_service_availability` = true;
                        ELSE
                             SET `$is_service_availability` = false;
                             LEAVE loop_available_service;
                        END IF;
                    ELSE
                        SET `$is_service_availability` = true;
                    END IF;
                    SET m = m+1;
                    END WHILE loop_available_service;

                IF(`$is_service_availability` = true) THEN
                	SET `$available_slots_after_service_avail_filter` = JSON_ARRAY_APPEND(
                         `$available_slots_after_service_avail_filter`,
                         ('$'),
                         JSON_OBJECT(
                              'slotStartTime', `$l_start_time`,
                              'slotEndTime', `$l_end_time`
                         )
                    );
                END IF;
                SET l = l+1;
                END WHILE loop_for_service_avail;

                SELECT JSON_LENGTH(`$available_slots_after_service_avail_filter`) INTO `$available_slot_count`;

                IF(`$available_slot_count` != 0) THEN
					SET j = 0;
                    loop_available_slots : WHILE (j < `$available_slot_count`) DO
						SET `$j_start_time` = JSON_UNQUOTE(JSON_EXTRACT(`$available_slots_after_service_avail_filter`, CONCAT('$[', j, '].slotStartTime')));
						SET `$j_end_time`   = JSON_UNQUOTE(JSON_EXTRACT(`$available_slots_after_service_avail_filter`, CONCAT('$[', j, '].slotEndTime')));

                        SET `$is_slot_unavailable` = false;
						SET slot_exist_count = 0;

                        SELECT COUNT(scheduled_time) INTO `$exiting_appt_count` FROM grow_practice.appointments AS a WHERE a.med_group_id = group_id AND a.provider_id = provider_id AND a.location_id = location_id AND a.scheduled_date = `$cur_date` AND a.scheduled_time IS NOT NULL;
                        IF(`$exiting_appt_count` = 0) THEN
							SET `$available_dates` = JSON_ARRAY_APPEND(`$available_dates`, '$', `$cur_date`);

                            SELECT DATE_ADD(`$cur_date`, INTERVAL 1 DAY) INTO `$cur_date`;
							ITERATE loop_to_eom;
                        ELSE
							SET k = 0;
							check_overlap: WHILE k < `$exiting_appt_count` DO
								SELECT scheduled_time, duration INTO `$exist_app_start_time`, exist_appt_duration FROM grow_practice.appointments AS a WHERE a.med_group_id = group_id AND a.provider_id = provider_id AND a.location_id = location_id AND a.scheduled_date = `$cur_date` AND a.scheduled_time IS NOT NULL LIMIT k,1;
                                SET `$exist_app_end_time` = TIME(DATE_ADD(`$exist_app_start_time`,Interval exist_appt_duration Minute));

                                IF ((`$j_start_time` < `$exist_app_start_time` AND (`$j_end_time` <= `$exist_app_start_time`))
									OR
									(`$j_start_time` >= `$exist_app_end_time` AND (`$j_end_time` > `$exist_app_end_time`))) THEN
									SET `$dummy` = true;
								ELSE
									SET slot_exist_count = slot_exist_count + 1;
									IF(slot_exist_count >= `$p_booking_per_slot`) THEN
										SET `$is_slot_unavailable` = true;
									END IF;
								END IF;
							SET k = k+1;
                            END WHILE check_overlap;

                            IF (`$is_slot_unavailable` = false) THEN
								SET `$available_dates` = JSON_ARRAY_APPEND(`$available_dates`, '$', `$cur_date`);

								SELECT DATE_ADD(`$cur_date`, INTERVAL 1 DAY) INTO `$cur_date`;
								ITERATE loop_to_eom;
							END IF;
                        END IF;
					SET j = j+1;
                    END WHILE loop_available_slots;
                END IF;
            END IF;
        END IF;
    END IF;
	SET `$cur_date` = DATE_ADD(`$cur_date`, INTERVAL 1 DAY);
END WHILE loop_to_eom;
    SELECT dates FROM JSON_TABLE(`$available_dates`, '$[*]' COLUMNS(dates DATE PATH '$')) AS jt;
END;