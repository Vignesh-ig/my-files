DROP PROCEDURE IF EXISTS get_same_day_reminder_info;

CREATE PROCEDURE get_same_day_reminder_info(
    IN time_zone VARCHAR(255)
)
    READS SQL DATA
BEGIN
    DROP TABLE IF EXISTS `Temp1`;
    CREATE TEMPORARY TABLE Temp1 (
                                     phone_number VARCHAR(255),
                                     email VARCHAR(255),
                                     first_name VARCHAR(255),
                                     last_name VARCHAR(255),
                                     perf_lang VARCHAR(255),
                                     patient_id BIGINT,
                                     appt_id VARCHAR(255),
                                     group_id VARCHAR(255),
                                     provider_id BIGINT,
                                     meeting_time TIME,
                                     schedule_date DATE,
                                     is_reminder_sent BIT,
                                     location_id BIGINT,
                                     is_patient_confirmed BIT
    );

    -- Single efficient query instead of nested loops
    INSERT INTO Temp1 (
        phone_number, email, first_name, last_name, perf_lang,
        patient_id, appt_id, group_id, provider_id, meeting_time,
        schedule_date, is_reminder_sent, location_id, is_patient_confirmed
    )
    SELECT
        p.phone_number,
        p.email,
        p.first_name,
        p.last_name,
        p.preferred_language,
        a.patient_id,
        a.id,
        a.med_group_id,
        a.provider_id,
        TIME(a.scheduled_date_time),
        DATE(a.scheduled_date_time),
        a.is_reminder_sent,
        a.location_id,
        a.is_patient_confirmed
    FROM
        grow_practice.appointments a
            JOIN
        grow_practice.patients p ON a.patient_id = p.id
            JOIN
        grow_practice.med_groups mg ON a.med_group_id = mg.group_id
            JOIN
        grow_practice.med_group_flags mgf ON mg.group_id = mgf.med_group_id
    WHERE
        DATE(a.scheduled_date_time) = CURDATE()
      AND a.is_provider_confirmed = 1
      AND mg.time_zone = time_zone
      AND mgf.reminder_days = 1;

    SELECT * FROM Temp1;
END;