DROP PROCEDURE IF EXISTS recall_appointment_reminder;

create procedure recall_appointment_reminder() reads sql data
BEGIN

    DECLARE patient_id, location_id, service_id, appt_id, provider_id bigint;
    DECLARE group_id, phone_number, email, first_name, last_name, perf_lang varchar(255);
    DECLARE schedule_date_time datetime;
    DECLARE is_result, is_result_rp, r_period, counter, counter_2, i, j, z INT;

    DROP TABLE IF EXISTS `Temp1`;
    CREATE TEMPORARY TABLE Temp1
    (
        phone_number  varchar(255),
        email         varchar(255),
        first_name    varchar(255),
        last_name     varchar(255),
        perf_lang     varchar(255),
        patient_id    bigint,
        appt_id       bigint,
        group_id      varchar(255),
        provider_id   bigint,
        meeting_time  time,
        schedule_date date,
        location_id   bigint
    );

    SET i = 0;
    SET z = 0;

    SELECT COUNT(*) INTO counter FROM grow_practice.med_group_flags WHERE recall_appt_reminder = 1;

    WHILE (i < counter)
        DO
            SELECT mg.group_id
            INTO group_id
            FROM grow_practice.med_groups mg
                     JOIN grow_practice.med_group_flags mgf ON mg.group_id = mgf.med_group_id
            WHERE mgf.recall_appt_reminder = 1
            limit z,1;
            SELECT COUNT(*)
            INTO counter_2
            FROM grow_practice.appointment_archives
            WHERE is_provider_confirmed = 1
              AND med_group_id = group_id;
            SET j = 0;
            WHILE (j < counter_2)
                DO
                    SELECT service_id, id
                    INTO service_id, appt_id
                    FROM grow_practice.appointment_archives
                    WHERE is_provider_confirmed = 1
                      AND med_group_id = group_id
                    limit j,1;

                    SELECT COUNT(*)
                    INTO is_result_rp
                    FROM grow_practice.services
                    WHERE grow_practice.appointment_archives.service_id = service_id
                      AND med_group_id = group_id
                      AND is_recall = 1;
                    IF is_result_rp > 0 THEN
                        SELECT recall_period
                        INTO r_period
                        FROM grow_practice.services
                        WHERE grow_practice.appointment_archives.service_id = service_id
                          AND med_group_id = group_id
                          AND is_recall = 1;
                        IF r_period = 30 THEN
                            SELECT COUNT(*)
                            INTO is_result
                            FROM grow_practice.appointment_archives
                            WHERE service_id = service_id
                              AND id = appt_id
                              AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                              AND is_provider_confirmed = 1
                              AND med_group_id = group_id;
                            IF is_result > 0 THEN
                                SELECT patient_id, id, med_group_id, provider_id, scheduled_date_time, location_id
                                INTO patient_id,appt_id,group_id,provider_id,schedule_date_time,location_id
                                FROM grow_practice.appointment_archives
                                WHERE service_id = service_id
                                  AND id = appt_id
                                  AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                                  AND is_provider_confirmed = 1
                                  AND med_group_id = group_id;
                                SELECT phone_number, email, first_name, last_name, preferred_language
                                INTO phone_number, email, first_name, last_name, perf_lang
                                FROM grow_practice.patients
                                WHERE id = patient_id
                                  AND med_group_id = group_id;
                                INSERT INTO Temp1
                                VALUES (phone_number, email, first_name, last_name, perf_lang, patient_id, appt_id,
                                        group_id, provider_id, TIME(schedule_date_time), DATE(schedule_date_time),
                                        location_id);
                            END IF;
                        ELSEIF r_period = 60 THEN
                            SELECT COUNT(*)
                            INTO is_result
                            FROM grow_practice.appointment_archives
                            WHERE service_id = service_id
                              AND id = appt_id
                              AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 60 DAY)
                              AND is_provider_confirmed = 1
                              AND med_group_id = group_id;
                            IF is_result > 0 THEN
                                SELECT patient_id,
                                       id,
                                       med_group_id,
                                       provider_id,
                                       scheduled_date_time,
                                       location_id
                                INTO patient_id,appt_id,group_id,provider_id,schedule_date_time, location_id
                                FROM grow_practice.appointment_archives
                                WHERE service_id = service_id
                                  AND ID = appt_id
                                  AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 60 DAY)
                                  AND is_provider_confirmed = 1
                                  AND med_group_id = group_id;
                                SELECT phone_number, email, first_name, last_name, preferred_language
                                INTO phone_number, email, first_name, last_name, perf_lang
                                FROM grow_practice.patients
                                WHERE id = patient_id
                                  AND med_group_id = group_id;
                                INSERT INTO Temp1
                                VALUES (phone_number, email, first_name, last_name, perf_lang, patient_id, appt_id,
                                        group_id, provider_id, TIME(schedule_date_time), DATE(schedule_date_time),
                                        location_id);
                            END IF;
                        ELSEIF r_period = 90 THEN
                            SELECT COUNT(*)
                            INTO is_result
                            FROM grow_practice.appointment_archives
                            WHERE service_id = service_id
                              AND id = appt_id
                              AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 90 DAY)
                              AND is_provider_confirmed = 1
                              AND med_group_id = group_id;
                            IF is_result > 0 THEN
                                SELECT patient_id,
                                       id,
                                       med_group_id,
                                       provider_id,
                                       scheduled_date_time,
                                       location_id
                                INTO patient_id,appt_id,group_id,provider_id,schedule_date_time, location_id
                                FROM grow_practice.appointment_archives
                                WHERE service_id = service_id
                                  AND id = appt_id
                                  AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 90 DAY)
                                  AND is_provider_confirmed = 1
                                  AND med_group_id = group_id;
                                SELECT phone_number, email, first_name, last_name, preferred_language
                                INTO phone_number, email, first_name, last_name, perf_lang
                                FROM grow_practice.patients
                                WHERE id = patient_id
                                  AND med_group_id = group_id;
                                INSERT INTO Temp1
                                VALUES (phone_number, email, first_name, last_name, perf_lang, patient_id, appt_id,
                                        group_id, provider_id, TIME(schedule_date_time), DATE(schedule_date_time),
                                        location_id);
                            END IF;
                        ELSEIF r_period = 180 THEN
                            SELECT COUNT(*)
                            INTO is_result
                            FROM grow_practice.appointment_archives
                            WHERE service_id = service_id
                              AND id = appt_id
                              AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 180 DAY)
                              AND is_provider_confirmed = 1
                              AND med_group_id = group_id;
                            IF is_result > 0 THEN
                                SELECT patient_id,
                                       id,
                                       med_group_id,
                                       provider_id,
                                       scheduled_date_time,
                                       location_id
                                INTO patient_id,appt_id,group_id,provider_id,schedule_date_time, location_id
                                FROM grow_practice.appointment_archives
                                WHERE service_id = service_id
                                  AND id = appt_id
                                  AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 180 DAY)
                                  AND is_provider_confirmed = 1
                                  AND med_group_id = group_id;
                                SELECT phone_number, email, first_name, last_name, preferred_language
                                INTO phone_number, email, first_name, last_name, perf_lang
                                FROM grow_practice.patients
                                WHERE id = patient_id
                                  AND med_group_id = group_id;
                                INSERT INTO Temp1
                                VALUES (phone_number, email, first_name, last_name, perf_lang, patient_id, appt_id,
                                        group_id, provider_id, TIME(schedule_date_time), DATE(schedule_date_time),
                                        location_id);
                            END IF;
                        ELSEIF r_period = 365 THEN
                            SELECT COUNT(*)
                            INTO is_result
                            FROM grow_practice.appointment_archives
                            WHERE service_id = service_id
                              AND id = appt_id
                              AND DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 365 DAY)
                              AND is_provider_confirmed = 1
                              AND med_group_id = group_id;
                            IF is_result > 0 THEN
                                SELECT patient_id,
                                       id,
                                       med_group_id,
                                       provider_id,
                                       scheduled_date_time,
                                       location_id
                                INTO patient_id,appt_id,group_id,provider_id,schedule_date_time, location_id
                                FROM grow_practice.appointment_archives
                                WHERE DATE(scheduled_date_time) = DATE_SUB(CURDATE(), INTERVAL 365 DAY)
                                  AND service_id = service_id
                                  AND id = appt_id
                                  AND is_provider_confirmed = 1
                                  AND med_group_id = group_id;
                                SELECT phone_number, email, first_name, last_name, preferred_language
                                INTO phone_number, email, first_name, last_name, perf_lang
                                FROM grow_practice.patients
                                WHERE id = patient_id
                                  AND med_group_id = group_id;
                                INSERT INTO Temp1
                                VALUES (phone_number, email, first_name, last_name, perf_lang, patient_id, appt_id,
                                        group_id, provider_id, TIME(schedule_date_time), DATE(schedule_date_time),
                                        location_id);
                            END IF;

                            /*NOTHING TO DO IF NONE OF THE CURRENT RECALL PERIODS NOT MATCHING THE MAIN VALUES*/
                        END IF;

                        /*NO RESULT SO WE MOVE TO NEXT SERVICE ID*/
                    END IF;
                    SET j = j + 1;
                END WHILE;
            SET i = i + 1;
            SET z = z + 1;
        END WHILE;
    SELECT * FROM Temp1;
END;
