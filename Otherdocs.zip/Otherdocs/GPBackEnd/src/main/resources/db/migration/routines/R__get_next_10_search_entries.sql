DROP PROCEDURE IF EXISTS get_next_10_search_entries;

create procedure get_next_10_search_entries(IN term varchar(255), IN p int,
                                                                  IN group_id varchar(255), IN is_dob bit)
    reads sql data
BEGIN

    IF is_dob = true THEN

        SELECT id, first_name, last_name, home_phone, phone_number, dob
        FROM grow_practice.patients
        WHERE med_group_id = group_id
          AND dob = term
        LIMIT 10 OFFSET p;

    ELSE

        SELECT id, first_name, last_name, home_phone, phone_number, dob
        FROM grow_practice.patients
        WHERE med_group_id = group_id
          AND (CONCAT(first_name, ' ', last_name) LIKE CONCAT('%', term, '%') OR
               home_phone LIKE CONCAT('%', term, '%') OR phone_number LIKE CONCAT('%', term, '%'))
        LIMIT 10 OFFSET p;

    END IF;

END;
