DROP PROCEDURE IF EXISTS get_appointment_available_slots;

CREATE PROCEDURE get_appointment_available_slots(IN group_id VARCHAR(10),
                                                 IN provider_id BIGINT,
                                                 IN appt_date DATE,
                                                 IN location_id BIGINT,
                                                 IN current_date_time DATETIME,
                                                 IN service_id BIGINT)
    READS SQL DATA
BEGIN

    DECLARE booking_type VARCHAR(25);

    DECLARE service_interval, appt_interval,
        booking_per_slot, booking_per_day, count_appt_time,
        count_provider_sa, count_provider_other_sa,
        count_provider_ra, counter, i, prepared_slot_count, j,
        specific_slot_exist_count, exist_appt_count, k,
        appt_duration INT;

    DECLARE date_now DATE;
    DECLARE time_now, avail_start_time, avail_end_time,
        slot_start_time, slot_end_time, pre_slot_start_time,
        pre_slot_end_time, appt_start_time, appt_end_time TIME;

    DECLARE specific_day_of_week VARCHAR(25);

    DECLARE is_slot_unavailable, is_slot_available BOOLEAN;

    DECLARE prepared_slots JSON;
    DECLARE available_slots JSON;

    SET date_now = DATE(current_date_time);
    SET time_now = TIME(current_date_time);

    SET specific_day_of_week = DAYNAME(appt_date);

    SET prepared_slots = JSON_ARRAY();
    SET available_slots = JSON_ARRAY();

    SELECT s.duration INTO service_interval FROM services s WHERE s.id = service_id AND s.med_group_id = group_id;

    SELECT p.booking_type, p.booking_per_slot, p.booking_per_day, p.default_appt_duration
    INTO booking_type, booking_per_slot, booking_per_day, appt_interval
    FROM grow_practice.providers p
    WHERE med_group_id = group_id
      AND id = provider_id;

    SELECT COUNT(a.scheduled_time)
    INTO count_appt_time
    FROM grow_practice.appointments a
    WHERE a.provider_id = provider_id
      AND a.med_group_id = group_id
      AND a.scheduled_date = appt_date
      AND a.location_id = location_id;

    IF count_appt_time < booking_per_day THEN

        IF booking_type = 'SINGLE' THEN
            SET booking_per_slot = 1;
        ELSEIF booking_type = 'DOUBLE' THEN
            SET booking_per_slot = 2;
        ELSEIF booking_type = 'TRIPLE' THEN
            SET booking_per_slot = 3;
        END IF;

        IF service_interval = 0 THEN
            SET service_interval = appt_interval;
        END IF;

        SELECT COUNT(*)
        INTO count_provider_sa
        FROM grow_practice.specific_availabilities sa
        WHERE sa.schedule_date = appt_date
          AND sa.med_group_id = group_id
          AND sa.location_id = location_id
          AND sa.provider_id = provider_id;

        SELECT COUNT(*)
        INTO count_provider_other_sa
        FROM grow_practice.specific_availabilities sa
        WHERE sa.schedule_date = appt_date
          AND sa.med_group_id = group_id
          AND sa.location_id != location_id
          AND sa.provider_id = provider_id;

        SELECT COUNT(*)
        INTO count_provider_ra
        FROM grow_practice.recurring_availabilities ra
        WHERE ra.day = specific_day_of_week
          AND ra.med_group_id = group_id
          AND ra.location_id = location_id
          AND ra.provider_id = provider_id;

        IF count_provider_sa > 0 THEN
            SET counter = count_provider_sa;
        ELSEIF (count_provider_sa = 0 AND count_provider_other_sa > 0) THEN
            SET counter = 0;
        ELSE
            SET counter = count_provider_ra;
        END IF;

        SET i = 0;

        loop1:
        WHILE i < counter
            DO

                IF count_provider_sa > 0 THEN

                    SELECT sa.start_time, sa.end_time
                    INTO avail_start_time, avail_end_time
                    FROM grow_practice.specific_availabilities sa
                    WHERE sa.schedule_date = appt_date
                      AND sa.med_group_id = group_id
                      AND sa.location_id = location_id
                      AND sa.provider_id = provider_id
                    ORDER BY Date(start_time)
                    LIMIT i, 1;

                ELSE

                    SELECT ra.start_time, ra.end_time
                    INTO avail_start_time, avail_end_time
                    FROM grow_practice.recurring_availabilities ra
                    WHERE ra.day = specific_day_of_week
                      AND ra.med_group_id = group_id
                      AND ra.location_id = location_id
                      AND ra.provider_id = provider_id
                    ORDER BY Date(start_time)
                    LIMIT i, 1;

                END IF;

                SET slot_start_time = avail_start_time;
                SET slot_end_time = TIME(DATE_ADD(slot_start_time, INTERVAL service_interval MINUTE));

                WHILE slot_end_time <= avail_end_time
                    DO

                        IF appt_date = date_now AND slot_start_time < time_now THEN
                            SET slot_start_time = slot_end_time;
                            SET slot_end_time = TIME(DATE_ADD(slot_end_time, INTERVAL service_interval MINUTE));
                        ELSE
                            SET prepared_slots = JSON_ARRAY_APPEND(
                                    prepared_slots,
                                    '$',
                                    JSON_OBJECT(
                                            'slotStartTime', slot_start_time,
                                            'slotEndTime', slot_end_time
                                    )
                                                 );

                            SET slot_start_time = slot_end_time;
                            SET slot_end_time = TIME(DATE_ADD(slot_end_time, INTERVAL service_interval MINUTE));

                        END IF;

                    END WHILE;

                SET i = i + 1;

            END WHILE loop1;

        SELECT JSON_LENGTH(prepared_slots) INTO prepared_slot_count;

        SET j = 0;

        slot_checking_loop:
        WHILE j < prepared_slot_count
            DO

                SET pre_slot_start_time =
                        JSON_UNQUOTE(JSON_EXTRACT(prepared_slots, CONCAT('$[', j, '].slotStartTime')));
                SET pre_slot_end_time = JSON_UNQUOTE(JSON_EXTRACT(prepared_slots, CONCAT('$[', j, '].slotEndTime')));

                SET is_slot_unavailable = false;
                SET specific_slot_exist_count = 0;

                SELECT COUNT(a.scheduled_time)
                INTO exist_appt_count
                FROM grow_practice.appointments a
                WHERE a.scheduled_date = appt_date
                  AND a.med_group_id = group_id
                  AND a.location_id = location_id
                  AND a.provider_id = provider_id
                  AND a.scheduled_time IS NOT NULL;

                SET k = 0;
                exist_appt_check_loop:
                WHILE k < exist_appt_count
                    DO

                        SELECT scheduled_time, duration
                        INTO appt_start_time, appt_duration
                        FROM grow_practice.appointments a
                        WHERE a.scheduled_date = appt_date
                          AND a.med_group_id = group_id
                          AND a.location_id = location_id
                          AND a.provider_id = provider_id
                          AND a.scheduled_time IS NOT NULL
                        LIMIT k, 1;

                        SET appt_end_time = TIME(DATE_ADD(appt_start_time, INTERVAL appt_duration MINUTE));

                        IF ((pre_slot_start_time < appt_start_time AND
                             (pre_slot_end_time <= appt_start_time)) OR
                            (pre_slot_start_time >= appt_end_time AND (pre_slot_end_time > appt_end_time))) THEN
                            SET is_slot_available = true; /*Not using this value*/
                        ELSE

                            SET specific_slot_exist_count = specific_slot_exist_count + 1;

                            IF (specific_slot_exist_count >= booking_per_slot) THEN
                                SET is_slot_unavailable = true;
                            END IF;

                        END IF;

                        SET k = k + 1;
                    END WHILE exist_appt_check_loop;

                IF is_slot_unavailable = false THEN
                    SET available_slots =
                            JSON_ARRAY_APPEND(available_slots, '$', TIME_FORMAT(pre_slot_start_time, '%H:%i:%s'));
                END IF;

                SET j = j + 1;

            END WHILE slot_checking_loop;

        SELECT time FROM JSON_TABLE(available_slots, '$[*]' COLUMNS (time time PATH '$')) AS jt ORDER BY time;
    ELSE
        SELECT time FROM JSON_TABLE(available_slots, '$[*]' COLUMNS (time time PATH '$')) AS jt ORDER BY time;
    END IF;
END;