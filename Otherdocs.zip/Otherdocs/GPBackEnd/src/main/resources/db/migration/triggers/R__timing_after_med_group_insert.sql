DROP TRIGGER IF EXISTS timing_after_med_group_insert;
CREATE TRIGGER timing_after_med_group_insert
    AFTER INSERT
    ON grow_practice.med_groups
    FOR EACH ROW
BEGIN
    INSERT INTO grow_practice.med_group_timings (friday_end_time,
                                                 friday_start_time,
                                                 monday_end_time,
                                                 monday_start_time,
                                                 saturday_end_time,
                                                 sunday_end_time,
                                                 saturday_start_time,
                                                 sunday_start_time,
                                                 thursday_end_time,
                                                 thursday_start_time,
                                                 tuesday_end_time,
                                                 tuesday_start_time,
                                                 wednesday_end_time,
                                                 wednesday_start_time,
                                                 med_group_id)
    VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NEW.group_id);
END;