package com.rhombuzz.gpbackend.modules.patient.controller;

import com.rhombuzz.gpbackend.modules.patient.dto.request.AdvancedSearchPatientRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponseList;
import com.rhombuzz.gpbackend.modules.patient.service.PatientSearchService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/patients/search")
@Validated
public class PatientSearchController {
    private final PatientSearchService patientSearchService;

    @PostMapping("/advanced")
    public ResponseEntity<Page<PatientResponseList>> advancedSearchPatients(
            @RequestBody AdvancedSearchPatientRequest request,
            Pageable pageable
    ) {
        Page<PatientResponseList> patients = patientSearchService.advancedSearchPatients(request, pageable);
        return ResponseEntity.ok(patients);
    }

    @GetMapping
    public ResponseEntity<Page<PatientResponseList>> searchPatients(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotBlank @Size(max = 100) String searchTerm,
            Pageable pageable
    ) {
        Page<PatientResponseList> patients = patientSearchService.searchPatients(groupId, searchTerm, pageable);
        return ResponseEntity.ok(patients);
    }
}
