package com.rhombuzz.gpbackend.modules.communication.entity;


import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms", indexes = {
        @Index(name = "idx_sms_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_sms_patient_id", columnList = "patient_id")
})
public class SMS {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @Column(name = "date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime dateTime;

    @Lob
    @Column(name = "message", nullable = false, columnDefinition = "TEXT")
    private String message;

    @Column(name = "sender", length = 45, nullable = false)
    private String sender;

    @Column(name = "conversation_id", length = 45)
    private String conversationId;

    @Column(name = "message_uuid", length = 45)
    private String messageUUID;

    @Column(name = "conversation_status")
    private Integer conversationStatus;

    @Column(name = "conversation_depth")
    private Integer conversationDepth;

    @Column(name = "conversation_type", length = 45)
    @Enumerated(EnumType.STRING)
    private ConversationType conversationType;

    @Column(name = "sms_type", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private SMSType smsType;

    @Column(name = "is_read")
    private boolean isRead;

    public enum ConversationType {

        WAITLIST,
        REMINDER,
        MISSING_APPOINTMENT_FOLLOW_UP,
        RECALL_APPOINTMENT_REMINDER
    }

    public enum SMSType {

        SYSTEM,
        PATIENT,
        MANUAL,
        APPOINTMENT_AVAILABLE,
        APPOINTMENT_UNAVAILABLE,
        APPOINTMENT_CANCELED,
        APPOINTMENT_CONFIRMED,
        APPOINTMENT_RESCHEDULED,
        APPOINTMENT_REQUESTED,
        PENDING_APPOINTMENT_CANCELED,
        PENDING_APPOINTMENT_RESCHEDULED,
    }
}
