package com.rhombuzz.gpbackend.modules.provider.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public record SaveUnavailabilityRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Provider ID cannot be null")
        @Positive(message = "Provider ID must be a positive number")
        Long providerId,

        @NotNull(message = "Date cannot be null")
        LocalDate date,

        @NotBlank(message = "Reason cannot be blank")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "Reason must contain only letters and spaces")
        @Size(max = 45, message = "Reason must be at most 45 characters long")
        String reason
) {
}
