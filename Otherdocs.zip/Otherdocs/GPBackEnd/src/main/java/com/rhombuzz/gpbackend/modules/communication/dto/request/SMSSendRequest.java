package com.rhombuzz.gpbackend.modules.communication.dto.request;

import jakarta.validation.constraints.NotBlank;

public record SMSSendRequest(
        @NotBlank(message = "From number cannot be blank")
        String fromNumber,

        @NotBlank(message = "To number cannot be blank")
        String toNumber,

        @NotBlank(message = "Message cannot be blank")
        String message
) {
}