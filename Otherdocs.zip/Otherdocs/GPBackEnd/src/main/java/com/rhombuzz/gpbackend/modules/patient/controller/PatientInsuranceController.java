package com.rhombuzz.gpbackend.modules.patient.controller;

import com.rhombuzz.gpbackend.modules.patient.dto.request.SavePatientInsuranceRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientInsuranceResponse;
import com.rhombuzz.gpbackend.modules.patient.service.PatientInsuranceService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/patient-insurances")
@Validated
public class PatientInsuranceController {
    private final PatientInsuranceService patientInsuranceService;

    @GetMapping("/patients/{patientId}")
    public ResponseEntity<PatientInsuranceResponse> getPatientInsurance(
            @PathVariable @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        PatientInsuranceResponse response = patientInsuranceService.getPatientInsurance(patientId, groupId);
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<Void> savePatientInsurance(@RequestBody @Valid SavePatientInsuranceRequest request) {
        patientInsuranceService.savePatientInsurance(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

}
