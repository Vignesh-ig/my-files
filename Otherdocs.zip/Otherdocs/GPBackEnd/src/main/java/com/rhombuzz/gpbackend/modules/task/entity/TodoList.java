package com.rhombuzz.gpbackend.modules.task.entity;

import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.task.dto.request.SaveTodoListRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "todo_lists", indexes = {
        @Index(name = "idx_todo_list_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_todo_list_patient_id", columnList = "patient_id"),
        @Index(name = "idx_todo_list_appointment_id", columnList = "appointment_id")
})
public class TodoList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "appointment_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Appointment appointment;

    @OneToMany(mappedBy = "todoList", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private List<TodoListHistory> todoListHistories;

    @Column(name = "title", length = 45, nullable = false)
    private String title;

    @Column(name = "detail", length = 100, nullable = false)
    private String detail;

    @Column(name = "priority", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private Priority priority;

    @Column(name = "created_by", length = 45, nullable = false)
    private String createdBy;

    @Column(name = "assigned_to", length = 45, nullable = false)
    private String assignedTo;

    @Column(name = "date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime dateTime;

    @Column(name = "is_deleted")
    private boolean isDeleted;

    @Column(name = "is_read")
    private boolean isRead;

    public static TodoList fromRequest(SaveTodoListRequest request) {
        return TodoList.builder()
                .title(request.title())
                .detail(request.detail())
                .priority(request.priority())
                .assignedTo(request.assignTo())
                .build();
    }

    public enum Priority {

        HIGH,
        MEDIUM,
        LOW
    }

}
