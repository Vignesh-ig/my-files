package com.rhombuzz.gpbackend.modules.provider.dto.response;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;

public interface ProviderResponse {

    Long getId();

    int getOrder();

    Provider.Prefix getPrefix();

    String getName();

    String getSuffix();

    String getSpecialist();

    String getReference();

    Provider.BookingType getBookingType();

    int getBookingPerSlot();

    int getBookingPerDay();

    int getDefaultApptDuration();

    ContactMethod getPreferredContactMethod();

    String getEmail();

    String getCellPhone();

}
