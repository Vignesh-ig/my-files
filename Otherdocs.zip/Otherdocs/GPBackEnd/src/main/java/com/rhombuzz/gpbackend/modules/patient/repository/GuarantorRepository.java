package com.rhombuzz.gpbackend.modules.patient.repository;

import com.rhombuzz.gpbackend.modules.patient.entity.Guarantor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface GuarantorRepository extends JpaRepository<Guarantor, Long> {

    @Query("SELECT g FROM Guarantor g WHERE g.patient.id = ?1 AND g.medGroup.groupId = ?2")
    Optional<Guarantor> findByPatientId(Long patientId, String groupId);

}
