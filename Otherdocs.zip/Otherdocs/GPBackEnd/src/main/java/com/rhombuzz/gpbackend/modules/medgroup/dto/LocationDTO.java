package com.rhombuzz.gpbackend.modules.medgroup.dto;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class LocationDTO {

    private Long id;
    private String name;

    public static LocationDTO fromEntity(Location location) {
        return LocationDTO.builder()
                .id(location.getId())
                .name(location.getName())
                .build();
    }

}
