package com.rhombuzz.gpbackend.integration.entity.enums;

public enum IntegrationActionType {
    CREATE("Create"),
    UPDATE("Update");

    private final String label;

    IntegrationActionType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
