package com.rhombuzz.gpbackend.modules.medgroup.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "med_group_flags", indexes = {
        @Index(name = "idx_med_group_flag_med_group_id", columnList = "med_group_id")
})
public class MedGroupFlag {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "today_appointment")
    private boolean todayAppointment;

    @Column(name = "checkin")
    private boolean checkin;

    @Column(name = "checkout")
    private boolean checkout;

    @Column(name = "patient_checkin_alert")
    private boolean patientCheckinAlert;

    @Column(name = "office_closed_auto_reply")
    private boolean officeClosedAutoReply;

    @Column(name = "reminder")
    private boolean reminder;

    @Column(name = "pre_reminder")
    private boolean preReminder;

    @Column(name = "missed_appt_follow_up")
    private boolean missedAppointmentFollowUp;

    @Column(name = "recall_appt_reminder")
    private boolean recallAppointmentReminder;

    @Column(name = "coverage")
    private boolean coverage;

    @Column(name = "online_intake")
    private boolean onlineIntake;

    @Column(name = "auto_request_quick_survey")
    private boolean autoRequestQuickSurvey;

    @Column(name = "auto_request_review")
    private boolean autoRequestReview;

    @Column(name = "integration_patient_run_check")
    private boolean integrationPatientRunCheck;

    @Column(name = "integration_appt_run_check")
    private boolean integrationAppointmentRuncheck;

    @Column(name = "sms_shutoff")
    private boolean smsShutoff;

    @Column(name = "email_shutoff")
    private boolean emailShutoff;

    @Column(name = "form_submission_email_alert")
    private boolean formSubmissionEmailAlert;

    @Column(name = "appt_request_email_alert")
    private boolean appointmentRequestEmailAlert;

    @Column(name = "auto_request_payment")
    private boolean autoRequestPayment;

    @Column(name = "daily_summary")
    private boolean dailySummarySwitch;

    @Column(name = "scheduling_actions")
    private boolean schedulingActions;

    @Column(name = "documents")
    private boolean documents;

    @Column(name = "payment")
    private boolean payment;

    @Column(name = "insurance")
    private boolean insurance;

    @Column(name = "notify_payment_success")
    private boolean notifyPaymentSuccess;

    @Column(name = "booking_fee")
    private boolean bookingFee;

    @Column(name = "marketing_blast")
    private boolean marketingBlast;

    @Column(name = "telehealth")
    private boolean telehealth;

    @AllArgsConstructor
    @Getter
    public enum AdminFlag {

        //No UI as well as not used in backend logic
        CHECKIN("checkin"),
        CHECKOUT("checkout"),
        TODAY_APPOINTMENT("todayAppointment"),

        // No UI but used in backend logic
        PATIENT_CHECKIN_ALERT("patientCheckinAlert"),
        INTEGRATION_PATIENT_RUN_CHECK("integrationPatientRunCheck"),
        INTEGRATION_APPOINTMENT_RUN_CHECK("integrationAppointmentRunCheck"),

        COVERAGE("coverage"),
        ONLINE_INTAKE("onlineIntake"),
        AUTO_REQUEST_REVIEW("autoRequestReview"),
        SMS_SHUTOFF("smsShutoff"),
        EMAIL_SHUTOFF("emailShutoff"),
        DAILY_SUMMARY("dailySummarySwitch"),
        DOCUMENTS("documents"),
        PAYMENT("payment"),
        INSURANCE("insurance"),
        SCHEDULING_ACTIONS("schedulingActions"),
        MARKETING_BLAST("marketingBlast"),
        TELEHEALTH("telehealth");

        private final String columnName;
    }

    @AllArgsConstructor
    @Getter
    public enum DashboardFlag {

        PRE_REMINDER("preReminder"),
        REMINDER("reminder"),
        OFFICE_CLOSED_AUTO_REPLY("officeClosedAutoReply"),
        MISSED_APPOINTMENT_FOLLOW_UP("missedAppointmentFollowUp"),
        RECALL_APPOINTMENT_REMINDER("recallAppointmentReminder"),
        AUTO_REQUEST_QUICK_SURVEY("autoRequestQuickSurvey"),
        FORM_SUBMISSION_EMAIL_ALERT("formSubmissionEmailAlert"),
        APPOINTMENT_REQUEST_EMAIL_ALERT("appointmentRequestEmailAlert"),
        AUTO_REQUEST_PAYMENT("autoRequestPayment"),
        NOTIFY_PAYMENT_SUCCESS("notifyPaymentSuccess"),
        BOOKING_FEE("bookingFee");

        private final String columnName;
    }
}
