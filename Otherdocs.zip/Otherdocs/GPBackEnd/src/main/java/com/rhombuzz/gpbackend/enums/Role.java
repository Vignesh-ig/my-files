package com.rhombuzz.gpbackend.enums;

public enum Role {
    ADMIN,
    MANAGEMENT,
    NORMAL_USER,
    SUPER_USER,
    RESTRICTED_USER
}
