package com.rhombuzz.gpbackend.modules.communication.service.patient.impl;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.event.model.generic.EmailCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.generic.SMSCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionEmailEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.submission.RequestSubmissionSMSEvent;
import com.rhombuzz.gpbackend.modules.communication.event.publisher.CommunicationEventPublisher;
import com.rhombuzz.gpbackend.modules.communication.event.publisher.RequestSubmissionsEventPublisher;
import com.rhombuzz.gpbackend.modules.communication.service.EmailTemplateService;
import com.rhombuzz.gpbackend.modules.communication.service.SMSTemplateService;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationService;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationValidator;
import com.rhombuzz.gpbackend.modules.communication.service.patient.TemplateProcessor;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;

@Slf4j
@Service
@RequiredArgsConstructor
public class PatientCommunicationServiceImpl implements PatientCommunicationService {

    private final SMSTemplateService smsTemplateService;
    private final PatientCommunicationValidator validator;
    private final TemplateProcessor templateProcessor;
    private final EmailTemplateService emailTemplateService;

    private final CommunicationEventPublisher communicationEventPublisher;
    private final RequestSubmissionsEventPublisher requestSubmissionsEventPublisher;

    @Override
    public void validateAndSendEmail(String groupId, Set<Long> patientIds, Appointment appointment, String templateId) {
        processEmailCommunication(
                groupId,
                patientIds,
                templateId,
                appointment,
                this::createEmailEvent,
                communicationEventPublisher::publishEmailEvent,
                "Email"
        );
    }

    @Override
    public void validateAndSendSMS(String groupId, Set<Long> patientIds, Appointment appointment, String templateId) {
        processSMSCommunication(
                groupId,
                patientIds,
                templateId,
                appointment,
                this::createSmsEvent,
                communicationEventPublisher::publishSMSEvent,
                "SMS"
        );
    }

    @Override
    public void validateAndRequestSubmissionViaEmail(String groupId, Set<@NotNull @Positive Long> patientIds, String templateId) {
        processEmailCommunication(
                groupId,
                patientIds,
                templateId,
                null,
                this::createRequestSubmissionEmailEvent,
                requestSubmissionsEventPublisher::publishRequestSubmissionEvent,
                "Request Submission Email"
        );
    }

    @Override
    public void validateAndRequestSubmissionViaSMS(String groupId, Set<@NotNull @Positive Long> patientIds, String templateId) {
        processSMSCommunication(
                groupId,
                patientIds,
                templateId,
                null,
                this::createRequestSubmissionSmsEvent,
                requestSubmissionsEventPublisher::publishRequestSubmissionEvents,
                "Request Submission SMS"
        );
    }

    private <E> void processEmailCommunication(
            String groupId,
            Set<Long> patientIds,
            String templateId,
            Appointment appointment,
            TriFunction<Patient, EmailTemplateResponse, String, E> eventCreator,
            Consumer<List<E>> eventPublisher,
            String communicationType) {

        log.info("Validating and sending {} for groupId: {}, templateId: {}, patientIds: {}",
                communicationType, groupId, templateId, patientIds);

        if (!validator.isCommunicationAllowed(groupId, templateId, ContactMethod.EMAIL)) {
            log.info("{} communication not allowed for groupId: {}, templateId: {}",
                    communicationType, groupId, templateId);
            return;
        }

        EmailTemplateResponse template = emailTemplateService.getEmailTemplate(templateId, groupId);

        List<E> events = patientIds.parallelStream()
                .map(patientId -> validator.getValidPatientForCommunication(
                        groupId, patientId, templateId, ContactMethod.EMAIL))
                .filter(Objects::nonNull)
                .map(patient -> {
                    String content = validator.getLocalizedContent(patient, template::getContent);
                    String processedContent = templateProcessor.processTemplate(patient, appointment, content);
                    return eventCreator.apply(patient, template, processedContent);
                })
                .toList();

        if (!events.isEmpty()) {
            log.info("Publishing {} events for groupId: {}, templateId: {}, patientIds: {}",
                    communicationType, groupId, templateId, patientIds);
            eventPublisher.accept(events);
        }
    }

    private <E> void processSMSCommunication(
            String groupId,
            Set<Long> patientIds,
            String templateId,
            Appointment appointment,
            TriFunction<Patient, SMSTemplateResponse, String, E> eventCreator,
            Consumer<List<E>> eventPublisher,
            String communicationType) {

        logCommunication("Validating and sending", communicationType, groupId, templateId, patientIds);

        if (!validator.isCommunicationAllowed(groupId, templateId, ContactMethod.SMS)) {
            logCommunication("Communication not allowed", communicationType, groupId, templateId, patientIds);
            return;
        }

        SMSTemplateResponse template = smsTemplateService.getSMSTemplate(templateId, groupId);

        List<E> events = patientIds.parallelStream()
                .map(patientId -> validator.getValidPatientForCommunication(
                        groupId, patientId, templateId, ContactMethod.SMS))
                .filter(Objects::nonNull)
                .map(patient -> {
                    String content = validator.getLocalizedContent(patient, template::getContent);
                    String processedContent = templateProcessor.processTemplate(patient, appointment, content);
                    return eventCreator.apply(patient, template, processedContent);
                })
                .toList();

        if (!events.isEmpty()) {
            logCommunication("Publishing events", communicationType, groupId, templateId, patientIds);
            eventPublisher.accept(events);
        }
    }

    @FunctionalInterface
    interface TriFunction<T, U, V, R> {
        R apply(T t, U u, V v);
    }

    private void logCommunication(String action, String communicationType, String groupId, String templateId, Set<Long> patientIds) {
        log.info("{} {} for groupId: {}, templateId: {}, patientIds: {}",
                action, communicationType, groupId, templateId, patientIds);
    }

    private EmailCommunicationEvent createEmailEvent(Patient patient, EmailTemplateResponse template, String processedContent) {
        return new EmailCommunicationEvent(
                patient.getMedGroup().getEmail(),
                patient.getEmail(),
                template.getSubject(),
                processedContent
        );
    }

    private SMSCommunicationEvent createSmsEvent(Patient patient, SMSTemplateResponse template, String processedContent) {
        return new SMSCommunicationEvent(
                patient.getMedGroup().getOfficePhone(),
                patient.getCellPhone(),
                processedContent
        );
    }

    private RequestSubmissionEmailEvent createRequestSubmissionEmailEvent(Patient patient, EmailTemplateResponse template, String processedContent) {
        return new RequestSubmissionEmailEvent(
                patient.getMedGroup().getGroupId(),
                patient.getId(),
                patient.getMedGroup().getEmail(),
                patient.getEmail(),
                template.getSubject(),
                processedContent
        );
    }

    private RequestSubmissionSMSEvent createRequestSubmissionSmsEvent(Patient patient, SMSTemplateResponse template, String processedContent) {
        return new RequestSubmissionSMSEvent(
                patient.getMedGroup().getGroupId(),
                patient.getId(),
                patient.getMedGroup().getOfficePhone(),
                patient.getCellPhone(),
                processedContent
        );
    }
}