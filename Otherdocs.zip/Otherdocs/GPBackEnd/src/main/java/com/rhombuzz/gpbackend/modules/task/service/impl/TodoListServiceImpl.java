package com.rhombuzz.gpbackend.modules.task.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.dto.request.SaveTodoListRequest;
import com.rhombuzz.gpbackend.modules.task.dto.response.TodoListResponse;
import com.rhombuzz.gpbackend.modules.task.entity.TodoList;
import com.rhombuzz.gpbackend.modules.task.repository.TodoListRepository;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.modules.task.service.TodoListService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class TodoListServiceImpl implements TodoListService {
    private static final String ACTIVITY_TYPE = "TODO";

    private final TodoListRepository todoListRepository;
    private final MedGroupService medGroupService;
    private final PatientService patientService;
    private final ActivityService activityService;

    @Override
    public void saveTodoList(SaveTodoListRequest request) {
        log.info("Saving todo list for group: {}", request.groupId());

        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        LocalDateTime dateTime = LocalDateTime.now(medGroup.getTimeZone().toZoneId());

        Patient patient = request.patientId() == null ? null :
                patientService.getPatientById(request.patientId(), request.groupId());

        Appointment appointment = request.appointmentId() == null ? null :
                Appointment.builder().id(request.appointmentId()).build(); //Todo: get from appointment service when module finished

        String username = Utils.getCurrentUsername();

        TodoList todoList = TodoList.fromRequest(request);
        todoList.setMedGroup(medGroup);
        todoList.setCreatedBy(username);
        todoList.setPatient(patient);
        todoList.setAppointment(appointment);
        todoList.setDateTime(dateTime);

        todoListRepository.save(todoList);
        log.info("Todo list saved successfully for group: {}", request.groupId());

        String description = String.format("A new sticky note has been created by user (%s) and it has been assigned to user (%s)",
                username, request.assignTo());
        saveActivity(request.groupId(), description, patient);
    }

    @Override
    @Transactional
    public Page<TodoListResponse> getTodoLists(String groupId, Pageable pageable) {
        log.info("Getting todo lists for group: {}", groupId);
        Page<TodoList> todoListPage = todoListRepository.findByGroupId(groupId, pageable);

        todoListRepository.updateReadTodoList(true, groupId);
        return todoListPage.map(TodoListResponse::fromEntity);
    }

    @Override
    public void deleteTodoList(Long id, String groupId) {
        log.info("Deleting todo list with id: {} for group: {}", id, groupId);
        TodoList todoList = getTodoList(id, groupId);

        todoList.setDeleted(true);

        todoListRepository.save(todoList);
        log.info("Todo list deleted successfully with id: {} for group: {}", id, groupId);

        String description = String.format("A sticky note has been deleted by user (%s)", Utils.getCurrentUsername());
        saveActivity(groupId, description, todoList.getPatient());
    }

    @Override
    public void reassignTodoList(Long id, String groupId, String assignTo) {
        log.info("Reassigning todo list with id: {} for group: {}", id, groupId);
        TodoList todoList = getTodoList(id, groupId);

        todoList.setAssignedTo(assignTo);

        todoListRepository.save(todoList);
        log.info("Todo list reassigned successfully with id: {} for group: {}", id, groupId);

        String description = String.format("The user (%s) has reassigned the sticky note to user (%s)",
                todoList.getCreatedBy(), assignTo);
        saveActivity(groupId, description, todoList.getPatient());
    }

    private void saveActivity(String groupId, String description, Patient patient) {
        ActivityRequest request = new ActivityRequest() {{
            setGroupId(groupId);
            setActivityDescription(description);
            setActivityType(ACTIVITY_TYPE);
            setPatient(patient);
        }};
        activityService.saveActivity(request);
    }

    private TodoList getTodoList(Long id, String groupId) {
        log.info("Getting todo list for id: {} and group: {}", id, groupId);
        return todoListRepository.findById(id, groupId)
                .orElseThrow(() -> {
                    log.error("Todo list not found with id: {} for group : {}", id, groupId);
                    return new NotFoundException("Todo list not found");
                });
    }
}
