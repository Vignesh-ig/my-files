package com.rhombuzz.gpbackend.modules.medgroup.service;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.OfficeClosureRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.OfficeClosureResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
public interface OfficeClosureService {

    void saveOfficeClosure(
            @Valid OfficeClosureRequest request
    );

    List<OfficeClosureResponse> getOfficeClosures(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateOfficeClosure(
            @NotNull @Positive Long id,
            @Valid OfficeClosureRequest request
    );

    @Transactional
    void deleteOfficeClosure(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

}
