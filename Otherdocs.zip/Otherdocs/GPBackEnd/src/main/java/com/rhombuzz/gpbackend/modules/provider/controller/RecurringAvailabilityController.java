package com.rhombuzz.gpbackend.modules.provider.controller;

import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveRecurringAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.RecurringAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.service.RecurringAvailabilityService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/recurring-availabilities")
@Validated
@PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
public class RecurringAvailabilityController {
    private final RecurringAvailabilityService recurringAvailabilityService;

    @GetMapping("/providers/{providerId}")
    public ResponseEntity<Map<DayOfWeek, List<RecurringAvailabilityResponse>>> getRecurringAvailabilities(
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Map<DayOfWeek, List<RecurringAvailabilityResponse>> recurringAvailabilities =
                recurringAvailabilityService.getRecurringAvailabilities(providerId, groupId);
        return ResponseEntity.ok(recurringAvailabilities);
    }

    @PostMapping
    public ResponseEntity<Void> saveRecurringAvailability(@RequestBody @Valid SaveRecurringAvailabilityRequest request) {
        recurringAvailabilityService.saveRecurringAvailability(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{id}/providers/{providerId}")
    public ResponseEntity<Void> deleteRecurringAvailability(
            @PathVariable @NotNull Long id,
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotNull Long locationId
    ) {
        recurringAvailabilityService.deleteRecurringAvailability(id, providerId, locationId, groupId);
        return ResponseEntity.noContent().build();
    }

}
