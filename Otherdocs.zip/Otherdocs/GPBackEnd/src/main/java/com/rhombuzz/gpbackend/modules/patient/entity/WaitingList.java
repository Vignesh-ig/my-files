package com.rhombuzz.gpbackend.modules.patient.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.dto.request.WaitingListRequest;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "waiting_lists", indexes = {
        @Index(name = "idx_waiting_list_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_waiting_list_location_id", columnList = "location_id"),
        @Index(name = "idx_waiting_list_provider_id", columnList = "provider_id"),
        @Index(name = "idx_waiting_list_service_id", columnList = "service_id"),
        @Index(name = "idx_waiting_list_patient_id", columnList = "patient_id"),
})
public class WaitingList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "provider_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Provider provider;

    @ManyToOne
    @JoinColumn(name = "location_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Location location;

    @ManyToOne
    @JoinColumn(name = "service_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Service service;

    @Column(name = "date", nullable = false)
    private LocalDate date;

    @Column(name = "wait_list_type", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private Type waitlistType;

    @Column(name = "wait_list_flag")
    private boolean waitListFlag; //Todo: Need to check.

    @Column(name = "alert_sent")
    private int alertSent;

    public static WaitingList fromRequest(WaitingListRequest request) {
        return WaitingList.builder()
                .waitlistType(request.waitlistType())
                .date(request.date())
                .build();
    }

    public enum Type {

        ASAP,
        SPECIFIC
    }
}
