package com.rhombuzz.gpbackend.modules.medgroup.dto;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class ServiceDTO {

    private Long id;
    private String name;

    public static ServiceDTO fromEntity(Service service) {
        return ServiceDTO.builder()
                .id(service.getId())
                .name(service.getServiceName())
                .build();
    }

}
