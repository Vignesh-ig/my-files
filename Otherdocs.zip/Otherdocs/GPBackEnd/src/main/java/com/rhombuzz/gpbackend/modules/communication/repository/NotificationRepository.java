package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface NotificationRepository extends JpaRepository<Notification, Long> {

    @Query("SELECT COUNT(n) > 0 FROM Notification n WHERE n.priority = ?1 AND n.isHidden = false")
    boolean existsByPriority(Notification.Priority priority);

    @Query("SELECT n FROM Notification n WHERE n.medGroup.groupId = ?1 AND n.isHidden = false ORDER BY n.dateTime DESC")
    List<Notification> findByGroupId(String groupId);

    @Modifying
    @Query("UPDATE Notification n SET n.isSeen = ?1 WHERE n.medGroup.groupId = ?2 AND n.isHidden = false")
    void updateSeenNotification(boolean isSeen, String groupId);

    @Query("SELECT n FROM Notification n ORDER BY n.dateTime DESC")
    List<Notification> findNotifications();

    @Query("SELECT n FROM Notification n WHERE n.id = ?1 AND n.medGroup.groupId = ?2")
    Optional<Notification> findById(Long id, String groupId);

    @Query("SELECT COUNT(n) FROM Notification n WHERE n.medGroup.groupId = ?1 AND n.isSeen = false AND n.isHidden = false")
    long countByGroupId(String groupId);
}
