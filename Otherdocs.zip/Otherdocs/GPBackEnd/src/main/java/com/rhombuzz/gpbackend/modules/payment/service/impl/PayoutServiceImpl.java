package com.rhombuzz.gpbackend.modules.payment.service.impl;

import com.rhombuzz.gpbackend.modules.payment.service.PayoutService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PayoutServiceImpl implements PayoutService {
}
