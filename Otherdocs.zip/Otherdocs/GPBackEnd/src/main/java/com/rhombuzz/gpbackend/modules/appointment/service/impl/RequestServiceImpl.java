package com.rhombuzz.gpbackend.modules.appointment.service.impl;

import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.modules.appointment.dto.request.PendingRequestFilter;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.PendingRequestResponse;
import com.rhombuzz.gpbackend.modules.appointment.repository.AppointmentRepository;
import com.rhombuzz.gpbackend.modules.appointment.repository.specification.PendingRequestSpecification;
import com.rhombuzz.gpbackend.modules.appointment.service.RequestService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Slf4j
public class RequestServiceImpl implements RequestService {
    private final AppointmentRepository appointmentRepository;
    private final MedGroupService medGroupService;

    @Override
    public Page<PendingRequestResponse> getPendingRequests(String groupId, PendingRequestFilter filter, Pageable pageable) {
        log.info("Fetching pending requests for groupId: {}", groupId);
        if (validateFilters(filter)) {
            throw new BadRequestException("Filters must have corresponding IDs set");
        }

        LocalDate currentDate = medGroupService.getCurrentDateTime(groupId).toLocalDate();
        return appointmentRepository.findBy(
                PendingRequestSpecification.defaultSpecification(currentDate)
                        .and(PendingRequestSpecification.hasGroupId(groupId))
                        .and(PendingRequestSpecification.hasFilter(filter)),
                q -> q.as(PendingRequestResponse.class)
                        .page(pageable)
        );
    }

    private boolean validateFilters(PendingRequestFilter filter) {
        if (filter == null) {
            return false;
        }

        if (filter.getFilters() == null || filter.getFilters().isEmpty()) {
            return false;
        }

        Set<PendingRequestFilter.FilterType> filters = filter.getFilters();
        return filters.contains(PendingRequestFilter.FilterType.PROVIDER) && filter.getProviderId() == null ||
               filters.contains(PendingRequestFilter.FilterType.LOCATION) && filter.getLocationId() == null ||
               filters.contains(PendingRequestFilter.FilterType.SERVICE) && filter.getServiceId() == null;
    }
}
