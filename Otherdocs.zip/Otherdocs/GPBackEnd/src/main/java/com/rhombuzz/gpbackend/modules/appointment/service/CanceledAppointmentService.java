package com.rhombuzz.gpbackend.modules.appointment.service;

import com.rhombuzz.gpbackend.modules.appointment.dto.request.SaveCanceledAppointmentRequest;

public interface CanceledAppointmentService {

    void saveCanceledAppointment(SaveCanceledAppointmentRequest request);

}
