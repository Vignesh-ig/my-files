package com.rhombuzz.gpbackend.modules.patient.dto.request;

import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public record SavePatientRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Patient ID cannot be blank")
        @Size(max = 45, message = "Patient first name must be at most 45 characters long")
        @Pattern(regexp = RegexPattern.NAME, message = "Patient ID must contain only letters")
        String firstName,

        @NotBlank(message = "Last Name cannot be blank")
        @Size(max = 45, message = "Patient last name must be at most 45 characters long")
        @Pattern(regexp = RegexPattern.NAME, message = "Last Name must contain only letters")
        String lastName,

        @NotNull(message = "Date of Birth cannot be null")
        @PastOrPresent(message = "Date of Birth must be in the past or present")
        LocalDate dob,

        @NotNull(message = "Gender cannot be null")
        Gender gender,

        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone number must be exactly 10 digits")
        String homePhone,

        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone number must be exactly 10 digits")
        @NotBlank(message = "Cell Phone number cannot be blank")
        String cellPhone,

        @NotNull(message = "Email cannot be null")
        @Email(message = "Email should be valid")
        @Size(max = 45, message = "Email must be at most 45 characters long")
        String email,

        @Pattern(regexp = RegexPattern.FIVE_DIGITS, message = "Zip Code must be exactly 5 digits")
        String zipCode,

        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "City must contain only letters and spaces")
        @Size(max = 45, message = "City must be at most 45 characters long")
        String city,

        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "State must contain only letters and spaces")
        @Size(max = 45, message = "State must be at most 45 characters long")
        String state,

        @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Work Phone number must be exactly 10 digits")
        String workPhone,

        @Pattern(regexp = RegexPattern.NO_WHITESPACE, message = "Patient Reference Number cannot contain whitespace")
        String patientReferenceNumber,

        @Pattern(regexp = RegexPattern.DIGITS, message = "SSN must contain only digits")
        @Size(max = 9, message = "SSN must be at most 9 characters long")
        String ssn,

        @Size(max = 200, message = "Street Address must be at most 200 characters long")
        String streetAddress,

        @Size(max = 45, message = "Preferred First Name must be at most 45 characters long")
        String preferredFirstName,

        PreferredLanguage preferredLanguage
) {
}
