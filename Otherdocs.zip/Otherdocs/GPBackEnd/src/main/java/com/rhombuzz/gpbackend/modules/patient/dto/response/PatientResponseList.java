package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.rhombuzz.gpbackend.enums.Gender;

import java.time.LocalDate;

public interface PatientResponseList {

    Long getId();
    String getFirstName();
    String getLastName();
    String getCellPhone();
    LocalDate getDob();
    String getHomePhone();
    Gender getGender();

}
