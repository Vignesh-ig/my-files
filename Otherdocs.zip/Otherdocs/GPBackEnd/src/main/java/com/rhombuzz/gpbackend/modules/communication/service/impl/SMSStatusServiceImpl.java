package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSStatusRequest;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSStatus;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.MessageStatus;
import com.rhombuzz.gpbackend.modules.communication.repository.SMSStatusRepository;
import com.rhombuzz.gpbackend.modules.communication.service.SMSStatusService;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
@Slf4j
public class SMSStatusServiceImpl implements SMSStatusService {
    private static final int INVALID_NUMBER_ERROR_CODE = 50;

    private final MedGroupService medGroupService;
    private final PatientService patientService;
    private final SMSStatusRepository smsStatusRepository;
    private final ActivityService activityService;

    @Override
    public void saveSMSStatus(SMSStatusRequest request) {

        String fromNumber = request.getFrom().substring(1);
        String toNumber = request.getTo().substring(1);
        String messageUUID = request.getMessageUUID();
        MessageStatus status = MessageStatus.fromString(request.getStatus());

        MedGroup medGroup = getMedGroup(fromNumber);
        Patient patient = patientService.getPatientByPhone(toNumber, medGroup.getGroupId());
        LocalDate smsDate = LocalDate.now(medGroup.getTimeZone().toZoneId());

        SMSStatus smsStatus = new SMSStatus();
        smsStatus.setMedGroup(medGroup);
        smsStatus.setPatient(patient);
        smsStatus.setSmsDate(smsDate);
        smsStatus.setMessageStatus(status);
        smsStatus.setMessageUUID(messageUUID);
        smsStatusRepository.save(smsStatus);

        switch (status) {
            case DELIVERED -> handleDeliveredStatus(patient, medGroup);
            case UNDELIVERED, FAILED -> handleFailedStatus(request, medGroup, patient, messageUUID);
            case null, default -> log.warn("Unhandled SMS status: {}", status);
        }
    }

    private void handleDeliveredStatus(Patient patient, MedGroup medGroup) {
        patientService.updatePhoneValid(patient.getId(), medGroup.getGroupId(), true);
    }

    private void handleFailedStatus(SMSStatusRequest request, MedGroup medGroup, Patient patient, String messageUUID) {
        String message = "smsService.getMessageByUUID(messageUUID);";
        saveToActivity(medGroup.getGroupId(), patient, messageUUID, message, request.getErrorCode());

        if (request.getErrorCode() != null && request.getErrorCode() == INVALID_NUMBER_ERROR_CODE) {
            patientService.updatePhoneValid(patient.getId(), medGroup.getGroupId(), false);
        }
    }

    private void saveToActivity(String groupId, Patient patient, String messageUUID, String message, Integer errorCode) {
        String description = String.format("Error! SMS UUID: %s could not be delivered. Error code is: %d To view the message, " +
                        "click here (<a href='javascript:;' id='viewCommButton' class='viewCommMsg'>View</a>)",
                messageUUID, errorCode);

        ActivityRequest request = new ActivityRequest() {{
            setGroupId(groupId);
            setPatient(patient);
            setActivityType("SMS");
            setActivityDescription(description);
            setContent(message);
        }};

        activityService.saveActivity(request);
    }

    private MedGroup getMedGroup(String fromNumber) {
        return medGroupService.getMedGroups().stream()
                .filter(m -> m.getEmsPhone().equals(fromNumber))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("MedGroup not found"));
    }

}
