package com.rhombuzz.gpbackend.integration.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.integration.dto.request.SaveIntegrationConfigRequest;
import com.rhombuzz.gpbackend.integration.entity.IntegrationConfig;
import com.rhombuzz.gpbackend.integration.repository.IntegrationConfigRepository;
import com.rhombuzz.gpbackend.integration.service.IntegrationConfigService;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class IntegrationConfigServiceImpl implements IntegrationConfigService {
    private final IntegrationConfigRepository integrationConfigRepository;
    private final MedGroupService medGroupService;

    @Override
    public void saveIntegrationConfig(SaveIntegrationConfigRequest request) {

        integrationConfigRepository.getIntegrationConfig(request)
                .ifPresentOrElse(
                        config -> {
                            log.info("Updating existing integration config: {}", request);
                            config.setConfigValue(request.configValue());
                            integrationConfigRepository.save(config);
                        },
                        () -> {
                            log.info("Creating new integration config: {}", request);
                            IntegrationConfig newConfig = buildNewIntegrationConfig(request);
                            integrationConfigRepository.save(newConfig);
                        }
                );


    }

    @Override
    public String getConfigValue(String groupId, String configName, String integratesWith) {

        log.info("Fetching config value for groupId: {}, configName: {}, integratesWith: {}",
                groupId, configName, integratesWith);
        return integrationConfigRepository.getConfigValue(groupId, configName, integratesWith)
                .orElseThrow(() -> {
                    log.error("Configuration not found for groupId: {}, configName: {}, integratesWith: {}",
                            groupId, configName, integratesWith);
                    return new NotFoundException("Configuration not found");
                });

    }

    private IntegrationConfig buildNewIntegrationConfig(SaveIntegrationConfigRequest request) {
        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        IntegrationConfig config = new IntegrationConfig();
        config.setConfigName(request.configName());
        config.setConfigValue(request.configValue());
        config.setIntegratesWith(request.integratesWith());
        config.setMedGroup(medGroup);
        return config;
    }
}
