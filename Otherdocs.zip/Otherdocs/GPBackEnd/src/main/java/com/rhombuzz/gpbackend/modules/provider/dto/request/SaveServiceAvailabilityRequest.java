package com.rhombuzz.gpbackend.modules.provider.dto.request;

import com.rhombuzz.gpbackend.modules.provider.dto.ServiceAvailabilityDTO;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.time.DayOfWeek;
import java.util.List;

public record SaveServiceAvailabilityRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Provider ID cannot be null")
        @Positive(message = "Provider ID must be a positive number")
        Long providerId,

        @NotEmpty(message = "Service availability list cannot be empty")
        List<@NotNull(message = "Service availability cannot be null")
        @Valid ServiceAvailabilityDTO> serviceAvailabilities,

        @NotNull(message = "Day of week cannot be null")
        DayOfWeek dayOfWeek
) {
}
