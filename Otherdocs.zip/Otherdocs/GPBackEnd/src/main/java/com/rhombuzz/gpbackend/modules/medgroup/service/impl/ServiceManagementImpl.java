package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveServiceRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.UpdateServiceRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.ServiceResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.medgroup.repository.ServiceRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.medgroup.service.ServiceManagement;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

@org.springframework.stereotype.Service
@RequiredArgsConstructor
@Slf4j
public class ServiceManagementImpl implements ServiceManagement {
    private static final String ACTIVITY_TYPE = "MANAGE SERVICE";

    private final ServiceRepository serviceRepository;
    private final MedGroupService medGroupService;
    private final EntityManager entityManager;
    private final ActivityService activityService;

    @Override
    public void saveService(SaveServiceRequest request) {
        log.info("saveService: called for groupId='{}'", request.groupId());
        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());

        validateRecallReminder(request.recall(), request.recallPeriod());

        if (serviceRepository.isServiceExist(request.serviceName(), request.groupId())) {
            log.error("saveService: Service already exists with service name='{}'", request.serviceName());
            throw new ConflictException("Service already exists");
        }

        Service service = Service.fromRequest(request);
        service.setMedGroup(medGroup);
        service.setCreatedBy("user");

        serviceRepository.save(service);
        log.info("A new service (ID: {}) has been created", service.getId());

        String description = String.format("The user (%s) created a new service %s.",
                Utils.getCurrentUsername(), request.serviceName());
        saveActivity(request.groupId(), description);
    }

    @Override
    public void updateService(Long id, UpdateServiceRequest request) {
        log.info("updateService: called for groupId='{}', serviceId='{}'", request.groupId(), id);
        validateRecallReminder(request.recall(), request.recallPeriod());

        Service service = getServiceEntity(id, request.groupId());
        setService(service, request);

        serviceRepository.save(service);
        log.info("Service updated successfully: serviceId='{}'", id);

        String description = String.format("The user (%s) updated the service %s.",
                Utils.getCurrentUsername(), service.getServiceName());
        saveActivity(request.groupId(), description);
    }

    @Override
    @Transactional
    public void deleteService(Long id, String groupId) {
        log.info("Deleting Service with id {}", id);

        String sql = "DELETE sa FROM service_availabilities sa JOIN service_availability_services sas ON " +
                "sa.id = sas.service_availability_id WHERE sas.service_id = ?1";

        entityManager.createNativeQuery(sql)
                .setParameter(1, id)
                .executeUpdate();

        Service service = getServiceEntity(id, groupId);
        serviceRepository.delete(service);
        log.info("Service deleted successfully");

        String description = String.format("The user (%s) deleted the service %s.",
                Utils.getCurrentUsername(), service.getServiceName());
        saveActivity(groupId, description);
    }

    @Override
    public Page<ServiceResponse> getServices(String groupId, Pageable pageable) {
        log.info("Retrieving services for groupId: {}", groupId);
        return serviceRepository.findByGroupId(groupId, pageable);
    }

    @Override
    public Service getServiceEntity(Long id, String groupId) {
        log.info("Fetching service entity by id: {}", id);
        return serviceRepository.findById(id, groupId)
                .orElseThrow(() -> {
                    log.error("Service not found with id: {}", id);
                    return new NotFoundException("Service not found");
                });
    }

    @Override
    public boolean isServiceExists(Long serviceId, String groupId) {
        log.info("Checking if service exists with id: {}", serviceId);
        return serviceRepository.existsById(serviceId, groupId);
    }

    @Override
    public List<ServiceDTO> getServiceNamesByIds(List<Long> serviceIds, String groupId) {
        log.info("Fetching service names for IDs: {}", serviceIds);
        return serviceRepository.findServiceNamesByIds(serviceIds, groupId);
    }

    private void saveActivity(String groupId, String description) {
        ActivityRequest request = new ActivityRequest(groupId, ACTIVITY_TYPE, description, null, null, null);
        activityService.saveActivity(request);
    }

    private void validateRecallReminder(boolean isRecall, Integer recallPeriod) {
        if (isRecall && recallPeriod == null) {
            log.error("Recall period is required when recall reminder is enabled");
            throw new BadRequestException("Recall period is required when recall reminder is enabled");
        }
    }

    private void setService(Service service, UpdateServiceRequest request) {
        service.setReference(request.serviceReference());
        service.setDuration(request.duration());
        service.setRecall(request.recall());
        service.setRecallPeriod(request.recallPeriod());
        service.setBookingFeeAmount(request.bookingFeeAmount());
        service.setColorCode(request.colorCode());
        service.setVisibleToPatient(request.visibleToPatient());
        service.setAllowReminder(request.allowReminder());
        service.setVisitType(request.visitType());
    }
}
