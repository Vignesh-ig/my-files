package com.rhombuzz.gpbackend.modules.communication.event.publisher.impl;

import com.rhombuzz.gpbackend.modules.communication.event.model.generic.EmailCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.generic.SMSCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.event.publisher.CommunicationEventPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class CommunicationEventPublisherImpl implements CommunicationEventPublisher {
    private final ApplicationEventPublisher eventPublisher;

    @Override
    public void publishSMSEvent(SMSCommunicationEvent event) {
        eventPublisher.publishEvent(event);
    }

    @Override
    public void publishEmailEvent(EmailCommunicationEvent event) {
        eventPublisher.publishEvent(event);
    }

    @Override
    public void publishEmailEvent(List<EmailCommunicationEvent> events) {
        events.forEach(eventPublisher::publishEvent);
    }

    @Override
    public void publishSMSEvent(List<SMSCommunicationEvent> events) {
        events.forEach(eventPublisher::publishEvent);
    }
}
