package com.rhombuzz.gpbackend.modules.patient.service;

import com.rhombuzz.gpbackend.modules.patient.dto.request.WaitingListRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.WaitingListResponse;
import com.rhombuzz.gpbackend.modules.patient.entity.WaitingList;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

@Validated
public interface WaitingListService {

    void saveWaitingList(
            @Valid WaitingListRequest request
    );

    void updateWaitingList(
            @Valid WaitingListRequest request
    );

    @Transactional
    void deleteWaitingList(
            @NotNull @Positive Long id,
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Page<WaitingListResponse> getWaitingLists(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    );

    WaitingList getWaitingList(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    boolean checkWaitingListExist(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateAlertSent(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

}
