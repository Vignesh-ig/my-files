package com.rhombuzz.gpbackend.modules.provider.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import lombok.Data;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

@Data
public class ServiceAvailabilityResponse {

    List<ServiceDTO> services;
    LocationDTO location;
    private Long id;
    private ProviderDTO provider;
    private LocalTime startTime;
    private LocalTime endTime;

    @JsonIgnore
    private DayOfWeek day;
    @JsonIgnore
    private String serviceIds;

    public ServiceAvailabilityResponse(Long id,
                                       java.sql.Time startTime,
                                       java.sql.Time endTime,
                                       String day,
                                       Long providerId,
                                       String providerName,
                                       Long locationId,
                                       String locationName,
                                       String serviceIds) {
        this.id = id;
        this.startTime = startTime.toLocalTime();
        this.endTime = endTime.toLocalTime();
        this.day = DayOfWeek.valueOf(day.toUpperCase());
        this.provider = new ProviderDTO(providerId, providerName);
        this.location = new LocationDTO(locationId, locationName);
        this.serviceIds = serviceIds;
    }



}
