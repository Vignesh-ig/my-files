package com.rhombuzz.gpbackend.modules.communication.service.patient.impl;

import com.rhombuzz.gpbackend.enums.Placeholder;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.api.dto.request.GetConfigValueRequest;
import com.rhombuzz.gpbackend.modules.api.service.ConfigService;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.communication.service.patient.TemplateProcessor;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.CustomizationService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
@Slf4j
public class TemplateProcessorImpl implements TemplateProcessor {

    private final ConfigService configService;
    private final CustomizationService customizationService;

    @Override
    public String processTemplate(Patient patient, Appointment appointment, String templateContent) {

        Set<String> placeholders = getTemplatePlaceholders(templateContent);
        log.info("Template placeholders: {}", placeholders);

        if (placeholders.isEmpty()) {
            return templateContent;
        }

        Map<String, String> placeholderValues = getPlaceholderValues(placeholders, patient, appointment);
        log.info("Placeholder values: {}", placeholderValues);

        return replacePlaceholders(placeholders, placeholderValues, templateContent);
    }

    private String replacePlaceholders(Set<String> placeholders, Map<String, String> values, String templateContent) {
        String result = templateContent;
        for (String ph : placeholders) {
            if (values.containsKey(ph)) {
                result = result.replace("{{" + ph + "}}", values.get(ph));
            }
        }
        return result;
    }

    private Set<String> getTemplatePlaceholders(String template) {
        Set<String> placeholders = new HashSet<>();
        Pattern pattern = Pattern.compile("\\{\\{(\\w+)}}");
        Matcher matcher = pattern.matcher(template);

        while (matcher.find()) {
            placeholders.add(matcher.group(1));
        }

        return placeholders;
    }

    private Map<String, String> getPlaceholderValues(Set<String> placeholders, Patient patient, Appointment appointment) {
        MedGroup medGroup = patient.getMedGroup();

        String serverURL = configService.getConfigValue(new GetConfigValueRequest("SERVER_URL", "GENERAL"))
                .orElseThrow(() -> new NotFoundException("Server URL not configured"));
        String formPacketLink = customizationService.getCustomization(medGroup.getGroupId()).getFormsPacketLink();

        formPacketLink = formPacketLink.replace("{{GroupId}}", medGroup.getGroupId());
        formPacketLink = formPacketLink.replace("{{ServerURL}}", serverURL);

        String finalFormPacketLink = formPacketLink;

        Map<String, String> values = new HashMap<>();
        for (String ph : placeholders) {
            Placeholder placeholder = Placeholder.fromKey(ph);
            String value = getValue(placeholder, patient, medGroup, appointment, serverURL, finalFormPacketLink);
            log.debug("Value for placeholder {}: {}", placeholder, value);
            values.put(placeholder.getKey(), value);
        }
        return values;
    }

    private String getValue(Placeholder placeholder,
                            Patient patient, MedGroup medGroup, Appointment appointment,
                            String serverURL, String formPacketLink) {

        return switch (placeholder) {

            case FIRST_NAME -> patient.getPreferredFirstName() != null
                    ? patient.getPreferredFirstName() : patient.getFirstName();
            case LAST_NAME -> patient.getLastName() != null ? patient.getLastName() : "";
            case OFFICE_NAME -> medGroup != null ? medGroup.getGroupName() : "";
            case OFFICE_ADDRESS -> medGroup != null ? medGroup.getDefaultAddress() : "";
            case OFFICE_PHONE -> medGroup != null ? medGroup.getOfficePhone() : "";

            case FORM_PACKET_LINK -> formPacketLink != null ? formPacketLink : "";

            case SERVER_URL -> serverURL != null ? serverURL : "";
            case APPOINTMENT_PROVIDER_NAME -> appointment != null && appointment.getProvider() != null
                    ? appointment.getProvider().getName() : "";
            case APPOINTMENT_DATE -> appointment != null ? appointment.getScheduledDate().toString() : "";
            case APPOINTMENT_TIME -> appointment != null ? appointment.getScheduledTime().toString() : "";
            case MEETING_LINK -> appointment != null ? appointment.getTelehealthMeetingUrl() : "";

        };
    }
}
