package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.plivo.api.exceptions.PlivoRestException;
import com.plivo.api.exceptions.PlivoValidationException;
import com.plivo.api.models.message.Message;
import com.plivo.api.models.message.MessageCreateResponse;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.api.dto.request.GetConfigValueRequest;
import com.rhombuzz.gpbackend.modules.api.service.ConfigService;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSSendRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSSendResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.MessageStatus;
import com.rhombuzz.gpbackend.modules.communication.service.SMSService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.util.Collections;

@Slf4j
@Service
@RequiredArgsConstructor
public class SMSServiceImpl implements SMSService {
    private final ConfigService configService;

    @Override
    public SMSSendResponse sendSMS(SMSSendRequest smsSendRequest) {
        log.info("Send SMS method called");
        String serverUrl = configService.getConfigValue(new GetConfigValueRequest("SERVER_URL", "GENERAL"))
                .orElseThrow(() -> new NotFoundException("Server URL not configured"));

        String statusDeliveryUrl = serverUrl + "/api/v1/sms-status";

        String fromNumber = builCellPhone(smsSendRequest.fromNumber());
        String toNumber = builCellPhone(smsSendRequest.toNumber());

        MessageCreateResponse response;

        try {
            response = Message.creator(
                    fromNumber,
                    Collections.singletonList(toNumber),
                    smsSendRequest.message()
            ).url(URI.create(statusDeliveryUrl).toURL()).create();
            String messageUuid = response.getMessageUuid().getFirst();

            if (messageUuid != null) {
                Message statusResponse = Message.getter(messageUuid).get();
                String sentStatus = statusResponse.getMessageState();
                log.info("SMS sent with UUID: {}, Status: {}", messageUuid, sentStatus);
                if (sentStatus != null &&
                        MessageStatus.fromString(sentStatus) == MessageStatus.SENT ||
                        MessageStatus.fromString(sentStatus) == MessageStatus.DELIVERED ||
                        MessageStatus.fromString(sentStatus) == MessageStatus.QUEUED
                ) {
                    return new SMSSendResponse(true, messageUuid);
                } else {
                    return new SMSSendResponse(false, null);
                }
            }
        } catch (IOException | PlivoRestException | PlivoValidationException e) {
            log.error("Error sending SMS: {}", e.getMessage());
            return new SMSSendResponse(false, null);
        }
        return new SMSSendResponse(false, null);
    }

    private String builCellPhone(String number) {
        return (number != null && !number.trim().isEmpty() && number.length() == 10) ? "1" + number : number;
    }

}
