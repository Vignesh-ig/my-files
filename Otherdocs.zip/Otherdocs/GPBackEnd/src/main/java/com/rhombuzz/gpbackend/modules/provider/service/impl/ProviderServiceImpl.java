package com.rhombuzz.gpbackend.modules.provider.service.impl;

import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveBookingTypeRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveProviderRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.UpdateProviderRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.BookingTypeResponse;
import com.rhombuzz.gpbackend.modules.provider.dto.response.ProviderResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.provider.repository.ProviderRepository;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProviderServiceImpl implements ProviderService {
    private final ProviderRepository providerRepository;
    private final MedGroupService medGroupService;

    @Override
    public void saveProvider(SaveProviderRequest request, MultipartFile image) {
        String providerFullName = String.format("%s %s", request.firstName(), request.lastName());
        Provider provider = buildProvider(request, providerFullName, image);
        if (providerRepository.existsByName(providerFullName, request.groupId())) {
            log.error("Provider {} already exists for group {}", providerFullName, request.groupId());
            throw new ConflictException("Provider already exists");
        }
        providerRepository.save(provider);
        log.info("A new provider has been created: {}", providerFullName);
    }

    @Override
    public void updateProvider(Long id, UpdateProviderRequest request, MultipartFile image) {

        log.info("Updating provider with id {}", id);
        Provider provider = getProviderById(id, request.groupId());

        setProvider(provider, request, image);
        providerRepository.save(provider);
        log.info("Provider updated successfully");
    }

    @Override
    public Page<ProviderResponse> getProviders(String groupId, Pageable pageable) {
        log.info("Fetching all providers for groupId: {}", groupId);
        return providerRepository.findByGroupId(groupId, pageable);
    }

    @Override
    public Provider getProviderById(Long providerId, String groupId) {
        log.info("Retrieving provider details for providerId: {}", providerId);
        return providerRepository.findById(providerId, groupId)
                .orElseThrow(() -> {
                    log.error("getProviderById: Provider not found with id {}", providerId);
                    return new NotFoundException("getProviderById: Provider not found");
                });
    }

    @Override
    @Transactional
    public void deleteProvider(Long providerId, String groupId) {
        log.info("Archiving provider with id {}", providerId);
        Provider provider = getProviderById(providerId, groupId);

        provider.setActive(false);
        providerRepository.save(provider);
        log.info("Provider Archived successfully");
    }

    @Override
    public Map<String, Object> getProviderImage(Long providerId, String groupId) {
        log.info("Getting Provider image with Id {}: ", providerId);
        Provider provider = getProviderById(providerId, groupId);

        byte[] imageBytes = provider.getImage();
        String imageName = provider.getImageName();

        if (imageBytes == null) {
            log.warn("No image found for provider with id {}", providerId);
            return null;
        }

        return Map.of(
                "imageName", imageName,
                "base64Image", Base64.getEncoder().encodeToString(imageBytes)
        );
    }

    @Override
    public List<ProviderDTO> getProviderNames(String groupId) {
        log.info("Getting all providers for groupId: {}", groupId);
        return providerRepository.findByGroupId(groupId);
    }

    @Override
    public void updateDefaultApptDuration(Long providerId, String groupId, Integer defaultApptDuration) {
        log.info("Updating default appointment duration for provider with id {} for group {}", providerId, groupId);
        Provider provider = getProviderById(providerId, groupId);
        provider.setDefaultApptDuration(defaultApptDuration);

        providerRepository.save(provider);
        log.info("Default appointment duration updated successfully");
    }

    @Override
    public Integer getDefaultApptDuration(String groupId, Long providerId) {
        log.info("Getting default appointment duration for provider with id {} in group {}", providerId, groupId);
        return providerRepository.findDefaultApptDuration(providerId, groupId)
                .orElseThrow(() -> {
                    log.error("getDefaultApptDuration: Provider not found with id {}", providerId);
                    return new NotFoundException("getDefaultApptDuration: Provider not found");
                });
    }

    @Override
    public boolean isProviderExists(Long id, String groupId) {
        log.info("Checking existence of provider with id {} in group {}", id, groupId);
        return providerRepository.existsById(id, groupId);
    }

    @Override
    public BookingTypeResponse getBookingTypeDetails(Long id, String groupId) {
        log.info("Getting booking type details for provider with id {} in group {}", id, groupId);
        return providerRepository.findBookingTypeDetailsByIdAndGroupId(id, groupId)
                .orElseThrow(() -> {
                    log.error("getBookingTypeDetails: Provider not found with id {}", id);
                    return new NotFoundException("getBookingTypeDetails: Provider not found");
                });
    }

    @Transactional
    @Override
    public void updateBookingTypeDetails(Long id, SaveBookingTypeRequest request) {
        log.info("Updating booking type details for provider with id {} for group {}", id, request.groupId());
        LocalDateTime updatedAt = medGroupService.getCurrentDateTime(request.groupId());

        if(!providerRepository.existsById(id, request.groupId())) {
            log.error("updateBookingTypeDetails: Provider not found with id {}", id);
            throw new NotFoundException("updateBookingTypeDetails: Provider not found");
        }
        providerRepository.updateBookingTypeDetailsByIdAndGroupId(
                id,
                request.groupId(),
                request.bookingType(),
                request.bookingPerSlot().orElse(0),
                request.bookingPerDay(),
                updatedAt
        );
    }

    private Provider buildProvider(SaveProviderRequest request, String providerFullName, MultipartFile image) {
        MedGroup medgroup = new MedGroup(request.groupId());
        medgroup.setTimeZone(medGroupService.getTimezone(request.groupId()));

        Provider provider = Provider.builder()
                .medGroup(medgroup)
                .order(request.order())
                .prefix(request.prefix())
                .name(providerFullName)
                .suffix(request.suffix())
                .specialist(request.specialist())
                .reference(request.reference())
                .email(request.email())
                .cellPhone(request.cellPhone())
                .preferredContactMethod(request.preferredContactMethod())
                .build();

        setImageForProvider(image, provider);
        return provider;
    }

    private void setProvider(Provider provider, UpdateProviderRequest request, MultipartFile image) {
        provider.setPrefix(request.prefix());
        provider.setSuffix(request.suffix());
        provider.setReference(request.reference());
        provider.setEmail(request.email());
        provider.setCellPhone(request.cellPhone());
        provider.setPreferredContactMethod(request.preferredContactMethod());
        setImageForProvider(image, provider);
    }

    private void setImageForProvider(MultipartFile image, Provider provider) {
        if (image != null) {
            try {
                provider.setImage(image.getBytes());
                provider.setImageName(provider.getName() + "-image");
            } catch (IOException e) {
                log.error("Error processing image for provider {} : {}", provider.getName(), e.getMessage());
                throw new InternalServerErrorException("Error processing image: " + e.getMessage());
            }
        }
    }
}
