package com.rhombuzz.gpbackend.modules.communication.dto.request;

import lombok.Data;

@Data
public class SMSStatusRequest {
    private String to;
    private String from;
    private String status;
    private String messageUUID;
    private Integer errorCode;
}