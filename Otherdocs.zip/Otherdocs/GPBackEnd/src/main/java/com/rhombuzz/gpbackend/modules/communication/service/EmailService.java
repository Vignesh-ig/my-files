package com.rhombuzz.gpbackend.modules.communication.service;

import com.rhombuzz.gpbackend.modules.communication.dto.request.EmailRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveEmailRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailResponse;
import jakarta.validation.Valid;
import org.springframework.validation.annotation.Validated;

@Validated
public interface EmailService {

    EmailResponse sendEmail(
            @Valid EmailRequest request
    );

    void saveEmail(
            @Valid SaveEmailRequest request
    );
}
