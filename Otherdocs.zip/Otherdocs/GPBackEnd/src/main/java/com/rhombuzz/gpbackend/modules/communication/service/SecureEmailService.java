package com.rhombuzz.gpbackend.modules.communication.service;

public interface SecureEmailService {
}
