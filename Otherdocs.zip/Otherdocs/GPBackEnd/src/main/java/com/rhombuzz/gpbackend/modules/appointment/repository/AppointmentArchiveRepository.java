package com.rhombuzz.gpbackend.modules.appointment.repository;

import com.rhombuzz.gpbackend.modules.appointment.entity.AppointmentArchive;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentArchiveRepository extends JpaRepository<AppointmentArchive, Long> {
}
