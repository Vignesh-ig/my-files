package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Customization;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalTime;

@Builder
@Data
public class CustomizationResponse {
    private boolean addressFlag;
    private boolean reasonForVisitFlag;
    private boolean preferredContactFlag;
    private boolean insuranceCompanyFlag;
    private boolean insuranceIdFlag;
    private boolean insuranceGroupIdFlag;
    private boolean patientUpdateFormFlag;
    private String formsPacketLink;
    private String apptThankYouPageContent;
    private String apptRequestPopupContent;
    private String medgroupWorkFlow;
    private boolean bookingFeeSwitch;
    private BigDecimal defaultBookingFee;
    private int bookingLeadTimeInMinutes;
    private boolean bookingPreventionSwitch;
    private LocalTime bookingPreventionsStartTime;
    private boolean notifyWaitlistPatientSwitch;
    private int notifyWaitlistPatientLimit;
    private int apptCancelRestrictionPeriod;
    private int apptRescheduleRestrictionPeriod;

    public static CustomizationResponse fromEntity(Customization customization) {
        return CustomizationResponse.builder()
                .addressFlag(customization.isAddressFlag())
                .reasonForVisitFlag(customization.isReasonForVisitFlag())
                .preferredContactFlag(customization.isPreferredContactFlag())
                .insuranceCompanyFlag(customization.isInsuranceCompanyFlag())
                .insuranceIdFlag(customization.isInsuranceIdFlag())
                .insuranceGroupIdFlag(customization.isInsuranceGroupIdFlag())
                .patientUpdateFormFlag(customization.isPatientUpdateFormFlag())
                .formsPacketLink(customization.getFormsPacketLink())
                .apptThankYouPageContent(customization.getApptThankYouPageContent())
                .apptRequestPopupContent(customization.getApptRequestPopupContent())
                .medgroupWorkFlow(customization.getMedgroupWorkFlow())
                .bookingFeeSwitch(customization.isBookingFeeSwitch())
                .defaultBookingFee(customization.getDefaultBookingFee())
                .bookingLeadTimeInMinutes(customization.getBookingLeadTimeInMinutes())
                .bookingPreventionSwitch(customization.isBookingPreventionSwitch())
                .bookingPreventionsStartTime(customization.getBookingPreventionsStartTime())
                .notifyWaitlistPatientSwitch(customization.isNotifyWaitlistPatientSwitch())
                .notifyWaitlistPatientLimit(customization.getNotifyWaitlistPatientLimit())
                .apptCancelRestrictionPeriod(customization.getApptCancelRestrictionPeriod())
                .apptRescheduleRestrictionPeriod(customization.getApptRescheduleRestrictionPeriod())
                .build();
    }
}
