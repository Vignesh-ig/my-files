package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

public interface LocationResponse {

    Long getId();

    String getName();

    String getAddress();

    String getLocationReference();

    String getGooglePlaceId();
}