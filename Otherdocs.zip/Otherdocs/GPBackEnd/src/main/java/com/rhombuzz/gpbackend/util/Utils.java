package com.rhombuzz.gpbackend.util;

import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.modules.provider.dto.TimeValidationDTO;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.security.SecureRandom;
import java.time.*;
import java.util.Comparator;
import java.util.List;

@Slf4j
public class Utils {

    private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    public static <T> void validateObject(T t) {
        try(ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
            Validator validator = factory.getValidator();
            var violations = validator.validate(t);

            if (!violations.isEmpty()) {
                throw new ConstraintViolationException(violations);
            }
        }
    }

    public static String toSnakeCase(String camelCase) {
        return camelCase != null ? camelCase.replaceAll("([a-z])([A-Z]+)", "$1_$2")
                .toLowerCase() : null;
    }

    public static void validateTimeOrder(List<TimeValidationDTO> timeValidations) {
        log.info("Validating time order");
        if (timeValidations == null || timeValidations.isEmpty()) {
            return;
        }

        for (TimeValidationDTO dto : timeValidations) {
            if (dto.startTime() == null || dto.endTime() == null) {
                throw new ConflictException("Invalid time slot: Start and end times cannot be null");
            }
            if (dto.startTime().equals(dto.endTime())) {
                throw new ConflictException("Invalid time slot: Start time cannot be equal to end time");
            }
            if (dto.startTime().isAfter(dto.endTime())) {
                throw new ConflictException("Invalid time slot: Start time must be before end time");
            }
            if (Duration.between(dto.startTime(), dto.endTime()).toMinutes() < 5) {
                throw new ConflictException("Invalid time slot: Duration must be at least 5 minutes");
            }
        }

        var sortedList = timeValidations.stream()
                .sorted(Comparator.comparing(TimeValidationDTO::startTime))
                .toList();

        for (int i = 0; i < sortedList.size() - 1; i++) {
            TimeValidationDTO current = sortedList.get(i);
            TimeValidationDTO next = sortedList.get(i + 1);

            LocalTime currentEnd = current.endTime();
            LocalTime nextStart = next.startTime();

            if (currentEnd.isAfter(nextStart)) {
                throw new ConflictException(
                        String.format("Invalid time order: Time slot %s-%s overlaps with %s-%s",
                                current.startTime(), current.endTime(),
                                next.startTime(), next.endTime())
                );
            }

//            if (Duration.between(currentEnd, nextStart).toMinutes() < 5) {
//                throw new ConflictException(
//                        String.format("Invalid time slots: There must be a gap between slots %s-%s and %s-%s",
//                                current.startTime(), current.endTime(),
//                                next.startTime(), next.endTime())
//                );
//            }
        }

        log.info("Time order validation passed");
    }

    public static String generateSecretId(int length) {

        log.info("Generating secret id");

        SecureRandom random = new SecureRandom();
        StringBuilder stringBuilder = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(ALPHA_NUMERIC_STRING.length());
            stringBuilder.append(ALPHA_NUMERIC_STRING.charAt(randomIndex));
        }

        return stringBuilder.toString();
    }

    public static String getCurrentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt jwt)) {
            return null;
        }

        return jwt.getClaimAsString("username");
    }

    public static void savePdf(byte[] pdfBytes, String filePath, Logger log) {
        File outputFile = new File(filePath);
        File parentDir = outputFile.getParentFile();

        if (parentDir != null && !parentDir.exists()) {
            if (!parentDir.mkdirs()) {
                log.error("Failed to create directory: {}", parentDir.getAbsolutePath());
                throw new InternalServerErrorException("Failed to create output directory");
            }
        }

        try (BufferedOutputStream outputStream = new BufferedOutputStream(
                new FileOutputStream(outputFile)
        )) {
            outputStream.write(pdfBytes);
            log.info("PDF saved to output path: {}", filePath);
        } catch (Exception e) {
            log.error("Error saving PDF to output path: {}", e.getMessage(), e);
            throw new InternalServerErrorException("Error saving PDF to output path");
        }
    }

    public static String getExtension(String filename) {
        if (filename == null || filename.isBlank()) {
            return null;
        }

        int lastDotIndex = filename.lastIndexOf('.');

        if (lastDotIndex <= 0 || lastDotIndex == filename.length() - 1) {
            return null;
        }

        return filename.substring(lastDotIndex + 1);
    }


    public static LocalDateTime resolveStartDateTime(Month month, Integer year, LocalDateTime dateTime) {
        if (month == null || year == null) {
            log.info("Month or Year not provided, using current dateTime: {}", dateTime);
            return dateTime;
        }

        YearMonth requestedYearMonth = YearMonth.of(year, month);
        YearMonth currentYearMonth = YearMonth.from(dateTime);

        if (requestedYearMonth.isBefore(currentYearMonth)) {
            log.info("Requested month/year {}-{} is in the past compared to current month/year {}-{}",
                    month, year, currentYearMonth.getMonthValue(), currentYearMonth.getYear());
            throw new BadRequestException("Month and Year must not be in the past");
        }

        if (requestedYearMonth.equals(currentYearMonth)) {
            log.info("Requested month/year {}-{} is the current month/year, using current dateTime: {}",
                    month, year, dateTime);
            return dateTime;
        }

        log.info("Requested month/year {}-{} is in the future, using start of that month",
                month, year);
        return LocalDateTime.of(year, month, 1, 0, 0);
    }
}