package com.rhombuzz.gpbackend.enums;

import lombok.Getter;

import java.util.Arrays;

@Getter
public enum Placeholder {

    FIRST_NAME("FirstName"),
    LAST_NAME("LastName"),

    OFFICE_NAME("OfficeName"), //groupName - In MedGroup entity.
    OFFICE_ADDRESS("OfficeAddress"), //defaultAddress - In MedGroup entity.
    OFFICE_PHONE("OfficePhone"),

    //GROUP_ID("groupId"),

    FORM_PACKET_LINK("FormPacketLink"),

    SERVER_URL("ServerURL"),

    APPOINTMENT_PROVIDER_NAME("AppointmentProviderName"),
    APPOINTMENT_DATE("AppointmentDate"),
    APPOINTMENT_TIME("AppointmentTime"),
    MEETING_LINK("MeetingLink");

    private final String key;

    Placeholder(String key) {
        this.key = key;
    }

    public static Placeholder fromKey(String key) {
        return Arrays.stream(values())
                .filter(placeholder -> placeholder.getKey().equals(key))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown placeholder: " + key));
    }
}
