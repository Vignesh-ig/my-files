package com.rhombuzz.gpbackend.modules.medgroup.controller;

import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import com.rhombuzz.gpbackend.modules.medgroup.dto.MedGroupDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.RunCheckRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveMedGroupRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.RunCheckResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.SaveMedGroupResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.Asset;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/med-groups")
@PreAuthorize("hasRole("+ AccessType.ADMIN +")")
@Validated
public class MedGroupController {
    private final MedGroupService medGroupService;

    @PostMapping("/run-check")
    public ResponseEntity<RunCheckResponse> runCheck(@RequestBody @Valid RunCheckRequest request) {
        RunCheckResponse response = medGroupService.runCheck(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<SaveMedGroupResponse> saveMedGroup(
            @RequestPart @Valid SaveMedGroupRequest request,
            @RequestPart(required = false)
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png", "gif"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png", "image/gif"},
                    required = false
            ) MultipartFile image
    ) {
        SaveMedGroupResponse response = medGroupService.saveMedGroup(request, image);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping
    public ResponseEntity<List<MedGroupDTO>> getMedGroupNames() {
        List<MedGroupDTO> medGroupNames = medGroupService.getMedGroupNames();
        return ResponseEntity.ok(medGroupNames);
    }

    @GetMapping("/{groupId}/exists")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> isMedGroupExists(
            @PathVariable @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        boolean response = medGroupService.isMedGroupExists(groupId);
        return ResponseEntity.ok(Map.of("exists", response));
    }

    @GetMapping("/assets/{assetName}")
    public ResponseEntity<byte[]> getManualOnboardAsset(
            @PathVariable @NotNull Asset assetName
    ) {
        byte[] asset = medGroupService.getAsset(assetName);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=" + assetName.getFileName())
                .contentType(MediaType.TEXT_PLAIN)
                .body(asset);
    }

    @GetMapping("/{groupId}/appointment-type")
    @PreAuthorize("permitAll()")
    public ResponseEntity<MedGroup.AppointmentType> getAppointmentType(
            @PathVariable @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        MedGroup.AppointmentType appointmentType = medGroupService.getAppointmentType(groupId);
        return ResponseEntity.ok(appointmentType);
    }
}
