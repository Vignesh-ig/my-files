package com.rhombuzz.gpbackend.modules.intake.dto;

import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class PatientDTO {

    @NotBlank(message = "First name cannot be blank")
    @Size(max = 45, message = "Patient first name must be at most 45 characters long")
    @Pattern(regexp = RegexPattern.NAME, message = "First name must contain only letters")
    private String firstName;

    @NotBlank(message = "Last name cannot be blank")
    @Size(max = 45, message = "Patient last name must be at most")
    @Pattern(regexp = RegexPattern.NAME, message = "Last name must contain only letters")
    private String lastName;

    @NotBlank(message = "Cell Phone cannot be blank")
    @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Cell Phone number must be exactly 10 digits")
    private String cellPhone;

    @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Home Phone number must be exactly 10 digits")
    private String homePhone;

    @Pattern(regexp = RegexPattern.TEN_DIGITS, message = "Work Phone number must be exactly 10 digits")
    private String workPhone;

    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Email should be valid")
    @Size(max = 45, message = "Email must be at most 45 characters long")
    private String email;

    @Pattern(regexp = RegexPattern.DIGITS, message = "SSN must contain only digits")
    @Size(max = 9, message = "SSN must be at most 9 characters long")
    private String ssn;

    @NotNull(message = "Gender cannot be null")
    private Gender gender;

    @NotNull(message = "Date of Birth cannot be null")
    @PastOrPresent(message = "Date of Birth must be in the past or present")
    private LocalDate dob;

    @NotBlank(message = "Street Address cannot be blank")
    @Size(max = 200, message = "Street Address must be at most 200 characters long")
    private String streetAddress;

    @NotBlank(message = "City cannot be blank")
    @Size(max = 45, message = "City must be at most 45 characters long")
    @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "City must contain only letters and spaces")
    private String city;

    @NotBlank(message = "State cannot be blank")
    @Size(max = 45, message = "State must be at most 45 characters long")
    @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "State must contain only letters and spaces")
    private String state;

    @NotBlank(message = "Zip Code cannot be blank")
    @Pattern(regexp = RegexPattern.FIVE_DIGITS)
    private String zipCode;

    private PreferredLanguage preferredLanguage;
}
