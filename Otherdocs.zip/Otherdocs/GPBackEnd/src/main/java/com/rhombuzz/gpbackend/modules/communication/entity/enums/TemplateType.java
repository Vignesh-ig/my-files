package com.rhombuzz.gpbackend.modules.communication.entity.enums;

public enum TemplateType {

    INTERNAL,
    EXTERNAL
}
