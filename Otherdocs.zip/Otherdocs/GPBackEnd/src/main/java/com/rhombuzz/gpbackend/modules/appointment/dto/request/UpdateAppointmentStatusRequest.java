package com.rhombuzz.gpbackend.modules.appointment.dto.request;

import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record UpdateAppointmentStatusRequest(
        @NotBlank @Size(min = 10, max = 10) String groupId,
        @NotNull AppointmentStatus currentStatus,
        @NotNull AppointmentStatus newStatus
) {
}
