package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmailTemplateResponse {
    private Long id;
    private String subject;
    private String content;
    private String englishContent;
    private String spanishContent;

    public static EmailTemplateResponse fromEntity( EmailTemplate emailTemplate) {
        return EmailTemplateResponse.builder()
                .id(emailTemplate.getId())
                .subject(emailTemplate.getSubject())
                .build();
    }

    public String getContent(PreferredLanguage language) {
        return language == PreferredLanguage.ENGLISH ? englishContent : spanishContent;
    }
}
