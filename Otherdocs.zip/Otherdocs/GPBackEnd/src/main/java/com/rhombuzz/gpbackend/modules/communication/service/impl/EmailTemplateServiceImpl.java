package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.UpdateEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateNameResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplateAttribute;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import com.rhombuzz.gpbackend.modules.communication.repository.EmailTemplateAttributeRepository;
import com.rhombuzz.gpbackend.modules.communication.repository.EmailTemplateRepository;
import com.rhombuzz.gpbackend.modules.communication.service.EmailTemplateService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailTemplateServiceImpl implements EmailTemplateService {
    private static final String ACTIVITY_TYPE = "EMAIL TEMPLATE";

    private final EmailTemplateRepository emailTemplateRepository;
    private final EmailTemplateAttributeRepository emailTemplateAttributeRepository;
    private final ActivityService activityService;

    @Override
    public void saveEmailTemplate(SaveEmailTemplateRequest request) {
        log.info("Saving email template with request: {}", request);

        JsonNode[] englishEmailTemplateContent = getEmailTemplateContent(request.englishEmailTemplate());
        JsonNode[] spanishEmailTemplateContent = getEmailTemplateContent(request.spanishEmailTemplate());

        Optional<EmailTemplateAttribute> attributeExist = emailTemplateAttributeRepository.findByGroupId(request.groupId());

        EmailTemplate emailTemplate = EmailTemplate.fromRequest(request);
        EmailTemplateAttribute attribute;
        EmailTemplateAttribute resultAttribute;

        if (attributeExist.isEmpty()) {

            attribute = new EmailTemplateAttribute();
            attribute.setGroupId(request.groupId());
            attribute.setEnglishHeaderFooter(englishEmailTemplateContent[0]);
            attribute.setSpanishHeaderFooter(spanishEmailTemplateContent[0]);
            attribute.setStyle(englishEmailTemplateContent[2]);

            resultAttribute = emailTemplateAttributeRepository.save(attribute);
            emailTemplate.setAttribute(resultAttribute);

        } else {
            emailTemplate.setAttribute(attributeExist.get());
        }

        emailTemplate.setGroupId(request.groupId());
        emailTemplate.setTemplateType(TemplateType.EXTERNAL);
        emailTemplate.setTemplateGroup(EmailTemplate.TemplateGroup.CUSTOM);
        emailTemplate.setEnglishContent(englishEmailTemplateContent[1]);
        emailTemplate.setSpanishContent(spanishEmailTemplateContent[1]);

        emailTemplateRepository.save(emailTemplate);
        log.info("Email template saved successfully with ID: {}", emailTemplate.getName());

        String description = String.format("The user (%s) created a new email template (%s)",
                Utils.getCurrentUsername(), request.templateName());
        saveActivity(request.groupId(), description);
    }

    @Override
    public EmailTemplateResponse getEmailTemplate(String templateId, String groupId, PreferredLanguage language) {
        log.info("Fetching email template with groupId: {} and templateId: {} and language: {}",
                groupId, templateId, language);
        EmailTemplate template = findTemplateOrThrow(templateId, groupId);

        EmailTemplateResponse response = new EmailTemplateResponse();
        response.setId(template.getId());
        response.setSubject(template.getSubject());
        response.setContent(buildHtmlEmailTemplate(template, language));
        return response;
    }

    @Override
    public EmailTemplateResponse getEmailTemplate(String templateId, String groupId) {
        log.info("Fetching email templates with groupId: {} and templateId: {}", groupId, templateId);
        EmailTemplate template = findTemplateOrThrow(templateId, groupId);

        EmailTemplateResponse response = new EmailTemplateResponse();
        response.setId(template.getId());
        response.setSubject(template.getSubject());
        response.setEnglishContent(buildHtmlEmailTemplate(template, PreferredLanguage.ENGLISH));
        response.setSpanishContent(buildHtmlEmailTemplate(template, PreferredLanguage.SPANISH));
        return response;
    }

    private EmailTemplate findTemplateOrThrow(String templateId, String groupId) {
        return emailTemplateRepository.getEmailTemplate(templateId, groupId)
                .orElseThrow(() -> {
                    log.error("Email template not found with groupId: {} and templateId: {}", groupId, templateId);
                    return new NotFoundException("Email template not found");
                });
    }

    @Override
    public Map<EmailTemplate.TemplateGroup, List<EmailTemplateNameResponse>> getEmailTemplatesNameWithGroup(String groupId) {
        log.info("Fetching email template subject with groupId: {}", groupId);
        return emailTemplateRepository.findEmailTemplates(groupId).stream()
                .collect(Collectors.groupingBy(
                        EmailTemplate::getTemplateGroup,
                        Collectors.mapping(EmailTemplateNameResponse::fromEntity, Collectors.toList())
                ));
    }

    @Override
    public void updateEmailTemplate(Long id, UpdateEmailTemplateRequest request) {
        log.info("Updating email template with ID: {} and groupId: {}", id, request.groupId());
        EmailTemplate emailTemplate = emailTemplateRepository.getEmailTemplate(id, request.groupId())
                .orElseThrow(() -> {
                    log.info("Email template not found with ID: {} and groupId: {}", id, request.groupId());
                    return new NotFoundException("Email template not found");
                });

        EmailTemplateAttribute attribute = emailTemplate.getAttribute();

        JsonNode[] emailTemplateContent;
        if (request.language() == PreferredLanguage.ENGLISH) {

            emailTemplateContent = getEmailTemplateContent(request.jsonTemplateContent());
            attribute.setEnglishHeaderFooter(emailTemplateContent[0]);
            emailTemplate.setEnglishContent(emailTemplateContent[1]);
            attribute.setStyle(emailTemplateContent[2]);

        } else if (request.language() == PreferredLanguage.SPANISH) {

            emailTemplateContent = getEmailTemplateContent(request.jsonTemplateContent());
            attribute.setSpanishHeaderFooter(emailTemplateContent[0]);
            emailTemplate.setSpanishContent(emailTemplateContent[1]);
            attribute.setStyle(emailTemplateContent[2]);

        }

        EmailTemplateAttribute updatedAttribute = emailTemplateAttributeRepository.save(attribute);
        emailTemplate.setAttribute(updatedAttribute);

        emailTemplateRepository.save(emailTemplate);
        log.info("Email template updated successfully with ID: {}", id);

        String description = String.format("The user (%s) updated the email template (%s).",
                Utils.getCurrentUsername(), emailTemplate.getName());
        saveActivity(request.groupId(), description);
    }

    @Override
    public boolean isRestrictedTemplate(String templateId, String groupId) {
        log.info("Checking if email template is restricted with groupId: {} and templateId: {}", groupId, templateId);
        return emailTemplateRepository.isRestricted(groupId, templateId);
    }

    private String buildHtmlEmailTemplate(EmailTemplate template, PreferredLanguage language) {
        log.info("Building HTML email template");

        JsonNode englishContent = template.getEnglishContent();
        JsonNode spanishContent = template.getSpanishContent();

        JsonNode englishHeaderFooterContent = template.getAttribute().getEnglishHeaderFooter();
        JsonNode spanishHeaderFooterContent = template.getAttribute().getSpanishHeaderFooter();

        JsonNode htmlStyle = template.getAttribute().getStyle();

        return switch (language) {
            case ENGLISH ->
                    parseJsonToHtmlEmailTemplate(mergeJsonNodes(englishHeaderFooterContent, englishContent, htmlStyle));
            case SPANISH ->
                    parseJsonToHtmlEmailTemplate(mergeJsonNodes(spanishHeaderFooterContent, spanishContent, htmlStyle));
        };
    }

    private void saveActivity(String groupId, String description) {
        ActivityRequest request = new ActivityRequest(groupId, ACTIVITY_TYPE, description, null, null, null);
        activityService.saveActivity(request);
    }

    private JsonNode mergeJsonNodes(JsonNode headerFooterJson, JsonNode bodyJson, JsonNode styleJson) {
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode mergedNode = objectMapper.createObjectNode();

        mergedNode.set("headerFooter", headerFooterJson);
        mergedNode.set("body", bodyJson);
        mergedNode.set("style", styleJson);

        return mergedNode;
    }

    public String parseJsonToHtmlEmailTemplate(JsonNode jsonNode) {
        log.info("Parsing JSON to HTML email template");
        String html = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" /><title>Email Template</title></head><body style=\"margin: 0; padding: 0;\"><center><table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;min-height: 600px;text-align: center;\"><!-- Header --><tr><td class=\"header\" style=\"padding: 20px; background: rgb(98, 177, 255);{headerStyle}\">{header}</td></tr><!-- Content --><tr><td class=\"body\" style=\"padding: 0px 20px; font-family: Arial, sans-serif;{bodyStyle}\">{body}</td></tr><!-- Footer --><tr><td class=\"footer\" style=\"padding: 0px 20px; background: #44525f; text-align: center;color: white;{footerStyle}\">{footer}</td></tr></table></center></body></html>";

        String headerJson = getConcatenatedText(jsonNode, "headerFooter", "header");
        String headerStyle = jsonNode.get("style").get("header").asText();

        String bodyJson = getConcatenatedText(jsonNode, "body");
        String bodyStyle = jsonNode.get("style").get("body").asText();

        String footerJson = getConcatenatedText(jsonNode, "headerFooter", "footer");
        String footerStyle = jsonNode.get("style").get("footer").asText();

        return html.replace("{header}", headerJson)
                .replace("{headerStyle}", headerStyle)
                .replace("{body}", bodyJson)
                .replace("{bodyStyle}", bodyStyle)
                .replace("{footer}", footerJson)
                .replace("{footerStyle}", footerStyle);
    }

    private String getConcatenatedText(JsonNode jsonNode, String... key) {

        StringBuilder result = new StringBuilder();
        if (key.length == 0 || !jsonNode.has(key[0])) {
            return "";
        }

        JsonNode targetNode = jsonNode.get(key[0]);
        if (key.length > 1 && targetNode.has(key[1])) {
            targetNode = targetNode.get(key[1]);
        }

        if (targetNode.has("content") && targetNode.get("content").isArray()) {
            for (JsonNode node : targetNode.get("content")) {
                result.append(node.asText());
            }
        }
        return result.toString();
    }


    private JsonNode[] getEmailTemplateContent(JsonNode jsonNode) {
        log.info("Parsing JSON to get email template content");

        JsonNode headerFooter = jsonNode.get("headerFooter");
        JsonNode body = jsonNode.get("body");
        JsonNode style = jsonNode.get("style");

        return new JsonNode[]{
                headerFooter,
                body,
                style
        };
    }

}

