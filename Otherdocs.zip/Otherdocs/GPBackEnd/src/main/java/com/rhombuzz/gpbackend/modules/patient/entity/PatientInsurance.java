package com.rhombuzz.gpbackend.modules.patient.entity;

import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.dto.PatientInsuranceDTO;
import com.rhombuzz.gpbackend.modules.patient.dto.request.SavePatientInsuranceRequest;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.RelationshipToPatient;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "patient_insurances", indexes = {
        @Index(name = "idx_patient_insurance_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_patient_insurance_patient_id", columnList = "patient_id")
})
public class PatientInsurance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @Column(name = "have_insurance")
    private boolean haveInsurance;

    @Column(name = "pri_ins_policyholder_relationship", length = 45)
    @Enumerated(EnumType.STRING)
    private RelationshipToPatient priInsPolicyholderRelationship;

    @Column(name = "pri_ins_policyholder_fn", length = 45)
    private String priInsPolicyholderFN;

    @Column(name = "pri_ins_policyholder_ln", length = 45)
    private String priInsPolicyholderLN;

    @Column(name = "pri_ins_policyholder_dob")
    private LocalDate priInsPolicyholderDob;

    @Column(name = "pri_ins_policyholder_gender", length = 45)
    @Enumerated(EnumType.STRING)
    private Gender priInsPolicyholderGender;

    @Column(name = "pri_ins_company_name", length = 100)
    private String priInsCompanyName;

    @Column(name = "pri_ins_company_code", length = 50)
    private String priInsCompanyCode;

    @Column(name = "pri_ins_group_id", length = 45)
    private String priInsGroupId;

    @Column(name = "pri_ins_id", length = 45)
    private String priInsId;

    @Column(name = "have_sec_ins")
    private boolean haveSecIns;

    @Column(name = "sec_ins_policyholder_relationship", length = 45)
    @Enumerated(EnumType.STRING)
    private RelationshipToPatient secInsPolicyholderRelationship;

    @Column(name = "sec_ins_policyholder_fn", length = 45)
    private String secInsPolicyholderFN;

    @Column(name = "sec_ins_policyholder_ln", length = 45)
    private String secInsPolicyholderLN;

    @Column(name = "sec_ins_policyholder_dob")
    private LocalDate secInsPolicyholderDob;

    @Column(name = "sec_ins_policyholder_gender", length = 45)
    @Enumerated(EnumType.STRING)
    private Gender secInsPolicyholderGender;

    @Column(name = "sec_ins_company_name", length = 100)
    private String secInsCompanyName;

    @Column(name = "sec_ins_company_code", length = 50)
    private String secInsCompanyCode;

    @Column(name = "sec_ins_group_id", length = 45)
    private String secInsGroupId;

    @Column(name = "sec_ins_id", length = 45)
    private String secInsId;

    public static PatientInsurance fromRequest(SavePatientInsuranceRequest request) {
        PatientInsurance.PatientInsuranceBuilder builder = PatientInsurance.builder()
                .haveInsurance(request.haveInsurance())
                .haveSecIns(request.haveSecIns());

        // Handle Primary Insurance
        if (request.haveInsurance()) {
            PatientInsuranceDTO primaryInsurance = request.primaryInsurance();

            builder.priInsPolicyholderRelationship(primaryInsurance.getPolicyholderRelationship())
                    .priInsCompanyName(primaryInsurance.getCompanyName())
                    .priInsCompanyCode(primaryInsurance.getCompanyCode())
                    .priInsGroupId(primaryInsurance.getInsGroupId())
                    .priInsId(primaryInsurance.getInsId());

            if (primaryInsurance.getPolicyholderRelationship() != RelationshipToPatient.SELF) {
                builder.priInsPolicyholderFN(primaryInsurance.getPolicyholderFN())
                        .priInsPolicyholderLN(primaryInsurance.getPolicyholderLN())
                        .priInsPolicyholderDob(primaryInsurance.getPolicyholderDob())
                        .priInsPolicyholderGender(primaryInsurance.getPolicyholderGender());
            }
        }

        // Handle Secondary Insurance
        if (request.haveSecIns()) {
            PatientInsuranceDTO secondaryInsurance = request.secondaryInsurance();

            builder.secInsPolicyholderRelationship(secondaryInsurance.getPolicyholderRelationship())
                    .secInsCompanyName(secondaryInsurance.getCompanyName())
                    .secInsCompanyCode(secondaryInsurance.getCompanyCode())
                    .secInsGroupId(secondaryInsurance.getInsGroupId())
                    .secInsId(secondaryInsurance.getInsId());

            if (secondaryInsurance.getPolicyholderRelationship() != RelationshipToPatient.SELF) {
                builder.secInsPolicyholderFN(secondaryInsurance.getPolicyholderFN())
                        .secInsPolicyholderLN(secondaryInsurance.getPolicyholderLN())
                        .secInsPolicyholderDob(secondaryInsurance.getPolicyholderDob())
                        .secInsPolicyholderGender(secondaryInsurance.getPolicyholderGender());
            }
        }
        return builder.build();
    }

}
