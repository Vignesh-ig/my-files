package com.rhombuzz.gpbackend.integration.telehealth.impl;

import com.rhombuzz.gpbackend.integration.telehealth.TelehealthService;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Set;

@Slf4j
@Service("PHONE")
@RequiredArgsConstructor
public class PhoneServiceImpl implements TelehealthService {
    private final PatientCommunicationService patientCommunicationService;

    @Override
    public Map<String, Object> setup(Appointment appointment) {
        return Map.of();
    }

    @Override
    public void sendEmail(Appointment appointment) {
        log.info("Sending email for telehealth appointment through phone for patient ID: {}",
                appointment.getPatient().getId());
        patientCommunicationService.validateAndSendEmail(
                appointment.getMedGroup().getGroupId(),
                Set.of(appointment.getPatient().getId()),
                appointment,
                "PHONE_APPOINTMENT_CONFIRMED"
        );
    }

    @Override
    public void sendSMS(Appointment appointment) {
        log.info("Sending SMS for telehealth appointment through phone for patient ID: {}",
                appointment.getPatient().getId());
        patientCommunicationService.validateAndSendSMS(
                appointment.getMedGroup().getGroupId(),
                Set.of(appointment.getPatient().getId()),
                appointment,
                "PHONE_APPOINTMENT_CONFIRMED"
        );
    }
}
