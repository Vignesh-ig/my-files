package com.rhombuzz.gpbackend.exception;

import com.rhombuzz.gpbackend.exception.dto.Error;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Profile("dev")
@RestControllerAdvice
public class DevGlobalExceptionHandler extends BaseGlobalExceptionHandler {

    @ExceptionHandler(Throwable.class)
    public ResponseEntity<Error> handleInternalError(Exception error) {
        return buildErrorResponse(error.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
