package com.rhombuzz.gpbackend.modules.medgroup.dto;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AWSDTO {
    private String groupName;
    private String accessKey;
    private String secretKey;
}
