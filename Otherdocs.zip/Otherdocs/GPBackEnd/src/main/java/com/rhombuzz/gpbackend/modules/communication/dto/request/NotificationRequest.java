package com.rhombuzz.gpbackend.modules.communication.dto.request;

import com.rhombuzz.gpbackend.modules.communication.entity.Notification;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record NotificationRequest(
        @NotBlank(message = "Message cannot be blank")
        String message,

        @NotNull(message = "Priority cannot be null")
        Notification.Priority priority
) {
}
