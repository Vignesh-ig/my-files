package com.rhombuzz.gpbackend.modules.appointment.controller;

import com.rhombuzz.gpbackend.modules.appointment.dto.request.*;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.AllAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormInitResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.PatientAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentFormType;
import com.rhombuzz.gpbackend.modules.appointment.service.AppointmentService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/appointments")
@Validated
public class AppointmentController {
    private final AppointmentService appointmentService;

    @PostMapping("/manual")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Void> saveManualAppointment(
            @Valid @RequestBody SaveManualAppointmentRequest request
    ) {
        appointmentService.saveManualAppointment(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/manual/dates")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<List<Date>> getAvailableDates(
            @Valid GetAvailableDatesRequest request
    ) {
        List<Date> availableDates = appointmentService.getAvailableDates(request, AppointmentFormType.STAFF);
        return ResponseEntity.ok(availableDates);
    }

    @GetMapping("/manual/slots")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<List<Time>> getAvailableSlots(
            @Valid GetAvailableSlotsRequest request
    ) {
        List<Time> availableSlots = appointmentService.getAvailableSlots(request, AppointmentFormType.STAFF);
        return ResponseEntity.ok(availableSlots);
    }

    @GetMapping("/patients/{patientId}")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Page<PatientAppointmentResponse>> getPatientAppointments(
            @PathVariable @NotNull @Positive Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<PatientAppointmentResponse> appointments = appointmentService
                .getPatientAppointments(patientId, groupId, pageable);
        return ResponseEntity.ok(appointments);
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Void> updateAppointmentStatus(
            @PathVariable @NotNull @Positive Long id,
            @RequestBody @Valid UpdateAppointmentStatusRequest request
    ) {
        appointmentService.updateAppointmentStatus(id, request);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/available-dates")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Set<LocalDate>> getAvailableAppointmentDates(
            @Valid GetAvailableAppointmentDatesRequest request
    ) {
        Set<LocalDate> availableDates = appointmentService
                .getAvailableAppointmentDates(request);
        return ResponseEntity.ok(availableDates);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Page<AllAppointmentResponse>> getAppointmentsByDate(
            @Valid GetAppointmentsRequest request,
            Pageable pageable
    ) {
        Page<AllAppointmentResponse> appointments = appointmentService
                .getAppointmentsByDate(request, pageable);
        return ResponseEntity.ok(appointments);
    }

    @GetMapping("/next-prev-dates")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Map<String, Object>> getRecentNextPreviousAvailableAppointmentDates(
            @Valid GetAppointmentsRequest request
    ) {
        Map<String, Object> appointments = appointmentService
                .getRecentNextPreviousDates(request);
        return ResponseEntity.ok(appointments);
    }

    @PatchMapping("/{id}/patient-confirm")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Void> savePatientConfirmed(
            @PathVariable @NotNull @Positive Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        appointmentService.savePatientConfirmed(id, groupId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/form/dates")
    public ResponseEntity<List<Date>> getAvailableDatesAtPatientEnd(
            @Valid GetAvailableDatesRequest request
    ) {
        List<Date> availableDates = appointmentService.getAvailableDates(request, AppointmentFormType.PATIENT);
        return ResponseEntity.ok(availableDates);
    }

    @GetMapping("/form/slots")
    public ResponseEntity<List<Time>> getAvailableSlotsAtPatientEnd(
            @Valid GetAvailableSlotsRequest request
    ) {
        List<Time> availableSlots = appointmentService.getAvailableSlots(request, AppointmentFormType.PATIENT);
        return ResponseEntity.ok(availableSlots);
    }

    @PostMapping("/form")
    public ResponseEntity<Void> saveAppointmentFromPatientForm(
            @Valid @RequestBody SaveFormAppointmentRequest request
    ) {
        appointmentService.saveFormAppointment(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/form/init")
    public ResponseEntity<AppointmentFormInitResponse> getAppointmentFormInitData(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        AppointmentFormInitResponse response = appointmentService.getAppointmentFormInitData(groupId);
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/{id}/confirm")
    public ResponseEntity<Void> confirmAppointment(
            @PathVariable @NotNull @Positive Long id,
            @RequestBody @Valid ConfirmAppointmentRequest request
    ) {
        appointmentService.confirmAppointment(id, request);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/reschedule")
    public ResponseEntity<Void> rescheduleAppointment(
            @PathVariable @NotNull @Positive Long id,
            @RequestBody @Valid RescheduleAppointmentRequest request
    ) {
        appointmentService.rescheduleAppointment(id, request, AppointmentFormType.PATIENT);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/manual/reschedule")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Void> rescheduleManualAppointment(
            @PathVariable @NotNull @Positive Long id,
            @RequestBody @Valid RescheduleAppointmentRequest request
    ) {
        appointmentService.rescheduleAppointment(id, request, AppointmentFormType.STAFF);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}/cancel")
    public ResponseEntity<Void> cancelAppointment(
            @PathVariable @NotNull @Positive Long id,
            @RequestBody @Valid CancelAppointmentRequest request
    ) {
        appointmentService.cancelAppointment(id, request, AppointmentFormType.PATIENT);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}/manual/cancel")
    @PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
    public ResponseEntity<Void> cancelManualAppointment(
            @PathVariable @NotNull @Positive Long id,
            @RequestBody @Valid CancelAppointmentRequest request
    ) {
        appointmentService.cancelAppointment(id, request, AppointmentFormType.STAFF);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}/pending")
    public ResponseEntity<Void> denyAppointment(
            @PathVariable @NotNull @Positive Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotNull @Positive Long patientId
    ) {
        appointmentService.denyAppointment(id, groupId, patientId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/form/patients/{patientId}")
    public ResponseEntity<Page<PatientAppointmentResponse>> getPatientConfirmedAppointments(
            @PathVariable @NotNull @Positive Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<PatientAppointmentResponse> appointments = appointmentService
                .getPatientConfirmedAppointments(patientId, groupId, pageable);
        return ResponseEntity.ok(appointments);
    }
}
