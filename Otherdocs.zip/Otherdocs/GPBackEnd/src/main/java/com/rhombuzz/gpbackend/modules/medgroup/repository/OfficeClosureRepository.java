package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.medgroup.entity.OfficeClosure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface OfficeClosureRepository extends JpaRepository<OfficeClosure, Long> {

    @Query("SELECT oc FROM OfficeClosure oc WHERE oc.medGroup.groupId = ?1")
    List<OfficeClosure> findByGroupId(String groupId);

    @Query("SELECT oc FROM OfficeClosure oc WHERE oc.id = ?1 AND oc.medGroup.groupId = ?2")
    Optional<OfficeClosure> findById(Long id, String groupId);

    @Query("SELECT COUNT(oc) > 0 FROM OfficeClosure oc WHERE oc.id = ?1 AND oc.medGroup.groupId = ?2")
    boolean existsById(Long id, String groupId);

    @Modifying
    @Query("DELETE FROM OfficeClosure oc WHERE oc.id = ?1 AND oc.medGroup.groupId = ?2")
    void deleteById(Long id, String groupId);
}
