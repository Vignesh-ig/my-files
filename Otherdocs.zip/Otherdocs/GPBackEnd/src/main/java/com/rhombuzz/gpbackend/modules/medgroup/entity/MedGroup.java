package com.rhombuzz.gpbackend.modules.medgroup.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.TimeZone;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "med_groups", indexes = {
        @Index(name = "idx_med_group_group_id", columnList = "group_id")
})
public class MedGroup {

    @Id
    @Column(name = "group_id", nullable = false, length = 10, unique = true)
    private String groupId;

    @Column(name = "group_name", length = 45, nullable = false, unique = true)
    private String groupName;

    @Column(name = "s3_access_key", nullable = false, length = 30)
    private String s3AccessKey;

    @Column(name = "s3_secret_key", nullable = false, length = 45)
    private String s3SecretKey;

    @Column(name = "first_name", length = 45)
    private String firstName; //Todo: need to check if this is required

    @Column(name = "group_type", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private GroupType groupType;

    @Column(name = "reminder_type", length = 45)
    @Enumerated(EnumType.STRING)
    private ReminderType reminderType;

    @Column(name = "reminder_days")
    private int reminderDays;

    @Column(name = "pre_reminder_days")
    private int preReminderDays;

    @Column(name = "time_zone", nullable = false, length = 45)
    private TimeZone timeZone;

    @Column(name = "group_description", length = 60, nullable = false)
    private String groupDescription;

    @Column(name = "from_name", length = 45)
    private String fromName;

    @Column(name = "appointment_type", length = 45)
    @Enumerated(EnumType.STRING)
    private AppointmentType appointmentType;

    @Column(name = "google_place_id", length = 500)
    private String googlePlaceId;

    @Column(name = "facebook_link", length = 500)
    private String facebookLink;

    @Column(name = "yelp_link", length = 500)
    private String yelpLink;

    @Column(name = "ems_phone", length = 11)
    private String emsPhone;

    @Column(name = "ems_toll_free_phone_number", length = 15)
    private String emsTollFreePhoneNumber;

    @Column(name = "office_phone", length = 10, nullable = false)
    private String officePhone;

    @Column(name = "default_address", length = 100, nullable = false)
    private String defaultAddress;

    @Lob
    @Column(name = "image", columnDefinition = "LONGBLOB")
    private byte[] image;

    @Column(name = "image_name", length = 45)
    private String imageName;

    @Column(name = "stripe_account_id", length = 50)
    private String stripeAccountId;

    @Column(name = "stripe_efm_fee_percent", precision = 5, scale = 2)
    private BigDecimal stripeEfmFeePercent;

    @Column(name = "email", length = 45, nullable = false)
    private String email;

    @Column(name = "appt_alert_office_email", length = 45)
    private String appointmentAlertOfficeEmail;

    @Column(name = "default_booking_fee", precision = 10, scale = 2)
    private BigDecimal defaultBookingFee;

    @Column(name = "per_text_fee", precision = 5, scale = 2)
    private BigDecimal perTextFee;

    @Column(name = "prepaid_text_count")
    private int prepaidTextCount;

    @Column(name = "telehealth", length = 45)
    @Enumerated(EnumType.STRING)
    private Telehealth telehealth;

    public MedGroup(String groupId) {
        this.groupId = groupId;
    }

    @PrePersist
    public void beforePersist() {
        this.reminderType = ReminderType.CALENDAR_DAYS;
        this.preReminderDays = 6;
        this.perTextFee = BigDecimal.valueOf(0.08);
        this.prepaidTextCount = 5000;
    }

    public enum GroupType {

        GENERAL_COVER_PAGE,
        DENTAL_COVER_PAGE,
        PEDIATRIC_COVER_PAGE,
        ORTHOPAEDIC_COVER_PAGE,
        PLASTIC_SURGEON_COVER_PAGE,
        CARDIOLOGY_COVER_PAGE,
        UROLOGIST_COVER_PAGE,
        PEDIATRIC_DENTAL_COVER_PAGE,
        GYNECOLOGIST_COVER_PAGE,
        PSYCHOLOGY_COVER_PAGE,
        PEDIATRIC_OT_COVER_PAGE,
        DERMATOLOGY_COVER_PAGE,
        ENT_COVER_PAGE,
        CUSTOMIZED_ENT,
        NEUROLOGY_COVER_PAGE,
        OPTOMETRY_COVER_PAGE,
        GASTROENTEROLOGY_COVER_PAGE,
        ORTHODONTIC_COVER_PAGE,
        OPHTHALMOLOGY_COVER_PAGE,
        ONCOLOGY_COVER_PAGE,
        INTERNAL_MEDICINE_COVER_PAGE,
        ENDOCRINOLOGIST_COVER_PAGE,
        PODIATRIST_COVER_PAGE,
        PEDIATRIC_THERAPY_COVER_PAGE,
        ABA_COVER_PAGE,
        PRIMARY_CARE_COVER_PAGE,
        CHIROPRACTIC_COVER_PAGE,
        PAIN_MEDICINE_COVER_PAGE,
        PHYSICAL_THERAPY_COVER_PAGE,
        RHEUMATOLOGIC_COVER_PAGE,
        NEPHROLOGY_COVER_PAGE,
        FAMILY_MEDICINE_COVER_PAGE
    }

    public enum ReminderType {

        CALENDAR_DAYS,
        WEEK_DAYS
    }

    public enum AppointmentType {

        SPECIFIC,
        GENERIC,
        CONFIRMED
    }

    public enum Telehealth {

        GOTO_MEETING,

        //Does not require any integration, just staff will
        PHONE
    }
}