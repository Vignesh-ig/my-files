package com.rhombuzz.gpbackend.component.csv;

import com.opencsv.bean.AbstractBeanField;
import com.rhombuzz.gpbackend.exception.domain.BadRequestException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class LocalDateConverter extends AbstractBeanField<LocalDate, String> {
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    protected Object convert(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }

        try {
            return LocalDate.parse(value.trim(), FORMATTER);
        } catch (DateTimeParseException e) {
            throw new BadRequestException("Invalid date. Expected format: yyyy-MM-dd");
        }
    }
}
