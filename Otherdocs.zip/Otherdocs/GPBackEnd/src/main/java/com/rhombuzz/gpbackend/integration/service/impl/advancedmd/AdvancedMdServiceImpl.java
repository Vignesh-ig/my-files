package com.rhombuzz.gpbackend.integration.service.impl.advancedmd;


import com.rhombuzz.gpbackend.integration.service.IntegrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service("advancedmd")
@Slf4j
public class AdvancedMdServiceImpl implements IntegrationService {

    @Override
    public void handlePatientResource() {
        log.info("AdvancedMdServiceImpl handlePatientResource called");
    }
}
