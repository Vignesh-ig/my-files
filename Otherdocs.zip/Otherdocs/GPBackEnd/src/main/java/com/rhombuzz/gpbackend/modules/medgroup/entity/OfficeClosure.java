package com.rhombuzz.gpbackend.modules.medgroup.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Table(name = "office_closures", indexes = {
        @Index(name = "idx_office_closure_med_group_id", columnList = "med_group_id")
})
public class OfficeClosure {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "close_date", nullable = false)
    private LocalDate closeDate;

    @Column(name = "reason", nullable = false, length = 45)
    private String reason;
}
