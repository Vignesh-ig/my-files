package com.rhombuzz.gpbackend.modules.support.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDateTime;

public record UpdateQuickSurveyRequest (

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Received date and time cannot be null")
        LocalDateTime receivedDateTime,

        @NotNull(message = "Score cannot be null")
        @Min(value = 1, message = "Score must be at least 1")
        @Max(value = 5, message = "Score must be at most 5")
        Integer score,

        @NotBlank(message = "Reason cannot be blank")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "Reason must contain only letters and spaces")
        @Size(max = 500, message = "Reason must be at most 500 characters long")
        String reason,

        Boolean isGoogleReviewIntent,
        Boolean isGoogleReviewStatus
) {
}
