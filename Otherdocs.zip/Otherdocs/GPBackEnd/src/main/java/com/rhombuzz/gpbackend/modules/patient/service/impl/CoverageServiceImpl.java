package com.rhombuzz.gpbackend.modules.patient.service.impl;

import com.rhombuzz.gpbackend.modules.patient.service.CoverageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CoverageServiceImpl implements CoverageService {
}
