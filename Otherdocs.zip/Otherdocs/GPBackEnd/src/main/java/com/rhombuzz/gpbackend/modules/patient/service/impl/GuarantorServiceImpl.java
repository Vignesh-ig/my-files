package com.rhombuzz.gpbackend.modules.patient.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.dto.request.GuarantorRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.GuarantorResponse;
import com.rhombuzz.gpbackend.modules.patient.entity.Guarantor;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.repository.GuarantorRepository;
import com.rhombuzz.gpbackend.modules.patient.service.GuarantorService;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class GuarantorServiceImpl implements GuarantorService {

    private final GuarantorRepository guarantorRepository;
    private final MedGroupService medGroupService;
    private final PatientService patientService;

    @Override
    public void saveGuarantor(Long patientId, GuarantorRequest request) {
        log.info("saveGuarantor: method called for patientId='{}'", patientId);
        Guarantor guarantor = guarantorRepository.findByPatientId(patientId, request.groupId())
                .map(existingGuarantor -> {
                    log.info("Updating existing Guarantor for patient='{}'", patientId);
                    setGuarantor(existingGuarantor, request);
                    return existingGuarantor;
                })
                .orElseGet(() -> {
                    log.info("Creating new Guarantor for patient='{}'", patientId);
                    return buildGuarantor(patientId, request);
                });
        guarantorRepository.save(guarantor);
        log.info("Guarantor created or updated successfully for patientId='{}'", patientId);
    }

    @Override
    public GuarantorResponse getGuarantor(Long patientId, String groupId) {
        log.info("getGuarantor: method called for patientId='{}'", patientId);
        return guarantorRepository.findByPatientId(patientId, groupId)
                .map(GuarantorResponse::fromEntity)
                .orElseThrow(() -> {
                    log.error("Guarantor is not exist for patientId='{}'", patientId);
                    return new NotFoundException("Guarantor is not exist");
                });
    }

    private Guarantor buildGuarantor(Long patientId, GuarantorRequest request) {
        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Patient patient = patientService.getPatientById(patientId, request.groupId());

        Guarantor guarantor = Guarantor.fromRequest(request);
        guarantor.setPatient(patient);
        guarantor.setMedGroup(medGroup);
        return guarantor;
    }

    private void setGuarantor(Guarantor guarantor, GuarantorRequest request) {
        guarantor.setRelationshipToPatient(request.relationshipToPatient());
        guarantor.setFirstName(request.firstName());
        guarantor.setLastName(request.lastName());
        guarantor.setDateOfBirth(request.dob());
        guarantor.setGender(request.gender());
        guarantor.setCellPhone(request.cellPhone());
        guarantor.setHomePhone(request.homePhone());
        guarantor.setAddress(request.address());
        guarantor.setState(request.state());
        guarantor.setCity(request.city());
        guarantor.setZipCode(request.zipCode());
    }
}

