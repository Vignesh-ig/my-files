package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;

import java.time.LocalDate;

public interface PatientResponse {

    Long getId();
    String getFirstName();
    String getLastName();
    String getPreferredFirstName();
    LocalDate getDob();
    Gender getGender();
    String getCellPhone();
    String getHomePhone();
    String getEmail();
    ContactMethod getOptOut();
    String getStreetAddress();
    String getCity();
    String getZipCode();
    ContactMethod getPreferredContactMethod();
    PreferredLanguage getPreferredLanguage();

}
