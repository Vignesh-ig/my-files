package com.rhombuzz.gpbackend.modules.support.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "tickets", indexes = {
        @Index(name = "idx_ticket_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_ticket_support_id", columnList = "support_id")
})
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "support_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Support support;

    @Column(name = "status", length = 45, nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

    @Lob
    @Column(name = "image", columnDefinition = "LONGBLOB")
    private byte[] image;

    @Column(name = "image_name", length = 45)
    private String imageName;

    @Column(name = "description", length = 200, nullable = false)
    private String description;

    @Column(name = "created_at", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime createdAt;

    @Column(name = "created_by", length = 45, nullable = false)
    private String createdBy;

    @Column(name = "is_admin")
    private boolean isAdmin;

    public enum Status {

        IN_PROGRESS,
        RESOLVED,
        NO_ISSUE,
        IN_ACTIVE,
        MORE_INFO
    }
}
