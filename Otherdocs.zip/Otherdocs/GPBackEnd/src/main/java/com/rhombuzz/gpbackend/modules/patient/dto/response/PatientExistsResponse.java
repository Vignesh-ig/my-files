package com.rhombuzz.gpbackend.modules.patient.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class PatientExistsResponse {
    private boolean exists;
    private Long patientId;
}
