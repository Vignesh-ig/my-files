package com.rhombuzz.gpbackend.modules.patient.service;

import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import com.rhombuzz.gpbackend.modules.appointment.dto.request.SaveFormAppointmentRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.request.*;
import com.rhombuzz.gpbackend.modules.patient.dto.response.DocumentStatusResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponseList;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Validated
public interface PatientService {

    Map<String, Object> savePatient(
            @Valid SavePatientRequest request
    );

    void updatePatient(
            @NotNull @Positive Long id,
            @Valid UpdatePatientRequest request
    );

    @Transactional
    void deletePatient(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Page<PatientResponseList> getPatients(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    );

    PatientResponse getPatient(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void loadPatientsFromCsv(
            @NotNull @ValidFile(contentTypes = "text/csv", extensions = "csv") MultipartFile file,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void uploadDocuments(
            @NotNull List<
                    @ValidFile(
                            contentTypes = {
                                    "application/pdf", "text/plain", "application/msword",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "image/png", "application/vnd.ms-excel", "text/csv",
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "image/jpeg", "image/jpg"
                            },
                            extensions = {"pdf", "txt", "doc", "docx", "png", "xls", "xlsx", "csv", "jpg", "jpeg"}
                    ) MultipartFile> files,
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    DocumentStatusResponse getDocuments(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Resource downloadDocument(
            @NotNull @Positive Long patientId,
            String fileName,
            String folderName,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void deleteDocument(
            @NotNull @Positive Long patientId,
            String fileName,
            String folderName,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Patient getPatientById(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    @Transactional
    void mergePatient(@Valid MergePatientRequest request);

    List<Map<Long, PatientResponseList>> getMergePatients(
            @Valid MergePatientRequest request
    );

    Patient getPatientByPhone(
            @NotBlank @Pattern(regexp = RegexPattern.TEN_DIGITS) String phone,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updatePhoneValid(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            boolean valid
    );

    Map<String, Object> isPatientExists(
            @Valid PatientExistsRequest request
    );

    void updateSubmissionFlagAndDateTime(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            boolean submitted
    );

    void saveFileToS3Bucket(
            @Valid SaveFileRequest request
    );

    void updateSubmissionDateTime(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void saveManualPatient(
            @Valid SaveManualPatientRequest request
    );

    boolean isPatientExists(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Long saveAppointmentFormPatientDetails(
            @Valid SaveFormAppointmentRequest.PatientDetails request,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull LocalDateTime currentDateTime
    );

    void updatePatientHomePhoneByIdAndGroupId(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotBlank @Pattern(regexp = RegexPattern.TEN_DIGITS) String homePhone
    );

    void updatePatientCellPhoneByIdAndGroupId(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotBlank @Pattern(regexp = RegexPattern.TEN_DIGITS) String cellPhone
    );
}
