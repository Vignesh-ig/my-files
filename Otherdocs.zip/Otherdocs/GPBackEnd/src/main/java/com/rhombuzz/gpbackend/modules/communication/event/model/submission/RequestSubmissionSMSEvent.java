package com.rhombuzz.gpbackend.modules.communication.event.model.submission;

import lombok.Getter;

@Getter
public class RequestSubmissionSMSEvent extends RequestSubmissionEvent {
    private final String fromNumber;
    private final String toNumber;
    private final String content;

    public RequestSubmissionSMSEvent(String groupId, Long patientId,
                                     String fromNumber, String toNumber, String content) {
        super(groupId, patientId);
        this.fromNumber = fromNumber;
        this.toNumber = toNumber;
        this.content = content;
    }
}
