package com.rhombuzz.gpbackend.modules.patient.dto.request;

import com.rhombuzz.gpbackend.modules.patient.repository.specification.ReceivedSpecification;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ReceivedSubmissionRequest(
        @NotBlank @Size(min = 10, max = 10) String groupId,
        ReceivedSpecification.ReceivedFilter filter,
        String claimedBy
) {
    @AssertTrue(message = "If filter is CLAIMED_BY then claimedBy must not be blank")
    public boolean isValidClaimedBy() {
        return filter != ReceivedSpecification.ReceivedFilter.CLAIMED_BY
            || (claimedBy != null && !claimedBy.isBlank());
    }
}
