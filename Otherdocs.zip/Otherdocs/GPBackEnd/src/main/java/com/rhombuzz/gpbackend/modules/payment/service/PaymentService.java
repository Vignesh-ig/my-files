package com.rhombuzz.gpbackend.modules.payment.service;

public interface PaymentService {
}
