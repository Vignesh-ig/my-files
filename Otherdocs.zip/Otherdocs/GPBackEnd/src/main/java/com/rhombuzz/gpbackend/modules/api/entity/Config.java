package com.rhombuzz.gpbackend.modules.api.entity;

import com.rhombuzz.gpbackend.modules.api.dto.request.UpdateConfigRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "configs")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Config {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "config_name", nullable = false, length = 45)
    private String configName;

    @Lob
    @Column(name = "config_value", nullable = false, columnDefinition = "TEXT")
    private String configValue;

    @Column(name = "environment", length = 45, nullable = false)
    private String environment;

    @Column(name = "type", length = 45, nullable = false)
    private String type;

    public static Config fromRequest(UpdateConfigRequest request) {
        return Config.builder()
                .configName(request.getConfigName())
                .type(request.getType())
                .build();
    }
}
