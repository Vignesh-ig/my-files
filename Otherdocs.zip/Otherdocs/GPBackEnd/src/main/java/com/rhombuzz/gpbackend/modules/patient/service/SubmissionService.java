package com.rhombuzz.gpbackend.modules.patient.service;

import com.rhombuzz.gpbackend.modules.patient.dto.request.ReceivedSubmissionRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.request.RequestSubmissionRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.AwaitingSubmissionResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.ReceivedSubmissionResponse;
import com.rhombuzz.gpbackend.modules.patient.repository.specification.AwaitingSpecification;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

@Validated
public interface SubmissionService {

    Page<AwaitingSubmissionResponse> getAwaitingSubmissions(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull AwaitingSpecification.AwaitingFilter awaitingFilter,
            Pageable pageable
    );

    Page<ReceivedSubmissionResponse> getReceivedSubmissions(
            @Valid ReceivedSubmissionRequest request,
            Pageable pageable
    );

    void claimSubmission(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateReviewStatus(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateClaimedByAndReviewStatus(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void requestSubmission(
            RequestSubmissionRequest request
    );

    void updateSubmissionStatus(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long patientId,
            boolean success
    );
}
