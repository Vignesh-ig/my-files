package com.rhombuzz.gpbackend.modules.appointment.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record GetAppointmentsRequest(
        @Positive Long providerId,
        @Positive Long locationId,
        @Positive Long serviceId,
        @NotBlank @Size(min = 10, max = 10) String groupId,
        @NotNull LocalDate scheduledDate
) {
}
