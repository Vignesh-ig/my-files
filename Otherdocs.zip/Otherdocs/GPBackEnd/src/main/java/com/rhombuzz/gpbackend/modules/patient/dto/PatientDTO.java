package com.rhombuzz.gpbackend.modules.patient.dto;

import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PatientDTO {
    private Long id;
    private String name;

    public static PatientDTO fromEntity(Patient patient) {
        return PatientDTO.builder()
                .id(patient.getId())
                .name(patient.getFirstName() + " " + patient.getLastName())
                .build();
    }
}
