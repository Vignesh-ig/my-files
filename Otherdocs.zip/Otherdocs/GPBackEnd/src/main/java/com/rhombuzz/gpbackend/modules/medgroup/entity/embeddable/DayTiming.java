package com.rhombuzz.gpbackend.modules.medgroup.entity.embeddable;

import jakarta.persistence.Embeddable;
import lombok.Data;

import java.time.LocalTime;

@Embeddable
@Data
public class DayTiming {
    private LocalTime startTime;
    private LocalTime endTime;
}
