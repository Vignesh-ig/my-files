package com.rhombuzz.gpbackend.modules.intake.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rhombuzz.gpbackend.modules.intake.dto.GuarantorDTO;
import com.rhombuzz.gpbackend.modules.intake.dto.InsuranceDTO;
import com.rhombuzz.gpbackend.modules.intake.dto.PatientDTO;
import com.rhombuzz.gpbackend.modules.intake.dto.request.IntakeRequest;
import com.rhombuzz.gpbackend.modules.intake.service.IntakeService;
import com.rhombuzz.gpbackend.modules.intake.service.PdfService;
import com.rhombuzz.gpbackend.modules.patient.dto.request.GuarantorRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.request.SavePatientInsuranceRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.request.SavePatientRequest;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.GuarantorService;
import com.rhombuzz.gpbackend.modules.patient.service.PatientInsuranceService;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.patient.service.SubmissionService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class IntakeServiceImpl implements IntakeService {

    private final PatientService patientService;
    private final GuarantorService guarantorService;
    private final PatientInsuranceService patientInsuranceService;
    private final ObjectMapper objectMapper;
    private final ActivityService activityService;
    private final SubmissionService submissionService;
    private final PdfService pdfService;

    @Override
    public void saveIntakeForm(JsonNode request) throws JsonProcessingException {
        log.info("Saving intake form");

        IntakeRequest intakeRequest = buildIntakeRequest(request);
        String groupId = intakeRequest.getGroupId();

        String actType = request.path("formName").asText().toUpperCase();

        PatientDTO patient = intakeRequest.getPatient();
        GuarantorDTO guarantor = intakeRequest.getGuarantor();
        InsuranceDTO insurance = intakeRequest.getInsurance();

        String patientName = patient.getFirstName() + " " + patient.getLastName();
        log.info("Saving intake form for patient: {} in group {}", patientName, groupId);

        Long patientId = savePatient(patient, groupId, patientName, actType);

        GuarantorRequest guarantorRequest = getGuarantorRequest(guarantor, groupId);
        guarantorService.saveGuarantor(patientId, guarantorRequest);
        log.info("Saved guarantor for patient: {}", patientName);

        SavePatientInsuranceRequest insuranceRequest = getPatientInsuranceRequest(insurance, patientId, groupId);
        patientInsuranceService.savePatientInsurance(insuranceRequest);
        log.info("Saved insurance for patient: {}", patientName);

        pdfService.savePDF(patientId, groupId, patientName, request);
    }

    private SavePatientInsuranceRequest getPatientInsuranceRequest(InsuranceDTO insurance, Long patientId, String groupId) {
        return new SavePatientInsuranceRequest(
                groupId, patientId, insurance.isHavePrimaryInsurance(), insurance.getPrimaryInsurance(),
                insurance.isHaveSecondaryInsurance(), insurance.getSecondaryInsurance());
    }

    private GuarantorRequest getGuarantorRequest(GuarantorDTO guarantor, String groupId) {
        return new GuarantorRequest(
                groupId, guarantor.getFirstName(), guarantor.getLastName(), guarantor.getDob(),
                guarantor.getRelationshipToPatient(), guarantor.getZipCode(), guarantor.getCellPhone(),
                guarantor.getHomePhone(), guarantor.getGender(), guarantor.getCity(),
                guarantor.getState(), guarantor.getAddress());
    }

    private SavePatientRequest getPatientRequest(PatientDTO patient, String groupId) {
        return new SavePatientRequest(
                groupId, patient.getFirstName(), patient.getLastName(), patient.getDob(),
                patient.getGender(), patient.getHomePhone(), patient.getCellPhone(), patient.getEmail(),
                patient.getZipCode(), patient.getCity(), patient.getState(), patient.getWorkPhone(),
                null, patient.getSsn(), patient.getStreetAddress(), null,
                patient.getPreferredLanguage());
    }

    private Long savePatient(PatientDTO patient, String groupId, String patientName, String actType) {
        SavePatientRequest patientRequest = getPatientRequest(patient, groupId);
        Map<String, Object> savePatient = patientService.savePatient(patientRequest);

        log.info("Saved patient: {}", patientName);
        Long patientId = (Long) savePatient.get("PATIENT_ID");
        String status = (String) savePatient.get("STATUS");

        patientService.updateSubmissionFlagAndDateTime(patientId, groupId, true);
        submissionService.updateClaimedByAndReviewStatus(patientId, groupId);

        Patient savedPatient = patientService.getPatientById(patientId, groupId);
        ActivityRequest activityRequest = ActivityRequest.builder()
                .groupId(groupId)
                .patient(savedPatient)
                .activityType(actType)
                .activityDescription(status.equals("update") ?
                        "Patient (" + patientName + ") has updated the general intake form." :
                        "Patient (" + patientName + ") has submitted the general intake form."
                )
                .build();

        activityService.saveActivity(activityRequest);
        return patientId;
    }

    private IntakeRequest buildIntakeRequest(JsonNode request) throws JsonProcessingException {

        String groupId = request.path("groupId").asText();
        if (groupId == null || groupId.isBlank() || groupId.length() != 10) {
            throw new IllegalArgumentException("Invalid groupId");
        }

        PatientDTO patient = objectMapper.treeToValue(request.get("patient"), PatientDTO.class);
        GuarantorDTO guarantor = objectMapper.treeToValue(request.get("guarantor"), GuarantorDTO.class);
        InsuranceDTO insurance = objectMapper.treeToValue(request.get("insurance"), InsuranceDTO.class);

        Utils.validateObject(patient);
        Utils.validateObject(guarantor);
        Utils.validateObject(insurance);

        return IntakeRequest.builder()
                .groupId(groupId)
                .patient(patient)
                .guarantor(guarantor)
                .insurance(insurance)
                .build();
    }
}
