package com.rhombuzz.gpbackend.modules.patient.controller;

import com.rhombuzz.gpbackend.modules.patient.dto.request.GuarantorRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.GuarantorResponse;
import com.rhombuzz.gpbackend.modules.patient.service.GuarantorService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/guarantors")
@Validated
public class GuarantorController {
    private final GuarantorService guarantorService;

    @GetMapping("/patients/{patientId}")
    public ResponseEntity<GuarantorResponse> getGuarantor(
            @PathVariable @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        GuarantorResponse response = guarantorService.getGuarantor(patientId, groupId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/patients/{patientId}")
    public ResponseEntity<Void> saveGuarantor(
            @PathVariable @NotNull Long patientId,
            @RequestBody @Valid GuarantorRequest request
    ) {
        guarantorService.saveGuarantor(patientId, request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
