package com.rhombuzz.gpbackend.util;

public final class AccessType {

    private AccessType() {
    }

    public static final String ADMIN = "'ADMIN'";
    public static final String MANAGEMENT = "'MANAGEMENT'";
    public static final String NORMAL_USER = "'NORMAL_USER'";
    public static final String SUPER_USER = "'SUPER_USER'";
    public static final String RESTRICTED_USER = "'RESTRICTED_USER'";

    public static final String DASHBOARD_STANDARD = "'SUPER_USER', 'NORMAL_USER', 'RESTRICTED_USER'";
    public static final String SUPER_AND_NORMAL = "'SUPER_USER', 'NORMAL_USER'";
    public static final String ADMIN_AND_SUPER  = "'ADMIN', 'SUPER_USER'";
    public static final String ADMIN_AND_GROUP = "'ADMIN', 'SUPER_USER', 'NORMAL_USER', 'RESTRICTED_USER'";
    public static final String ALL = "'ADMIN', 'MANAGEMENT', 'NORMAL_USER', 'SUPER_USER', 'RESTRICTED_USER'";
}
