package com.rhombuzz.gpbackend.modules.payment.repository;

import com.rhombuzz.gpbackend.modules.payment.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
}
