package com.rhombuzz.gpbackend.modules.api.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class UpdateConfigRequest {

    @NotBlank(message = "Config name must not be blank")
    @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE,
            message = "Config name must be uppercase and can only contain alphabets, numbers, underscores")
    private String configName;

    @NotBlank(message = "Config value must not be blank")
    private String configValue;

    @NotBlank(message = "Config type must not be blank")
    @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE,
            message = "Config type must be uppercase and can only contain alphabets, numbers, underscores")
    private String type;
}
