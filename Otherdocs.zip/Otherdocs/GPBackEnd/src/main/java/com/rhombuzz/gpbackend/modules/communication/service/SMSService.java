package com.rhombuzz.gpbackend.modules.communication.service;

import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSSendRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSSendResponse;

public interface SMSService {
    SMSSendResponse sendSMS(SMSSendRequest smsSendRequest);
}
