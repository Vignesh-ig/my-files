package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupFlag;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class UpdateDashboardFlagRequest {
    @NotBlank(message = "Group ID cannot be blank")
    @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
    @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
    String groupId;

    @NotNull(message = "Flag type cannot be null")
    MedGroupFlag.DashboardFlag flag;

    @NotNull(message = "Flag value cannot be null")
    Boolean value;

    @Email
    String formSubmissionAlertOfficeEmail;
    @Email
    String appointmentAlertOfficeEmail;
}
