package com.rhombuzz.gpbackend.modules.communication.event.listener;

import com.rhombuzz.gpbackend.modules.communication.dto.request.EmailRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSSendRequest;
import com.rhombuzz.gpbackend.modules.communication.event.model.generic.EmailCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.event.model.generic.SMSCommunicationEvent;
import com.rhombuzz.gpbackend.modules.communication.service.EmailService;
import com.rhombuzz.gpbackend.modules.communication.service.SMSService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@RequiredArgsConstructor
@Service
public class CommunicationEventListener {
    private final SMSService smsService;
    private final EmailService emailService;

    @EventListener
    @Async
    public void handleSmsEvent(SMSCommunicationEvent event) {
        smsService.sendSMS(new SMSSendRequest(
                event.getFromNumber(),
                event.getToNumber(),
                event.getContent()
        ));
    }

    @EventListener
    @Async
    public void handleEmailEvent(EmailCommunicationEvent event) {
        emailService.sendEmail(new EmailRequest(
                event.getFromEmail(),
                event.getToEmail(),
                event.getSubject(),
                event.getContent()
        ));
    }
}
