package com.rhombuzz.gpbackend.modules.communication.event.model.generic;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Data
public abstract class CommunicationEvent {
}
