package com.rhombuzz.gpbackend.integration.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record GetIntegrationConfigRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        String groupId,

        @NotBlank(message = "Config name must not be blank")
        @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE,
                message = "Config name must be uppercase and can only contain alphabets, numbers, underscores")
        String configName,

        @NotBlank(message = "Config type must not be blank")
        @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE,
                message = "Integrates with must be uppercase and can only contain alphabets, numbers, underscores")
        String integratesWith
) {
}
