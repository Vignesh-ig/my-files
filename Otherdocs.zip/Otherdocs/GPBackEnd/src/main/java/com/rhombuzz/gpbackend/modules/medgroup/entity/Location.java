package com.rhombuzz.gpbackend.modules.medgroup.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "locations", indexes = {
        @Index(name = "idx_location_med_group_id", columnList = "med_group_id")
})
@Builder
public class Location {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "name", length = 45)
    private String name;

    @Column(name = "address", length = 100, nullable = false)
    private String address;

    @Column(name = "location_hours")
    private Integer locationHours;//Todo: Need to check.

    @Column(name = "location_reference", length = 45)
    private String locationReference;

    @Column(name = "location_reference_code", length = 45)
    private String locationReferenceCode;

    @Column(name = "google_place_id", length = 200)
    private String googlePlaceId;

    @Column(name = "appointment_color", length = 8)
    private String appointmentColor;//Todo: Need to check.

    @Column(name = "call_appointment_id", length = 45)
    private String callAppointmentId;//Todo: Need to check.

    @Column(name = "is_primary")
    private boolean isPrimary;

    public Location(Long id) {
        this.id = id;
    }
}
