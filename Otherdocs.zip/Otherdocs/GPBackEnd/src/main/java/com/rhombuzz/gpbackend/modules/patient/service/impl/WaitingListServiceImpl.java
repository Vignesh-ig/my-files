package com.rhombuzz.gpbackend.modules.patient.service.impl;

import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.LocationService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.dto.request.WaitingListRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.WaitingListResponse;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.entity.WaitingList;
import com.rhombuzz.gpbackend.modules.patient.repository.WaitingListRepository;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.patient.service.WaitingListService;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import com.rhombuzz.gpbackend.modules.medgroup.service.ServiceManagement;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@org.springframework.stereotype.Service
@RequiredArgsConstructor
@Slf4j
public class WaitingListServiceImpl implements WaitingListService {

    private final WaitingListRepository waitingListRepository;
    private final MedGroupService medGroupService;
    private final ProviderService providerService;
    private final ServiceManagement serviceManagement;
    private final LocationService locationService;
    private final PatientService patientService;

    @Override
    public void saveWaitingList(WaitingListRequest request) {
        log.info("saveWaitingList: method called for patientId='{}', groupId='{}'", request.patientId(), request.groupId());
        if (checkWaitingListExist(request.patientId(), request.groupId())) {
            log.error("WaitingList already exist for patientId='{}', groupId='{}'", request.patientId(), request.groupId());
            throw new ConflictException("WaitingList already exist.");
        }
        WaitingList waitingList = buildWaitingList(request);
        waitingListRepository.save(waitingList);

        //Todo: add data to MedGroupInsights
        log.info("patientId='{}' was added to waitingList from groupId='{}'", request.patientId(), request.groupId());
    }

    @Override
    public void updateWaitingList(WaitingListRequest request) {
        log.info("updateWaitingList: method called for patientId='{}', groupId='{}'", request.patientId(), request.groupId());
        WaitingList waitingList = getWaitingList(request.patientId(), request.groupId());
        setWaitingList(waitingList, request);
        waitingListRepository.save(waitingList);
        log.info("WaitingList was updated for patientId='{}', groupId='{}'", request.patientId(), request.groupId());
    }

    @Transactional
    @Override
    public void deleteWaitingList(Long id, Long patientId, String groupId) {
        log.info("deleteWaitingList: method called for id='{}', patientId='{}', groupId='{}'", id, patientId, groupId);
        if (!waitingListRepository.existsById(id, patientId, groupId)) {
            log.error("WaitingList record is not present for id='{}', patientId='{}', groupId='{}'", id, patientId, groupId);
            throw new NotFoundException("WaitingList record is not present.");
        }
        waitingListRepository.deleteById(id, patientId, groupId);
        log.info("WaitingList is removed for id='{}', patientId='{}', groupId='{}'", id, patientId, groupId);
    }

    @Override
    public Page<WaitingListResponse> getWaitingLists(String groupId, Pageable pageable) {
        log.info("getWaitingLists: method called for groupId='{}'", groupId);
        return waitingListRepository.findByGroupId(groupId, pageable)
                .map(WaitingListResponse::fromEntity);
    }

    @Override
    public WaitingList getWaitingList(Long patientId, String groupId) {
        log.info("getWaitingList: method called for patientId='{}', groupId='{}'", patientId, groupId);
        return waitingListRepository.findByPatientId(patientId, groupId)
                .orElseThrow(() -> {
                    log.info("No waitingList record found for patientId='{}', groupId='{}'", patientId, groupId);
                    return new NotFoundException("No waiting list record found");
                });
    }

    @Override
    public boolean checkWaitingListExist(Long patientId, String groupId) {
        log.info("checkWaitingListExist: method called for patientId='{}', groupId='{}'", patientId, groupId);
        return waitingListRepository.existsByPatientId(patientId, groupId);
    }

    @Override
    public void updateAlertSent(Long patientId, String groupId) {
        log.info("updateAlertSent: method called for patientId='{}', groupId='{}'", patientId, groupId);
        WaitingList waitingList = getWaitingList(patientId, groupId);
        waitingList.setAlertSent(waitingList.getAlertSent() + 1);
        waitingListRepository.save(waitingList);
        log.info("alertSent incremented by 1 for patientId='{}', groupId='{}'", patientId, groupId);
    }

    private void setWaitingList(WaitingList waitingList, WaitingListRequest request) {
        setProviderServiceLocation(waitingList, request);
        waitingList.setWaitlistType(request.waitlistType());
        waitingList.setDate(request.date());
    }

    private WaitingList buildWaitingList(WaitingListRequest request) {
        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Patient patient = patientService.getPatientById(request.patientId(), request.groupId());
        WaitingList waitingList = WaitingList.fromRequest(request);
        waitingList.setMedGroup(medGroup);
        waitingList.setPatient(patient);
        setProviderServiceLocation(waitingList, request);
        return waitingList;
    }

    private void setProviderServiceLocation(WaitingList waitingList, WaitingListRequest request) {
        Provider provider = providerService.getProviderById(request.providerId(), request.groupId());
        Location location = locationService.getLocationById(request.locationId(), request.groupId());
        Service service = serviceManagement.getServiceEntity(request.serviceId(), request.groupId());
        waitingList.setService(service);
        waitingList.setLocation(location);
        waitingList.setProvider(provider);
    }
}