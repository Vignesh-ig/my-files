package com.rhombuzz.gpbackend.modules.auth.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SaveUserRequest {

    @NotBlank(message = "Group ID cannot be blank")
    @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
    @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
    private String groupId;

    @NotBlank(message = "Role ID cannot be blank")
    @Pattern(regexp = RegexPattern.ROLE_ID, message = "Role ID must start with 'rol_' followed by 15 to 17 alphanumeric characters.")
    private String roleId;

    @NotBlank(message = "Username cannot be blank")
    @Size(min = 7, max = 15, message = "Username must be between 7 and 15 characters long")
    @Pattern(regexp = RegexPattern.USER_NAME, message = "Username must contain only letters, digits and _+=,@-.")
    private String username;

    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Email should be valid")
    @Size(max = 45, message = "Email must be at most 45 characters long")
    private String email;

    @NotBlank(message = "Password cannot be blank")
    @Pattern(regexp = RegexPattern.PASSWORD,
    message = "Password must be at least 8 characters long, contain at least one uppercase letter, one number, and one special character.")
    private String password;

    @NotBlank(message = "First name cannot be blank")
    @Size(max = 45, message = "First name must be at most 45 characters long")
    @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "First name must contain only letters")
    private String firstName;

    @NotBlank(message = "Last name cannot be blank")
    @Size(max = 45, message = "Last name must be at most 45 characters long")
    @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Last name must contain only letters")
    private String lastName;
}
