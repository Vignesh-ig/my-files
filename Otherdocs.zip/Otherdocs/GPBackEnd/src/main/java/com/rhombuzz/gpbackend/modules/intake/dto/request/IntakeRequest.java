package com.rhombuzz.gpbackend.modules.intake.dto.request;

import com.rhombuzz.gpbackend.modules.intake.dto.GuarantorDTO;
import com.rhombuzz.gpbackend.modules.intake.dto.InsuranceDTO;
import com.rhombuzz.gpbackend.modules.intake.dto.PatientDTO;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class IntakeRequest {

    @NotBlank
    @Size(min = 10, max = 10)
    private String groupId;

    @NotNull
    @Valid
    private PatientDTO patient;

    @NotNull
    @Valid
    private GuarantorDTO guarantor;

    @NotNull
    @Valid
    private InsuranceDTO insurance;

}