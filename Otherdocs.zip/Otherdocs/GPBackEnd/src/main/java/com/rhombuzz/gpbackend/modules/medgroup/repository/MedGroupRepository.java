package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.medgroup.dto.AWSDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.MedGroupDTO;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

public interface MedGroupRepository extends JpaRepository<MedGroup, String> {
    Optional<MedGroup> findByGroupId(String groupId);

    @Query("SELECT mg.timeZone FROM MedGroup mg WHERE mg.groupId = ?1")
    Optional<TimeZone> getTimeZone(String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.medgroup.dto.AWSDTO(mg.groupName, mg.s3AccessKey, mg.s3SecretKey) FROM MedGroup mg WHERE mg.groupId = ?1")
    Optional<AWSDTO> getAWSAccess(String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.medgroup.dto.MedGroupDTO(mg.groupId, mg.groupName) FROM MedGroup mg")
    List<MedGroupDTO> getMedGroupNames();

    @Query("SELECT COUNT(mg) > 0 FROM MedGroup mg WHERE mg.groupId = ?1")
    boolean existsByGroupId(String groupId);

    @Query("SELECT mg.appointmentType FROM MedGroup mg WHERE mg.groupId = ?1")
    Optional<MedGroup.AppointmentType> findAppointmentType(String groupId);

    @Query("SELECT mg.groupDescription FROM MedGroup mg WHERE mg.groupId = ?1")
    String findGroupDescriptionByGroupId(String groupId);
}
