package com.rhombuzz.gpbackend.modules.communication.event.model.submission;

import lombok.Getter;

@Getter
public abstract class RequestSubmissionEvent {
    private final String groupId;
    private final Long patientId;

    protected RequestSubmissionEvent(String groupId, Long patientId) {
        this.groupId = groupId;
        this.patientId = patientId;
    }
}
