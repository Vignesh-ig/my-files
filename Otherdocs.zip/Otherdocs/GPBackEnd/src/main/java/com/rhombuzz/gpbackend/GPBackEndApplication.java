package com.rhombuzz.gpbackend;

import io.github.cdimascio.dotenv.Dotenv;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.scheduling.annotation.EnableScheduling;

import static java.util.Arrays.stream;

@SpringBootApplication
@EnableScheduling
@EnableSpringDataWebSupport(pageSerializationMode = EnableSpringDataWebSupport.PageSerializationMode.VIA_DTO)
@Slf4j
public class GPBackEndApplication {

    public static void main(String[] args) {
        dotEnvSafeCheck();

        SpringApplication.run(GPBackEndApplication.class, args);
    }

    enum EnvVars {
        DB_USERNAME,
        DB_PASSWORD,
        DB_HOST,
        DB_PORT,
        DB_NAME,
        PROFILE,
        SERVER_PORT,
        OKTA_OAUTH2_ISSUER,
        OKTA_OAUTH2_AUDIENCE,
        TEMPLATES_PATH,
        TEMPLATES_OUTPUT_PATH,
        PUPPETEER_SERVER_PATH,
        PUPPETEER_SERVER_PORT
    }

    private static void dotEnvSafeCheck() {
        final var dotenv = Dotenv.configure()
                .ignoreIfMissing()
                .load();

        final var profile = dotenv.get(EnvVars.PROFILE.name(), "").toLowerCase();

        stream(EnvVars.values())
                .map(EnvVars::name)
                .filter(varName -> {
                    if (varName.equals(EnvVars.PUPPETEER_SERVER_PATH.name()) && !"dev".equals(profile)) {
                        return false;
                    }
                    return dotenv.get(varName, "").isEmpty();
                })
                .findFirst()
                .ifPresent(varName -> {
                    log.error("[Fatal] Missing or empty environment variable: {}", varName);
                    System.exit(1);
                });
    }

}
