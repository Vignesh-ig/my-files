package com.rhombuzz.gpbackend.modules.appointment.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AppointmentFormInitResponse {
    private boolean telehealthEnabled;
    private boolean bookingFeeEnabled;
    private MedGroup.AppointmentType appointmentType;
    private String appointmentRequestPopupMessage;
    private String groupDescription;
    private String timeZone;

    private AppointmentFormBuilderSettingResponse formBuilderSetting;
}
