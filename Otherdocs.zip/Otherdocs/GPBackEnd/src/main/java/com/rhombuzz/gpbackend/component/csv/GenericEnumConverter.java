package com.rhombuzz.gpbackend.component.csv;

import com.opencsv.bean.AbstractBeanField;
import com.rhombuzz.gpbackend.exception.domain.BadRequestException;

import java.util.Arrays;

public class GenericEnumConverter extends AbstractBeanField<Enum<?>, String> {
    @Override
    protected Object convert(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }

        Class<?> fieldType = getField().getType();

        if (!fieldType.isEnum()) {
            throw new IllegalArgumentException("Field type must be an enum");
        }

        try {
            Object[] enumConstants = fieldType.getEnumConstants();
            for (Object enumConstant : enumConstants) {
                Enum<?> e = (Enum<?>) enumConstant;
                if (e.name().equalsIgnoreCase(value.trim())) {
                    return e;
                }
            }
            throw new IllegalArgumentException();
        } catch (IllegalArgumentException e) {
            throw new BadRequestException(
                    "Invalid value '" + value + "' for enum " + fieldType.getSimpleName() +
                            ". Valid values: " + Arrays.toString(fieldType.getEnumConstants())
            );
        }
    }
}
