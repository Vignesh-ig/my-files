package com.rhombuzz.gpbackend.modules.communication.service.patient;

import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.validation.annotation.Validated;

@Validated
public interface TemplateProcessor {

    String processTemplate(
            @NotNull Patient patient,
            Appointment appointment,
            @NotBlank String templateContent
    );
}
