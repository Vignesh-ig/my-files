package com.rhombuzz.gpbackend.modules.task.repository;

import com.rhombuzz.gpbackend.modules.task.entity.Activity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ActivityRepository extends JpaRepository<Activity, Long> {

    @Query("SELECT a FROM Activity a WHERE a.medGroup.groupId = ?1 ORDER BY a.dateTime DESC")
    Page<Activity> findByGroupId(String groupId, Pageable pageable);

    @Query("SELECT a FROM Activity a WHERE a.patient.id = ?1 AND a.medGroup.groupId = ?2 ORDER BY a.dateTime DESC")
    Page<Activity> findByPatientId(Long patientId, String groupId, Pageable pageable);
}
