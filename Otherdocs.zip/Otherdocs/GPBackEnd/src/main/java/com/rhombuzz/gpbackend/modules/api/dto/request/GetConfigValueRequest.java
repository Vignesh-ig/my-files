package com.rhombuzz.gpbackend.modules.api.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record GetConfigValueRequest(

        @NotBlank(message = "Config name must not be blank")
        @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE,
                 message = "Config name must be uppercase and can only contain alphabets, numbers, underscores")
        String configName,

        @NotBlank(message = "Config type must not be blank")
        @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE,
                message = "Config type must be uppercase and can only contain alphabets, numbers, underscores")
        String type
) {
}
