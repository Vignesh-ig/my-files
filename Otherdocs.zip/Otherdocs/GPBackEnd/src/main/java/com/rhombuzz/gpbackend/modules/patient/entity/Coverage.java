package com.rhombuzz.gpbackend.modules.patient.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "coverages", indexes = {
        @Index(name = "idx_coverage_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_coverage_patient_id", columnList = "patient_id")
})
public class Coverage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @Column(name = "de_ind_in_limit_amt", precision = 5, scale = 2)
    private BigDecimal deIndInLimitAmt;

    @Column(name = "de_ind_in_applied_amt", precision = 5, scale = 2)
    private BigDecimal deIndInAppliedAmt;

    @Column(name = "de_ind_in_remaining_amt", precision = 5, scale = 2)
    private BigDecimal deIndInRemainingAmt;

    @Column(name = "de_ind_out_limit_amt", precision = 5, scale = 2)
    private BigDecimal deIndOutLimitAmt;

    @Column(name = "de_ind_out_applied_amt", precision = 5, scale = 2)
    private BigDecimal deIndOutAppliedAmt;

    @Column(name = "de_ind_out_remaining_amt", precision = 5, scale = 2)
    private BigDecimal deIndOutRemainingAmt;

    @Column(name = "de_fam_in_limit_amt", precision = 5, scale = 2)
    private BigDecimal deFamInLimitAmt;

    @Column(name = "de_fam_in_applied_amt", precision = 5, scale = 2)
    private BigDecimal deFamInAppliedAmt;

    @Column(name = "de_fam_in_remaining_amt", precision = 5, scale = 2)
    private BigDecimal deFamInRemainingAmt;

    @Column(name = "de_i_fam_out_limit_amt", precision = 5, scale = 2)
    private BigDecimal deIFamOutLimitAmt;

    @Column(name = "de_i_fam_out_applied_amt", precision = 5, scale = 2)
    private BigDecimal deIFamOutAppliedAmt;

    @Column(name = "de_i_fam_out_remaining_amt", precision = 5, scale = 2)
    private BigDecimal deIFamOutRemainingAmt;

    @Column(name = "coinsurance_in_benefit", precision = 5, scale = 2)
    private BigDecimal coinsuranceInBenefit;

    @Column(name = "co_insurance_in_service_type", length = 45)
    private String coInsuranceInServiceType;

    @Column(name = "co_insurance_in_messages", length = 400)
    private String coInsuranceInMessages;

    @Column(name = "co_insurance_out_benefit", precision = 5, scale = 2)
    private BigDecimal coInsuranceOutBenefit;

    @Column(name = "co_insurance_out_service_type", length = 45)
    private String coInsuranceOutServiceType;

    @Column(name = "co_insurance_out_messages", length = 400)
    private String coInsuranceOutMessages;

    @Column(name = "co_pay_in_payment", precision = 5, scale = 2)
    private BigDecimal coPayInPayment;

    @Column(name = "co_pay_in_service_type", length = 45)
    private String coPayInServiceType;

    @Column(name = "co_pay_in_messages", length = 45)
    private String coPayInMessages;

    @Column(name = "co_pay_not_payment", precision = 5, scale = 2)
    private BigDecimal coPayNotPayment;

    @Column(name = "co_pay_not_service_type", length = 45)
    private String coPayNotServiceType;

    @Column(name = "co_pay_not_messages", length = 45)
    private String coPayNotMessages;

    @Column(name = "limitation_benefit_amount", precision = 5, scale = 2)
    private BigDecimal limitationBenefitAmount;

    @Column(name = "limitation_service_type", length = 450)
    private String limitationServiceType;

    @Column(name = "limitation_messages", length = 450)
    private String limitationMessages;

    @Column(name = "pocket_ind_in_limit_amt", precision = 5, scale = 2)
    private BigDecimal pocketIndInLimitAmt;

    @Column(name = "pocket_ind_in_applied_amt", precision = 5, scale = 2)
    private BigDecimal pocketIndInAppliedAmt;

    @Column(name = "pocket_ind_in_remaining_amt", precision = 5, scale = 2)
    private BigDecimal pocketIndInRemainingAmt;

    @Column(name = "pocket_ind_out_limit_amt", precision = 5, scale = 2)
    private BigDecimal pocketIndOutLimitAmt;

    @Column(name = "pocket_ind_out_applied_amt", precision = 5, scale = 2)
    private BigDecimal pocketIndOutAppliedAmt;

    @Column(name = "pocket_ind_out_remaining_amt", precision = 5, scale = 2)
    private BigDecimal pocketIndOutRemainingAmt;

    @Column(name = "pocket_fam_in_limit_amt", precision = 5, scale = 2)
    private BigDecimal pocketFamInLimitAmt;

    @Column(name = "pocket_fam_in_applied_amt", precision = 5, scale = 2)
    private BigDecimal pocketFamInAppliedAmt;

    @Column(name = "pocket_fam_in_remaining_amt", precision = 5, scale = 2)
    private BigDecimal pocketFamInRemainingAmt;

    @Column(name = "pocket_fam_out_limit_amt", precision = 5, scale = 2)
    private BigDecimal pocketFamOutLimitAmt;

    @Column(name = "pocket_fam_out_applied_amt", precision = 5, scale = 2)
    private BigDecimal pocketFamOutAppliedAmt;

    @Column(name = "pocket_fam_out_remaining_amt", precision = 5, scale = 2)
    private BigDecimal pocketFamOutRemainingAmt;
}
