package com.rhombuzz.gpbackend.integration.repository;

import com.rhombuzz.gpbackend.integration.dto.request.SaveIntegrationConfigRequest;
import com.rhombuzz.gpbackend.integration.entity.IntegrationConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface IntegrationConfigRepository extends JpaRepository<IntegrationConfig, Long> {

    @Query("SELECT ic.configValue FROM IntegrationConfig ic WHERE ic.medGroup.groupId = ?1 " +
            "AND ic.configName = ?2 AND ic.integratesWith = ?3")
    Optional<String> getConfigValue(String groupId, String configName, String integratesWith);

    @Query("SELECT ic FROM IntegrationConfig ic WHERE ic.medGroup.groupId = " +
            ":#{#request.groupId()} AND ic.configName = :#{#request.configName()} " +
            "AND ic.integratesWith = :#{#request.integratesWith()}")
    Optional<IntegrationConfig> getIntegrationConfig(SaveIntegrationConfigRequest request);

}
