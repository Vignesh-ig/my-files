package com.rhombuzz.gpbackend.modules.communication.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "notifications", indexes = {
        @Index(name = "idx_notification_med_group_id", columnList = "med_group_id")
})
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime dateTime;

    @Lob
    @Column(name = "message", nullable = false, columnDefinition = "TEXT")
    private String message;

    @Column(name = "priority", length = 45)
    @Enumerated(EnumType.STRING)
    private Priority priority;

    @Column(name = "is_hidden")
    private boolean isHidden;

    @Column(name = "is_seen")
    private boolean isSeen;

    public enum Priority {
        NORMAL,
        HIGH,
        SEVERE
    }
}
