package com.rhombuzz.gpbackend.modules.communication.service;

import com.rhombuzz.gpbackend.modules.communication.dto.request.NotificationRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.NotificationResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Map;

@Validated
public interface NotificationService {

    void saveNotification(
            @Valid NotificationRequest request
    );

    @Transactional
    List<NotificationResponse> getNotifications(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<NotificationResponse> getNotifications();

    void hideNotification(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void showNotification(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Map<String, Long> getNotificationsCount(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
