package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupInsights;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public record GetInsightsRangeRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Source type cannot be null")
        MedGroupInsights.SourceType sourceType,

        @NotNull(message = "Start date cannot be null")
        @PastOrPresent
        LocalDate startDate,

        @NotNull(message = "End date cannot be null")
        @PastOrPresent (message = "End date must be in the past or present")
        LocalDate endDate
) {
}
