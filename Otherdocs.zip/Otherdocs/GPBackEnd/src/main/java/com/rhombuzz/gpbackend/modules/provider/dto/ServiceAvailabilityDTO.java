package com.rhombuzz.gpbackend.modules.provider.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.time.LocalTime;
import java.util.List;

public record ServiceAvailabilityDTO(

        @Positive(message = "ID must be a positive number")
        Long id,

        @NotNull(message = "Start time cannot be null")
        LocalTime startTime,

        @NotNull(message = "End time cannot be null")
        LocalTime endTime,

        @NotNull(message = "Location ID cannot be null")
        @Positive(message = "Location ID must be a positive number")
        Long locationId,

        @NotEmpty(message = "Service IDs cannot be empty")
        List<@NotNull(message = "Service ID cannot be null") @Positive(message = "Service ID must be a positive number") Long> serviceIds
) {
}
