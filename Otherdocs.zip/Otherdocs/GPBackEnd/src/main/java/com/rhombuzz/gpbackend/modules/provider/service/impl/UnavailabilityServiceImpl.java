package com.rhombuzz.gpbackend.modules.provider.service.impl;

import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveUnavailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.UnavailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.provider.entity.Unavailability;
import com.rhombuzz.gpbackend.modules.provider.repository.UnavailabilityRepository;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import com.rhombuzz.gpbackend.modules.provider.service.UnavailabilityService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class UnavailabilityServiceImpl implements UnavailabilityService {
    private static final String ACTIVITY_TYPE = "MANAGE AVAILABILITY";

    private final UnavailabilityRepository unavailabilityRepository;
    private final MedGroupService medGroupService;
    private final ProviderService providerService;
    private final ActivityService activityService;

    @Override
    public void saveUnavailability(SaveUnavailabilityRequest request) {
        log.info("Saving unavailability for group: {}", request.groupId());

        if (!medGroupService.isMedGroupExists(request.groupId())) {
            log.error("MedGroup not found with ID: {}", request.groupId());
            throw new NotFoundException("MedGroup not found");
        }

        if (!providerService.isProviderExists(request.providerId(), request.groupId())) {
            log.error("Provider not found with ID: {}", request.providerId());
            throw new NotFoundException("Provider not found");
        }

        MedGroup medGroup = new MedGroup(request.groupId());
        Provider provider = new Provider(request.providerId());

        if (unavailabilityRepository.exists(request.providerId(), request.groupId(), request.date())) {
            log.error("Unavailability already exists for group {}", request.groupId());
            throw new ConflictException("Unavailability already exists");
        }

        Unavailability unavailability = Unavailability.builder()
                .medGroup(medGroup)
                .provider(provider)
                .exceptionDate(request.date())
                .reason(request.reason())
                .build();

        unavailabilityRepository.save(unavailability);
        log.info("Unavailability saved successfully");

        String description = String.format("The unavailable date %s got added for provider %s by user (%s).",
                request.date(), provider.getName(), Utils.getCurrentUsername());
        saveActivity(request.groupId(), description, provider);
    }

    @Override
    public List<UnavailabilityResponse> getUnavailabilities(Long providerId, String groupId) {
        log.info("Retrieving unavailability for group: {}", providerId);
        return unavailabilityRepository.findByProviderId(providerId, groupId).stream()
                .map(UnavailabilityResponse::fromEntity)
                .toList();
    }

    @Override
    @Transactional
    public void deleteUnavailability(Long id, Long providerId, String groupId) {
        log.info("Deleting unavailability for group: {}", id);
        Unavailability unavailability = getUnavailability(id, providerId, groupId);

        unavailabilityRepository.deleteById(id, providerId, groupId);
        log.info("Unavailability deleted successfully");

        String description = String.format("The unavailable date %s got removed for provider %s by user (%s).",
                unavailability.getExceptionDate(), unavailability.getProvider().getName(), Utils.getCurrentUsername());
        saveActivity(groupId, description, unavailability.getProvider());
    }

    private Unavailability getUnavailability(Long id, Long providerId, String groupId) {
        return unavailabilityRepository.findById(id, providerId, groupId)
                .orElseThrow(() -> {
                    log.error("Unavailability not found with ID: {}", id);
                    return new NotFoundException("Unavailability not found");
                });
    }

    private void saveActivity(String groupId, String description, Provider provider) {
        ActivityRequest activityRequest = new ActivityRequest() {{
            setGroupId(groupId);
            setProvider(provider);
            setActivityDescription(description);
            setActivityType(ACTIVITY_TYPE);
        }};

        activityService.saveActivity(activityRequest);
    }
}
