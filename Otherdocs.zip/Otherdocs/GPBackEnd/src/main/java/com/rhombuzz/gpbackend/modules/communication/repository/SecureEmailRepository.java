package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.entity.SecureEmail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SecureEmailRepository extends JpaRepository<SecureEmail, Long> {
}
