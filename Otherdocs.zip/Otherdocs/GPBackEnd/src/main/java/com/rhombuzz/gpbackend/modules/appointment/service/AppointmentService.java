package com.rhombuzz.gpbackend.modules.appointment.service;

import com.rhombuzz.gpbackend.modules.appointment.dto.request.*;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.AllAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormInitResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.PatientAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentFormType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Validated
public interface AppointmentService {

    List<Date> getAvailableDates(
            @Valid GetAvailableDatesRequest request,
            AppointmentFormType formType
    );

    List<Time> getAvailableSlots(
            @Valid GetAvailableSlotsRequest request,
            AppointmentFormType formType
    );

    void saveManualAppointment(
            @Valid SaveManualAppointmentRequest request
    );

    Page<PatientAppointmentResponse> getPatientAppointments(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    );

    void updateAppointmentStatus(
            @NotNull @Positive Long id,
            @Valid UpdateAppointmentStatusRequest request
    );

    Set<LocalDate> getAvailableAppointmentDates(
            @Valid GetAvailableAppointmentDatesRequest request
    );

    Page<AllAppointmentResponse> getAppointmentsByDate(
            @Valid GetAppointmentsRequest request,
            Pageable pageable
    );

    Map<String, Object> getRecentNextPreviousDates(
            @Valid GetAppointmentsRequest request
    );

    void savePatientConfirmed(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void saveFormAppointment(
            @Valid SaveFormAppointmentRequest request
    );

    AppointmentFormInitResponse getAppointmentFormInitData(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void confirmAppointment(
            @NotNull @Positive Long id,
            @Valid ConfirmAppointmentRequest request
    );

    void rescheduleAppointment(
            @NotNull @Positive Long id,
            @Valid RescheduleAppointmentRequest request,
            AppointmentFormType formType
    );

    void cancelAppointment(
            @NotNull @Positive Long id,
            @Valid CancelAppointmentRequest request,
            AppointmentFormType formType
    );

    void denyAppointment(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long patientId
    );

    Page<PatientAppointmentResponse> getPatientConfirmedAppointments(
            @NotNull @Positive Long patientId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    );
}
