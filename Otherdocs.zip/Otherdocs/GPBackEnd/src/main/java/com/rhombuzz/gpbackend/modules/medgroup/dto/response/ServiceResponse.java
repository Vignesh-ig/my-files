package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Builder
@Data
public class ServiceResponse {
    Long id;
    String serviceName;
    int duration;
    String reference;
    String colorCode;
    boolean visibleToPatient;
    boolean recall;
    boolean allowReminder;
    Integer recallPeriod;
    BigDecimal bookingFeeAmount;
    Service.VisitType visitType;
}