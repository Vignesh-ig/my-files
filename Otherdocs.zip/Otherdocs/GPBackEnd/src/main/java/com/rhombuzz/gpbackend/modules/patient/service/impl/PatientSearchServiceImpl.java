package com.rhombuzz.gpbackend.modules.patient.service.impl;

import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.patient.dto.request.AdvancedSearchPatientRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponseList;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.repository.PatientRepository;
import com.rhombuzz.gpbackend.modules.patient.repository.specification.PatientSearchSpecification;
import com.rhombuzz.gpbackend.modules.patient.service.PatientSearchService;
import jakarta.persistence.criteria.Expression;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class PatientSearchServiceImpl implements PatientSearchService {

    private final PatientRepository patientRepository;

    @Override
    public Page<PatientResponseList> advancedSearchPatients(AdvancedSearchPatientRequest request, Pageable pageable) {

        Specification<Patient> spec = PatientSearchSpecification.hasGroupId(request.groupId())
                .and(buildSpecification(request.criteria().getFirst()));

        for (int i = 1; i < request.criteria().size(); i++) {
            Specification<Patient> currentSpec = buildSpecification(request.criteria().get(i));
            if (currentSpec != null) {
                AdvancedSearchPatientRequest.LogicalOperator logicalOperator = request.criteria().get(i).logicalOperator();
                if (logicalOperator == null || logicalOperator == AdvancedSearchPatientRequest.LogicalOperator.AND) {
                    spec = spec.and(currentSpec);
                } else {
                    spec = spec.or(currentSpec);
                }
            }
        }

        return patientRepository.findBy(spec,
                query -> query
                        .as(PatientResponseList.class)
                        .page(pageable)
        );
    }

    @Override
    public Page<PatientResponseList> searchPatients(String groupId, String searchTerm, Pageable pageable) {
        return patientRepository.findBy(
                PatientSearchSpecification.hasGroupId(groupId)
                        .and(PatientSearchSpecification.searchAll(searchTerm)),
                query -> query
                        .as(PatientResponseList.class)
                        .page(pageable)
        );
    }

    private Specification<Patient> buildSpecification(AdvancedSearchPatientRequest.SearchCriteria criteria) {
        AdvancedSearchPatientRequest.FilterType filterType = criteria.filterType();
        AdvancedSearchPatientRequest.CompareOperator compareOperator = criteria.compareOperator();
        String value = criteria.value();

        return switch (filterType) {
            case FIRST_NAME, LAST_NAME, CELL_PHONE ->
                    buildNameOrPhoneSpecification(filterType.getColumnName(), compareOperator, value);
            case DOB -> buildDobSpecification(filterType.getColumnName(), compareOperator, value);
            case LANGUAGE -> buildLanguageSpecification(filterType.getColumnName(), compareOperator);
        };
    }

    private Specification<Patient> buildLanguageSpecification(String columnName, AdvancedSearchPatientRequest.CompareOperator compareOperator) {
        return (root, query, cb) -> {
            Expression<PreferredLanguage> language = root.get(columnName);
            return switch (compareOperator) {
                case EQUAL -> cb.equal(language, PreferredLanguage.ENGLISH);
                case NOT_EQUAL -> cb.notEqual(language, PreferredLanguage.SPANISH);
                default -> null;
            };
        };
    }

    private Specification<Patient> buildDobSpecification(String columnName,
                                                         AdvancedSearchPatientRequest.CompareOperator compareOperator,
                                                         String value) {
        return (root, query, cb) -> {
            LocalDate date = LocalDate.parse(value);
            Expression<LocalDate> dobExpr = root.get(columnName);

            return switch (compareOperator) {
                case EQUAL -> cb.equal(dobExpr, date);
                case NOT_EQUAL -> cb.notEqual(dobExpr, date);
                case BEFORE -> cb.lessThan(dobExpr, date);
                case AFTER -> cb.greaterThan(dobExpr, date);
                case LIKE -> cb.like(dobExpr.as(String.class), value);
            };
        };
    }

    private Specification<Patient> buildNameOrPhoneSpecification(String columnName,
                                                                 AdvancedSearchPatientRequest.CompareOperator compareOperator,
                                                                 String value) {
        return (root, query, cb) -> {
            Expression<String> fieldExpr = root.get(columnName);

            return switch (compareOperator) {
                case EQUAL -> cb.equal(fieldExpr, value);
                case NOT_EQUAL -> cb.notEqual(fieldExpr, value);
                case LIKE -> cb.like(fieldExpr, "%" + value + "%");
                default -> null;
            };
        };
    }
}