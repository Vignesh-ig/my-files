package com.rhombuzz.gpbackend.modules.patient.dto.response;

import lombok.Builder;
import lombok.Data;
import software.amazon.awssdk.services.s3.model.S3Object;

import java.time.LocalDateTime;
import java.time.ZoneId;

@Builder
@Data
public class DocumentResponse {
    private String fileName;
    private LocalDateTime uploadedAt;

    public static DocumentResponse fromS3ObjectWithTimezone(S3Object s3Object, ZoneId timezone) {
        LocalDateTime uploadedAt = s3Object.lastModified().atZone(timezone).toLocalDateTime();
        String key = s3Object.key();

        return DocumentResponse.builder()
                .fileName(key.substring(key.lastIndexOf("/") + 1))
                .uploadedAt(uploadedAt)
                .build();
    }
}
