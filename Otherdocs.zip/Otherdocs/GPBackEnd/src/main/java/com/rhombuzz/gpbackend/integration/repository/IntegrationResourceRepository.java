package com.rhombuzz.gpbackend.integration.repository;

import com.rhombuzz.gpbackend.integration.entity.IntegrationResource;
import com.rhombuzz.gpbackend.integration.entity.enums.IntegrationResourceType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IntegrationResourceRepository extends JpaRepository<IntegrationResource, Long> {

    boolean existsByMedGroup_GroupIdAndIntegrationNameAndIntegrationResource(String groupId, String integrationName, IntegrationResourceType resourceType);
}
