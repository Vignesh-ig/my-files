package com.rhombuzz.gpbackend.modules.task.service.impl;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.dto.response.ActivityResponse;
import com.rhombuzz.gpbackend.modules.task.entity.Activity;
import com.rhombuzz.gpbackend.modules.task.repository.ActivityRepository;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class ActivityServiceImpl implements ActivityService {
    private final ActivityRepository activityRepository;
    private final MedGroupService medGroupService;

    @Override
    public void saveActivity(ActivityRequest request) {
        Utils.validateObject(request);

        log.info("Saving activity for group: {}", request.getGroupId());
        MedGroup medGroup = medGroupService.getMedGroup(request.getGroupId());
        LocalDateTime dateTime = medGroupService.getCurrentDateTime(request.getGroupId());

        Activity activity = Activity.fromRequest(request);
        activity.setMedGroup(medGroup);
        activity.setDateTime(dateTime);

        activityRepository.save(activity);
        log.info("Saved activity for group: {}", request.getGroupId());
    }

    @Override
    public Page<ActivityResponse> getActivities(String groupId, Pageable pageable) {
        log.info("Getting activities for group: {}", groupId);
        return activityRepository.findByGroupId(groupId, pageable)
                .map(ActivityResponse::fromEntity);
    }

    @Override
    public Page<ActivityResponse> getPatientActivities(Long patientId, String groupId, Pageable pageable) {
        log.info("Getting activities for patient: {} in group: {}", patientId, groupId);
        return activityRepository.findByPatientId(patientId, groupId, pageable)
                .map(ActivityResponse::fromEntity);
    }
}
