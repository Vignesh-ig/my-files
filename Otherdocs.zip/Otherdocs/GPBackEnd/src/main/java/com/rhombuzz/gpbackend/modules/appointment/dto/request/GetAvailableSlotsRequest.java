package com.rhombuzz.gpbackend.modules.appointment.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record GetAvailableSlotsRequest(
        @NotBlank(message = "Group Id cannot be blank")
        @Size(min = 10, max = 10, message = "Group Id must be exactly 10 characters")
        String groupId,

        @NotNull(message = "Provider Id cannot be null")
        @Positive(message = "Provider Id must be a positive number")
        Long providerId,

        @NotNull(message = "Location Id cannot be null")
        @Positive(message = "Location Id must be a positive number")
        Long locationId,

        @NotNull(message = "Service Id cannot be null")
        @Positive(message = "Service Id must be a positive number")
        Long serviceId,

        @NotNull(message = "Date cannot be null")
        LocalDate date
) {
}
