package com.rhombuzz.gpbackend.modules.communication.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record EmailRequest(
        @NotBlank(message = "From email address cannot be blank")
        @Email(message = "Invalid email format")
        String fromEmail,

        @NotBlank(message = "Recipient email address cannot be blank")
        @Email(message = "Invalid email format")
        String toEmail,

        @NotBlank(message = "Subject cannot be blank")
        String subject,

        @NotBlank(message = "Body cannot be blank")
        String body
) {
}
