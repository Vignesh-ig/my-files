package com.rhombuzz.gpbackend.modules.api.service.impl;

import com.rhombuzz.gpbackend.modules.api.dto.request.GetConfigValueRequest;
import com.rhombuzz.gpbackend.modules.api.dto.request.UpdateConfigRequest;
import com.rhombuzz.gpbackend.modules.api.entity.Config;
import com.rhombuzz.gpbackend.modules.api.repository.ConfigRepository;
import com.rhombuzz.gpbackend.modules.api.service.ConfigService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class ConfigServiceImpl implements ConfigService {

    @Value("${spring.profiles.active}")
    private String activeProfile;

    private final ConfigRepository configRepository;

    @Override
    public Optional<String> getConfigValue(GetConfigValueRequest request) {
        return configRepository.getConfigValue(request.configName(), activeProfile, request.type());
    }

    @Override
    public void saveConfig(UpdateConfigRequest request) {
        log.info("Saving config with name: {}", request.getConfigName());
        Config config = Config.fromRequest(request);
        config.setEnvironment(activeProfile);

        configRepository.findOne(Example.of(config))
                .ifPresentOrElse(
                        existingConfig -> {
                            existingConfig.setConfigValue(request.getConfigValue());
                            configRepository.save(existingConfig);
                            log.info("Successfully updated Auth0 management token in config");
                        },
                        () -> {
                            config.setConfigValue(request.getConfigValue());
                            configRepository.save(config);
                            log.info("Successfully saved new config with name: {}", request.getConfigName());
                        }
                );
    }
}
