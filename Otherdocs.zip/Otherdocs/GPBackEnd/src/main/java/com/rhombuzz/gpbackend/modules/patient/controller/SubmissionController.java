package com.rhombuzz.gpbackend.modules.patient.controller;

import com.rhombuzz.gpbackend.modules.patient.dto.request.ReceivedSubmissionRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.request.RequestSubmissionRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.AwaitingSubmissionResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.ReceivedSubmissionResponse;
import com.rhombuzz.gpbackend.modules.patient.repository.specification.AwaitingSpecification;
import com.rhombuzz.gpbackend.modules.patient.service.SubmissionService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/submissions")
@PreAuthorize("hasAnyRole(" + AccessType.DASHBOARD_STANDARD + ")")
@Validated
public class SubmissionController {
    private final SubmissionService submissionService;

    @GetMapping("/awaiting")
    public ResponseEntity<Page<AwaitingSubmissionResponse>> getAwaitingSubmissions(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam AwaitingSpecification.AwaitingFilter filter,
            Pageable pageable
    ) {
        Page<AwaitingSubmissionResponse> response = submissionService.getAwaitingSubmissions(groupId, filter, pageable);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/received")
    public ResponseEntity<Page<ReceivedSubmissionResponse>> getReceivedSubmissions(
            ReceivedSubmissionRequest request,
            Pageable pageable
    ) {
        Page<ReceivedSubmissionResponse> response = submissionService.getReceivedSubmissions(request, pageable);
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/{patientId}/claim")
    public ResponseEntity<Void> claimSubmission(
            @PathVariable @NotNull @Positive Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        submissionService.claimSubmission(patientId, groupId);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{patientId}/complete")
    public ResponseEntity<Void> completeSubmission(
            @PathVariable @NotNull @Positive Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        submissionService.updateReviewStatus(patientId, groupId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/request")
    public ResponseEntity<Void> requestSubmission(
            @RequestBody @Valid RequestSubmissionRequest request
    ) {
        submissionService.requestSubmission(request);
        return ResponseEntity.noContent().build();
    }
}
