package com.rhombuzz.gpbackend.modules.medgroup.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "insurance_companies", indexes = {
        @Index(name = "idx_insurance_company_med_group_id", columnList = "med_group_id")
})
public class InsuranceCompany {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "insurance_code", length = 50, nullable = false)
    private String insuranceCode;

    @Column(name = "insurance_name", length = 100, nullable = false)
    private String insuranceName;

}
