package com.rhombuzz.gpbackend.modules.patient.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvCustomBindByName;
import com.rhombuzz.gpbackend.component.csv.BooleanConvertor;
import com.rhombuzz.gpbackend.component.csv.GenericEnumConverter;
import com.rhombuzz.gpbackend.component.csv.LocalDateConverter;
import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.time.LocalDate;

@Data
public class PatientCSVDTO {

    @NotBlank
    @CsvBindByName(column = "patientFirstName")
    private String firstName;

    @NotBlank
    @CsvBindByName(column = "patientLastName")
    private String lastName;

    @NotBlank
    @CsvBindByName(column = "email")
    @Email
    private String email;

    @NotNull
    @CsvBindByName(column = "dob")
    @CsvCustomBindByName(converter = LocalDateConverter.class)
    private LocalDate dob;

    @NotBlank
    @Pattern(regexp = RegexPattern.TEN_DIGITS)
    @CsvBindByName(column = "homePhone")
    private String homePhone;

    @NotBlank
    @Pattern(regexp = RegexPattern.TEN_DIGITS)
    @CsvBindByName(column = "cellPhone")
    private String cellPhone;

    @CsvBindByName(column = "SSN")
    private String ssn;

    @CsvBindByName(column = "city")
    private String city;

    @CsvBindByName(column = "state")
    private String state;

    @Pattern(regexp = RegexPattern.FIVE_DIGITS)
    @CsvBindByName(column = "zipCode")
    private String zipCode;

    @NotNull
    @CsvBindByName(column = "gender")
    @CsvCustomBindByName(converter = GenericEnumConverter.class)
    private Gender gender;

    @CsvBindByName(column = "preferredLanguage")
    @CsvCustomBindByName(converter = GenericEnumConverter.class)
    private PreferredLanguage preferredLanguage;

    @CsvBindByName(column = "coverage")
    private String coverage;

    @CsvBindByName(column = "optOut")
    @CsvCustomBindByName(converter = GenericEnumConverter.class)
    private ContactMethod optOut;

    @NotNull
    @CsvBindByName(column = "submissionFlag")
    @CsvCustomBindByName(converter = BooleanConvertor.class)
    private Boolean submissionFlag;

    @CsvBindByName(column = "patientRefNumber")
    private String patientReferenceNumber;
}
