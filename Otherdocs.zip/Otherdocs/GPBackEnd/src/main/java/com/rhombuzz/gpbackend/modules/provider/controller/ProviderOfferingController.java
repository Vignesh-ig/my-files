package com.rhombuzz.gpbackend.modules.provider.controller;

import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderOfferingRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.ServiceResponse;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderOfferingService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/provider-services")
@RequiredArgsConstructor
@Validated
public class ProviderOfferingController {
    private final ProviderOfferingService providerOfferingService;

    @PostMapping
    @PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Long> saveProviderOffering(
            @Valid @RequestBody ProviderOfferingRequest request
    ) {
        providerOfferingService.saveProviderOffering(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    @PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Page<ServiceResponse>> getProviderOfferings(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @Positive Long providerId,
            Pageable pageable
    ) {
        Page<ServiceResponse> providerOfferings = providerOfferingService
                .getProviderOfferings(groupId, providerId, pageable);
        return ResponseEntity.ok(providerOfferings);
    }

    @PatchMapping("/{providerId}/services/{serviceId}/enable")
    @PreAuthorize("denyAll()")
    public ResponseEntity<Void> enableProviderOffering(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @PathVariable @Positive Long providerId,
            @PathVariable @Positive Long serviceId
    ) {
        providerOfferingService.enableProviderOffering(groupId, providerId, serviceId);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{providerId}/services/{serviceId}/disable")
    @PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Void> disableProviderOffering(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @PathVariable @Positive Long providerId,
            @PathVariable @Positive Long serviceId
    ) {
        providerOfferingService.disableProviderOffering(groupId, providerId, serviceId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{providerId}/services/names")
    @PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<List<ServiceDTO>> getServiceNames(
            @PathVariable @NotNull @Positive Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
       List<ServiceDTO> serviceNames = providerOfferingService.getServiceNames(providerId, groupId);
        return ResponseEntity.ok(serviceNames);
    }

    @GetMapping("/{providerId}/services/visit-type")
    public ResponseEntity<List<ServiceDTO>> getServiceByVisitType(
            @PathVariable @NotNull @Positive Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotNull Service.VisitType visitType
    ) {
        List<ServiceDTO> services = providerOfferingService
                .getServiceByVisitType(providerId, groupId, visitType);
        return ResponseEntity.ok(services);
    }
}