package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.entity.InsuranceCompany;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class InsuranceCompanyResponse {

    private Long id;
    @NotBlank
    private String groupId;
    @NotBlank
    private String insuranceName;
    @NotBlank
    private String insuranceCode;

    public static InsuranceCompanyResponse fromEntity(InsuranceCompany insuranceCompany) {
        return InsuranceCompanyResponse.builder()
                .id(insuranceCompany.getId())
                .groupId(insuranceCompany.getMedGroup().getGroupId())
                .insuranceName(insuranceCompany.getInsuranceName())
                .insuranceCode(insuranceCompany.getInsuranceCode())
                .build();
    }

}
