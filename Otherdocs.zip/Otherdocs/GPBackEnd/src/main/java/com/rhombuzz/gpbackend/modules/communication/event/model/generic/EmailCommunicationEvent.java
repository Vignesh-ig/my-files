package com.rhombuzz.gpbackend.modules.communication.event.model.generic;

import lombok.Getter;

@Getter
public class EmailCommunicationEvent extends  CommunicationEvent {
    private final String fromEmail;
    private final String toEmail;
    private final String subject;
    private final String content;

    public EmailCommunicationEvent(String fromEmail, String toEmail, String subject, String content) {
        this.fromEmail = fromEmail;
        this.toEmail = toEmail;
        this.subject = subject;
        this.content = content;
    }

//    public EmailCommunicationEvent(String groupId, Long patientId, String templateId,
//                                   ContactMethod contactMethod, String email, String fromEmail,
//                                   String subject, String content) {
//        super(groupId, patientId, templateId, contactMethod);
//        this.email = email;
//        this.fromEmail = fromEmail;
//        this.subject = subject;
//        this.content = content;
//    }
}
