package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.entity.embeddable.DayTiming;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupTiming;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MedGroupTimingResponse {
    private DayTiming sunday;
    private DayTiming monday;
    private DayTiming tuesday;
    private DayTiming wednesday;
    private DayTiming thursday;
    private DayTiming friday;
    private DayTiming saturday;

    public static MedGroupTimingResponse fromEntity(MedGroupTiming medGroupTiming) {
        return MedGroupTimingResponse.builder()
                .sunday(medGroupTiming.getSunday())
                .monday(medGroupTiming.getMonday())
                .tuesday(medGroupTiming.getTuesday())
                .wednesday(medGroupTiming.getWednesday())
                .thursday(medGroupTiming.getThursday())
                .friday(medGroupTiming.getFriday())
                .saturday(medGroupTiming.getSaturday())
                .build();
    }

}
