package com.rhombuzz.gpbackend.integration.repository;

import com.rhombuzz.gpbackend.integration.entity.Integration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface IntegrationRepository extends JpaRepository<Integration, Long> {

    @Query("SELECT i.integrationName FROM Integration i WHERE i.medGroup.groupId = ?1")
    List<String> getIntegrationsByGroupId(String groupId);
}
