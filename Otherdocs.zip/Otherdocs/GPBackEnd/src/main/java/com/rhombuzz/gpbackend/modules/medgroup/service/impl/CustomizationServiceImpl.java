package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormBuilderSettingResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.CustomizationRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.CustomizationResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Customization;
import com.rhombuzz.gpbackend.modules.medgroup.repository.CustomizationRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.CustomizationService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalTime;

@Service
@RequiredArgsConstructor
public class CustomizationServiceImpl implements CustomizationService {
    private final CustomizationRepository customizationRepository;

    @PersistenceContext
    private final EntityManager entityManager;

    @Override
    @Transactional
    public void updateCustomization(CustomizationRequest request) {
        String columnName = request.type().getColumnName();
        Object parsedValue = parseValue(request.type(), request.value());

        String query = "UPDATE Customization c SET c." + columnName + " = :value WHERE c.medGroup.groupId = :groupId";

        entityManager.createQuery(query)
                .setParameter("groupId", request.groupId())
                .setParameter("value", parsedValue)
                .executeUpdate();
    }

    @Override
    public CustomizationResponse getCustomization(String groupId) {
        return customizationRepository.findByGroupId(groupId)
                .map(CustomizationResponse::fromEntity)
                .orElseThrow(() -> new NotFoundException("Customization not found"));
    }

    @Override
    public String getMedGroupThankYouPageContent(String groupId) {
        return customizationRepository.findApptThankYouPageContentByMedGroup_GroupId(groupId)
                .orElseThrow(() -> new NotFoundException("Customization not found"));
    }

    @Override
    public AppointmentFormBuilderSettingResponse getAppointmentFormBuilderSetting(String groupId) {
        return customizationRepository.getAppointmentFormBuilderSettingByGroupId(groupId)
                .orElseThrow(() -> new NotFoundException("Customization not found"));
    }

    private Object parseValue(Customization.Type type, Object value) {
        Object parsedValue;

        try {
            parsedValue = switch (type) {
                case DEFAULT_BOOKING_FEE -> new BigDecimal(String.valueOf(value));
                case BOOKING_LEAD_TIME_IN_MINUTES, NOTIFY_WAITLIST_PATIENT_LIMIT, APPT_CANCEL_RESTRICTION_PERIOD,
                     APPT_RESCHEDULE_RESTRICTION_PERIOD -> Integer.parseInt(String.valueOf(value));
                case BOOKING_PREVENTIONS_START_TIME -> LocalTime.parse(String.valueOf(value));
                case ADDRESS_FLAG, REASON_FOR_VISIT_FLAG, PREFERRED_CONTACT_FLAG, INSURANCE_COMPANY_FLAG,
                     INSURANCE_ID_FLAG,
                     INSURANCE_GROUP_ID_FLAG, PATIENT_UPDATE_FORM_FLAG, BOOKING_FEE_SWITCH, BOOKING_PREVENTION_SWITCH,
                     NOTIFY_WAITLIST_PATIENT_SWITCH -> Boolean.parseBoolean(String.valueOf(value));
                default -> value;
            };

        } catch (Exception e) {
            throw new InternalServerErrorException("Failed to parse value");
        }

        return parsedValue;
    }
}
