package com.rhombuzz.gpbackend.modules.appointment.service.impl;

import com.rhombuzz.gpbackend.modules.appointment.service.AppointmentArchiveService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AppointmentArchiveServiceImpl implements AppointmentArchiveService {
}
