package com.rhombuzz.gpbackend.modules.support.repository;

import com.rhombuzz.gpbackend.modules.support.entity.QuickSurvey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface QuickSurveyRepository extends JpaRepository<QuickSurvey, Long> {

    @Query("SELECT qs FROM QuickSurvey qs WHERE qs.medGroup.groupId = ?1 AND qs.secretId = ?2")
    Optional<QuickSurvey> findByGroupIdAndSecretId(String groupId, String secretId);

    @Query("SELECT COUNT(qs) > 0 FROM QuickSurvey qs WHERE qs.medGroup.groupId = ?1 AND qs.secretId = ?2")
    boolean existsByGroupIdAndSecretId(String groupId, String secretId);
}
