package com.rhombuzz.gpbackend.modules.provider.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@AllArgsConstructor
public class SpecificAvailabilityResponse {
    private Long id;
    private ProviderDTO provider;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private LocationDTO location;
}
