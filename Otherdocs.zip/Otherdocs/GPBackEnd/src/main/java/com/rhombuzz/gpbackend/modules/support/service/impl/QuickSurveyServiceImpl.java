package com.rhombuzz.gpbackend.modules.support.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.support.dto.request.SaveQuickSurveyRequest;
import com.rhombuzz.gpbackend.modules.support.dto.request.UpdateQuickSurveyRequest;
import com.rhombuzz.gpbackend.modules.support.entity.QuickSurvey;
import com.rhombuzz.gpbackend.modules.support.repository.QuickSurveyRepository;
import com.rhombuzz.gpbackend.modules.support.service.QuickSurveyService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class QuickSurveyServiceImpl implements QuickSurveyService {

    private final MedGroupService medGroupService;
    private final PatientService patientService;

    private final QuickSurveyRepository quickSurveyRepository;

    @Override
    public void saveQuickSurvey(SaveQuickSurveyRequest request) {

        log.info("Saving quick survey for patientId: {} on appointmentId: {}", request.patientId(), request.appointmentId());

        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Patient patient = patientService.getPatientById(request.patientId(), request.groupId());
        Appointment appointment = Appointment.builder().id(request.appointmentId()).build();//Todo: Temporary solution.

        QuickSurvey quickSurvey = QuickSurvey.builder()
                .medGroup(medGroup)
                .patient(patient)
                .appointment(appointment)
                .secretId(getUniqueSecretId(request.groupId()))
                .requestedDateTime(request.requestedDateTime())
                .build();

        quickSurveyRepository.save(quickSurvey);
        log.info("Quick survey saved successfully");

    }

    @Override
    public void updateQuickSurvey(String secretId, UpdateQuickSurveyRequest request) {

        log.info("Updating quick survey for groupId: {} and secretId: {}", request.groupId(), secretId);

        QuickSurvey quickSurvey = quickSurveyRepository.findByGroupIdAndSecretId(request.groupId(), secretId)
                .orElseThrow(() -> {
                    log.error("Quick survey not found with secretId: {} for medgroup groupId: {}", secretId, request.groupId());
                    return new NotFoundException("Quick survey not found");
                });

        quickSurvey.setReceivedDateTime(request.receivedDateTime());
        quickSurvey.setScore(request.score());
        quickSurvey.setReason(request.reason());
        quickSurvey.setGoogleReviewIntent(request.isGoogleReviewIntent());
        quickSurvey.setGoogleReviewStatus(request.isGoogleReviewStatus());

        quickSurveyRepository.save(quickSurvey);
        log.info("Quick survey updated successfully");

    }

    private String getUniqueSecretId(String groupId) {

        String secretId;

        do {
            secretId = Utils.generateSecretId(10);
        } while (quickSurveyRepository.existsByGroupIdAndSecretId(groupId, secretId));

        return secretId;
    }

}
