package com.rhombuzz.gpbackend.modules.appointment.service.impl;

import com.rhombuzz.gpbackend.modules.appointment.dto.request.SaveCanceledAppointmentRequest;
import com.rhombuzz.gpbackend.modules.appointment.entity.CanceledAppointment;
import com.rhombuzz.gpbackend.modules.appointment.repository.CanceledAppointmentRepository;
import com.rhombuzz.gpbackend.modules.appointment.service.CanceledAppointmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class CanceledAppointmentServiceImpl implements CanceledAppointmentService {
    private final CanceledAppointmentRepository canceledAppointmentRepository;

    @Override
    public void saveCanceledAppointment(SaveCanceledAppointmentRequest request) {
        log.info("Save canceled appointment for patient: {}", request.patient().getId());
        CanceledAppointment canceledAppointment = CanceledAppointment.fromRequest(request);

        LocalDateTime currentDateTime = LocalDateTime.now(request.medGroup().getTimeZone().toZoneId());
        canceledAppointment.setCanceledDateTime(currentDateTime);

        canceledAppointmentRepository.save(canceledAppointment);
        log.info("Canceled appointment saved successfully");

    }

}
