package com.rhombuzz.gpbackend.modules.communication.dto.request;

import com.rhombuzz.gpbackend.modules.communication.entity.SMS;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class SaveSMSRequest {

    @NotBlank(message = "Group ID cannot be blank")
    @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
    private String groupId;

    @NotNull(message = "Patient ID cannot be null")
    @Positive(message = "Patient ID must be a positive number")
    private Long patientId;

    private Integer conversationStatus;
    private Integer conversationDepth;

    @NotBlank(message = "Message cannot be null")
    private String message;

    @Size(max = 45, message = "Message UUID must be at most 45 characters long")
    private String messageUuid;

    @Size(max = 45, message = "Conversation ID must be at most 45 characters long")
    private String conversationId;

    @NotBlank(message = "Sender cannot be blank")
    @Size(max = 45, message = "Sender must be at most 45 characters long")
    private String sender;

    private boolean isRead;

    @NotNull(message = "SMS type cannot be null")
    private SMS.SMSType smsType;
    private SMS.ConversationType conversationType;
}
