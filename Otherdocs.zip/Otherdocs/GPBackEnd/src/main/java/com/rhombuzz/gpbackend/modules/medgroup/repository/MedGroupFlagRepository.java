package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupFlag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface MedGroupFlagRepository extends JpaRepository<MedGroupFlag, Long> {

    @Query("SELECT f FROM MedGroupFlag f WHERE f.medGroup.groupId = ?1")
    Optional<MedGroupFlag> findByGroupId(String groupId);
}
