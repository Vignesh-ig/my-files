package com.rhombuzz.gpbackend.modules.payment.entity;

import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "payments", indexes = {
        @Index(name = "idx_payment_med_group_id", columnList = "med_group_id"),
        @Index(name = "idx_payment_patient_id", columnList = "patient_id"),
        @Index(name = "idx_payment_appointment_id", columnList = "appointment_id"),
})
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false, referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "appointment_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Appointment appointment;

    @Column(name = "secure_id", length = 100)
    private String secureId;

    @Column(name = "status", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(name = "amount", precision = 16, scale = 2, nullable = false)
    private BigDecimal amount;

    @Column(name = "reason", nullable = false)
    private String reason;

    @Column(name = "requested_date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime requestedDate;

    @Column(name = "payment_date_time", nullable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime paymentDate;

    @Column(name = "short_url", length = 45)
    private String shortURL;

    @Column(name = "request_status", length = 45)
    private String requestStatus; //Todo: Need To Check

    @Column(name = "payment_type", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private Type paymentType;

    @Column(name = "refund_id", length = 90)
    private String refundId;

    @Column(name = "checkout_id", length = 90)
    private String checkoutId;

    @Column(name = "payment_intent_id", length = 90)
    private String paymentIntentId;

    @Column(name = "description", length = 500, nullable = false)
    private String description;

    @Column(name = "refund_info", length = 90)
    private String refundInfo;

    @Column(name = "charge_id", length = 90)
    private String chargeId;

    @Column(name = "payout_id", length = 90)
    private String payoutId;

    @Column(name = "initiated_by", length = 60)
    private String initiatedBy;

    @Column(name = "payment_reference")
    private Long paymentReference;

    public enum Status {

        REQUESTED,
        PAID,
        PAID_BY_CASH,
        INITIATED
    }

    public enum Type {

        REQUEST_PAYMENT,
        CARD_PAYMENT,
        CASH_PAYMENT,
        REFUND_PAYMENT
    }

}
