package com.rhombuzz.gpbackend.modules.intake.dto;

import com.rhombuzz.gpbackend.modules.patient.dto.PatientInsuranceDTO;
import jakarta.validation.constraints.AssertTrue;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class InsuranceDTO {
    private boolean havePrimaryInsurance;
    private PatientInsuranceDTO primaryInsurance;

    private boolean haveSecondaryInsurance;
    private PatientInsuranceDTO secondaryInsurance;

    @AssertTrue(message = "Primary insurance is not having all the valid fields.")
    public boolean isPrimaryInsuranceValid() {
        log.info("called isPrimaryInsuranceValid.");
        return !havePrimaryInsurance || (primaryInsurance != null && primaryInsurance.isValid());
    }

    @AssertTrue(message = "Secondary insurance is not having all the valid fields.")
    public boolean isSecondaryInsuranceValid() {
        log.info("called isSecondaryInsuranceValid.");
        if (haveSecondaryInsurance && !havePrimaryInsurance) return false;
        return !haveSecondaryInsurance || (secondaryInsurance != null && secondaryInsurance.isValid());
    }
}
