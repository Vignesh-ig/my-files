package com.rhombuzz.gpbackend.modules.communication.event.model.generic;

import lombok.Getter;

@Getter
public class SMSCommunicationEvent extends CommunicationEvent {
    private final String fromNumber;
    private final String toNumber;
    private final String content;

    public SMSCommunicationEvent(String fromNumber, String toNumber, String content) {
        this.fromNumber = fromNumber;
        this.toNumber = toNumber;
        this.content = content;
    }

//    public SMSCommunicationEvent(String groupId, Long patientId, String templateId,
//                                 ContactMethod contactMethod, String cellPhone, String officePhone,
//                                 String content) {
//        super(groupId, patientId, templateId, contactMethod);
//        this.cellPhone = cellPhone;
//        this.officePhone = officePhone;
//        this.content = content;
//    }
}
