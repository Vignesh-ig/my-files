package com.rhombuzz.gpbackend.integration.service;

public interface IntegrationService {

    default void handlePatientResource() {
        throw new UnsupportedOperationException("handlePatientResource not supported");
    }

    default void handleAppointmentResource() {
        throw new UnsupportedOperationException("handlePatientResource not supported");
    }

}
