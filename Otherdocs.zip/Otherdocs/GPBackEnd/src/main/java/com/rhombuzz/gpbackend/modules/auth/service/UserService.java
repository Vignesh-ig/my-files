package com.rhombuzz.gpbackend.modules.auth.service;

import com.rhombuzz.gpbackend.modules.auth.dto.request.SaveUserRequest;
import com.rhombuzz.gpbackend.modules.auth.dto.response.UserExistsResponse;
import com.rhombuzz.gpbackend.modules.auth.dto.response.UserResponse;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
public interface UserService {

    void saveUser(
            @Valid SaveUserRequest request
    );

    UserResponse getUser(
            @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<UserResponse> getUsers(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void deleteUser(
            @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateEmail(
            @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotBlank @Email String email
    );

    void updateRole(
            @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotBlank @Pattern(regexp = RegexPattern.ROLE_ID) String oldRoleId,
            @NotBlank @Pattern(regexp = RegexPattern.ROLE_ID) String newRoleId
    );

    UserExistsResponse isUserExists(
            @NotBlank @Size(min = 7, max = 15) String username,
            @NotBlank @Email String email
    );

    List<UserResponse.Role> getGroupRoles();

    UserResponse.Role getManagementRole();

    void changePassword(
            @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotBlank @Pattern(regexp = RegexPattern.PASSWORD) String oldPassword,
            @NotBlank @Pattern(regexp = RegexPattern.PASSWORD) String newPassword
    );

    List<String> getUserNames(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void blockUnblockUser(
            @NotBlank @Pattern(regexp = RegexPattern.USER_ID) String userId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            boolean blockFlag
    );
}
