package com.rhombuzz.gpbackend.modules.patient.repository;

import com.rhombuzz.gpbackend.modules.patient.entity.PatientInsurance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface PatientInsuranceRepository extends JpaRepository<PatientInsurance, Long> {

    @Query("SELECT pi FROM PatientInsurance pi WHERE pi.patient.id = ?1 AND pi.medGroup.groupId = ?2")
    Optional<PatientInsurance> findByPatientId(Long patientId, String groupId);

}
