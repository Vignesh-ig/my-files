package com.rhombuzz.gpbackend.modules.medgroup.service;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.GetInsightsCompareRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.GetInsightsRangeRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.GetInsightsRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveInsightsRequest;
import jakarta.validation.Valid;
import org.springframework.validation.annotation.Validated;

import java.time.LocalDate;
import java.util.Map;

@Validated
public interface MedGroupInsightsService {

    Map<String, Integer> getDayInsights(
            @Valid GetInsightsRequest request
    );

    Map<LocalDate, Map<String, Integer>> getInsightsDateRange(
            @Valid GetInsightsRangeRequest request
    );

    Map<String, Map<String, Integer>> getInsightsMonthRange(
            @Valid GetInsightsRangeRequest request
    );

    Map<String, Map<String, Integer>> getInsightsDateRangeCompare(
            @Valid GetInsightsCompareRequest request
    );

    void saveDataToInsights(
            @Valid SaveInsightsRequest request
    );
}
