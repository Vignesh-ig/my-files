package com.rhombuzz.gpbackend.modules.provider.controller;

import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveBookingTypeRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveProviderRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.UpdateProviderRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.BookingTypeResponse;
import com.rhombuzz.gpbackend.modules.provider.dto.response.ProviderResponse;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import com.rhombuzz.gpbackend.util.AccessType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/providers")
@Validated
public class ProviderController {
    private final ProviderService providerService;

    @GetMapping
    @PreAuthorize("hasAnyRole("+ AccessType.ADMIN +")")
    public ResponseEntity<Page<ProviderResponse>> getProviders(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<ProviderResponse> providers = providerService.getProviders(groupId, pageable);
        return ResponseEntity.ok(providers);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole("+ AccessType.ADMIN +")")
    public ResponseEntity<Void> saveProvider(
            @RequestPart @Valid SaveProviderRequest request,
            @RequestPart(required = false)
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png"},
                    required = false
            ) MultipartFile image
    ) {
        providerService.saveProvider(request, image);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{providerId}")
    @PreAuthorize("hasAnyRole("+ AccessType.ADMIN +")")
    public ResponseEntity<Void> updateProvider(
            @PathVariable @NotNull Long providerId,
            @RequestPart @Valid UpdateProviderRequest request,
            @RequestPart(required = false)
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png"},
                    required = false
            ) MultipartFile image
    ) {
        providerService.updateProvider(providerId, request, image);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{providerId}")
    @PreAuthorize("hasAnyRole("+ AccessType.ADMIN +")")
    public ResponseEntity<Void> deleteProvider(
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        providerService.deleteProvider(providerId, groupId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{providerId}/image")
    public ResponseEntity<Map<String, Object>> getProviderImage(
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Map<String, Object> imageResponse = providerService.getProviderImage(providerId, groupId);
        return ResponseEntity.ok(imageResponse);
    }

    @GetMapping("/names")
    public ResponseEntity<List<ProviderDTO>> getProviderNames(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        List<ProviderDTO> providerNames = providerService.getProviderNames(groupId);
        return ResponseEntity.ok(providerNames);
    }

    @GetMapping("/{providerId}/default-appointment-duration")
    @PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Integer> getDefaultApptDuration(
            @PathVariable @NotNull @Positive Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Integer defaultApptDuration = providerService.getDefaultApptDuration(groupId, providerId);
        return ResponseEntity.ok(defaultApptDuration);
    }

    @PatchMapping("/{providerId}/default-appointment-duration")
    @PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Void> updateDefaultApptDuration(
            @PathVariable @NotNull @Positive Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotNull @Min(5) Integer defaultApptDuration
    ) {
        providerService.updateDefaultApptDuration(providerId, groupId, defaultApptDuration);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{providerId}/booking-details")
    @PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<BookingTypeResponse> getBookingTypeDetails(
            @PathVariable @NotNull @Positive Long providerId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ){
        return ResponseEntity.ok(providerService.getBookingTypeDetails(providerId, groupId));
    }

    @PutMapping("/{providerId}/booking-details")
    @PreAuthorize("hasAnyRole("+ AccessType.DASHBOARD_STANDARD +")")
    public ResponseEntity<Void> updateBookingTypeDetails(
            @PathVariable @NotNull @Positive Long providerId,
            @RequestBody @Valid SaveBookingTypeRequest request
    ){
        providerService.updateBookingTypeDetails(providerId, request);
        return ResponseEntity.noContent().build();
    }
}
