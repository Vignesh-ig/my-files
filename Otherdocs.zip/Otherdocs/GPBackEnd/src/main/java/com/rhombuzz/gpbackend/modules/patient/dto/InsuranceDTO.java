package com.rhombuzz.gpbackend.modules.patient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class InsuranceDTO {
    private String companyName;
    private String companyCode;
    private String insuranceGroupId;
    private String insuranceId;
}
