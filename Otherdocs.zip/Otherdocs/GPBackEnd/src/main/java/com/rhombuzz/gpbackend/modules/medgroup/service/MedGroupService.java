package com.rhombuzz.gpbackend.modules.medgroup.service;

import com.rhombuzz.gpbackend.component.annotation.ValidFile;
import com.rhombuzz.gpbackend.modules.medgroup.dto.AWSDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.MedGroupDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.RunCheckRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveMedGroupRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.RunCheckResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.SaveMedGroupResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.Asset;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;
import java.util.TimeZone;

@Validated
public interface MedGroupService {

    RunCheckResponse runCheck(
            @Valid RunCheckRequest request
    );

    SaveMedGroupResponse saveMedGroup(
            @Valid SaveMedGroupRequest request,
            @ValidFile(
                    extensions = {"jpg", "jpeg", "png", "gif"},
                    contentTypes = {"image/jpg", "image/jpeg", "image/png", "image/gif"},
                    required = false
            ) MultipartFile image);

    LocalDateTime getCurrentDateTime(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    MedGroup getMedGroup(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    AWSDTO getAWSAccess(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    List<MedGroup> getMedGroups();

    List<MedGroupDTO> getMedGroupNames();

    boolean isMedGroupExists(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    byte[] getAsset(
            @NotNull Asset asset
    );

    MedGroup.AppointmentType getAppointmentType(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    TimeZone getTimezone(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    String getGroupDescription(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
