package com.rhombuzz.gpbackend.modules.provider.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.time.LocalTime;

public record SaveSpecificAvailabilityRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Provider ID cannot be null")
        @Positive(message = "Provider ID must be a positive number")
        Long providerId,

        @NotNull(message = "Date cannot be null")
        LocalDate date,

        @NotNull(message = "Start time cannot be null")
        LocalTime startTime,

        @NotNull(message = "End time cannot be null")
        LocalTime endTime,

        @NotNull(message = "Location ID cannot be null")
        @Positive(message = "Location ID must be a positive number")
        Long locationId
) {
}
