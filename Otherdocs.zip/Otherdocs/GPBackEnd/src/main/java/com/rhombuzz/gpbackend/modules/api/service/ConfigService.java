package com.rhombuzz.gpbackend.modules.api.service;

import com.rhombuzz.gpbackend.modules.api.dto.request.GetConfigValueRequest;
import com.rhombuzz.gpbackend.modules.api.dto.request.UpdateConfigRequest;
import jakarta.validation.Valid;
import org.springframework.validation.annotation.Validated;

import java.util.Optional;

@Validated
public interface ConfigService {

    Optional<String> getConfigValue(
            @Valid GetConfigValueRequest request
    );

    void saveConfig(
            @Valid UpdateConfigRequest request
    );
}
