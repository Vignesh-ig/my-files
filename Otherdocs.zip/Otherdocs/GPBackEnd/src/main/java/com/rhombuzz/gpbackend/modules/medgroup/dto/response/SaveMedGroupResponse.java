package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SaveMedGroupResponse {
    private boolean s3BucketCreated;
    private boolean iamGroupCreated;
    private boolean iamUserCreated;
    private boolean iamUserAddedToGroup;
    private boolean accessKeyCreated;
    private boolean iamPolicyCreated;
    private boolean iamPolicyAttached;
    private boolean iamLoginProfileCreated;
    private boolean groupCreated;
    private boolean userCreated;
}
