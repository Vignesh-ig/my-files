package com.rhombuzz.gpbackend.modules.communication.dto;

import com.rhombuzz.gpbackend.modules.patient.entity.Patient;

public record TemplateValidDTO(
        boolean valid,
        Patient patient
) {
}
