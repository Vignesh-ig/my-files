package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSTemplate;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SMSTemplateResponse {
    private String templateName;
    private String englishContent;
    private String spanishContent;

    public static SMSTemplateResponse fromEntity(SMSTemplate smsTemplate) {
        return SMSTemplateResponse.builder()
                .templateName(smsTemplate.getName())
                .englishContent(smsTemplate.getEnglishContent())
                .spanishContent(smsTemplate.getSpanishContent())
                .build();
    }

    public String getContent(PreferredLanguage language) {
        return language == PreferredLanguage.ENGLISH ? englishContent : spanishContent;
    }
}
