package com.rhombuzz.gpbackend.modules.appointment.service.impl;

import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.integration.telehealth.TelehealthService;
import com.rhombuzz.gpbackend.modules.appointment.dto.request.*;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.AllAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormBuilderSettingResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormInitResponse;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.PatientAppointmentResponse;
import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;
import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentFormType;
import com.rhombuzz.gpbackend.modules.appointment.entity.enums.AppointmentStatus;
import com.rhombuzz.gpbackend.modules.appointment.repository.AppointmentRepository;
import com.rhombuzz.gpbackend.modules.appointment.service.AppointmentService;
import com.rhombuzz.gpbackend.modules.appointment.service.CanceledAppointmentService;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationService;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.CustomizationResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.medgroup.service.*;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.provider.entity.ProviderOffering;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderOfferingService;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Function;

@Slf4j
@org.springframework.stereotype.Service
@RequiredArgsConstructor
@Transactional
public class AppointmentServiceImpl implements AppointmentService {
    private final AppointmentRepository appointmentRepository;
    private final MedGroupService medGroupService;
    private final ProviderOfferingService providerOfferingService;
    private final ServiceManagement serviceManagement;
    private final LocationService locationService;
    private final PatientService patientService;
    private final ProviderService providerService;
    private final Map<String, TelehealthService> telehealthServiceMap;
    private final Executor asyncExecutor;
    private final PatientCommunicationService patientCommunicationService;
    private final ActivityService activityService;
    private final MedGroupFlagService medGroupFlagService;
    private final CustomizationService customizationService;
    private final CanceledAppointmentService canceledAppointmentService;

    @Override
    public List<Date> getAvailableDates(GetAvailableDatesRequest request, AppointmentFormType formType) {
        log.info("Fetching available dates for groupId: {}", request.groupId());
        LocalDateTime dateTime = determineStartDateTime(request);

        checkProviderOfferingDisabled(request.providerId(), request.serviceId(), request.groupId());

        Function<LocalDateTime, List<Date>> fetchDates =
                (dt) -> formType == AppointmentFormType.STAFF
                        ? appointmentRepository.getAvailableDates(request.groupId(), request.providerId(),
                        request.locationId(), request.serviceId(), dt)
                        : appointmentRepository.getAvailableDatesAtPatientEnd(request.groupId(), request.providerId(),
                        request.locationId(), request.serviceId(), dt);

        return findAvailableDates(fetchDates, request, dateTime);
    }

    @Override
    public List<Time> getAvailableSlots(GetAvailableSlotsRequest request, AppointmentFormType formType) {
        log.info("Fetching available slots for provider with id {} and service id {} in group {}",
                request.providerId(), request.serviceId(), request.groupId());
        LocalDateTime dateTime = medGroupService.getCurrentDateTime(request.groupId());

        if (request.date().isBefore(dateTime.toLocalDate())) {
            log.error("Requested date {} is in the past compared to current date {}",
                    request.date(), dateTime.toLocalDate());
            throw new BadRequestException("Date must not be in the past");
        }

        return formType == AppointmentFormType.STAFF ?
                appointmentRepository.getAvailableSlots(request.groupId(), request.providerId(),
                        request.date(), request.locationId(), dateTime, request.serviceId()) :
                appointmentRepository.getAvailableSlotsAtPatientEnd(request.groupId(), request.providerId(),
                        request.date(), request.locationId(), dateTime, request.serviceId());
    }

    @Override
    public void saveManualAppointment(SaveManualAppointmentRequest request) {
        log.info("Saving manual appointment for patient ID: {}, group ID: {}",
                request.patientId(), request.groupId());
        validatedExistence(request.groupId(), request.patientId(),
                request.providerId(), request.serviceId());

        Service service = serviceManagement.getServiceEntity(request.serviceId(), request.groupId());
        Appointment appointment = getAppointment(request);
        boolean isTelehealth = Boolean.TRUE.equals(request.isTelehealth());

        if (isTelehealth) {
            validateTelehealthEligibility(request.groupId(), request.providerId(), service);
        }

        appointment.setService(service);
        appointment.setDuration(service.getDuration());
        appointment.setServiceName(service.getServiceName());

        Appointment savedAppointment = appointmentRepository.save(appointment);
        log.info("Appointment saved successfully with ID: {} for patient ID: {} in group ID: {}",
                savedAppointment.getId(), request.patientId(), request.groupId());

        String description = String.format("The user (%s) has manually scheduled an appointment for patient (%s).",
                Utils.getCurrentUsername(), appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName());
        saveActivity(savedAppointment, "APPOINTMENT", description);
        if (isTelehealth) {
            log.debug("Scheduling asynchronous tasks for setting telehealth details for appointment ID: {}", savedAppointment.getId());
            CompletableFuture.runAsync(() -> setTelehealthDetails(savedAppointment.getId()), asyncExecutor);
        } else {
            log.debug("Scheduling asynchronous tasks for sending SMS and Email for appointment ID: {}", savedAppointment.getId());
            CompletableFuture.runAsync(() -> sendSMSAndEmail(savedAppointment.getId(), "MANUAL_APPOINTMENT_CONFIRMED"), asyncExecutor);
        }
        log.debug("Asynchronous tasks for appointment ID: {} have been initiated", savedAppointment.getId());
    }

    @Override
    public Page<PatientAppointmentResponse> getPatientAppointments(Long patientId, String groupId, Pageable pageable) {
        log.info("Fetching appointments for patient ID: {}, group ID: {}", patientId, groupId);
        return appointmentRepository.findByPatientId(patientId, groupId, pageable);
    }

    @Transactional
    @Override
    public void updateAppointmentStatus(Long id, UpdateAppointmentStatusRequest request) {
        log.info("Updating appointment status for appointment ID: {}, group ID: {}", id, request.groupId());
        LocalDateTime currentDateTime = medGroupService.getCurrentDateTime(request.groupId());

        Appointment appointment = appointmentRepository.findByIdAndGroupId(id, request.groupId()).orElseThrow(() -> {
            log.error("Appointment not found with ID: {} in group ID: {}", id, request.groupId());
            return new NotFoundException("Appointment not found");
        });
        AppointmentStatus currentStatus = appointment.getStatus();
        if (currentStatus == request.newStatus()) {
            log.warn("The current status is the same as the new status for appointment ID: {}, group ID: {}. No update performed.", id, request.groupId());
            return;
        }

        if (!isAppointmentStatusFlowValid(currentStatus, request.newStatus())) {
            log.error("Invalid status transition from {} to {} for appointment ID: {}, group ID: {}", currentStatus, request.newStatus(), id, request.groupId());
            throw new ConflictException("Appointment is already in (" + currentStatus.getLabel() + "),so (" + request.newStatus().getLabel() + ") status is not allowed please refresh the page");
        }

        switch (request.newStatus()) {
            case PATIENT_CONFIRMED ->
                    appointmentRepository.savePatientConfirmed(id, request.groupId(), currentDateTime, request.newStatus(), currentStatus == AppointmentStatus.UPCOMING);
            case CHECKED_IN ->
                    appointmentRepository.saveCheckInStatus(id, request.groupId(), currentDateTime, request.newStatus());
            case COMPLETED ->
                    appointmentRepository.saveCheckOutStatus(id, request.groupId(), currentDateTime, request.newStatus());
            case NO_SHOW ->
                    appointmentRepository.saveNoShow(id, request.groupId(), currentDateTime, request.newStatus());
        }

        log.info("Appointment status updated successfully from {} to {} for appointment ID: {}, group ID: {}", request.currentStatus(), request.newStatus(), id, request.groupId());

        String description = String.format("The user (%s) has updated the appointment status from %s to %s.",
                Utils.getCurrentUsername(), currentStatus.getLabel(), request.newStatus().getLabel());

        saveActivity(appointment, "APPOINTMENT", description);
    }

    @Override
    public Set<LocalDate> getAvailableAppointmentDates(GetAvailableAppointmentDatesRequest request) {
        log.info("Fetching available appointment dates for provider with id {} and location id {}, service id {} in group {}",
                request.providerId(), request.locationId(), request.serviceId(), request.groupId());

        return appointmentRepository.getAvailableAppointmentDates(
                request.providerId(),
                request.locationId(),
                request.serviceId(),
                request.groupId(),
                request.month().getValue(),
                request.year()
        );
    }

    @Override
    public Page<AllAppointmentResponse> getAppointmentsByDate(GetAppointmentsRequest request, Pageable pageable) {
        log.info("Fetching appointments for group ID: {} with filters - provider ID: {}, location ID: {}, service ID: {} on date: {}",
                request.groupId(), request.providerId(), request.locationId(), request.serviceId(), request.scheduledDate());

        return appointmentRepository.getAppointments(
                request.providerId(),
                request.locationId(),
                request.serviceId(),
                request.groupId(),
                request.scheduledDate(),
                pageable
        );
    }

    @Override
    public Map<String, Object> getRecentNextPreviousDates(GetAppointmentsRequest request) {
        log.info("Fetching recent, next, and previous available appointment dates for provider with id {} and location id {}, service id {} in group {} around date {}",
                request.providerId(), request.locationId(), request.serviceId(), request.groupId(), request.scheduledDate());

        LocalDate scheduledDate = appointmentRepository.findRecentAvailableAppointmentDate(
                request.providerId(),
                request.locationId(),
                request.serviceId(),
                request.groupId(),
                request.scheduledDate()
        );

        LocalDate hasNextDate = appointmentRepository.findNextAvailableAppointmentDate(request.providerId(),
                request.locationId(),
                request.serviceId(),
                request.groupId(),
                scheduledDate
        );

        LocalDate hasPreviousDate = appointmentRepository.findPreviousAvailableAppointmentDate(request.providerId(),
                request.locationId(),
                request.serviceId(),
                request.groupId(),
                scheduledDate
        );

        Map<String, Object> result = new HashMap<>();
        result.put("hasNextDate", hasNextDate);
        result.put("hasPreviousDate", hasPreviousDate);
        result.put("scheduledDate", scheduledDate);
        return result;
    }

    @Override
    public void savePatientConfirmed(Long id, String groupId) {
        log.info("Saving patient confirmation for appointment ID: {}, group ID: {}", id, groupId);
        LocalDateTime currentDateTime = medGroupService.getCurrentDateTime(groupId);

        Appointment appointment = appointmentRepository.findByIdAndGroupId(id, groupId).orElseThrow(() -> {
            log.error("Appointment not found with ID: {} in group ID: {}", id, groupId);
            return new NotFoundException("Appointment not found");
        });
        AppointmentStatus currentStatus = appointment.getStatus();
        if (currentStatus == AppointmentStatus.PATIENT_CONFIRMED) {
            log.warn("Patient already confirmed with appointment ID: {}, group ID: {}. No update performed.", id, groupId);
            return;
        }

        appointmentRepository.savePatientConfirmed(id, groupId, currentDateTime, AppointmentStatus.PATIENT_CONFIRMED, currentStatus == AppointmentStatus.UPCOMING);
        log.info("Patient confirmation saved successfully for appointment ID: {}, group ID: {}", id, groupId);

        String description = String.format("The user (%s) has confirmed the appointment for patient (%s).",
                Utils.getCurrentUsername(), appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName());

        saveActivity(appointment, "APPOINTMENT", description);
    }

    @Override
    public void saveFormAppointment(SaveFormAppointmentRequest request) {
        log.info("Saving form appointment group ID: {}", request.getGroupId());
        LocalDateTime currentDateTime = medGroupService.getCurrentDateTime(request.getGroupId());

        String groupId = request.getGroupId();
        Long patientId = patientService.saveAppointmentFormPatientDetails(request.getPatient(), groupId, currentDateTime);

        Long serviceId = request.getAppointment().getServiceId();
        Long locationId = request.getAppointment().getLocationId();
        Long providerId = request.getAppointment().getProviderId();

        LocalDate scheduleDate = request.getAppointment().getScheduleDate();
        LocalTime scheduleTime = request.getAppointment().getScheduleTime();

        boolean isAppointmentExistForPatient = appointmentRepository.existsByPatientIdAndAppointmentDateTime(patientId, groupId, scheduleDate, scheduleTime);
        if (isAppointmentExistForPatient) {
            log.error("Patient with id {} already has an appointment on {} at {} in group {}",
                    patientId, scheduleDate, scheduleTime, groupId);
            throw new ConflictException("You already having an appointment in this time. So book some other appointment.");
        }

        boolean exists = appointmentRepository.getAvailableSlotsAtPatientEnd(groupId, providerId, scheduleDate, locationId, LocalDateTime.of(scheduleDate, scheduleTime), serviceId)
                .stream()
                .map(Time::toLocalTime)
                .anyMatch(t -> t.equals(scheduleTime));

        if (!exists) {
            log.error("The selected time slot {} on date {} is no longer available for provider ID: {}, location ID: {}, service ID: {} in group {}",
                    scheduleTime, scheduleDate, providerId, locationId, serviceId, groupId);
            throw new NotFoundException("The selected appointment slot is currently unavailable. Please choose a different time");
        }

        MedGroup.AppointmentType appointmentType = medGroupService.getAppointmentType(groupId);
        Appointment appointment = buildAppointmentFromForm(patientId, request, currentDateTime);
        appointment.setProviderConfirmed(appointmentType == MedGroup.AppointmentType.CONFIRMED);

        Appointment savedAppointment = appointmentRepository.save(appointment);
        String patientName = request.getPatient().getFirstName() + " " + request.getPatient().getLastName();
        log.info("Appointment saved for patient ID: {} form", patientId);

        String description = String.format(
                "The patient (%s) %s an appointment on %s at %s",
                patientName,
                appointmentType == MedGroup.AppointmentType.CONFIRMED ? "has scheduled" : "requested",
                request.getAppointment().getScheduleDate(),
                request.getAppointment().getScheduleTime()
        );

        saveActivity(savedAppointment, "APPOINTMENT", description);
    }

    @Override
    public AppointmentFormInitResponse getAppointmentFormInitData(String groupId) {
        log.info("Fetching appointment form initialization data for group ID: {}", groupId);
        if (!medGroupService.isMedGroupExists(groupId)) {
            throw new NotFoundException("MedGroup does not exist");
        }

        CustomizationResponse customization = customizationService.getCustomization(groupId);
        return AppointmentFormInitResponse.builder()
                .telehealthEnabled(medGroupFlagService.getAdminFlag(groupId).isTelehealth())
                .appointmentType(medGroupService.getAppointmentType(groupId))
                .appointmentRequestPopupMessage(customization.getApptRequestPopupContent())
                .groupDescription(medGroupService.getGroupDescription(groupId))
                .timeZone(medGroupService.getTimezone(groupId).toZoneId().toString())
                .formBuilderSetting(AppointmentFormBuilderSettingResponse.builder()
                        .showAddressFields(customization.isAddressFlag())
                        .showReasonField(customization.isReasonForVisitFlag())
                        .showPreferredContactField(customization.isPreferredContactFlag())
                        .showInsuranceCompanyField(customization.isInsuranceCompanyFlag())
                        .showInsuranceIdField(customization.isInsuranceIdFlag())
                        .showInsuranceGroupIdField(customization.isInsuranceGroupIdFlag())
                        .build())
                .build();
    }

    @Override
    public void confirmAppointment(Long id, ConfirmAppointmentRequest request) {
        log.info("Confirming appointment for patient ID: {}, appointment ID: {}, group ID: {}",
                request.patientId(), id, request.groupId());
        Appointment appointment = getAppointment(id, request.providerId(), request.locationId(),
                request.serviceId(), request.patientId(), request.groupId());

        appointment.setProviderConfirmed(true);
        Appointment savedAppointment = appointmentRepository.save(appointment);
        log.info("Appointment confirmed successfully for appointment ID: {}, patient ID: {}, group ID: {}",
                id, request.patientId(), request.groupId());

        String description = String.format("The user (%s) has confirmed the appointment for patient (%s).",
                Utils.getCurrentUsername(), appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName());
        saveActivity(savedAppointment, "APPOINTMENT", description);

        if (savedAppointment.isTelehealth()) {
            CompletableFuture.runAsync(() -> setTelehealthDetails(savedAppointment.getId()), asyncExecutor);
        } else {
            CompletableFuture.runAsync(() -> sendSMSAndEmail(savedAppointment.getId(), "APPOINTMENT_CONFIRMED"), asyncExecutor);
        }
    }

    @Override
    public void rescheduleAppointment(Long id, RescheduleAppointmentRequest request, AppointmentFormType formType) {
        switch (formType) {
            case STAFF -> handleStaffReschedule(id, request);
            case PATIENT -> handlePatientReschedule(id, request);
        }
    }

    @Override
    @Transactional
    public void cancelAppointment(Long id, CancelAppointmentRequest request, AppointmentFormType formType) {
        log.info("Cancel appointment with ID: {} for patient ID: {}, group ID: {} from {}",
                id, request.patientId(), request.groupId(), formType == AppointmentFormType.STAFF ? "staff" : "patient");
        Appointment appointment = getAppointment(id, request.patientId(), request.groupId());

        if (!appointment.isProviderConfirmed()) {
            log.error("Cannot cancel unconfirmed appointment ID: {} for patient ID: {}, group ID: {}", id, request.patientId(), request.groupId());
            throw new BadRequestException("Only confirmed appointments can be cancelled");
        }

        MedGroup medGroup = appointment.getMedGroup();
        Provider provider = appointment.getProvider();
        Patient patient = appointment.getPatient();
        Location location = appointment.getLocation();
        LocalDateTime scheduledDateTime = LocalDateTime.of(appointment.getScheduledDate(), appointment.getScheduledTime());

        // Integration call

        if (formType == AppointmentFormType.STAFF) {
            handleStaffCancellation(appointment);
        } else {
            handlePatientCancellation(appointment);
        }

        String canceledBy = formType == AppointmentFormType.STAFF ?
                Utils.getCurrentUsername() :
                "PATIENT";

        SaveCanceledAppointmentRequest cancelAppointmentRequest = getCancelAppointmentRequest(medGroup, patient, provider, location, scheduledDateTime, canceledBy, appointment.getLocationName());
        canceledAppointmentService.saveCanceledAppointment(cancelAppointmentRequest);
    }

    @Override
    public void denyAppointment(Long id, String groupId, Long patientId) {
        log.info("Denying appointment with ID: {} for patient ID: {}, group ID: {}", id, patientId, groupId);
        Appointment appointment = getAppointment(id, patientId, groupId);

        if (appointment.isProviderConfirmed()) {
            log.error("Cannot deny confirmed appointment ID: {} for patient ID: {}, group ID: {}", id, patientId, groupId);
            throw new BadRequestException("Only unconfirmed appointments can be denied");
        }

        String description = String.format("The user (%s) has cancelled the appointment request of %s at %s made by patient (%s)",
                Utils.getCurrentUsername(), appointment.getScheduledDate(), appointment.getScheduledTime(),
                appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName());
        saveActivity(appointment, "CANCEL APPOINTMENT REQUEST", description);

        sendAsyncNotifications(appointment, "APPOINTMENT_REQUEST_CANCELLATION");
        appointmentRepository.delete(appointment);
        log.info("Appointment request denied and deleted successfully for appointment ID: {}, patient ID: {}, group ID: {}", id, patientId, groupId);
    }

    @Override
    public Page<PatientAppointmentResponse> getPatientConfirmedAppointments(Long patientId, String groupId, Pageable pageable) {
        log.info("Fetching specific appointments for patient ID: {}, group ID: {}", patientId, groupId);
        LocalDateTime currentDateTime = medGroupService.getCurrentDateTime(groupId);
        Page<PatientAppointmentResponse> byPatientId = appointmentRepository.findByPatientId(patientId, groupId, currentDateTime.toLocalDate(), pageable);
        log.debug("data : {}", byPatientId.getContent());
        return byPatientId;
    }

    private List<Date> findAvailableDates(Function<LocalDateTime, List<Date>> fetchDates,
                                          GetAvailableDatesRequest request,
                                          LocalDateTime startDate) {
        LocalDateTime dateTime = startDate;

        for (int i = 0; i < 12; i++) {
            List<Date> availableDates = fetchDates.apply(dateTime);
            if (availableDates != null && !availableDates.isEmpty()) {
                return availableDates;
            }

            dateTime = dateTime.plusMonths(1).withDayOfMonth(1);
        }

        log.warn("No available dates found within 12 months for provider ID: {}, location ID: {}, service ID: {} in group {}",
                request.providerId(), request.locationId(), request.serviceId(), request.groupId());

        return Collections.emptyList();
    }

    private SaveCanceledAppointmentRequest getCancelAppointmentRequest(MedGroup medGroup, Patient patient, Provider provider, Location location, LocalDateTime scheduledDateTime, String canceledBy, String locationName) {
        return new SaveCanceledAppointmentRequest(medGroup, patient, provider, location, scheduledDateTime, canceledBy, locationName);
    }

    private void handleStaffCancellation(Appointment appointment) {
        String patientName = appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName();
        String description = "The user (%s) has cancelled the appointment for patient (%s)."
                .formatted(Utils.getCurrentUsername(), patientName);

        saveActivity(appointment, "APPOINTMENT CANCELLED", description);
        sendAsyncNotifications(appointment, "APPOINTMENT_CANCELLATION");

        appointmentRepository.delete(appointment);
    }

    private void handlePatientCancellation(Appointment appointment) {
        int restrictionHours = customizationService
                .getCustomization(appointment.getMedGroup().getGroupId())
                .getApptCancelRestrictionPeriod();

        LocalDateTime now = LocalDateTime.now(appointment.getMedGroup().getTimeZone().toZoneId());
        LocalDateTime scheduledDateTime = LocalDateTime.of(
                appointment.getScheduledDate(),
                appointment.getScheduledTime()
        );

        String patientName = appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName();
        boolean restricted = isWithinRestrictionPeriod(now, scheduledDateTime, restrictionHours, "cancellation");

        if (!restricted) {
            cancelAppointment(appointment, patientName);
        } else {
            requestCancellation(appointment, patientName);
        }
    }

    private boolean isWithinRestrictionPeriod(LocalDateTime now, LocalDateTime scheduled, int restrictionHours, String action) {
        if (restrictionHours == -1) {
            log.error("Appointment {} is not allowed as per the group settings", action);
            throw new BadRequestException(String.format("Appointment %s is not allowed as per the group settings", action));
        }

        if (restrictionHours == 0) {
            log.info("No restriction on appointment {} as per the group settings", action);
            return false;
        }

        LocalDateTime restrictionStart = scheduled.minusHours(restrictionHours);
        return now.isAfter(restrictionStart);
    }

    private void cancelAppointment(Appointment appointment, String patientName) {
        String description = String.format("The patient (%s) has cancelled their appointment.", patientName);
        saveActivity(appointment, "APPOINTMENT CANCELLED", description);
        sendAsyncNotifications(appointment, "APPOINTMENT_CANCELLATION");
        appointmentRepository.delete(appointment);
    }

    private void requestCancellation(Appointment appointment, String patientName) {
        appointment.setCancelRequested(true);
        appointmentRepository.save(appointment);

        String description = String.format("The patient (%s )has requested to cancel their appointment.", patientName);
        saveActivity(appointment, "APPOINTMENT CANCELLATION REQUESTED", description);
        sendAsyncNotifications(appointment, "APPOINTMENT_CANCELLATION_REQUESTED");
    }


    private void sendAsyncNotifications(Appointment appointment, String templateId) {
        CompletableFuture.runAsync(() -> {
            try {
                sendSMSAndEmail(appointment.getId(), templateId);
            } catch (Exception e) {
                log.error("Failed to send notifications for appointment {}", appointment.getId(), e);
            }
        }, asyncExecutor);
    }

    private void handlePatientReschedule(Long id, RescheduleAppointmentRequest request) {
        log.info("Rescheduling appointment ID: {} for patient ID: {}, group ID: {} from patient", id, request.patientId(), request.groupId());
        Appointment appointment = getAppointment(id, request.patientId(), request.groupId());

        if (!appointment.isProviderConfirmed()) {
            log.error("Cannot reschedule unconfirmed appointment ID: {} for patient ID: {}, group ID: {}", id, request.patientId(), request.groupId());
            throw new BadRequestException("Only confirmed appointments can be rescheduled");
        }
        setupNewProviderServiceLocationIfChanged(appointment, request);

        Long providerId = appointment.getProvider().getId();
        Long locationId = appointment.getLocation().getId();
        Long serviceId = appointment.getService().getId();

        int apptRescheduleRestrictionPeriod = customizationService.getCustomization(appointment.getMedGroup().getGroupId()).getApptRescheduleRestrictionPeriod();
        MedGroup.AppointmentType appointmentType = medGroupService.getAppointmentType(request.groupId());

        log.info("Appointment type for group {} is {}", request.groupId(), appointmentType);
        LocalDateTime currentDateTime = LocalDateTime.now(appointment.getMedGroup().getTimeZone().toZoneId());
        LocalDateTime scheduled = LocalDateTime.of(appointment.getScheduledDate(), appointment.getScheduledTime());

        boolean isRestricted = isWithinRestrictionPeriod(currentDateTime, scheduled, apptRescheduleRestrictionPeriod, "reschedule");

        log.info("Rescheduling to a specific time {} for appointment ID: {}", request.scheduleTime(), id);
        boolean slotExists = appointmentRepository.getAvailableSlotsAtPatientEnd(request.groupId(), providerId, request.scheduleDate(), locationId, currentDateTime, serviceId).stream()
                .map(Time::toLocalTime).anyMatch(t -> t.equals(request.scheduleTime()));
        if (!slotExists) {
            log.error("The selected time slot {} on date {} is no longer available for provider ID: {}, location ID: {}, service ID: {} in group {}", request.scheduleTime(), request.scheduleDate(), providerId, locationId, serviceId, request.groupId());
            throw new NotFoundException("The selected appointment slot is currently unavailable. Please choose a different time");
        }

        appointment.setScheduledTime(request.scheduleTime());
        appointment.setSession(null);

        String activityDescription;
        String savedLog;

        if (appointmentType == MedGroup.AppointmentType.CONFIRMED) {
            appointment.setProviderConfirmed(!isRestricted);
            activityDescription = "The patient %s has rescheduled their appointment.".formatted(appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName());
            savedLog = "Appointment rescheduled successfully for appointment ID: {}";
        } else {
            appointment.setProviderConfirmed(false);
            activityDescription = "The patient %s has requested to reschedule their appointment.".formatted(appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName());
            savedLog = "Appointment reschedule requested successfully for appointment ID: {}";
        }
        appointment.setScheduledDate(request.scheduleDate());
        appointment.setReasonForVisit(request.reason());
        appointment.setStatus(AppointmentStatus.UPCOMING);

        Appointment savedAppointment = appointmentRepository.save(appointment);
        log.info(savedLog, savedAppointment.getId());
        log.debug("scheduledTime: {}", savedAppointment.getScheduledTime());
        saveActivity(savedAppointment, "APPOINTMENT RESCHEDULED", activityDescription);

        if (savedAppointment.isTelehealth()) {
            CompletableFuture.runAsync(() -> setTelehealthDetails(savedAppointment.getId()), asyncExecutor);
        } else {
            CompletableFuture.runAsync(() -> sendSMSAndEmail(savedAppointment.getId(), "APPOINTMENT_RESCHEDULED"), asyncExecutor);
        }
    }

    private Appointment getAppointment(Long id, Long patientId, String groupId) {
        log.info("Retrieving appointment with ID: {}, patient ID: {}, group ID: {}",
                id, patientId, groupId);
        return appointmentRepository.findByIdAndPatientId(id, patientId, groupId).orElseThrow(() -> {
            log.error("Appointment not found with ID: {}, patient ID: {}, group ID: {}",
                    id, patientId, groupId);
            return new NotFoundException("Appointment not found");
        });
    }

    private void handleStaffReschedule(Long id, RescheduleAppointmentRequest request) {
        log.info("Rescheduling appointment ID: {} for patient ID: {}, group ID: {} from staff", id, request.patientId(), request.groupId());
        Appointment appointment = getAppointment(id, request.patientId(), request.groupId());

        LocalDateTime currentDateTime = LocalDateTime.now(appointment.getMedGroup().getTimeZone().toZoneId());
        setupNewProviderServiceLocationIfChanged(appointment, request);

        Long providerId = appointment.getProvider().getId();
        Long locationId = appointment.getLocation().getId();
        Long serviceId = appointment.getService().getId();

        if (request.scheduleTime() == null) {
            log.error("Scheduled time cannot be null during staff rescheduling for appointment ID: {}", id);
            throw new BadRequestException("Scheduled time cannot be null");
        }

        boolean slotExists = appointmentRepository.getAvailableSlots(request.groupId(), providerId, request.scheduleDate(), locationId, currentDateTime, serviceId).stream()
                .map(Time::toLocalTime)
                .anyMatch(t -> t.equals(request.scheduleTime()));
        if (!slotExists) {
            log.error("The selected time slot {} on date {} is no longer available for provider ID: {}, location ID: {}, service ID: {} in group {}", request.scheduleTime(), request.scheduleDate(), providerId, locationId, serviceId, request.groupId());
            throw new NotFoundException("The selected appointment slot is currently unavailable. Please choose a different time");
        }

        appointment.setScheduledDate(request.scheduleDate());
        appointment.setScheduledTime(request.scheduleTime());
        appointment.setSession(null);
        appointment.setProviderConfirmed(true);
        appointment.setReasonForVisit(request.reason());
        appointment.setStatus(AppointmentStatus.UPCOMING);

        Appointment savedAppointment = appointmentRepository.save(appointment);
        log.info("Appointment rescheduled successfully for appointment ID: {}, patient ID: {}, group ID: {}", id, request.patientId(), request.groupId());

        String description = "The user (%s) has rescheduled the appointment for patient (%s)."
                .formatted(Utils.getCurrentUsername(), appointment.getPatient().getFirstName() + " " + appointment.getPatient().getLastName());
        saveActivity(savedAppointment, "APPOINTMENT RESCHEDULED", description);

        if (savedAppointment.isTelehealth()) {
            CompletableFuture.runAsync(() -> setTelehealthDetails(savedAppointment.getId()), asyncExecutor);
        } else {
            CompletableFuture.runAsync(() -> sendSMSAndEmail(savedAppointment.getId(), "APPOINTMENT_RESCHEDULED"), asyncExecutor);
        }
    }

    private void setupNewProviderServiceLocationIfChanged(Appointment appointment, RescheduleAppointmentRequest request) {
        if (request.newProviderId() != null) {
            checkProviderExists(request.newProviderId(), request.groupId());
            appointment.setProvider(new Provider(request.newProviderId()));
        }

        if (request.newLocationId() != null) {
            Location location = locationService.getLocationById(request.newLocationId(), request.groupId());
            appointment.setLocation(location);
            appointment.setLocationName(location.getName());
        }

        if (request.newServiceId() != null) {
            Service service = serviceManagement.getServiceEntity(request.newServiceId(), request.groupId());

            if (service.getVisitType() != Service.VisitType.TELEHEALTH) {
                ProviderOffering providerOffering = providerOfferingService.getProviderOffering(appointment.getProvider().getId(),
                        service.getId(), request.groupId());
                if (providerOffering != null) {
                    if (providerOffering.getVisitType() != null && providerOffering.getVisitType() == Service.VisitType.IN_PERSON) {
                        appointment.setTelehealth(false);
                    }
                }
            } else {
                validateTelehealthEligibility(request.groupId(), appointment.getProvider().getId(), service);
                appointment.setTelehealth(true);
            }

            appointment.setService(service);
            appointment.setDuration(service.getDuration());
            appointment.setServiceName(service.getServiceName());
        }
    }


    private Appointment getAppointment(Long id, Long providerId, Long locationId, Long serviceId, Long patientId, String groupId) {
        log.info("Retrieving appointment with ID: {}, provider ID: {}, location ID: {}, service ID: {}, patient ID: {}, group ID: {}",
                id, providerId, locationId, serviceId, patientId, groupId);
        return appointmentRepository.findById(
                id,
                providerId,
                locationId,
                serviceId,
                patientId,
                groupId
        ).orElseThrow(() -> {
            log.error("Appointment not found with ID: {}, provider ID: {}, location ID: {}, service ID: {}, patient ID: {}, group ID: {}",
                    id, providerId, locationId, serviceId, patientId, groupId);
            return new NotFoundException("Appointment not found");
        });
    }

    private Appointment buildAppointmentFromForm(Long patientId, SaveFormAppointmentRequest request, LocalDateTime currentDateTime) {
        String groupId = request.getGroupId();
        Long providerId = request.getAppointment().getProviderId();
        Long serviceId = request.getAppointment().getServiceId();

        Service service = serviceManagement.getServiceEntity(serviceId, groupId);
        boolean isTelehealth = request.getAppointment().getIsTelehealth();
        if (isTelehealth) {
            validateTelehealthEligibility(
                    groupId,
                    providerId,
                    service
            );
        }

        Location location = locationService.getLocationById(request.getAppointment().getLocationId(), groupId);

        Appointment appointment = new Appointment();
        appointment.setMedGroup(new MedGroup(groupId));
        appointment.setLocation(location);
        appointment.setLocationName(location.getName());
        appointment.setProvider(new Provider(providerId));
        appointment.setService(service);
        appointment.setDuration(service.getDuration());
        appointment.setServiceName(service.getServiceName());
        appointment.setPatient(new Patient(patientId));
        appointment.setScheduledDate(request.getAppointment().getScheduleDate());
        appointment.setScheduledTime(request.getAppointment().getScheduleTime());
        appointment.setStatus(AppointmentStatus.UPCOMING);
        appointment.setTelehealth(isTelehealth);
        appointment.setReasonForVisit(request.getAppointment().getReason());
        appointment.setWaitlistRequested(request.getAppointment().isWaitingForEarlyAppointment());
        appointment.setInsuranceCompanyName(request.getAppointment().getInsuranceCompany());
        appointment.setInsuranceCompanyCode(request.getAppointment().getInsuranceCompanyCode());
        appointment.setInsuranceId(request.getAppointment().getInsuranceId());
        appointment.setInsuranceGroupId(request.getAppointment().getInsuranceGroupId());
        appointment.setCreatedAt(currentDateTime);

        return appointment;
    }

    private void saveActivity(Appointment appointment, String activityType, String description) {
        ActivityRequest request = new ActivityRequest();
        Patient patient = appointment.getPatient();

        request.setPatient(patient);
        request.setGroupId(appointment.getMedGroup().getGroupId());
        request.setProvider(appointment.getProvider());
        request.setActivityType(activityType);
        request.setActivityDescription(description);
        activityService.saveActivity(request);
    }

    private void sendSMSAndEmail(Long id, String templateId) {
        log.info("Fetching appointment details for sending SMS and Email for appointment ID: {}", id);
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Appointment not found"));
        String groupId = appointment.getMedGroup().getGroupId();
        Long patientId = appointment.getPatient().getId();

        log.info("Sending SMS for appointment ID: {} to patient ID: {}", id, patientId);
        patientCommunicationService.validateAndSendSMS(
                groupId,
                Set.of(patientId),
                appointment,
                templateId
        );

        log.info("Sending Email for appointment ID: {} to patient ID: {}", id, patientId);
        patientCommunicationService.validateAndSendEmail(
                groupId,
                Set.of(patientId),
                appointment,
                templateId
        );
    }

    private void setTelehealthDetails(Long id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Appointment not found"));
        MedGroup medGroup = appointment.getMedGroup();
        appointment.setTelehealth(true);

        switch (medGroup.getTelehealth()) {
            case GOTO_MEETING -> handleGotoMeeting(appointment);
            case PHONE -> handlePhone(appointment);
        }

        saveTelehealthAppointment(appointment);
    }

    private void handlePhone(Appointment appointment) {
        log.info("Setting up Phone telehealth for appointment ID: {}", appointment.getId());
        TelehealthService telehealthService = telehealthServiceMap.get("PHONE");

        telehealthService.sendEmail(appointment);
        telehealthService.sendSMS(appointment);
    }

    private void handleGotoMeeting(Appointment appointment) {
        log.info("Setting up GoToMeeting for appointment ID: {}", appointment.getId());
        TelehealthService telehealthService = telehealthServiceMap.get("GOTO_MEETING");
        Map<String, Object> result = telehealthService.setup(appointment);

        appointment.setTelehealthMeetingUrl((String) result.get("MEETING_URL"));
        appointment.setTelehealthMeetingId((Integer) result.get("MEETING_ID"));

        telehealthService.sendEmail(appointment);
        telehealthService.sendSMS(appointment);
    }

    private void saveTelehealthAppointment(Appointment appointment) {
        appointmentRepository.save(appointment);
        log.info("Telehealth details set for appointment ID: {}", appointment.getId());
    }

    private Appointment getAppointment(SaveManualAppointmentRequest request) {
        Location location = locationService.getLocationById(request.locationId(), request.groupId());
        Appointment appointment = new Appointment();

        appointment.setMedGroup(new MedGroup(request.groupId()));
        appointment.setLocation(location);
        appointment.setLocationName(location.getName());
        appointment.setProvider(new Provider(request.providerId()));
        appointment.setPatient(new Patient(request.patientId()));
        appointment.setScheduledDate(request.scheduledDate());
        appointment.setScheduledTime(request.scheduledTime());
        appointment.setStatus(AppointmentStatus.UPCOMING);
        appointment.setProviderConfirmed(true);
        appointment.setReasonForVisit(request.reason());

        return appointment;
    }

    private void validateTelehealthEligibility(String groupId, Long providerId, Service service) {
        Long serviceId = service.getId();

        if (!medGroupFlagService.getAdminFlag(groupId).isTelehealth() ||
                service.getMedGroup().getTelehealth() == null) {
            log.error("Telehealth configuration is missing for group {}", service.getMedGroup().getGroupId());
            throw new BadRequestException("Telehealth configuration is missing for this group");
        }

        if (service.getVisitType() != null) {
            if (service.getVisitType() == com.rhombuzz.gpbackend.modules.medgroup.entity.Service.VisitType.IN_PERSON) {
                log.error("Service with id {} is in-person only, cannot book telehealth appointment",
                        service.getId());
                throw new BadRequestException("Selected service is not eligible for telehealth");
            }
        }

        ProviderOffering providerOffering = providerOfferingService.getProviderOffering(
                providerId, serviceId, groupId);
        if (providerOffering != null && providerOffering.getVisitType() != null) {
            if (providerOffering.getVisitType() == Service.VisitType.IN_PERSON) {
                log.error("Provider with id {} offers service id {} as in-person only, cannot book telehealth appointment",
                        providerId, serviceId);
                throw new BadRequestException("Selected service is not eligible for telehealth");
            }
        }
    }

    private void validatedExistence(String groupId, Long patientId, Long providerId, Long serviceId) {
        checkMedGroupExists(groupId);
        checkPatientExists(patientId, groupId);
        checkProviderExists(providerId, groupId);
        checkProviderOfferingDisabled(providerId, serviceId, groupId);
    }

    private void checkProviderExists(Long providerId, String groupId) {
        if (!providerService.isProviderExists(providerId, groupId)) {
            log.error("Provider with id {} does not exist", providerId);
            throw new BadRequestException("Provider does not exist");
        }
    }

    private void checkPatientExists(Long patientId, String groupId) {
        if (!patientService.isPatientExists(patientId, groupId)) {
            log.error("Patient with id {} does not exist", patientId);
            throw new BadRequestException("Patient does not exist");
        }
    }

    private void checkMedGroupExists(String groupId) {
        if (!medGroupService.isMedGroupExists(groupId)) {
            log.error("MedGroup with id {} does not exist", groupId);
            throw new BadRequestException("MedGroup does not exist");
        }
    }

    private void checkProviderOfferingDisabled(Long providerId, Long serviceId, String groupId) {
        if (providerOfferingService.isProviderOfferingDisabled(providerId, serviceId, groupId)) {
            log.error("Service with id {} is disabled for provider with id {} in group {}",
                    serviceId, providerId, groupId);
            throw new BadRequestException("Service is not offered by the provider");
        }
    }

    private LocalDateTime determineStartDateTime(GetAvailableDatesRequest request) {
        LocalDateTime dateTime = medGroupService.getCurrentDateTime(request.groupId());
        return Utils.resolveStartDateTime(request.month(), request.year(), dateTime);
    }

    private AppointmentStatus getExistingAppointmentStatus(Long id, String groupId) {
        return appointmentRepository.findStatusById(id, groupId)
                .orElseThrow(() -> new NotFoundException("Appointment not found with given ID ={" + id + "} and groupId ={" + groupId + "}"));
    }

    private boolean isAppointmentStatusFlowValid(AppointmentStatus currentStatus, AppointmentStatus newStatus) {
        return switch (currentStatus) {
            case UPCOMING ->
                    newStatus == AppointmentStatus.PATIENT_CONFIRMED || newStatus == AppointmentStatus.CHECKED_IN || newStatus == AppointmentStatus.NO_SHOW;
            case PATIENT_CONFIRMED ->
                    newStatus == AppointmentStatus.CHECKED_IN || newStatus == AppointmentStatus.COMPLETED || newStatus == AppointmentStatus.NO_SHOW;
            case CHECKED_IN ->
                    newStatus == AppointmentStatus.PATIENT_CONFIRMED || newStatus == AppointmentStatus.COMPLETED || newStatus == AppointmentStatus.NO_SHOW;
            case COMPLETED, NO_SHOW -> false;
        };
    }
}
