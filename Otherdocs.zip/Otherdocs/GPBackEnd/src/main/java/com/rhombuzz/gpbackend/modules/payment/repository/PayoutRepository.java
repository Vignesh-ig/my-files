package com.rhombuzz.gpbackend.modules.payment.repository;

import com.rhombuzz.gpbackend.modules.payment.entity.Payout;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PayoutRepository extends JpaRepository<Payout, Long> {
}
