package com.rhombuzz.gpbackend.modules.patient.dto.request;

import com.rhombuzz.gpbackend.modules.patient.dto.PatientInsuranceDTO;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public record SavePatientInsuranceRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Patient ID cannot be null")
        @Positive(message = "Patient ID must be a positive number")
        Long patientId,

        boolean haveInsurance,
        PatientInsuranceDTO primaryInsurance,
        boolean haveSecIns,
        PatientInsuranceDTO secondaryInsurance
) {

    @AssertTrue(message = "Primary insurance is not having all the valid fields.")
    public boolean isPrimaryInsuranceValid() {
        log.info("called isPrimaryInsuranceValid.");
        return !haveInsurance || (primaryInsurance != null && primaryInsurance.isValid());
    }

    @AssertTrue(message = "Secondary insurance is not having all the valid fields.")
    public boolean isSecondaryInsuranceValid() {
        log.info("called isSecondaryInsuranceValid.");
        if (haveSecIns && !haveInsurance) return false;
        return !haveSecIns || (secondaryInsurance != null && secondaryInsurance.isValid());
    }
}
