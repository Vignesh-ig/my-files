package com.rhombuzz.gpbackend.modules.provider.service;

import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveSpecificAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.request.UpdateSpecificAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.SpecificAvailabilityResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
public interface SpecificAvailabilityService {

    void saveSpecificAvailability(
            @Valid SaveSpecificAvailabilityRequest request
    );

    List<SpecificAvailabilityResponse> getSpecificAvailabilities(
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateSpecificAvailability(
            @NotNull @Positive Long id,
            @Valid UpdateSpecificAvailabilityRequest request);

    @Transactional
    void deleteSpecificAvailability(
            @NotNull @Positive Long id,
            @NotNull @Positive Long providerId,
            @NotNull @Positive Long locationId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
