package com.rhombuzz.gpbackend.modules.task.controller;

import com.rhombuzz.gpbackend.modules.task.dto.request.SaveTodoListRequest;
import com.rhombuzz.gpbackend.modules.task.dto.response.TodoListResponse;
import com.rhombuzz.gpbackend.modules.task.service.TodoListService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/todo-lists")
@Validated
public class TodoListController {
    private final TodoListService todoListService;

    @PostMapping
    public ResponseEntity<Void> saveTodoList(@RequestBody @Valid SaveTodoListRequest request) {
        todoListService.saveTodoList(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<Page<TodoListResponse>> getTodoLists(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<TodoListResponse> todoLists = todoListService.getTodoLists(groupId, pageable);
        return ResponseEntity.ok(todoLists);
    }

    @PatchMapping("/{id}/reassign")
    public ResponseEntity<Void> reassignTodoList(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            @RequestParam @NotBlank String assignTo
    ) {
        todoListService.reassignTodoList(id, groupId, assignTo);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTodoList(
            @PathVariable @NotNull Long id,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        todoListService.deleteTodoList(id, groupId);
        return ResponseEntity.noContent().build();
    }
}
