package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.entity.SMS;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SMSRepository extends JpaRepository<SMS, Long> {
    @Query("SELECT s FROM SMS s WHERE s.patient.id = ?1 AND s.medGroup.groupId = ?2 AND s.conversationStatus = ?3")
    List<SMS> findByPatientAndGroupIdAndStatus(Long patientId, String groupId, Integer conversationStatus);

    @Query("UPDATE SMS s SET s.conversationStatus = ?4 WHERE s.id = ?1 AND s.medGroup.groupId = ?2 AND s.conversationId = ?3")
    void updateConversationStatusById(Long id, String groupId, String conversationId, Integer conversationStatus);
}
