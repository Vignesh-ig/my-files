package com.rhombuzz.gpbackend.exception;

import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Profile("prod")
@RestControllerAdvice
public class ProdGlobalExceptionHandler extends BaseGlobalExceptionHandler {
}
