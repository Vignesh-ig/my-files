package com.rhombuzz.gpbackend.modules.support.repository;

import com.rhombuzz.gpbackend.modules.support.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    @Query("SELECT t FROM Ticket t WHERE t.id = ?1 AND t.support.id = ?2 AND t.medGroup.groupId = ?3")
    Optional<Ticket> findById(Long id, Long supportId, String groupId);

    @Query("SELECT t FROM Ticket t WHERE t.support.id = ?1 AND t.medGroup.groupId = ?2 ORDER BY t.createdAt DESC LIMIT 1")
    Optional<Ticket> findLastTicket(Long supportId, String groupId);

    @Query("SELECT t FROM Ticket t WHERE t.support.id = ?1 AND t.medGroup.groupId = ?2 ORDER BY t.createdAt ASC")
    List<Ticket> findBySupportId(Long supportId, String groupId);
}
