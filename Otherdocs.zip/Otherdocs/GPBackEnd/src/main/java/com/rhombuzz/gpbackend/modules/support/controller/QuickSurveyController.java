package com.rhombuzz.gpbackend.modules.support.controller;

import com.rhombuzz.gpbackend.modules.support.dto.request.SaveQuickSurveyRequest;
import com.rhombuzz.gpbackend.modules.support.dto.request.UpdateQuickSurveyRequest;
import com.rhombuzz.gpbackend.modules.support.service.QuickSurveyService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/quick-surveys")
@Validated
public class QuickSurveyController {
    private final QuickSurveyService quickSurveyService;

    @PostMapping
    public ResponseEntity<Void> saveQuickSurvey(@RequestBody @Valid SaveQuickSurveyRequest request) {
        quickSurveyService.saveQuickSurvey(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PatchMapping("/secret/{secretId}")
    public ResponseEntity<Void> submitQuickSurvey(
            @PathVariable @NotBlank @Size(min = 10, max = 10) String secretId,
            @RequestBody @Valid UpdateQuickSurveyRequest request
    ) {
        quickSurveyService.updateQuickSurvey(secretId, request);
        return ResponseEntity.noContent().build();
    }
}
