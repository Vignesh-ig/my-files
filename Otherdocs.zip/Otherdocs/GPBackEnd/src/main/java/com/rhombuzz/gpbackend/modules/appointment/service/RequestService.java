package com.rhombuzz.gpbackend.modules.appointment.service;

import com.rhombuzz.gpbackend.modules.appointment.dto.request.PendingRequestFilter;
import com.rhombuzz.gpbackend.modules.appointment.dto.response.PendingRequestResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

@Validated
public interface RequestService {

    Page<PendingRequestResponse> getPendingRequests(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @Valid PendingRequestFilter filter,
            Pageable pageable
    );
}
