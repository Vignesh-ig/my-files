package com.rhombuzz.gpbackend.integration.service;

import com.rhombuzz.gpbackend.integration.entity.enums.IntegrationActionType;
import com.rhombuzz.gpbackend.integration.entity.enums.IntegrationResourceType;
import com.rhombuzz.gpbackend.integration.repository.IntegrationRepository;
import com.rhombuzz.gpbackend.integration.repository.IntegrationResourceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class IntegrationDispatcher {

    private final IntegrationRepository integrationRepository;
    private final IntegrationResourceRepository integrationResourceRepository;
    private final Map<String, IntegrationService> integrationServicesMap;

    public void dispatchDataToIntegrations(String groupId, IntegrationResourceType resourceType, IntegrationActionType actionType) {

        log.info("Dispatching data to external integration for groupId: {} resourceType: {} actionType: {}", groupId, resourceType, actionType);

        List<String> integrations = integrationRepository.getIntegrationsByGroupId(groupId);
        log.info("Found integrations for groupId {}: {}", groupId, integrations);

        if (!integrations.isEmpty()) {

            for (String integration : integrations) {

                IntegrationService integrationService = integrationServicesMap.get(integration);

                if(integrationService == null) {
                    log.warn("No IntegrationService found for integration: {}", integration); // Need to handle
                    continue;
                }

                log.info("Using integration service: {} for integration: {}", integrationService.getClass().getSimpleName(), integration);

                boolean isResourceAllowed = integrationResourceRepository.existsByMedGroup_GroupIdAndIntegrationNameAndIntegrationResource(groupId, integration, resourceType);

                log.info("isResourceAllowed : {}", isResourceAllowed);
                if (isResourceAllowed) {
                    callIntegrationService(integrationService, resourceType, actionType);
                }
            }
        }
    }

    private void callIntegrationService(IntegrationService integrationService, IntegrationResourceType resourceType, IntegrationActionType actionType) {

        log.info("Calling action: {} on integration service: {}", actionType, integrationService.getClass().getSimpleName());

        switch (resourceType) {
            case IntegrationResourceType.PATIENT -> integrationService.handlePatientResource();
            case IntegrationResourceType.APPOINTMENT -> integrationService.handleAppointmentResource();
            default -> throw new IllegalArgumentException("Unknown resource type for integration : " + resourceType);
        }

    }
}
