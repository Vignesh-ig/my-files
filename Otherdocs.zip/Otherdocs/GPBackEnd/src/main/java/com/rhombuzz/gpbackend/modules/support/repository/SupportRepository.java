package com.rhombuzz.gpbackend.modules.support.repository;

import com.rhombuzz.gpbackend.modules.support.entity.Support;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface SupportRepository extends JpaRepository<Support, Long> {

    @Query("SELECT s FROM Support s WHERE s.id = ?1 AND s.medGroup.groupId = ?2")
    Optional<Support> findById(Long supportId, String groupId);
}
