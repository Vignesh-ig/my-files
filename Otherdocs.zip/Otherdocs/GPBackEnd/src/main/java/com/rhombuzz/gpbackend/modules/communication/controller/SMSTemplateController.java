package com.rhombuzz.gpbackend.modules.communication.controller;

import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.UpdateSMSTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSTemplate;
import com.rhombuzz.gpbackend.modules.communication.service.SMSTemplateService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/sms-templates")
@Validated
public class SMSTemplateController {
    private final SMSTemplateService smsTemplateService;

    @PostMapping
    public ResponseEntity<Void> saveSMSTemplate(
            @RequestBody @Valid SaveSMSTemplateRequest request
    ) {
        smsTemplateService.saveSMSTemplate(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<Map<SMSTemplate.TemplateGroup, List<SMSTemplateIdResponse>>> getSMSTemplates(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Map<SMSTemplate.TemplateGroup, List<SMSTemplateIdResponse>> templates = smsTemplateService.getSMSTemplates(groupId);
        return ResponseEntity.ok(templates);
    }

    @GetMapping("/{templateId}")
    public ResponseEntity<SMSTemplateResponse> getSMSTemplate(
            @PathVariable @NotBlank String templateId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        SMSTemplateResponse template = smsTemplateService.getSMSTemplate(templateId, groupId);
        return ResponseEntity.ok(template);
    }

    @PutMapping("/{templateId}")
    public ResponseEntity<Void> updateSMSTemplate(
            @PathVariable @NotBlank String templateId,
            @RequestBody @Valid UpdateSMSTemplateRequest request
    ) {
        smsTemplateService.updateSMSTemplate(templateId, request);
        return ResponseEntity.noContent().build();
    }
}
