package com.rhombuzz.gpbackend.component;

import com.auth0.client.auth.AuthAPI;
import com.auth0.client.mgmt.ManagementAPI;
import com.auth0.client.mgmt.RolesEntity;
import com.auth0.client.mgmt.UsersEntity;
import com.auth0.exception.Auth0Exception;
import com.auth0.json.auth.TokenHolder;
import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.rhombuzz.gpbackend.modules.api.dto.request.GetConfigValueRequest;
import com.rhombuzz.gpbackend.modules.api.dto.request.UpdateConfigRequest;
import com.rhombuzz.gpbackend.modules.api.service.ConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;

@Component
@Slf4j
public class TokenValidator {
    private static final String AUTH0_API_AUDIENCE_SUFFIX = "api/v2/";
    private static final String AUTH0_CONFIG_TYPE = "AUTH0";
    private static final String AUTH0_MANAGEMENT_TOKEN = "AUTH0_MANAGEMENT_TOKEN";

    private final ReentrantLock tokenRefreshLock = new ReentrantLock();

    private final String auth0Domain;
    private final AuthAPI authAPI;
    private final ManagementAPI managementAPI;
    private final ConfigService configService;

    public TokenValidator(CredentialsFactory credentialsFactory, AuthAPI authAPI, ManagementAPI managementAPI, ConfigService configService) {
        this.auth0Domain = credentialsFactory.getValue("AUTH0_DOMAIN", AUTH0_CONFIG_TYPE, "DOMAIN");
        this.authAPI = authAPI;
        this.managementAPI = managementAPI;
        this.configService = configService;
    }

    public void refreshTokenIfExpired() {
        Optional<String> currentToken = getCurrentToken();
        if (currentToken.isPresent() && isTokenValid(currentToken.get())) {
            log.debug("Token is still valid, no refresh needed");
            return;
        }

        String newToken = getValidToken();
        managementAPI.setApiToken(newToken);
    }

    public UsersEntity users() {
        return managementAPI.users();
    }

    public RolesEntity roles() {
        return managementAPI.roles();
    }

    private String getValidToken() {
        Optional<String> currentToken = getCurrentToken();
        if (currentToken.isPresent() && isTokenValid(currentToken.get())) {
            log.debug("Using existing valid token");
            return currentToken.get();
        }

        tokenRefreshLock.lock();
        try {
            currentToken = getCurrentToken();
            if (currentToken.isPresent() && isTokenValid(currentToken.get())) {
                log.debug("Using existing valid token after lock acquisition");
                return currentToken.get();
            }

            log.info("Refreshing Auth0 management API token");
            String newToken = refreshAuth0Token();
            updateConfigToken(newToken);
            return newToken;
        } finally {
            tokenRefreshLock.unlock();
        }
    }

    private Optional<String> getCurrentToken() {
        return configService.getConfigValue(new GetConfigValueRequest(AUTH0_MANAGEMENT_TOKEN, AUTH0_CONFIG_TYPE));
    }

    private boolean isTokenValid(String token) {
        try {
            DecodedJWT decodedJWT = JWT.decode(token);
            Instant expiresAt = decodedJWT.getExpiresAtAsInstant();
            return expiresAt.isAfter(Instant.now());
        } catch (JWTDecodeException e) {
            log.warn("Invalid JWT token: {}", e.getMessage());
            return false;
        }
    }

    private String refreshAuth0Token() {
        String audience = auth0Domain + AUTH0_API_AUDIENCE_SUFFIX;
        log.debug("Refreshing Auth0 token for audience: {}", audience);

        try {
            TokenHolder tokenHolder = authAPI.requestToken(audience).execute().getBody();
            if (tokenHolder == null || tokenHolder.getAccessToken() == null) {
                throw new RuntimeException("Received null token from Auth0");
            }
            return tokenHolder.getAccessToken();
        } catch (Auth0Exception e) {
            log.error("Failed to refresh Auth0 token", e);
            throw new RuntimeException("Failed to refresh access token", e);
        }
    }

    private void updateConfigToken(String newToken) {
        UpdateConfigRequest request = new UpdateConfigRequest() {{
            setConfigName(AUTH0_MANAGEMENT_TOKEN);
            setType(AUTH0_CONFIG_TYPE);
            setConfigValue(newToken);
            setType(AUTH0_CONFIG_TYPE);
        }};

        configService.saveConfig(request);
    }
}
