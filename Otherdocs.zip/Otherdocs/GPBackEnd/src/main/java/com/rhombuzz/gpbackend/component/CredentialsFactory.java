package com.rhombuzz.gpbackend.component;

import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.api.dto.request.GetConfigValueRequest;
import com.rhombuzz.gpbackend.modules.api.service.ConfigService;
import com.rhombuzz.gpbackend.modules.medgroup.dto.AWSDTO;
import com.rhombuzz.gpbackend.modules.medgroup.repository.MedGroupRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.iam.IamClient;
import software.amazon.awssdk.services.s3.S3Client;

@Component
@RequiredArgsConstructor
@Slf4j
public class CredentialsFactory {
    private final MedGroupRepository medGroupRepository;
    private final ConfigService configService;

    @Value("${spring.profiles.active}")
    private String activeProfile;

    public S3Client s3Client(AccessType accessType) {
        log.info("Access type for s3Client : {}", accessType);
        if (accessType != AccessType.ADMIN) {
            log.error("Access type {} not supported for s3Client", accessType);
            throw new IllegalArgumentException("groupId is required for non-ADMIN access types");
        }
        return s3Client(accessType, null);
    }

    public S3Client s3Client(AccessType accessType, String groupId) {
        log.info("Access type for s3Client : {}, groupId : {}", accessType, groupId);
        return S3Client.builder()
                .region(Region.US_EAST_1)
                .credentialsProvider(credentialsProvider(accessType, groupId))
                .build();
    }

    public IamClient iamClient(AccessType accessType) {
        log.info("Access type for iamClient : {}", accessType);
        if (accessType != AccessType.ADMIN) {
            log.error("Access type {} not supported for iamClient", accessType);
            throw new IllegalArgumentException("groupId is required for non-ADMIN access types");
        }
        return iamClient(accessType, null);
    }

    public IamClient iamClient(AccessType accessType, String groupId) {
        log.info("Access type for iamClient : {}, groupId : {}", accessType, groupId);
        return IamClient.builder()
                .region(Region.US_EAST_1)
                .credentialsProvider(credentialsProvider(accessType, groupId))
                .build();
    }

    private AwsCredentialsProvider credentialsProvider(AccessType accessType, String groupId) {
        if (accessType != AccessType.ADMIN && (groupId == null || groupId.isEmpty())) {
            throw new IllegalArgumentException("groupId is required for accessType: " + accessType);
        }

        AWSDTO crd = getCredentials(accessType, groupId);
        String accessKey = crd.getAccessKey();
        String secretKey = crd.getSecretKey();
        return StaticCredentialsProvider.create(AwsBasicCredentials.create(accessKey, secretKey));
    }

    private AWSDTO getCredentials(AccessType accessType, String groupId) {
        return switch (accessType) {
            case ADMIN -> AWSDTO.builder()
                    .accessKey(getValue("S3_ADMIN_USERNAME", "AMAZON_STORAGE", ""))
                    .secretKey(getValue("S3_ADMIN_PASSWORD", "AMAZON_STORAGE", ""))
                    .build();
            case GROUP -> {
                if (groupId == null || groupId.isEmpty()) {
                    throw new InternalServerErrorException("groupId is required for GROUP access type");
                }
                yield medGroupRepository.getAWSAccess(groupId)
                        .orElseThrow(() -> new NotFoundException("AWS credentials not found"));
            }
        };
    }

    public String getValue(String configName, String type, String defaultValue) {
        final var configValue = configService.getConfigValue(new GetConfigValueRequest(configName, type));
        if ("prod".equalsIgnoreCase(activeProfile)) {
            return configValue.orElseThrow(() -> {
                        log.error("Config value not found for configName: {}, type: {}, activeProfile: {}", configName, type, activeProfile);
                        return new NotFoundException("Config value not found");
                    });
        } else {
            return configValue.orElseGet(() -> {
                        log.warn("Config value not found for configName: {}, type: {}, activeProfile: {}", configName, type, activeProfile);
                        log.warn("Returning default value: {}", defaultValue);
                        return defaultValue;
                    });
        }
    }

    public enum AccessType {
        ADMIN,
        GROUP
    }
}