package com.rhombuzz.gpbackend.modules.patient.service;

public interface CoverageService {
}
