package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.rhombuzz.gpbackend.enums.Gender;
import com.rhombuzz.gpbackend.modules.patient.entity.Guarantor;
import com.rhombuzz.gpbackend.modules.patient.entity.enums.RelationshipToPatient;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class GuarantorResponse {

    Long id;
    String firstName;
    String lastName;
    LocalDate dateOfBirth;
    RelationshipToPatient relationshipToPatient;
    String address;
    String city;
    String state;
    String zipCode;
    String cellPhone;
    String homePhone;
    Gender gender;

    public static GuarantorResponse fromEntity(Guarantor guarantor) {
        return GuarantorResponse.builder()
                .id(guarantor.getId())
                .firstName(guarantor.getFirstName())
                .lastName(guarantor.getLastName())
                .dateOfBirth(guarantor.getDateOfBirth())
                .relationshipToPatient(guarantor.getRelationshipToPatient())
                .address(guarantor.getAddress())
                .city(guarantor.getCity())
                .state(guarantor.getState())
                .zipCode(guarantor.getZipCode())
                .cellPhone(guarantor.getCellPhone())
                .homePhone(guarantor.getHomePhone())
                .gender(guarantor.getGender())
                .build();
    }
}
