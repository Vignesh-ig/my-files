package com.rhombuzz.gpbackend.modules.provider.controller;

import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveServiceAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.ServiceAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.service.ServiceAvailabilityService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/service-availabilities")
@Validated
public class ServiceAvailabilityController {
    private final ServiceAvailabilityService serviceAvailabilityService;

    @GetMapping("/providers/{providerId}")
    public ResponseEntity<Map<DayOfWeek, List<ServiceAvailabilityResponse>>> getServiceAvailabilities(
            @PathVariable @NotNull Long providerId,
            @RequestParam @Size(min = 10, max = 10) String groupId
    ) {
        Map<DayOfWeek, List<ServiceAvailabilityResponse>> serviceAvailabilities =
                serviceAvailabilityService.getServiceAvailabilities(providerId, groupId);
        return ResponseEntity.ok(serviceAvailabilities);
    }

    @PostMapping
    public ResponseEntity<Void> saveServiceAvailability(@RequestBody @Valid SaveServiceAvailabilityRequest request) {
        serviceAvailabilityService.saveServiceAvailability(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{id}/providers/{providerId}")
    public ResponseEntity<Void> deleteServiceAvailability(
            @PathVariable @NotNull Long id,
            @PathVariable @NotNull Long providerId,
            @RequestParam @NotNull Long locationId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        serviceAvailabilityService.deleteServiceAvailability(id, providerId, locationId, groupId);
        return ResponseEntity.noContent().build();
    }
}
