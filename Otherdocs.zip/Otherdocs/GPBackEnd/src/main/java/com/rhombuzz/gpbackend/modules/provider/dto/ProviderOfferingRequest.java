package com.rhombuzz.gpbackend.modules.provider.dto;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

public record ProviderOfferingRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Provider ID cannot be null")
        @Positive(message = "Provider ID must be a positive number")
        Long providerId,

        @NotNull(message = "Service ID cannot be null")
        @Positive(message = "Service ID must be a positive number")
        Long serviceId,

        Service.VisitType visitType,
        Boolean visibleToPatient
) {
}
