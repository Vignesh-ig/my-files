package com.rhombuzz.gpbackend.modules.appointment.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.dto.LocationDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.patient.dto.InsuranceDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderDTO;
import lombok.Getter;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter
public class PendingRequestResponse {
    private final Long appointmentId;
    private final ProviderDTO provider;
    private final ServiceDTO service;
    private final LocationDTO location;
    private final PatientWrapper patient;
    private final InsuranceDTO insurance;
    private final LocalDate requestedDate;
    private final LocalTime requestedTime;
    private final boolean isTelehealth;
    private final String reasonForVisit;

    public PendingRequestResponse(Long id, Long providerId, String providerName, Long serviceId, String serviceServiceName, Long locationId, String locationName,
                                      Long patientId, String patientFirstName, String patientLastName, String patientCellPhone, LocalDate patientDob,
                                      String insuranceCompanyName, String insuranceCompanyCode, String insuranceId, String insuranceGroupId, LocalDate scheduledDate,LocalTime scheduledTime, boolean isTelehealth, String reasonForVisit) {
        this.appointmentId = id;
        this.provider = new ProviderDTO(providerId, providerName);
        this.service = new ServiceDTO(serviceId, serviceServiceName);
        this.location = new LocationDTO(locationId, locationName);
        this.patient = new PatientWrapper(patientId, patientFirstName + " " + patientLastName, patientCellPhone, patientDob);
        this.insurance = new InsuranceDTO(insuranceCompanyName, insuranceCompanyCode, insuranceId, insuranceGroupId);
        this.requestedDate = scheduledDate;
        this.requestedTime = scheduledTime;
        this.isTelehealth = isTelehealth;
        this.reasonForVisit = reasonForVisit;
    }

    public record PatientWrapper(Long patientId, String name, String cellPhone, LocalDate dob) {}
}
