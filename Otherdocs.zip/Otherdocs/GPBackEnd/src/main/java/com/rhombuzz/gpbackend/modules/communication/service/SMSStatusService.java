package com.rhombuzz.gpbackend.modules.communication.service;

import com.rhombuzz.gpbackend.modules.communication.dto.request.SMSStatusRequest;
import jakarta.validation.Valid;
import org.springframework.validation.annotation.Validated;

@Validated
public interface SMSStatusService {

    void saveSMSStatus(
            @Valid SMSStatusRequest request
    );
}
