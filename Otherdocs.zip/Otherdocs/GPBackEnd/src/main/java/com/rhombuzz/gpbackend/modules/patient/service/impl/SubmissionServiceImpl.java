package com.rhombuzz.gpbackend.modules.patient.service.impl;

import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.dto.request.ReceivedSubmissionRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.request.RequestSubmissionRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.AwaitingSubmissionResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.ReceivedSubmissionResponse;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.repository.PatientRepository;
import com.rhombuzz.gpbackend.modules.patient.repository.specification.AwaitingSpecification;
import com.rhombuzz.gpbackend.modules.patient.repository.specification.ReceivedSpecification;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.modules.patient.service.SubmissionService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
@Slf4j
public class SubmissionServiceImpl implements SubmissionService {
    private static final String TEMPLATE_ID = "LINK_TO_ALL_FORMS";

    private final PatientRepository patientRepository;
    private final PatientService patientService;
    private final ActivityService activityService;
    private final PatientCommunicationService patientCommunicationService;
    private final MedGroupService medGroupService;

    @Override
    public Page<AwaitingSubmissionResponse> getAwaitingSubmissions(String groupId, AwaitingSpecification.AwaitingFilter awaitingFilter, Pageable pageable) {
        LocalDate currentDate = medGroupService.getCurrentDateTime(groupId).toLocalDate();
        return patientRepository.findBy(
                        AwaitingSpecification.defaultSpecification()
                                .and(AwaitingSpecification.hasGroupId(groupId))
                                .and(AwaitingSpecification.hasFilter(awaitingFilter, currentDate)),
                q -> q.as(AwaitingSubmissionResponse.class)
                        .page(pageable));
    }

    @Override
    public Page<ReceivedSubmissionResponse> getReceivedSubmissions(ReceivedSubmissionRequest request, Pageable pageable) {
        return patientRepository.findBy(
                ReceivedSpecification.defaultSpecification()
                        .and(ReceivedSpecification.hasGroupId(request.groupId()))
                        .and(ReceivedSpecification.hasFilter(request.filter(), request.claimedBy())),
                q -> q.as(ReceivedSubmissionResponse.class)
                        .page(pageable));
    }

    @Override
    public void claimSubmission(Long patientId, String groupId) {
        Patient patient = patientService.getPatientById(patientId, groupId);

        if (!patient.isSubmissionFlag()) {
            throw new BadRequestException("Patient submission is not available for claiming.");
        }

        if (patient.isReviewStatus()) {
            throw new BadRequestException("Patient submission is already reviewed.");
        }

        if (patient.getClaimedBy() != null) {
            throw new BadRequestException("Patient submission is already claimed by another user.");
        }

        String username = Utils.getCurrentUsername();
        patient.setClaimedBy(username);

        patientRepository.save(patient);
        ActivityRequest activity = buildActivity(
                patient,
                groupId,
                "CLAIM",
                "The user (" + username + ") claimed the submission by the patient " + patient.getFirstName() + " " + patient.getLastName() + "."
        );

        activityService.saveActivity(activity);
    }

    @Override
    public void updateReviewStatus(Long patientId, String groupId) {

        Patient patient = patientService.getPatientById(patientId, groupId);

        if (!patient.isSubmissionFlag()) {
            throw new BadRequestException("Patient submission is not available for review.");
        }

        if (patient.getClaimedBy() == null) {
            throw new BadRequestException("Patient submission is not yet claimed by any user.");
        }

        if (patient.isReviewStatus()) {
            throw new BadRequestException("Patient submission is already reviewed.");
        }

        patient.setReviewStatus(true);
        patientRepository.save(patient);

        String username = Utils.getCurrentUsername();
        ActivityRequest activity = buildActivity(
                patient,
                groupId,
                "DOCUMENT REVIEW",
                "The user (" + username + ") marked the submission by the patient " + patient.getFirstName() + " " + patient.getLastName() + " as complete."
        );

        activityService.saveActivity(activity);
        log.info("Patient submission with ID {} has been reviewed successfully.", patientId);

    }

    @Transactional
    @Override
    public void updateClaimedByAndReviewStatus(Long patientId, String groupId) {
        Patient patient = patientService.getPatientById(patientId, groupId);
        if (patient.getClaimedBy() != null && patient.isReviewStatus()) {
            patientRepository.updateClaimedByStatusAndReviewStatusByIdAndGroupId(patientId, groupId, null, false);
        }
    }

    @Override
    @Async
    public void requestSubmission(RequestSubmissionRequest request) {
        switch (request.requestMethod()) {
            case EMAIL -> patientCommunicationService.validateAndRequestSubmissionViaEmail(request.groupId(), request.patientIds(), TEMPLATE_ID);
            case SMS -> patientCommunicationService.validateAndRequestSubmissionViaSMS(request.groupId(), request.patientIds(), TEMPLATE_ID);
            case BOTH -> {
                patientCommunicationService.validateAndRequestSubmissionViaEmail(request.groupId(), request.patientIds(), TEMPLATE_ID);
                patientCommunicationService.validateAndRequestSubmissionViaSMS(request.groupId(), request.patientIds(), TEMPLATE_ID);
            }
        }
    }

    @Override
    public void updateSubmissionStatus(String groupId, Long patientId, boolean success) {
        Patient patient = patientService.getPatientById(patientId, groupId);
        if (!success) {
            log.warn("Submission request for patient {} {} was not successful.", patient.getFirstName(), patient.getLastName());
            String description = "The submission request for the patient " + patient.getFirstName() + " " + patient.getLastName() + " was not successful.";
            ActivityRequest activity = buildActivity(patient, groupId, "REQUEST SUBMISSION", description);
            activityService.saveActivity(activity);
            return;
        }

        log.info("Submission request for patient {} {} was successful.", patient.getFirstName(), patient.getLastName());
        patient.setRequestFormFlag(true);
        patientRepository.save(patient);

        String description = "The submission request for the patient " + patient.getFirstName() + " " + patient.getLastName() + " was successful.";
        ActivityRequest activity = buildActivity(patient, groupId, "REQUEST SUBMISSION", description);
        activityService.saveActivity(activity);
    }

    private ActivityRequest buildActivity(Patient patient, String groupId, String actType, String activityDescription) {
        return ActivityRequest.builder()
                .patient(patient)
                .groupId(groupId)
                .activityType(actType.toUpperCase())
                .activityDescription(activityDescription)
                .build();
    }
}
