package com.rhombuzz.gpbackend.modules.patient.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class DocumentStatusResponse {
    private String claimedBy;
    private boolean reviewStatus;
    private List<DocumentFrom> documents;

    @Data
    @AllArgsConstructor
    public static class DocumentFrom {
        private String name;
        private List<DocumentResponse> documents;
    }
}
