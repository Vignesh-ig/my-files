package com.rhombuzz.gpbackend.modules.communication.service.impl;

import com.rhombuzz.gpbackend.modules.communication.dto.request.EmailRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveEmailRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.Email;
import com.rhombuzz.gpbackend.modules.communication.repository.EmailRepository;
import com.rhombuzz.gpbackend.modules.communication.service.EmailService;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailServiceImpl implements EmailService {
    private final JavaMailSender mailSender;
    private final MedGroupService medGroupService;
    private final PatientService patientService;
    private final EmailRepository emailRepository;

    @Override
    public EmailResponse sendEmail(EmailRequest request) {
        log.info("Preparing to send email");

        try {
            MimeMessage message = mailSender.createMimeMessage();
            setupMessage(request, message);

            log.info("Sending email");
            mailSender.send(message);
            log.info("Email sent successfully");

            return EmailResponse.builder()
                    .success(true)
                    .message("Email sent successfully")
                    .build();

        } catch (Exception e) {
            log.error("Error sending email", e);
            return EmailResponse.builder()
                    .success(false)
                    .message("Error sending email")
                    .build();
        }
    }

    @Override
    public void saveEmail(SaveEmailRequest request) {
        log.info("Saving email for patientId: {} in group {}", request.patientId(), request.groupId());

        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Patient patient = patientService.getPatientById(request.patientId(), request.groupId());
        LocalDateTime dateTime = LocalDateTime.now(medGroup.getTimeZone().toZoneId());

        Email email = Email.builder()
                .medGroup(medGroup)
                .patient(patient)
                .message(request.emailContent())
                .dateTime(dateTime)
                .messageStatus(request.status())
                .build();

        emailRepository.save(email);
        log.info("Email saved successfully for patientId: {} in group {}", request.patientId(), request.groupId());
    }

    private void setupMessage(EmailRequest request, MimeMessage message) throws MessagingException {
        MimeMessageHelper helper = new MimeMessageHelper(message);

        helper.setTo(request.toEmail());
        helper.setFrom(request.fromEmail());
        helper.setSubject(request.subject());
        helper.setText(request.body(), true);
    }
}
