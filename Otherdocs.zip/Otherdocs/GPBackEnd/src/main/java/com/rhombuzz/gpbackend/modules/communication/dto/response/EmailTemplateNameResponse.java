package com.rhombuzz.gpbackend.modules.communication.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailTemplateNameResponse {

    private Long id;
    private String templateName;

    @JsonIgnore
    private EmailTemplate.TemplateGroup templateGroup;

    public static EmailTemplateNameResponse fromEntity(EmailTemplate emailTemplate) {
        return EmailTemplateNameResponse.builder()
                .id(emailTemplate.getId())
                .templateName(emailTemplate.getName())
                .templateGroup(emailTemplate.getTemplateGroup())
                .build();
    }
}
