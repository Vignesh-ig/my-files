package com.rhombuzz.gpbackend.modules.medgroup.service;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.InsuranceRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.InsuranceCompanyResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

import java.util.Map;

@Validated
public interface InsuranceCompanyService {

    Page<InsuranceCompanyResponse> getInsuranceCompanies(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    );

    void saveInsuranceCompany(
            @Valid InsuranceRequest request
    );

    @Transactional
    void deleteInsuranceCompany(
            @NotNull @Positive Long id,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateInsuranceCompany(
            @NotNull @Positive Long id,
            @Valid InsuranceRequest request
    );

    Map<String, String> getInsuranceCompaniesForForms(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

}
