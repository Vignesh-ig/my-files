package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rhombuzz.gpbackend.enums.Gender;

import java.time.LocalDate;
import java.time.LocalDateTime;

public interface ReceivedSubmissionResponse {
    Long getId();
    String getFirstName();
    String getLastName();
    Gender getGender();
    LocalDate getDob();
    String getCellPhone();
    String getClaimedBy();
    boolean isReviewStatus();

    @JsonProperty("submissionDateTime")
    LocalDateTime getDocumentSubmissionDateTime();
}
