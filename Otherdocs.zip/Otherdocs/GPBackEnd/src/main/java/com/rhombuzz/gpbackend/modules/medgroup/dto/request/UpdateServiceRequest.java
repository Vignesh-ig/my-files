package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

public record UpdateServiceRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Duration cannot be null")
        @Min(value = 5, message = "Minimum duration is 5 minutes")
        @Max(value = 180, message = "Maximum duration is 180 minutes")
        Integer duration,

        @Pattern(regexp = RegexPattern.NO_WHITESPACE, message = "Service reference cannot contain whitespace")
        @Size(max = 45, message = "Service reference must not exceed 45 characters")
        String serviceReference,

        @Pattern(regexp = RegexPattern.RGB_HEX_CODE, message = "Service description must be a valid RGB hex code")
        String colorCode,

        @NotNull(message = "Visible to patient cannot be null")
        Boolean visibleToPatient,

        boolean allowReminder,
        boolean recall,
        Integer recallPeriod,
        BigDecimal bookingFeeAmount,
        Service.VisitType visitType
) {
}
