package com.rhombuzz.gpbackend.integration.entity;

import com.rhombuzz.gpbackend.integration.entity.enums.IntegrationResourceType;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.type.SqlTypes;

import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@Table(name = "integration_resources", indexes = {
        @Index(name = "idx_ir_groupId_integration_resource", columnList = "med_group_id, integration_name, integration_resource")
})
public class IntegrationResource {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Long Id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "integration_name", nullable = false, length = 45)
    private String integrationName;

    @Enumerated(EnumType.STRING)
    @Column(name = "integration_resource", nullable = false, length = 45)
    private IntegrationResourceType integrationResource;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "actions", columnDefinition = "json", nullable = false)
    private Set<String> actions = new HashSet<>();
}
