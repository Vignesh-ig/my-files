package com.rhombuzz.gpbackend.integration.service;

import com.rhombuzz.gpbackend.integration.dto.request.SaveIntegrationConfigRequest;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

@Validated
public interface IntegrationConfigService {

    void saveIntegrationConfig(
            @Valid SaveIntegrationConfigRequest request
    );

    String getConfigValue(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String configName,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String integratesWith
    );

}
