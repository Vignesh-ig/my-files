package com.rhombuzz.gpbackend.modules.communication.service.patient;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.util.function.Function;

public interface PatientCommunicationValidator {
    boolean isCommunicationAllowed(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotNull ContactMethod method
    );

    boolean isValidForCommunication(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long patientId,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotNull ContactMethod method
    );

    Patient getValidPatientForCommunication(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull @Positive Long patientId,
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotNull ContactMethod method
    );

    String getLocalizedContent(
            @NotNull Patient patient,
            Function<PreferredLanguage, String> contentProvider
    );
}
