package com.rhombuzz.gpbackend.modules.provider.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Location;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.medgroup.service.LocationService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.medgroup.service.ServiceManagement;
import com.rhombuzz.gpbackend.modules.provider.dto.ServiceAvailabilityDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.TimeValidationDTO;
import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveServiceAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.ServiceAvailabilityResponse;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.provider.entity.ServiceAvailability;
import com.rhombuzz.gpbackend.modules.provider.repository.ServiceAvailabilityRepository;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import com.rhombuzz.gpbackend.modules.provider.service.ServiceAvailabilityService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.DayOfWeek;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@org.springframework.stereotype.Service
@RequiredArgsConstructor
@Slf4j
public class ServiceAvailabilityServiceImpl implements ServiceAvailabilityService {
    private static final String ACTIVITY_TYPE = "SERVICE AVAILABILITY";

    private final ServiceAvailabilityRepository serviceAvailabilityRepository;
    private final ServiceManagement serviceManagement;
    private final MedGroupService medGroupService;
    private final ProviderService providerService;
    private final LocationService locationService;
    private final ActivityService activityService;

    @Override
    public void saveServiceAvailability(SaveServiceAvailabilityRequest request) {
        log.info("Saving service availability for provider {} on {}", request.providerId(), request.dayOfWeek());

        if (request.serviceAvailabilities().isEmpty()) {
            log.info("No service availabilities provided for provider {}", request.providerId());
            return;
        }

        Utils.validateTimeOrder(
                request.serviceAvailabilities().stream()
                        .map(dto -> new TimeValidationDTO(dto.startTime(), dto.endTime()))
                        .toList()
        );

        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        Provider provider = providerService.getProviderById(request.providerId(), request.groupId());

        List<ServiceAvailability> serviceAvailabilities = request.serviceAvailabilities().stream()
                .map(dto -> dto.id() != null
                        ? updateExistingAvailability(dto, request)
                        : buildNewAvailability(dto, request, medGroup, provider))
                .toList();

        if (serviceAvailabilities.isEmpty()) {
            log.info("No valid service availabilities to save for provider {}", request.providerId());
            return;
        }

        List<ServiceAvailability> savedAvailabilities = serviceAvailabilityRepository.saveAll(serviceAvailabilities);
        log.info("Saved {} service availabilities for provider {}", savedAvailabilities.size(), request.providerId());

        String description = String.format("The user (%s) has added a service availability slot for provider (%s) on (%s).",
                Utils.getCurrentUsername(), provider.getName(), request.dayOfWeek());
        saveActivity(request.groupId(), description, provider);
    }

    @Override
    public Map<DayOfWeek, List<ServiceAvailabilityResponse>> getServiceAvailabilities(Long providerId, String groupId) {
        log.info("Get service availabilities for provider: {}", providerId);

        List<ServiceAvailabilityResponse> responses = serviceAvailabilityRepository.findByProviderId(providerId, groupId);

        List<Long> allServiceIds = responses.stream()
                .flatMap(r -> Arrays.stream(Optional.ofNullable(r.getServiceIds()).orElse("").split(",")))
                .filter(s -> !s.isBlank())
                .map(Long::parseLong)
                .toList();

        Map<Long, ServiceDTO> serviceMap = serviceManagement.getServiceNamesByIds(allServiceIds, groupId)
                .stream()
                .collect(Collectors.toMap(ServiceDTO::getId, Function.identity()));

        responses.forEach(r -> {
            List<ServiceDTO> services = Arrays.stream(Optional.ofNullable(r.getServiceIds()).orElse("").split(","))
                    .filter(s -> !s.isBlank())
                    .map(Long::parseLong)
                    .map(serviceMap::get)
                    .toList();
            r.setServices(services);
        });

        return responses.stream()
                .collect(Collectors.groupingBy(ServiceAvailabilityResponse::getDay));
    }


    @Override
    @Transactional
    public void deleteServiceAvailability(Long id, Long providerId, Long locationId, String groupId) {
        log.info("Delete service availability with id: {}", id);
        ServiceAvailability serviceAvailability = serviceAvailabilityRepository.findById(id, providerId, locationId, groupId)
                .orElseThrow(() -> {
                    log.error("Service availability with id: {} not found.", id);
                    return new NotFoundException("Service availability not found");
                });

        serviceAvailabilityRepository.deleteById(id, providerId, locationId, groupId);
        log.info("Service availability with id: {} deleted successfully.", id);

        String description = String.format("The user (%s) has deleted a service availability slot for provider (%s) on (%s)",
                Utils.getCurrentUsername(), serviceAvailability.getProvider().getName(), serviceAvailability.getDay());
        saveActivity(groupId, description, serviceAvailability.getProvider());
    }

    private ServiceAvailability buildNewAvailability(ServiceAvailabilityDTO dto,
                                                     SaveServiceAvailabilityRequest request,
                                                     MedGroup medGroup,
                                                     Provider provider) {
        ServiceAvailability serviceAvailability = new ServiceAvailability();
        serviceAvailability.setDay(request.dayOfWeek());
        serviceAvailability.setStartTime(dto.startTime());
        serviceAvailability.setEndTime(dto.endTime());
        serviceAvailability.setLocation(validateAndGetLocation(dto.locationId(), request.groupId()));
        serviceAvailability.setMedGroup(medGroup);
        serviceAvailability.setProvider(provider);
        serviceAvailability.setServices(
                validateAndMapServices(dto.serviceIds(), request.groupId(), "creation")
        );
        return serviceAvailability;
    }

    private ServiceAvailability updateExistingAvailability(ServiceAvailabilityDTO dto,
                                                           SaveServiceAvailabilityRequest request) {
        ServiceAvailability serviceAvailability = serviceAvailabilityRepository
                .findById(dto.id(), request.providerId(), request.groupId())
                .orElseThrow(() -> {
                    log.error("Service availability with id: {} not found for update.", dto.id());
                    return new NotFoundException("Service availability not found for update");
                });

        serviceAvailability.setStartTime(dto.startTime());
        serviceAvailability.setEndTime(dto.endTime());

        if (!Objects.equals(serviceAvailability.getLocation().getId(), dto.locationId())) {
            serviceAvailability.setLocation(validateAndGetLocation(dto.locationId(), request.groupId()));
        }

        serviceAvailability.setServices(
                validateAndMapServices(dto.serviceIds(), request.groupId(), "update")
        );

        return serviceAvailability;
    }

    private Location validateAndGetLocation(Long locationId, String groupId) {
        if (!locationService.isLocationExists(locationId, groupId)) {
            log.error("Location with id: {} not found in group {}", locationId, groupId);
            throw new NotFoundException("Location not found");
        }
        return new Location(locationId);
    }

    private Set<Service> validateAndMapServices(List<Long> serviceIds, String groupId, String context) {
        if (!isServiceExists(serviceIds, groupId)) {
            log.error("Services with ids: {} not found during {}", serviceIds, context);
            throw new NotFoundException("One or more services not found");
        }
        return serviceIds.stream()
                .map(Service::new)
                .collect(Collectors.toSet());
    }

    private void saveActivity(String groupId, String description, Provider provider) {
        ActivityRequest activityRequest = new ActivityRequest() {{
            setGroupId(groupId);
            setProvider(provider);
            setActivityDescription(description);
            setActivityType(ACTIVITY_TYPE);
        }};

        activityService.saveActivity(activityRequest);
    }

    private boolean isServiceExists(List<Long> serviceIds, String groupId) {
        return serviceIds.stream()
                .allMatch(serviceId -> serviceManagement.isServiceExists(serviceId, groupId));
    }
}
