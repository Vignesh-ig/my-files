package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.OfficeClosureRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.OfficeClosureResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.entity.OfficeClosure;
import com.rhombuzz.gpbackend.modules.medgroup.repository.OfficeClosureRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.medgroup.service.OfficeClosureService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class OfficeClosureServiceImpl implements OfficeClosureService {
    private static final String ACTIVITY_TYPE = "OFFICE UNAVAILABLE";

    private final OfficeClosureRepository officeClosureRepository;
    private final MedGroupService medGroupService;
    private final ActivityService activityService;

    @Override
    public void saveOfficeClosure(OfficeClosureRequest request) {
        log.info("Save office closure for group: {}", request.groupId());

        MedGroup medGroup = medGroupService.getMedGroup(request.groupId());
        OfficeClosure officeClosure = OfficeClosure.builder()
                .medGroup(medGroup)
                .closeDate(request.closeDate())
                .reason(request.reason())
                .build();

        if (officeClosureRepository.exists(Example.of(officeClosure))) {
            log.error("Office closure for group: {} is already exists.", request.groupId());
            throw new ConflictException("Office closure already exists");
        }

        officeClosureRepository.save(officeClosure);
        log.info("Office closure for group: {} is saved.", request.groupId());

        String description = String.format("Office close date %s added by %s", request.closeDate(), Utils.getCurrentUsername());
        saveActivity(request.groupId(), description);

    }

    @Override
    public List<OfficeClosureResponse> getOfficeClosures(String groupId) {
        log.info("Fetching office closures for group: {}", groupId);
        return officeClosureRepository.findByGroupId(groupId).stream()
                .map(OfficeClosureResponse::fromEntity)
                .toList();

    }

    @Override
    public void updateOfficeClosure(Long id, OfficeClosureRequest request) {
        log.info("Update office closure with ID: {}", id);

        OfficeClosure officeClosure = getOfficeClosure(id, request.groupId());

        officeClosure.setCloseDate(request.closeDate());
        officeClosure.setReason(request.reason());

        officeClosureRepository.save(officeClosure);
        log.info("Office closure with ID {} updated", id);

        String description = String.format("Office close date %s updated to %s by %s", officeClosure.getCloseDate(), request.closeDate(), Utils.getCurrentUsername());
        saveActivity(request.groupId(), description);
    }

    @Override
    @Transactional
    public void deleteOfficeClosure(Long id,String groupId) {
        log.info("Delete office closure with ID: {}", id);

        if (!officeClosureRepository.existsById(id, groupId)) {
            officeClosureNotFoundLog(id, groupId);
            throw new NotFoundException("Office closure not found with ID " + id);
        }

        officeClosureRepository.deleteById(id, groupId);
        log.info("Office closure with ID {} deleted", id);

        String description = String.format("Office close date %s deleted by %s", id, groupId);
        saveActivity(groupId, description);

    }

    private void saveActivity(String groupId, String description) {
        ActivityRequest activityRequest = new ActivityRequest() {{
            setGroupId(groupId);
            setActivityType(ACTIVITY_TYPE);
            setActivityDescription(description);
        }};
        activityService.saveActivity(activityRequest);
    }

    private void officeClosureNotFoundLog(Long id, String groupId) {
        log.error("Office closure with ID {} not found for group {}", id, groupId);
    }

    private OfficeClosure getOfficeClosure(Long id, String groupId) {
        return officeClosureRepository.findById(id, groupId)
                .orElseThrow(() -> {
                    officeClosureNotFoundLog(id, groupId);
                    return new NotFoundException("Office closure not found with ID " + id);
                });
    }

}