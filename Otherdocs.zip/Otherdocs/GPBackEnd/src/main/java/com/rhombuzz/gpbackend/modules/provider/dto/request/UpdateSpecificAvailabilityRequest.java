package com.rhombuzz.gpbackend.modules.provider.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.time.LocalTime;

public record UpdateSpecificAvailabilityRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Provider ID cannot be null")
        @Positive(message = "Provider ID must be a positive number")
        Long providerId,

        @NotNull(message = "Date cannot be null")
        LocalDate date,

        @NotNull(message = "Start time cannot be null")
        LocalTime startTime,

        @NotNull(message = "End time cannot be null")
        LocalTime endTime,

        @NotNull(message = "Old location ID cannot be null")
        @Positive(message = "Old location ID must be a positive number")
        Long oldLocationId,

        @NotNull(message = "New location ID cannot be null")
        @Positive(message = "New location ID must be a positive number")
        Long newLocationId
) {
}
