package com.rhombuzz.gpbackend.modules.communication.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record SaveSMSTemplateRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Template name cannot be blank")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS_WITH_WHITESPACES, message = "Template name must contain only letters")
        @Size(max = 45, message = "Template name must be at most 45 characters long")
        String name,

        @NotBlank(message = "English content cannot be blank")
        String englishContent,

        @NotBlank(message = "Spanish content cannot be blank")
        String spanishContent
) {
}
