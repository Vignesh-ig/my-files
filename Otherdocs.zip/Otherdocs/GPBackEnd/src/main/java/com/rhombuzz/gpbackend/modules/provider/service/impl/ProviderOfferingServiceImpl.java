package com.rhombuzz.gpbackend.modules.provider.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.ServiceDTO;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.ServiceResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Service;
import com.rhombuzz.gpbackend.modules.medgroup.repository.ServiceRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.medgroup.service.ServiceManagement;
import com.rhombuzz.gpbackend.modules.provider.dto.ProviderOfferingRequest;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.modules.provider.entity.ProviderOffering;
import com.rhombuzz.gpbackend.modules.provider.entity.id.ProviderOfferingId;
import com.rhombuzz.gpbackend.modules.provider.repository.ProviderOfferingRepository;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderOfferingService;
import com.rhombuzz.gpbackend.modules.provider.service.ProviderService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@org.springframework.stereotype.Service
@RequiredArgsConstructor
public class ProviderOfferingServiceImpl implements ProviderOfferingService {
    private static final String ACTIVITY_TYPE = "MANAGE PROVIDER SERVICE";

    private final ProviderOfferingRepository providerOfferingRepository;
    private final ProviderService providerService;
    private final ServiceManagement serviceManagement;
    private final MedGroupService medGroupService;
    private final ServiceRepository serviceRepository;
    private final ActivityService activityService;

    @Override
    public void saveProviderOffering(ProviderOfferingRequest request) {
        log.info("Saving provider offering for groupId: {}, providerId: {}, serviceId: {}",
                request.groupId(), request.providerId(), request.serviceId());

        ProviderOfferingId providerOfferingId = getProviderOfferingId(request.groupId(),
                request.providerId(), request.serviceId());
        ProviderOffering providerOffering = providerOfferingRepository.findById(providerOfferingId)
                .orElseGet(() -> {
                    log.info("No existing provider offering found. Creating a new one.");
                    return createNewProviderOffering(providerOfferingId);
                });

        updateProviderOfferingFields(providerOffering, request);
        providerOfferingRepository.save(providerOffering);

        log.info("Provider offering saved successfully for groupId: {}, providerId: {}, serviceId: {}",
                request.groupId(), request.providerId(), request.serviceId());

        String description = String.format("The user (%s) has updated the service (%s) for provider (%s)",
                Utils.getCurrentUsername(), providerOfferingId.getService().getServiceName(), providerOfferingId.getProvider().getName());
        saveActivity(request.groupId(), description, providerOfferingId.getProvider());
    }

    @Override
    public void disableProviderOffering(String groupId, Long providerId, Long serviceId) {
        log.info("Deleting provider offering for groupId: {}, providerId: {}, serviceId: {}",
                groupId, providerId, serviceId);

        ProviderOfferingId providerOfferingId = getProviderOfferingId(groupId, providerId, serviceId);
        ProviderOffering providerOffering = providerOfferingRepository.findById(providerOfferingId)
                .orElseGet(() -> {
                    log.info("No existing provider offering found. Creating a new one to disable.");
                    return createNewProviderOffering(providerOfferingId);
                });

        providerOffering.setDisabled(true);
        providerOfferingRepository.save(providerOffering);

        log.info("Provider offering disabled successfully for groupId: {}, providerId: {}, serviceId: {}",
                groupId, providerId, serviceId);

        String description = String.format("The user (%s) has deleted the service (%s) for provider (%s).",
                Utils.getCurrentUsername(), providerOfferingId.getService().getServiceName(), providerOfferingId.getProvider().getName());
        saveActivity(groupId, description, providerOfferingId.getProvider());
    }

    @Override
    public void enableProviderOffering(String groupId, Long providerId, Long serviceId) {
        log.info("Enabling provider offering for groupId: {}, providerId: {}, serviceId: {}",
                groupId, providerId, serviceId);

        ProviderOfferingId providerOfferingId = getProviderOfferingId(groupId, providerId, serviceId);
        ProviderOffering providerOffering = getProviderOffering(providerOfferingId);

        providerOffering.setDisabled(false);
        providerOfferingRepository.save(providerOffering);

        log.info("Provider offering enabled successfully for groupId: {}, providerId: {}, serviceId: {}",
                groupId, providerId, serviceId);

        String description = String.format("The user (%s) has enabled the service (%s) for provider (%s)",
                Utils.getCurrentUsername(), providerOfferingId.getService().getServiceName(), providerOfferingId.getProvider().getName());
        saveActivity(groupId, description, providerOfferingId.getProvider());
    }

    @Override
    public Page<ServiceResponse> getProviderOfferings(String groupId, Long providerId, Pageable pageable) {
        log.info("Fetching provider offerings for groupId: {}, providerId: {}", groupId, providerId);
        List<Object[]> serviceIds = providerOfferingRepository.findServiceIdsByProviderId(providerId, groupId);

        Set<Long> disabledIds = new HashSet<>();
        Set<Long> enabledIds = new HashSet<>();

        for (Object[] row : serviceIds) {
            Long id = (Long) row[0];
            boolean isDisabled = (boolean) row[1];
            if (isDisabled) {
                disabledIds.add(id);
            } else {
                enabledIds.add(id);
            }
        }

        Page<ServiceResponse> services = serviceRepository.findByServiceIds(disabledIds, groupId, pageable);

        if (enabledIds.isEmpty()) {
            return services;
        }

        List<ProviderOffering> providerOfferings =
                providerOfferingRepository.findByProviderAndServiceIds(providerId, groupId, enabledIds);

        Map<Long, ProviderOffering> offeringMap = providerOfferings.stream()
                .collect(Collectors.toMap(po -> po.getId().getService().getId(), po -> po));

        List<ProviderOfferingId> idsToDelete = new ArrayList<>();

        for (ServiceResponse service : services) {
            ProviderOffering po = offeringMap.get(service.getId());
            if (po == null) continue;

            boolean poHasBoth = po.getVisitType() != null && po.getVisibleToPatient() != null;
            boolean bothNull = po.getVisitType() == null && po.getVisibleToPatient() == null;

            if (bothNull) {
                idsToDelete.add(po.getId());
                continue;
            }

            if (poHasBoth
                    && Objects.equals(service.isVisibleToPatient(), po.getVisibleToPatient())
                    && Objects.equals(service.getVisitType(), po.getVisitType())) {
                idsToDelete.add(po.getId());
                continue;
            }

            if (po.getVisitType() != null && !Objects.equals(po.getVisitType(), service.getVisitType())) {
                service.setVisitType(po.getVisitType());
            }
            if (po.getVisibleToPatient() != null && !Objects.equals(po.getVisibleToPatient(), service.isVisibleToPatient())) {
                service.setVisibleToPatient(po.getVisibleToPatient());
            }
        }

        if (!idsToDelete.isEmpty()) {
            providerOfferingRepository.deleteAllByIdInBatch(idsToDelete);
        }

        return services;
    }

    @Override
    public List<ServiceDTO> getServiceNames(Long providerId, String groupId) {
        log.info("Fetching service names for groupId: {}, providerId: {}", groupId, providerId);
        return providerOfferingRepository.findServiceNamesByProviderId(providerId, groupId);
    }

    @Override
    public boolean isProviderOfferingDisabled(Long providerId, Long serviceId, String groupId) {
        log.info("Checking if provider offering is disabled for groupId: {}, providerId: {}, serviceId: {}",
                groupId, providerId, serviceId);
        return providerOfferingRepository.getDisabledStatus(providerId, serviceId, groupId)
                .orElse(false);
    }

    @Override
    public List<ServiceDTO> getServiceByVisitType(Long providerId, String groupId, Service.VisitType visitType) {
        log.info("Fetching service names for groupId: {}, providerId: {}, visitType: {}", groupId, providerId, visitType);
        return providerOfferingRepository.findServiceNamesByVisitType(providerId, groupId, visitType);
    }

    @Override
    public ProviderOffering getProviderOffering(Long providerId, Long serviceId, String groupId) {
        log.info("Fetching provider offering for groupId: {}, providerId: {}, serviceId: {}",
                groupId, providerId, serviceId);
        return providerOfferingRepository.getProviderOffering(providerId, serviceId, groupId)
                .orElseGet(() -> {
                    log.warn("No active provider offering found, returning null");
                    return null;
                });
    }

    private void saveActivity(String groupId, String description, Provider provider) {
        ActivityRequest request = new ActivityRequest(groupId, ACTIVITY_TYPE, description, null, provider, null);
        activityService.saveActivity(request);
    }

    private ProviderOffering getProviderOffering(ProviderOfferingId providerOfferingId) {
        return providerOfferingRepository.findById(providerOfferingId)
                .orElseThrow(() -> {
                    log.error("Provider Service Customization not found for groupId: {}, providerId: {}, serviceId: {}",
                            providerOfferingId.getMedGroup().getGroupId(), providerOfferingId.getProvider().getId(),
                            providerOfferingId.getService().getId());
                    return new NotFoundException("Provider Service Customization not found");
                });
    }

    private ProviderOfferingId getProviderOfferingId(String groupId, Long providerId, Long serviceId) {
        MedGroup medGroup = medGroupService.getMedGroup(groupId);
        Provider provider = providerService.getProviderById(providerId, groupId);
        Service service = serviceManagement.getServiceEntity(serviceId, groupId);

        return new ProviderOfferingId(medGroup, provider, service);
    }

    private ProviderOffering createNewProviderOffering(ProviderOfferingId providerOfferingId) {
        ProviderOffering providerOffering = new ProviderOffering();
        providerOffering.setId(providerOfferingId);
        return providerOffering;
    }

    private void updateProviderOfferingFields(ProviderOffering providerOffering, ProviderOfferingRequest request) {
        if (request.visibleToPatient() != null) {
            providerOffering.setVisibleToPatient(request.visibleToPatient());
        }
        if (request.visitType() != null) {
            providerOffering.setVisitType(request.visitType());
        }
    }
}
