package com.rhombuzz.gpbackend.integration.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "integration_config", indexes = {
        @Index(name = "idx_integration_config_med_group_id", columnList = "med_group_id")
})
public class IntegrationConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "config_name", length = 45, nullable = false)
    private String configName;

    @Column(name = "config_value", length = 2000, nullable = false)
    private String configValue;

    @Column(name = "integrates_with", nullable = false, length = 45)
    private String integratesWith;

}
