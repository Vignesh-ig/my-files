package com.rhombuzz.gpbackend.integration.telehealth;

import com.rhombuzz.gpbackend.modules.appointment.entity.Appointment;

import java.util.Map;

public interface TelehealthService {

    Map<String, Object> setup(Appointment appointment);

    void sendEmail(Appointment appointment);

    void sendSMS(Appointment appointment);

}
