package com.rhombuzz.gpbackend.modules.patient.service;

import com.rhombuzz.gpbackend.modules.patient.dto.request.AdvancedSearchPatientRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponseList;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;

@Validated
public interface PatientSearchService {

    Page<PatientResponseList> advancedSearchPatients(
            @Valid AdvancedSearchPatientRequest request,
            Pageable pageable
    );

    Page<PatientResponseList> searchPatients(
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotBlank @Size(max = 100) String searchTerm,
            Pageable pageable
    );
}
