package com.rhombuzz.gpbackend.modules.intake.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.AcroFields;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.rhombuzz.gpbackend.component.FormFormatter;
import com.rhombuzz.gpbackend.component.PdfGenerator;
import com.rhombuzz.gpbackend.exception.domain.BadRequestException;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.modules.patient.dto.request.SaveFileRequest;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.batik.transcoder.TranscoderException;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.PNGTranscoder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
@Slf4j
public class PdfService {
    private final PatientService patientService;
    private final MedGroupService medGroupService;
    private final FormFormatter formFormatter;
    private final ObjectMapper objectMapper;
    private final TemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;

    @Value("${templates.input.path}")
    private String templateFilePath;

    @Value("${templates.output.path}")
    private String outputPath;

    private CompletableFuture<Void> savePdfAsync(Long patientId, String groupId, String patientName, JsonNode request) {

        try {
            log.info("Saving PDF for patient: {} in group {}", patientName, groupId);

            String groupName = medGroupService.getMedGroup(groupId).getGroupName();
            String templateFileName = request.path("templateFileName").asText();

            Context context = new Context();
            context.setVariable("formFormatter", formFormatter);
            context.setVariable("jsonData", objectMapper.convertValue(request, Map.class));

            if (templateFileName == null || templateFileName.isBlank() || templateFileName.lastIndexOf('.') == -1 || templateFileName.lastIndexOf('.') == 0) {
                String message = "Invalid template file name: " + templateFileName;
                log.error(message);
                throw new BadRequestException(message);
            }

            String templateFile = Paths.get(groupName, templateFileName).toString();
            String templateExtension = Utils.getExtension(templateFileName);

            log.debug("templateFile: {}, templateExtension: {}",templateFile,templateExtension);

            byte[] pdfBytes = switch (templateExtension.toLowerCase()) {
                case "pdf" -> {
                    String pdfTemplatePath = Paths.get(templateFilePath, templateFile).toString();
                    log.debug("pdfTemplatePath: {}", pdfTemplatePath);
                    yield generatePDFUsingPDFTemplate(request, pdfTemplatePath);
                }
                case "html" -> {
                    String page = templateEngine.process(templateFile, context);
                    yield pdfGenerator.generatePdf(page);
                }
                default -> {
                    String message = "Unsupported template file type: " + templateExtension;
                    log.error(message);
                    throw new BadRequestException(message);
                }
            };

            String fileName = buildFileName(
                    patientName,
                    request.path("formName").asText(),
                    medGroupService.getCurrentDateTime(groupId)
            );
            log.info("Generated PDF file name: {}", fileName);

            String outputFilePath = Paths.get(outputPath, groupName, String.valueOf(patientId), fileName).toString();
            savePdfToOutput(pdfBytes, outputFilePath);

            SaveFileRequest saveFileRequest = SaveFileRequest.builder()
                    .groupId(groupId)
                    .patientId(patientId)
                    .key(patientId + "/" + fileName)
                    .fileData(List.of(pdfBytes))
                    .build();
            patientService.saveFileToS3Bucket(saveFileRequest);

            deleteFile(outputFilePath);

            return CompletableFuture.completedFuture(null);
        } catch (Exception e) {
            log.error("Failed to save PDF for patient {} in group {}: {}", patientName, groupId, e.getMessage(), e);
            return CompletableFuture.failedFuture(e);
        }
    }

    @Async
    public void savePDF(Long patientId, String groupId, String patientName, JsonNode request) {
        try {
            savePdfAsync(patientId, groupId, patientName, request)
                    .exceptionally(e -> {
                        log.error("Error saving PDF for patient {} in group {}: {}", patientName, groupId, e.getMessage(), e);
                        return null;
                    });
        } catch (Exception e) {
            log.error("Failed to save PDF for patient {} in group {}: {}", patientName, groupId, e.getMessage(), e);
        }
    }

    private String buildFileName(String patientName, String formName, LocalDateTime currentDateTime) {
        String fileCurrentDateTime = currentDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss"));
        return patientName + "-" + formName + "-" + fileCurrentDateTime + ".pdf";
    }

    private void savePdfToOutput(byte[] pdfBytes, String filePath) {
        Utils.savePdf(pdfBytes, filePath, log);
    }

    private void deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            if (file.delete()) {
                log.info("Deleted local PDF file: {}", filePath);
            } else {
                log.warn("Failed to delete local PDF file: {}", filePath);
            }
        }
    }

    private byte[] generatePDFUsingPDFTemplate(JsonNode request, String templatePath) throws IOException, BadRequestException, DocumentException, TranscoderException {

        Map<String, Object> flatData = extractKeyValues(request);

        if (flatData.isEmpty()) {
            String message = "No valid data found in JSON node";
            log.error(message);
            throw new BadRequestException(message);
        }

        PdfReader reader = new PdfReader(templatePath);
        ByteArrayOutputStream byteArrOpStream = new ByteArrayOutputStream();
        PdfStamper stamper = new PdfStamper(reader, byteArrOpStream);
        AcroFields form = stamper.getAcroFields();

        for (Map.Entry<String, Object> entry : flatData.entrySet()) {
            String fieldName = entry.getKey();

            Object fieldValue = entry.getValue();

            if (!form.getAllFields().containsKey(fieldName)) {
                log.error("Field not found: {}", fieldName);
                continue;
            }

            String value = fieldValue != null ? fieldValue.toString().replace("\"", "") : "";
            int fieldType = form.getFieldType(fieldName);

            switch (fieldType) {
                case AcroFields.FIELD_TYPE_TEXT, AcroFields.FIELD_TYPE_RADIOBUTTON -> form.setField(fieldName, value);
                case AcroFields.FIELD_TYPE_CHECKBOX ->
                        form.setField(fieldName, fieldValue != null && Boolean.parseBoolean(fieldValue.toString()) ? "Yes" : "No");
                case AcroFields.FIELD_TYPE_SIGNATURE -> handleSignatureField(stamper, form, fieldName, value);
            }
        }

        stamper.setFormFlattening(true);
        stamper.close();
        reader.close();

        return byteArrOpStream.toByteArray();

    }

    private void handleSignatureField(PdfStamper stamper, AcroFields form, String fieldName, String base64Svg)
            throws IOException, BadRequestException, DocumentException, TranscoderException {

        // 1. Validate inputs
        if (base64Svg == null || base64Svg.isBlank()) return;
        if (!form.getAllFields().containsKey(fieldName)) {
            String message = "Signature field not found: " + fieldName;
            log.error(message);
            throw new BadRequestException(message);
        }

        // 2. Get field dimensions (in points)
        float[] positions = form.getFieldPositions(fieldName);
        if (positions == null || positions.length < 4) {
            String message = "Invalid field positions";
            log.error(message);
            throw new BadRequestException(message);
        }

        float llx = positions[1];
        float lly = positions[2];
        float urx = positions[3];
        float ury = positions[4];

        float fieldWidth = urx - llx;
        float fieldHeight = ury - lly;

        // 3. Convert SVG to PNG (without size constraints)
        byte[] svgBytes = Base64.getDecoder().decode(base64Svg.replace("data:image/svg+xml;base64,", ""));
        ByteArrayOutputStream pngOut = new ByteArrayOutputStream();

        PNGTranscoder transcoder = new PNGTranscoder();
        transcoder.transcode(
                new TranscoderInput(new ByteArrayInputStream(svgBytes)),
                new TranscoderOutput(pngOut)
        );

        // 4. Create PDF image and scale to fit field
        Image image = Image.getInstance(pngOut.toByteArray());

        // Calculate scaling while maintaining aspect ratio
        float widthRatio = fieldWidth / image.getWidth();
        float heightRatio = fieldHeight / image.getHeight();
        float scaleRatio = Math.min(widthRatio, heightRatio);

        // Apply scaling
        float scaledWidth = image.getWidth() * scaleRatio;
        float scaledHeight = image.getHeight() * scaleRatio;

        // Center the signature in the field
        float xPos = llx + (fieldWidth - scaledWidth) / 2;
        float yPos = lly + (fieldHeight - scaledHeight) / 2;

        // 5. Place signature precisely
        PdfContentByte canvas = stamper.getOverContent(1); // Force first page
        image.setAbsolutePosition(xPos, yPos);
        image.scaleAbsolute(scaledWidth, scaledHeight);
        canvas.addImage(image);

    }

    private Map<String, Object> extractKeyValues(JsonNode node) {
        return extractKeyValuesRecursive(node, "");
    }

    private Map<String, Object> extractKeyValuesRecursive(JsonNode node, String parentKey) {
        Map<String, Object> flatData = new HashMap<>();

        node.fieldNames().forEachRemaining(field -> {
            JsonNode value = node.get(field);
            String fullKey = parentKey.isEmpty() ? field : parentKey + "." + field;

            if (value.isObject()) {
                flatData.putAll(extractKeyValuesRecursive(value, fullKey));
            } else if (value.isValueNode()) {
                flatData.put(fullKey, value.asText());
            }
        });

        return flatData;
    }

}
