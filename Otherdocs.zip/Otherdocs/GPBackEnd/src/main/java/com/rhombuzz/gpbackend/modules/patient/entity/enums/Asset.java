package com.rhombuzz.gpbackend.modules.patient.entity.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum Asset {
    INSERT_MED_GROUP("manual-medgroup-create.sql"),
    INSERT_USER("manual-user-create");

    private final String fileName;
}
