package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.rhombuzz.gpbackend.modules.patient.dto.PatientInsuranceDTO;
import com.rhombuzz.gpbackend.modules.patient.entity.PatientInsurance;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PatientInsuranceResponse {

    String groupId;
    Long patientId;
    Long insuranceId;
    boolean haveInsurance;
    PatientInsuranceDTO primaryInsurance;
    boolean haveSecIns;
    PatientInsuranceDTO secondaryInsurance;

    public static PatientInsuranceResponse fromEntity(PatientInsurance patientInsurance) {

        PatientInsuranceResponseBuilder builder = PatientInsuranceResponse.builder()
                .groupId(patientInsurance.getMedGroup().getGroupId())
                .patientId(patientInsurance.getPatient().getId())
                .insuranceId(patientInsurance.getId())
                .haveInsurance(patientInsurance.isHaveInsurance())
                .haveSecIns(patientInsurance.isHaveSecIns());

        if (patientInsurance.isHaveInsurance()) {
            builder.primaryInsurance(
                    PatientInsuranceDTO.builder()
                            .policyholderRelationship(patientInsurance.getPriInsPolicyholderRelationship())
                            .policyholderFN(patientInsurance.getPriInsPolicyholderFN())
                            .policyholderLN(patientInsurance.getPriInsPolicyholderLN())
                            .policyholderDob(patientInsurance.getPriInsPolicyholderDob())
                            .policyholderGender(patientInsurance.getPriInsPolicyholderGender())
                            .companyName(patientInsurance.getPriInsCompanyName())
                            .companyCode(patientInsurance.getPriInsCompanyCode())
                            .insGroupId(patientInsurance.getPriInsGroupId())
                            .insId(patientInsurance.getPriInsId())
                            .build()
            );
        }

        if (patientInsurance.isHaveSecIns() && patientInsurance.isHaveInsurance()) {
            builder.secondaryInsurance(
                    PatientInsuranceDTO.builder()
                            .policyholderRelationship(patientInsurance.getSecInsPolicyholderRelationship())
                            .policyholderFN(patientInsurance.getSecInsPolicyholderFN())
                            .policyholderLN(patientInsurance.getSecInsPolicyholderLN())
                            .policyholderDob(patientInsurance.getSecInsPolicyholderDob())
                            .policyholderGender(patientInsurance.getSecInsPolicyholderGender())
                            .companyName(patientInsurance.getSecInsCompanyName())
                            .companyCode(patientInsurance.getSecInsCompanyCode())
                            .insGroupId(patientInsurance.getSecInsGroupId())
                            .insId(patientInsurance.getSecInsId())
                            .build()
            );
        }
        return builder.build();
    }

}
