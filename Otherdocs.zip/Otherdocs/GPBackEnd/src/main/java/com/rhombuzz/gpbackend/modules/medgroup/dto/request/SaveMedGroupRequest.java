package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

import java.time.DateTimeException;
import java.time.ZoneId;

public record SaveMedGroupRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.TEXT_LOWER, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Group name cannot be blank")
        @Pattern(regexp = RegexPattern.TEXT_LOWER_WITH_DIGIT, message = "Group name must contain only small letters and digits")
        @Size(max = 45, message = "Group Name must be at most 45 characters long")
        String groupName,

        @NotBlank(message = "Group description cannot be blank")
        @Size(max = 60, message = "Group description must be at most 65 characters long")
        String groupDescription,

        @NotBlank(message = "Username cannot be blank")
        @Pattern(regexp = RegexPattern.USER_NAME, message = "Username must contain only letters, digits and _+=,@-.")
        @Size(min = 7, max = 15, message = "Username must be between 7 and 15 characters long")
        String username,

        @NotBlank(message = "First name cannot be blank")
        @Pattern(regexp = RegexPattern.NAME, message = "First name must contain only letters")
        @Size(max = 45, message = "First name must be at most 45 characters long")
        String firstName,

        @NotBlank(message = "Last name cannot be blank")
        @Pattern(regexp = RegexPattern.NAME, message = "Last name must contain only letters")
        @Size(max = 45, message = "Last name must be at most 45 characters long")
        String lastName,

        @NotBlank(message = "Email cannot be blank")
        @Email(message = "Invalid email format")
        @Size(max = 45, message = "Email must be at most 45 characters long")
        String email,

        @Pattern(regexp = RegexPattern.PASSWORD,
                message = "Password must be at least 8 characters long, include at " +
                        "least one special character and one number")
        @NotBlank(message = "Password cannot be blank")
        String password,

        @NotBlank(message = "Time zone cannot be blank")
        String timeZone,

        @NotNull(message = "Group type cannot be null")
        MedGroup.GroupType groupType,

        @NotBlank(message = "Office phone number cannot be blank")
        @Pattern(regexp = RegexPattern.DIGITS, message = "Office phone number must contain only digits")
        @Size(min = 10, max = 10, message = "Office phone number must be exactly 11 digits long")
        String officePhone,

        @NotBlank(message = "Default address cannot be blank")
        @Size(max = 100, message = "Default address must be at most 255 characters long")
        String defaultAddress
) {
    @AssertTrue(message = "Invalid time zone")
    public boolean isTimeZoneValid() {
        try {
            if (timeZone != null) {
                ZoneId.of(timeZone);
            }
            return true;
        } catch (DateTimeException e) {
            return false;
        }
    }
}
