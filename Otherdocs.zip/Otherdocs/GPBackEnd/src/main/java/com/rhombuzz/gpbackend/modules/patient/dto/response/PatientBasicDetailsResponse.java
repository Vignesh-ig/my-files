package com.rhombuzz.gpbackend.modules.patient.dto.response;

import com.rhombuzz.gpbackend.enums.Gender;

import java.time.LocalDate;

public record PatientBasicDetailsResponse(
        String firstName,
        String lastName,
        LocalDate dob,
        String cellPhone,
        String email,
        Gender gender
) {
}
