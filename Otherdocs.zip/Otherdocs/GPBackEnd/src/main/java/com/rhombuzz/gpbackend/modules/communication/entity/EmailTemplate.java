package com.rhombuzz.gpbackend.modules.communication.entity;

import com.fasterxml.jackson.databind.JsonNode;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.entity.enums.TemplateType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.type.SqlTypes;


@Entity
@Table(name = "email_templates")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmailTemplate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "group_id", length = 10, nullable = false)
    private String groupId;

    @ManyToOne
    @JoinColumn(name = "attribute_id", referencedColumnName = "id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private EmailTemplateAttribute attribute;

    @Column(name = "template_id", length = 100, nullable = false)
    private String templateId;

    @Column(name = "name", length = 45, nullable = false)
    private String name;

    @Column(name = "subject", length = 100, nullable = false)
    private String subject;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "english_content", nullable = false, columnDefinition = "JSON")
    private JsonNode englishContent;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "spanish_content", nullable = false, columnDefinition = "JSON")
    private JsonNode spanishContent;

    @Column(name = "template_type", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private TemplateType templateType;

    @Column(name = "template_group", nullable = false, length = 45)
    @Enumerated(EnumType.STRING)
    private TemplateGroup templateGroup;

    @Column(name = "is_restricted")
    private boolean isRestricted;

    public static EmailTemplate fromRequest(SaveEmailTemplateRequest request) {
        String templateId = request.templateName().trim().replace(" ", "_").toUpperCase();

        return EmailTemplate.builder()
                .templateId(templateId)
                .name(request.templateName())
                .subject(request.templateSubject())
                .build();
    }

    public enum TemplateGroup {

        APPOINTMENT_AVAILABILITY,
        APPOINTMENT_CONFIRMATION,
        APPOINTMENT_CANCELED,
        APPOINTMENT_REMINDER,
        APPOINTMENT_GENERAL,
        APPOINTMENT_RESCHEDULED,
        CSV,
        FORMS,
        PAYMENT,
        SECURE_DOWNLOAD,
        SECURE_EMAIL,
        SURVEY,
        CUSTOM
    }

}
