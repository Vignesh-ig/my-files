package com.rhombuzz.gpbackend.modules.communication.dto.request;

import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record UpdateSMSTemplateRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotBlank(message = "Template ID cannot be blank")
        String englishContent,

        @NotBlank(message = "Spanish content cannot be blank")
        String spanishContent
) {
}
