package com.rhombuzz.gpbackend.modules.patient.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public record MergePatientRequest(

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        String groupId,

        @NotNull(message = "Source ID cannot be null")
        @Positive(message = "Source ID must be a positive number")
        Long sourceId,

        @NotNull(message = "Target ID cannot be null")
        @Positive(message = "Target ID must be a positive number")
        Long targetId
) {
}
