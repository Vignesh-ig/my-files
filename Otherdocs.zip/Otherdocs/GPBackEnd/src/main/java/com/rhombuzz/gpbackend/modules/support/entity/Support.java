package com.rhombuzz.gpbackend.modules.support.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.support.dto.request.SupportRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "supports", indexes = {
        @Index(name = "idx_support_med_group_id", columnList = "med_group_id" ),
        @Index(name = "idx_support_username", columnList = "username"),
})
public class Support {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @OneToMany(mappedBy = "support", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<Ticket> tickets;

    @Column(name = "username", length = 45)
    private String username;

    @Column(name = "problem", length = 45)
    @Enumerated(EnumType.STRING)
    private Problem problem;

    @Column(name = "summary", length = 500, nullable = false)
    private String summary;

    public static Support fromRequest(SupportRequest request) {
        return Support.builder()
                .problem(request.problem())
                .summary(request.summary())
                .build();
    }

    public enum Problem {

        TECHNICAL, ISSUE,
        FEATURE_ENHANCEMENT,
        NEW_FEATURE
    }

}
