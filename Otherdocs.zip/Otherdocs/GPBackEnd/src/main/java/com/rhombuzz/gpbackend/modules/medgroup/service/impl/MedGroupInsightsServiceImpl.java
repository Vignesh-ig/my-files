package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.exception.domain.InternalServerErrorException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.GetInsightsCompareRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.GetInsightsRangeRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.GetInsightsRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveInsightsRequest;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroup;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupInsights;
import com.rhombuzz.gpbackend.modules.medgroup.repository.MedGroupInsightsRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupInsightsService;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.persistence.Column;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class MedGroupInsightsServiceImpl implements MedGroupInsightsService {
    private static final String DATE_FORMAT = "%m-%Y";
    private final JdbcClient jdbcClient;
    private final MedGroupInsightsRepository medGroupInsightsRepository;
    private final MedGroupService medGroupService;

    @Override
    public Map<String, Integer> getDayInsights(GetInsightsRequest request) {
        log.info("Fetching day insights for groupId: {} and date: {}", request.groupId(), request.date());

        try {
            String columns = request.sourceType().getColumns();
            String sql = String.format("SELECT %s FROM med_group_insights WHERE med_group_id = :med_group_id AND insight_date = :insight_date", columns);
            logSQL(sql);

            return jdbcClient.sql(sql)
                    .param("med_group_id", request.groupId())
                    .param("insight_date", request.date())
                    .query((rs, i) -> {
                        Map<String, Integer> row = new HashMap<>();
                        Arrays.stream(columns.split(","))
                                .forEach(column -> {
                                    try {
                                        row.put(column, rs.getInt(column));
                                    } catch (SQLException e) {
                                        throw new RuntimeException(e);
                                    }
                                });
                        return row;
                    })
                    .stream()
                    .reduce(
                            new HashMap<>(),
                            (acc, row) -> {
                                row.forEach((k, v) -> acc.merge(k, v, Integer::sum));
                                return acc;
                            }
                    );
        } catch (Exception e) {
            log.error("Error fetching day insights for groupId: {}", request.groupId(), e);
            throw new InternalServerErrorException("Failed to process day insights");
        }
    }

    @Override
    public Map<LocalDate, Map<String, Integer>> getInsightsDateRange(GetInsightsRangeRequest request) {
        log.info("Fetching insights date range for groupId: {} between {} and {}",
                request.groupId(), request.startDate(), request.endDate());

        try {
            String columns = request.sourceType().getColumns();
            String sql = String.format(
                    "SELECT insight_date,%s FROM med_group_insights " +
                            "WHERE med_group_id = :med_group_id AND insight_date BETWEEN :start_date AND :end_date " +
                            "GROUP BY insight_date,%s",
                    columns, columns
            );
            logSQL(sql);

            return jdbcClient.sql(sql)
                    .param("med_group_id", request.groupId())
                    .param("start_date", request.startDate())
                    .param("end_date", request.endDate())
                    .query((rs, i) -> new AbstractMap.SimpleEntry<>(
                            rs.getDate("insight_date").toLocalDate(),
                            Arrays.stream(columns.split(","))
                                    .collect(Collectors.toMap(
                                            column -> column,
                                            column -> {
                                                try {
                                                    return rs.getInt(column);
                                                } catch (Exception e) {
                                                    log.warn("Error reading column {}", column, e);
                                                    return 0;
                                                }
                                            }
                                    ))
                    ))
                    .stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (v1, i) -> v1,
                            TreeMap::new
                    ));
        } catch (Exception e) {
            log.error("Error fetching insights date range for groupId: {}", request.groupId(), e);
            throw new InternalServerErrorException("Failed to process date range insights");
        }
    }

    @Override
    public Map<String, Map<String, Integer>> getInsightsMonthRange(GetInsightsRangeRequest request) {
        log.info("Fetching monthly insights for groupId: {} between {} and {}",
                request.groupId(), request.startDate(), request.endDate());

        String sourceColumns = request.sourceType().getColumns();
        try {
            List<String> columns = Arrays.asList(sourceColumns.split(","));
            String aggregatedColumns = buildAggregatedColumns(columns);

            String sql = String.format(
                    "SELECT DATE_FORMAT(insight_date, '%s') AS month_year, %s " +
                            "FROM med_group_insights WHERE med_group_id = :med_group_id " +
                            "AND insight_date BETWEEN :start_date AND :end_date " +
                            "GROUP BY month_year ORDER BY month_year",
                    DATE_FORMAT, aggregatedColumns
            );
            logSQL(sql);

            return jdbcClient.sql(sql)
                    .param("med_group_id", request.groupId())
                    .param("start_date", request.startDate())
                    .param("end_date", request.endDate())
                    .query((rs, i) -> new AbstractMap.SimpleEntry<>(
                            rs.getString("month_year"),
                            columns.stream().collect(Collectors.toMap(
                                    column -> column,
                                    column -> {
                                        try {
                                            return rs.getInt(column);
                                        } catch (Exception e) {
                                            log.warn("Error reading column {}", column, e);
                                            return 0;
                                        }
                                    }
                            ))
                    ))
                    .stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (v1, i) -> v1,
                            TreeMap::new
                    ));
        } catch (Exception e) {
            log.error("Error fetching monthly insights for groupId: {}", request.groupId(), e);
            throw new InternalServerErrorException("Failed to process monthly insights");
        }
    }

    @Override
    public Map<String, Map<String, Integer>> getInsightsDateRangeCompare(GetInsightsCompareRequest request) {
        log.info("Comparing insights for {} groups between {} and {}",
                request.groupIds().size(), request.startDate(), request.endDate());

        String sourceColumns = request.sourceType().getColumns();

        try {
            List<String> columns = Arrays.asList(sourceColumns.split(","));
            String aggregatedColumns = buildAggregatedColumnsWithCoalesce(columns);
            String groupIdsList = buildGroupIdsSubquery(request.groupIds());

            String sql = String.format(
                    "SELECT g.med_group_id, %s FROM (%s) g " +
                            "LEFT JOIN med_group_insights m ON g.med_group_id = m.med_group_id " +
                            "AND m.insight_date BETWEEN :start_date AND :end_date " +
                            "GROUP BY g.med_group_id",
                    aggregatedColumns, groupIdsList
            );
            logSQL(sql);

            return jdbcClient.sql(sql)
                    .param("start_date", request.startDate())
                    .param("end_date", request.endDate())
                    .query((rs, i) -> new AbstractMap.SimpleEntry<>(
                            rs.getString("med_group_id"),
                            columns.stream().collect(Collectors.toMap(
                                    column -> column,
                                    column -> {
                                        try {
                                            return rs.getInt(column);
                                        } catch (Exception e) {
                                            log.warn("Error reading column {}", column, e);
                                            return 0;
                                        }
                                    }
                            ))
                    ))
                    .stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (v1, i) -> v1,
                            HashMap::new
                    ));
        } catch (Exception e) {
            log.error("Error comparing insights for groups: {}", request.groupIds(), e);
            throw new InternalServerErrorException("Failed to process comparative insights");
        }
    }

    @Override
    public void saveDataToInsights(SaveInsightsRequest request) {
        String groupId = request.groupId();
        String sourceName = request.sourceName();
        int count = request.count();

        log.info("Saving data to insights for groupId: {} and source: {}", groupId, sourceName);

        LocalDate date = medGroupService.getCurrentDateTime(request.groupId()).toLocalDate();
        log.info("Current date: {}", date);

        MedGroupInsights.InsightsSourceType sourceType = MedGroupInsights.InsightsSourceType.fromName(sourceName);
        if (medGroupInsightsRepository.existsByGroupIdAndInsightDate(groupId, date)) {
            updateExistingInsights(groupId, date, sourceType, sourceName, count);
        } else {
            createNewInsights(groupId, date, sourceType, sourceName, count);
        }
    }

    private void logSQL(String sql) {
        log.debug("Hibernate: {}", sql);
    }

    private String buildAggregatedColumnsWithCoalesce(List<String> columns) {
        return columns.stream()
                .map(col -> String.format("COALESCE(SUM(%s), 0) AS %s", col, col))
                .collect(Collectors.joining(", "));
    }

    private String buildGroupIdsSubquery(List<String> groupIds) {
        return groupIds.stream()
                .map(id -> String.format("SELECT '%s' AS med_group_id", id))
                .collect(Collectors.joining(" UNION ALL "));
    }

    private String buildAggregatedColumns(List<String> columns) {
        return columns.stream()
                .map(col -> String.format("SUM(%s) AS %s", col, col))
                .collect(Collectors.joining(", "));
    }

    private void updateExistingInsights(String groupId, LocalDate date, MedGroupInsights.InsightsSourceType sourceType,
                                        String sourceName, int count) {
        log.info("Updating existing insights for groupId: {} and date: {}", groupId, date);
        if (sourceType != null) {
            updateStandardInsights(groupId, date, sourceType, count);
        } else {
            incrementDynamicColumn(groupId, date, sourceName, count);
        }
    }

    private void updateStandardInsights(String groupId, LocalDate date, MedGroupInsights.InsightsSourceType sourceType, int count) {
        switch (sourceType) {
            case APPOINTMENT_BOOKED_BY_PATIENT ->
                    medGroupInsightsRepository.incrementAppointmentBookedByPatient(groupId, date, count);
            case APPOINTMENT_BOOKED_BY_STAFF ->
                    medGroupInsightsRepository.incrementAppointmentBookedByStaff(groupId, date, count);
            case APPOINTMENT_CANCELED_BY_PATIENT ->
                    medGroupInsightsRepository.incrementAppointmentCanceledByPatient(groupId, date, count);
            case APPOINTMENT_CANCELED_BY_STAFF ->
                    medGroupInsightsRepository.incrementAppointmentCanceledByStaff(groupId, date, count);
        }
    }

    private void incrementDynamicColumn(String groupId, LocalDate date, String sourceName, int count) {

        String columnName = Utils.toSnakeCase(sourceName);

        String sql = String.format("UPDATE med_group_insights SET %s = %s + :count WHERE med_group_id = :med_group_id AND insight_date = :insight_date",
                columnName, columnName);
        logSQL(sql);

        jdbcClient.sql(sql)
                .param("med_group_id", groupId)
                .param("insight_date", date)
                .param("count", count)
                .update();
    }

    private void createNewInsights(String groupId, LocalDate date, MedGroupInsights.InsightsSourceType sourceType,
                                   String sourceName, int count) {
        log.info("Creating new insights for groupId: {} and date: {}", groupId, date);
        MedGroupInsights insights = new MedGroupInsights();

        MedGroup medGroup = medGroupService.getMedGroup(groupId);
        insights.setMedGroup(medGroup);
        insights.setInsightDate(date);

        if (sourceType != null) {
            initializeStandardInsights(insights, sourceType, count);
        } else {
            setDynamicColumn(insights, sourceName, count);
        }
        medGroupInsightsRepository.save(insights);
    }

    private void setDynamicColumn(MedGroupInsights insights, String sourceName, int count) {
        log.info("Setting dynamic column for source: {}", sourceName);

        Field field = findColumnField(sourceName);
        log.info("Found field: {}", field);

        try {
            if (field != null) {
                field.setAccessible(true);
                field.set(insights, count);
            }
        } catch (IllegalAccessException e) {
            log.error("Error setting column for source: {}", sourceName, e);
            throw new InternalServerErrorException("Invalid source name: " + sourceName);
        }
    }

    private Field findColumnField(String sourceName) {
        log.info("Finding column field for source: {}", sourceName);

        String annotationName = Utils.toSnakeCase(sourceName);

        return Arrays.stream(MedGroupInsights.class.getDeclaredFields())
                .filter(field -> {
                    Column annotation = field.getAnnotation(Column.class);
                    return annotation != null && annotation.name().equalsIgnoreCase(annotationName);
                })
                .findFirst()
                .orElse(null);
    }

    private void initializeStandardInsights(MedGroupInsights insights, MedGroupInsights.InsightsSourceType sourceType, int count) {
        switch (sourceType) {
            case APPOINTMENT_BOOKED_BY_PATIENT -> {
                insights.setAppointmentBookedByPatient(count);
                insights.setTotalAppointmentCreated(count);
            }

            case APPOINTMENT_BOOKED_BY_STAFF -> {
                insights.setAppointmentBookedByStaff(count);
                insights.setTotalAppointmentCreated(count);
            }

            case APPOINTMENT_CANCELED_BY_PATIENT -> {
                insights.setAppointmentCanceledByPatient(count);
                insights.setTotalAppointmentCanceled(count);
            }

            case APPOINTMENT_CANCELED_BY_STAFF -> {
                insights.setAppointmentCanceledByStaff(count);
                insights.setTotalAppointmentCanceled(count);
            }
        }
    }
}
