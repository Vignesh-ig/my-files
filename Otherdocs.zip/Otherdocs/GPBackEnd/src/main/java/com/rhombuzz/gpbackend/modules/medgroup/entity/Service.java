package com.rhombuzz.gpbackend.modules.medgroup.entity;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.SaveServiceRequest;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "services", indexes = {
        @Index(name = "idx_service_med_group_id", columnList = "med_group_id")
})
public class Service {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "service_name", length = 45, nullable = false)
    private String serviceName;

    @Column(name = "duration")
    private int duration;

    @Column(name = "reference", length = 45)
    private String reference;

    @Column(name = "color_code", length = 7)
    private String colorCode;

    @Column(name = "visible_to_patient")
    private boolean visibleToPatient;

    @Column(name = "recall")
    private boolean recall;

    @Column(name = "recall_period")
    private Integer recallPeriod;

    @Column(name = "booking_fee_amount", precision = 5, scale = 2)
    private BigDecimal bookingFeeAmount;

    @Column(name = "visit_type", length = 45)
    @Enumerated(EnumType.STRING)
    private VisitType visitType;

    @Column(name = "created_by", length = 45, nullable = false)
    private String createdBy;

    @Column(name = "allow_reminder")
    private boolean allowReminder;

    @Column(name = "created_at", nullable = false, updatable = false, columnDefinition = "DATETIME(0)")
    private LocalDateTime createdAt;

    @Column(name = "updated_at", columnDefinition = "DATETIME(0)")
    private LocalDateTime updatedAt;

    public Service(Long id) {
        this.id = id;
    }

    @PrePersist
    private void beforePersist() {
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    private void beforeUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public static Service fromRequest(SaveServiceRequest request) {
        return Service.builder()
                .serviceName(request.serviceName())
                .duration(request.duration())
                .reference(request.serviceReference())
                .colorCode(request.colorCode())
                .visibleToPatient(request.visibleToPatient())
                .recall(request.recall())
                .recallPeriod(request.recallPeriod())
                .bookingFeeAmount(request.bookingFeeAmount())
                .visitType(request.visitType())
                .allowReminder(request.allowReminder())
                .build();
    }

    public enum VisitType {
        IN_PERSON,
        TELEHEALTH,
        BOTH
    }
}
