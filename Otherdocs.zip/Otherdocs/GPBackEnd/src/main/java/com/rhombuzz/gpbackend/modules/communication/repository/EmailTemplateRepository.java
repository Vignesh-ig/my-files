package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface EmailTemplateRepository extends JpaRepository<EmailTemplate, Long> {
    @Query("SELECT e FROM EmailTemplate e WHERE e.groupId = ?1")
    List<EmailTemplate> findEmailTemplates(String groupId);

    @Query("SELECT e FROM EmailTemplate e WHERE e.id = ?1 AND e.groupId = ?2")
    Optional<EmailTemplate> getEmailTemplate(Long id, String groupId);

    @Query("SELECT e FROM EmailTemplate e WHERE e.templateId = ?1 AND e.groupId = ?2")
    Optional<EmailTemplate> getEmailTemplate(String templateId, String groupId);

    @Query("SELECT e.isRestricted FROM EmailTemplate e WHERE e.groupId = ?1 AND e.templateId = ?2")
    boolean isRestricted(String groupId, String templateId);
}