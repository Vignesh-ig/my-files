package com.rhombuzz.gpbackend.modules.communication.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.dto.request.SaveEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.request.UpdateEmailTemplateRequest;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateNameResponse;
import com.rhombuzz.gpbackend.modules.communication.dto.response.EmailTemplateResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.EmailTemplate;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Map;

@Validated
public interface EmailTemplateService {
    void saveEmailTemplate(
            @Valid SaveEmailTemplateRequest request
    );

    EmailTemplateResponse getEmailTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId,
            @NotNull PreferredLanguage language
    );

    EmailTemplateResponse getEmailTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    Map<EmailTemplate.TemplateGroup, List<EmailTemplateNameResponse>> getEmailTemplatesNameWithGroup(
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    void updateEmailTemplate(
            @NotNull @Positive Long id,
            @Valid UpdateEmailTemplateRequest request
    ) throws JsonProcessingException;

    boolean isRestrictedTemplate(
            @NotBlank @Pattern(regexp = RegexPattern.UPPERCASE_UNDERSCORE) String templateId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
