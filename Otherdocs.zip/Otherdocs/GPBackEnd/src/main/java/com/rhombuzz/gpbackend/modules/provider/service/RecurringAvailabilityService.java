package com.rhombuzz.gpbackend.modules.provider.service;

import com.rhombuzz.gpbackend.modules.provider.dto.request.SaveRecurringAvailabilityRequest;
import com.rhombuzz.gpbackend.modules.provider.dto.response.RecurringAvailabilityResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

@Validated
public interface RecurringAvailabilityService {

    void saveRecurringAvailability(
            @Valid SaveRecurringAvailabilityRequest request
    );

    Map<DayOfWeek, List<RecurringAvailabilityResponse>> getRecurringAvailabilities(
            @NotNull @Positive Long providerId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );

    @Transactional
    void deleteRecurringAvailability(
            @NotNull @Positive Long id,
            @NotNull @Positive Long providerId,
            @NotNull @Positive Long locationId,
            @NotBlank @Size(min = 10, max = 10) String groupId
    );
}
