package com.rhombuzz.gpbackend.modules.communication.repository;

import com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse;
import com.rhombuzz.gpbackend.modules.communication.entity.SMSTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SMSTemplateRepository extends JpaRepository<SMSTemplate, Long> {

    @Query("SELECT new com.rhombuzz.gpbackend.modules.communication.dto.response.SMSTemplateIdResponse(t.templateId, t.name, t.templateGroup) " +
            "FROM SMSTemplate t WHERE t.groupId = ?1")
    List<SMSTemplateIdResponse> findTemplateGroups(String groupId);

    @Query("SELECT t FROM SMSTemplate t WHERE t.templateId = ?1 AND t.groupId = ?2")
    Optional<SMSTemplate> findByTemplateId(String templateId, String groupId);

    @Query("SELECT t.isRestricted FROM SMSTemplate t WHERE t.templateId = ?1 AND t.groupId = ?2")
    Optional<Boolean> isTemplateRestricted(String templateId, String groupId);
}
