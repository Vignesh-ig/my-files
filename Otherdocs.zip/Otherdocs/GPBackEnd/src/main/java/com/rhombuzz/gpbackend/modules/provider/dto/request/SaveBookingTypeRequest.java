package com.rhombuzz.gpbackend.modules.provider.dto.request;


import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import jakarta.validation.constraints.*;

import java.util.Optional;

public record SaveBookingTypeRequest (
        @NotBlank @Size(min = 10, max = 10)
        String groupId,

        @NotNull(message = "Booking type is required")
        Provider.BookingType bookingType,

        Optional<@Min(value = 4, message = "Booking per slot must be at least 4") Integer> bookingPerSlot,

        @Positive(message = "Booking per day must be greater than 0")
        int bookingPerDay
){
    @AssertTrue(message = "Booking per day must be greater than booking per slot")
    public boolean isBookingPerDayGreaterThanPerSlot() {
        return bookingPerDay >= bookingPerSlot.orElse(0);
    }
}
