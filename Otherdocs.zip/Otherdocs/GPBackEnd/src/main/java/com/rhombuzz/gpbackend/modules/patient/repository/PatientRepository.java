package com.rhombuzz.gpbackend.modules.patient.repository;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientBasicDetailsResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientCellphoneAndEmailResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponse;
import com.rhombuzz.gpbackend.modules.patient.dto.response.PatientResponseList;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PatientRepository extends JpaRepository<Patient, Long>, JpaSpecificationExecutor<Patient> {
    Page<PatientResponseList> findByMedGroup_GroupId(String groupId, Pageable pageable);

    @Query("SELECT p FROM Patient p WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    Optional<Patient> findById(Long id, String groupId);

    @Query("SELECT COUNT(p) > 0 FROM Patient p WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    boolean existsById(Long id, String groupId);

    @Query("SELECT p FROM Patient p WHERE p.medGroup.groupId = ?1 AND " +
            "(p.firstName = ?2 OR p.firstName = ?3) AND " +
            "(p.lastName = ?4 OR p.lastName = ?5) AND " +
            "p.dob = ?6 ORDER BY p.createdDateTime DESC")
    List<Patient> findByGroupIdAndNameAndDob(String groupId, String firstName, String fName,
                                             String lastName, String lName, LocalDate dob);

    @Query("SELECT p FROM Patient p WHERE p.medGroup.groupId = ?1 AND " +
            "(p.firstName = ?2 OR p.firstName = ?3) AND " +
            "(p.lastName = ?4 OR p.lastName = ?5) AND " +
            "(p.cellPhone = ?6 OR p.email = ?7) ORDER BY p.createdDateTime DESC")
    List<Patient> findByGroupIdAndNameAndPhoneOrEmail(String groupId, String firstName, String fName,
                                                      String lastName, String lName, String cellPhone, String email);

    @Query("SELECT p FROM Patient p WHERE p.medGroup.groupId = ?1 AND " +
            "(p.firstName = ?2 OR p.firstName = ?3) AND " +
            "(p.lastName = ?4 OR p.lastName = ?5) AND " +
            "p.cellPhone = ?6 ORDER BY p.createdDateTime DESC")
    List<Patient> findByGroupIdAndNameAndPhone(String groupId, String firstName, String fName,
                                               String lastName, String lName, String cellPhone);

    @Query("SELECT p FROM Patient p WHERE p.medGroup.groupId = ?1 AND " +
            "(p.firstName = ?2 OR p.firstName = ?3) AND " +
            "(p.lastName = ?4 OR p.lastName = ?5) AND " +
            "p.email = ?6 ORDER BY p.createdDateTime DESC")
    List<Patient> findByGroupIdAndNameAndEmail(String groupId, String firstName, String fName,
                                               String lastName, String lName, String email);

    @Query("SELECT p FROM Patient p WHERE p.medGroup.groupId = ?1 AND " +
            "(p.cellPhone = ?2 OR p.email = ?3) AND " +
            "p.id IN ?4 ORDER BY p.createdDateTime DESC")
    List<Patient> findByGroupIdAndPhoneOrEmailInPatientIds(String groupId, String cellPhone,
                                                           String email, List<Long> patientIds);

    @Query("SELECT p FROM Patient p WHERE p.medGroup.groupId = ?1 AND " +
            "p.cellPhone = ?2 AND " +
            "p.id IN ?3 ORDER BY p.createdDateTime DESC")
    List<Patient> findByGroupIdAndPhoneInPatientIds(String groupId, String cellPhone,
                                                    List<Long> patientIds);

    @Query("SELECT p FROM Patient p WHERE p.medGroup.groupId = ?1 AND " +
            "p.email = ?2 AND " +
            "p.id IN ?3 ORDER BY p.createdDateTime DESC")
    List<Patient> findByGroupIdAndEmailInPatientIds(String groupId, String email,
                                                    List<Long> patientIds);

    @Modifying
    @Query("DELETE FROM Patient p WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    void deleteById(Long id, String groupId);

    @Query("SELECT p.medGroup.groupId FROM Patient p WHERE p.id = ?1")
    Optional<String> findGroupId(Long id);

    List<PatientResponseList> findByIdInAndMedGroup_GroupId(List<Long> ids, String groupId);

    @Query("SELECT p FROM Patient p WHERE p.cellPhone = ?1 AND p.medGroup.groupId = ?2")
    Optional<Patient> findByPhone(String phone, String groupId);

    @Modifying
    @Query("UPDATE Patient p SET p.claimedBy = ?3, p.reviewStatus = ?4 WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    void updateClaimedByStatusAndReviewStatusByIdAndGroupId(Long id, String groupId, String claimedBy, boolean reviewStatus);

    Optional<PatientResponse> findByIdAndMedGroup_GroupId(Long id, String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.patient.dto.response.PatientCellphoneAndEmailResponse(p.cellPhone, p.email) FROM Patient p WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    PatientCellphoneAndEmailResponse getCellPhoneAndEmailById(Long id, String groupId);

    @Modifying
    @Query("UPDATE Patient p SET p.cellPhone = ?3, p.email = ?4, p.lastModifiedDateTime = ?5 WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    void updateCellPhoneAndEmailByIdAndGroupId(Long id, String groupId, String cellPhone, String email, LocalDateTime updatedAt);

    @Modifying
    @Query(value = "UPDATE grow_practice.patients p " +
            "SET p.street_address = IF(?3 IS NULL OR ?3 = '', p.street_address, ?3), " +
            "p.city = IF(?4 IS NULL OR ?4 = '', p.city, ?4), " +
            "p.state = IF(?5 IS NULL OR ?5 = '', p.state, ?5), " +
            "p.zip_code = IF(?6 IS NULL OR ?6 = '', p.zip_code, ?6), " +
            "p.preferred_contact_method = IF(?7 IS NULL, p.preferred_contact_method, ?7), " +
            "p.last_modified_date_time = ?8 " +
            "WHERE p.id = ?1 AND p.med_group_id = ?2", nativeQuery = true)
    void updateAddressByIdAndGroupId(Long id, String groupId, String streetAddress, String city, String state, String zipCode, ContactMethod preferredContactMethod, LocalDateTime updatedAt);

    @Modifying
    @Query("UPDATE Patient p SET p.homePhone = ?3, p.lastModifiedDateTime = ?4 WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    void updateHomePhoneByIdAndGroupId(Long id, String groupId, String homePhone, LocalDateTime currentDateTime);

    @Modifying
    @Query("UPDATE Patient p SET p.cellPhone = ?3, p.lastModifiedDateTime = ?4 WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    void updateCellPhoneByIdAndGroupId(Long id, String groupId, String cellPhone, LocalDateTime currentDateTime);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.patient.dto.response.PatientBasicDetailsResponse(p.firstName, p.lastName, p.dob, p.cellPhone, " +
            "p.email, p.gender) FROM Patient p WHERE p.id = ?1 AND p.medGroup.groupId = ?2")
    Optional<PatientBasicDetailsResponse> getPatientBasicDetailsByIdAndGroupId(Long id, String groupId);
}
