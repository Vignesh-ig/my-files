package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.exception.domain.ConflictException;
import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.UpdateAdminFlagRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.UpdateDashboardFlagRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.AdminFlagResponse;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.DashboardFlagResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupFlag;
import com.rhombuzz.gpbackend.modules.medgroup.repository.MedGroupFlagRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupFlagService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Slf4j
@Service
@RequiredArgsConstructor
public class MedGroupFlagServiceImpl implements MedGroupFlagService {

    @PersistenceContext
    private final EntityManager entityManager;
    private final MedGroupFlagRepository medGroupFlagRepository;
    private final ActivityService activityService;

    @Override
    @Transactional
    public void updateAdminFlag(UpdateAdminFlagRequest request) {
        updateFlag(request.groupId(), FlagFrom.ADMIN, request.flag(), request.value());
    }

    @Override
    public AdminFlagResponse getAdminFlag(String groupId) {
        return getFlagResponse(groupId, AdminFlagResponse::fromEntity, FlagFrom.ADMIN);
    }

    @Override
    @Transactional
    public void updateDashboardFlag(UpdateDashboardFlagRequest request) {
        log.info("save medGroup flag value for group : {}", request.getGroupId());
        MedGroupFlag medGroupFlag = medGroupFlagRepository.findByGroupId(request.getGroupId())
                .orElseThrow(() -> {
                    log.error("MedGroup Flag not found for groupId: {}", request.getGroupId());
                    return new NotFoundException("MedGroupFlag not found");
                });

        if (request.getFlag() == MedGroupFlag.DashboardFlag.FORM_SUBMISSION_EMAIL_ALERT) {
            if (request.getValue() == Boolean.FALSE) {
                log.info("Disabling form submission email alert for group: {}", request.getGroupId());
                medGroupFlag.setFormSubmissionEmailAlert(false);
            }
            if (request.getValue() && request.getFormSubmissionAlertOfficeEmail() != null && !request.getFormSubmissionAlertOfficeEmail().isBlank()) {
                log.info("Enabling form submission email alert for group: {}", request.getGroupId());
                medGroupFlag.setFormSubmissionEmailAlert(true);
                medGroupFlag.getMedGroup().setEmail(request.getFormSubmissionAlertOfficeEmail());
            } else if (request.getValue() && request.getFormSubmissionAlertOfficeEmail() == null) {
                log.warn("Form submission alert email cannot be set to true without a valid office email.");
                throw new ConflictException("Form submission alert email cannot be set to true without a valid office email.");
            }
            medGroupFlagRepository.save(medGroupFlag);

            ActivityRequest activityRequest = buildActivityRequest(
                    request.getGroupId(),
                    "SETTINGS UPDATED",
                    "The user (" + Utils.getCurrentUsername() + ") has updated the form submission alert email."
            );
            activityService.saveActivity(activityRequest);
            return;
        }

        if (request.getFlag() == MedGroupFlag.DashboardFlag.APPOINTMENT_REQUEST_EMAIL_ALERT) {
            if (request.getValue() == Boolean.FALSE) {
                log.info("Disabling appointment request email alert for group: {}", request.getGroupId());
                medGroupFlag.setAppointmentRequestEmailAlert(false);
            }
            if (request.getValue() && request.getAppointmentAlertOfficeEmail() != null && !request.getAppointmentAlertOfficeEmail().isBlank()) {
                log.info("Enabling appointment request email alert for group: {}", request.getGroupId());
                medGroupFlag.setAppointmentRequestEmailAlert(true);
                medGroupFlag.getMedGroup().setAppointmentAlertOfficeEmail(request.getAppointmentAlertOfficeEmail());
            } else if (request.getValue() && request.getAppointmentAlertOfficeEmail() == null) {
                log.warn("Appointment Alert Office Email is required when enabling Appointment Request Email Alert for group: {}", request.getGroupId());
                throw new ConflictException("Appointment Alert Office Email is required when enabling Appointment Request Email Alert");
            }
            log.info("Updating appointment email alert to office email for group: {}", request.getGroupId());
            medGroupFlagRepository.save(medGroupFlag);

            ActivityRequest activityRequest = buildActivityRequest(
                    request.getGroupId(),
                    "SETTINGS UPDATED",
                    "The user (" + Utils.getCurrentUsername() + ") has updated the appointment request alert email."
            );
            activityService.saveActivity(activityRequest);
        }
    }

    @Override
    public DashboardFlagResponse getDashboardFlag(String groupId) {
        return getFlagResponse(groupId, DashboardFlagResponse::fromEntity, FlagFrom.DASHBOARD);
    }

    private <T> T getFlagResponse(String groupId, Function<MedGroupFlag, T> mapper, FlagFrom from) {
        log.info("Fetching {} Flag for groupId: {}", from, groupId);
        return medGroupFlagRepository.findByGroupId(groupId)
                .map(mapper)
                .orElseThrow(() -> {
                    log.error("Medgroup Flag from {} not found for groupId: {}", from, groupId);
                    return new NotFoundException("MedGroupFlag not found");
                });
    }

    private void updateFlag(String groupId, FlagFrom from, Enum<?> flag, Boolean value) {
        String columnName = getColumnName(flag);
        log.info("Updating MedGroupFlag from {} with groupId: {}, flag: {}", from, groupId, flag);

        int updatedCount = entityManager.createQuery(
                        "UPDATE MedGroupFlag mf SET mf." + columnName + " = ?1 " +
                                "WHERE mf.medGroup.groupId = ?2 AND mf." + columnName + " <> ?1")
                .setParameter(1, value)
                .setParameter(2, groupId)
                .executeUpdate();

        if (updatedCount == 0) {
            log.warn("No MedGroupFlag from {} was updated for groupId: {}, flag: {}", from, groupId, flag);
            return;
        }

        log.info("Updated MedGroupFlag from {} groupId: {}, flag: {}", from, groupId, flag);
        activityService.saveActivity(createActivityRequest(groupId, flag, value));
    }

    private String getColumnName(Enum<?> flag) {
        if (flag instanceof MedGroupFlag.AdminFlag) {
            return ((MedGroupFlag.AdminFlag) flag).getColumnName();
        } else if (flag instanceof MedGroupFlag.DashboardFlag) {
            return ((MedGroupFlag.DashboardFlag) flag).getColumnName();
        }
        throw new IllegalArgumentException("Unsupported flag type: " + flag.getClass());
    }

    private ActivityRequest createActivityRequest(String groupId, Object flag, Boolean value) {
        String description = String.format("%s is %s by %s",
                flag,
                value ? "enabled" : "disabled",
                Utils.getCurrentUsername());

        return ActivityRequest.builder()
                .groupId(groupId)
                .activityType("UPDATE FLAG")
                .activityDescription(description)
                .build();
    }

    private enum FlagFrom {
        ADMIN,
        DASHBOARD
    }

    private ActivityRequest buildActivityRequest(String groupId, String activityType, String activityDescription) {
        return ActivityRequest.builder()
                .groupId(groupId)
                .activityType(activityType)
                .activityDescription(activityDescription)
                .build();
    }
}
