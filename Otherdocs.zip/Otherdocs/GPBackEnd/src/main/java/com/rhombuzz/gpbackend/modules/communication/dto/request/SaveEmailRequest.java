package com.rhombuzz.gpbackend.modules.communication.dto.request;

import com.rhombuzz.gpbackend.modules.communication.entity.enums.MessageStatus;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.*;

public record SaveEmailRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Patient ID cannot be null")
        @Positive(message = "Patient ID must be a positive number")
        Long patientId,

        @NotBlank(message = "Email subject cannot be blank")
        String emailContent,

        @NotNull(message = "Message status cannot be null")
        MessageStatus status
) {
}
