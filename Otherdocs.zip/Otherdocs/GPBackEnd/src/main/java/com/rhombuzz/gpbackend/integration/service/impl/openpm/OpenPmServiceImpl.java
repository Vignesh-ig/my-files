package com.rhombuzz.gpbackend.integration.service.impl.openpm;

import com.rhombuzz.gpbackend.integration.service.IntegrationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Service("openpm")
@Slf4j
public class OpenPmServiceImpl implements IntegrationService {

    @Override
    public void handlePatientResource() {
        log.info("OpenPmServiceImpl handlePatientResource called");
    }

    @Override
    public void handleAppointmentResource() {
        log.info("OpenPmServiceImpl handleAppointmentResource called");
    }

}
