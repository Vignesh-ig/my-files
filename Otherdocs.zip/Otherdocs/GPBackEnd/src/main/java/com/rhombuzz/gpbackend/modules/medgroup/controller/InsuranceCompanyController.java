package com.rhombuzz.gpbackend.modules.medgroup.controller;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.InsuranceRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.InsuranceCompanyResponse;
import com.rhombuzz.gpbackend.modules.medgroup.service.InsuranceCompanyService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/insurance-companies")
@Validated
public class InsuranceCompanyController {
    private final InsuranceCompanyService insuranceCompanyService;

    @GetMapping
    public ResponseEntity<Page<InsuranceCompanyResponse>> getInsuranceCompanies(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<InsuranceCompanyResponse> response = insuranceCompanyService.getInsuranceCompanies(groupId, pageable);
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<Void> saveInsuranceCompany(@RequestBody @Valid InsuranceRequest request) {
        insuranceCompanyService.saveInsuranceCompany(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateInsuranceCompany(@PathVariable Long id,
                                                       @RequestBody @Valid InsuranceRequest request) {
        insuranceCompanyService.updateInsuranceCompany(id, request);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInsuranceCompany(@PathVariable Long id,
                                                       @RequestParam String groupId) {
        insuranceCompanyService.deleteInsuranceCompany(id, groupId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/names")
    public ResponseEntity<Map<String, String>> getInsuranceCompaniesForForms(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        Map<String, String> response = insuranceCompanyService.getInsuranceCompaniesForForms(groupId);
        return ResponseEntity.ok(response);
    }
}