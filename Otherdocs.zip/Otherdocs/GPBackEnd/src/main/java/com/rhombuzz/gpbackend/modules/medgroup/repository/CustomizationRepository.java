package com.rhombuzz.gpbackend.modules.medgroup.repository;

import com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormBuilderSettingResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.Customization;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface CustomizationRepository extends JpaRepository<Customization, Long> {

    @Query("SELECT c FROM Customization c WHERE c.medGroup.groupId = ?1")
    Optional<Customization> findByGroupId(String groupId);

    @Query("SELECT c.apptThankYouPageContent FROM Customization c WHERE c.medGroup.groupId = ?1")
    Optional<String> findApptThankYouPageContentByMedGroup_GroupId(String groupId);

    @Query("SELECT new com.rhombuzz.gpbackend.modules.appointment.dto.response.AppointmentFormBuilderSettingResponse(" +
            "c.addressFlag, c.reasonForVisitFlag, c.preferredContactFlag, " +
            "c.insuranceCompanyFlag, c.insuranceIdFlag, c.insuranceGroupIdFlag) " +
            "FROM Customization c WHERE c.medGroup.groupId = ?1")
    Optional<AppointmentFormBuilderSettingResponse> getAppointmentFormBuilderSettingByGroupId(String groupId);
}
