package com.rhombuzz.gpbackend.modules.communication.service.patient.impl;

import com.rhombuzz.gpbackend.enums.ContactMethod;
import com.rhombuzz.gpbackend.enums.PreferredLanguage;
import com.rhombuzz.gpbackend.modules.communication.service.EmailTemplateService;
import com.rhombuzz.gpbackend.modules.communication.service.SMSTemplateService;
import com.rhombuzz.gpbackend.modules.communication.service.patient.PatientCommunicationValidator;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.AdminFlagResponse;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupFlagService;
import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.patient.service.PatientService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
@RequiredArgsConstructor
public class PatientCommunicationValidatorImpl implements PatientCommunicationValidator {
    private final MedGroupFlagService medGroupFlagService;
    private final PatientService patientService;
    private final SMSTemplateService smsTemplateService;
    private final EmailTemplateService emailTemplateService;

    @Override
    public boolean isCommunicationAllowed(String groupId, String templateId, ContactMethod method) {
        AdminFlagResponse flags = medGroupFlagService.getAdminFlag(groupId);

        if ((method == ContactMethod.SMS && flags.isSmsShutoff()) ||
                (method == ContactMethod.EMAIL && flags.isEmailShutoff())) {
            return false;
        }

        return !((method == ContactMethod.SMS && smsTemplateService.isTemplateRestricted(templateId, groupId)) ||
                (method == ContactMethod.EMAIL && emailTemplateService.isRestrictedTemplate(templateId, groupId)));
    }

    @Override
    public boolean isValidForCommunication(String groupId, Long patientId, String templateId, ContactMethod method) {
        Patient patient = patientService.getPatientById(patientId, groupId);
        return isValidForMethod(patient, method);
    }

    @Override
    public Patient getValidPatientForCommunication(String groupId, Long patientId, String templateId, ContactMethod method) {
        if (!isValidForCommunication(groupId, patientId, templateId, method)) {
            return null;
        }
        return patientService.getPatientById(patientId, groupId);
    }

    public static boolean isValidForMethod(Patient patient, ContactMethod method) {
        if (patient == null) return false;

        ContactMethod optOut = patient.getOptOut();
        return switch (method) {
            case SMS -> optOut != ContactMethod.SMS && optOut != ContactMethod.BOTH;
            case EMAIL -> optOut != ContactMethod.EMAIL && optOut != ContactMethod.BOTH;
            default -> false;
        };
    }

    @Override
    public String getLocalizedContent(Patient patient, Function<PreferredLanguage, String> contentProvider) {
        PreferredLanguage language = patient.getPreferredLanguage() != null ?
                patient.getPreferredLanguage() : PreferredLanguage.ENGLISH;
        return contentProvider.apply(language);
    }
}