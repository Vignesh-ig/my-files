package com.rhombuzz.gpbackend.modules.appointment.repository;

import com.rhombuzz.gpbackend.modules.appointment.entity.CanceledAppointment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CanceledAppointmentRepository extends JpaRepository<CanceledAppointment, Long> {
}
