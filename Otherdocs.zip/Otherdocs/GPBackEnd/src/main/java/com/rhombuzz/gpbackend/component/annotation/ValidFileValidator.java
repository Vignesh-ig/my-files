package com.rhombuzz.gpbackend.component.annotation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;

@Slf4j
public class ValidFileValidator implements ConstraintValidator<ValidFile, MultipartFile> {

    private String[] extensions;
    private String[] contentTypes;
    private boolean required;

    @Override
    public void initialize(ValidFile constraintAnnotation) {
        this.extensions = constraintAnnotation.extensions();
        this.contentTypes = constraintAnnotation.contentTypes();
        this.required = constraintAnnotation.required();
    }

    @Override
    public boolean isValid(MultipartFile file, ConstraintValidatorContext context) {
        if (required && (file == null || file.isEmpty())) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("File is required")
                    .addConstraintViolation();
            return false;
        }

        if (!required && (file == null || file.isEmpty())) {
            return true;
        }

        boolean isValid = true;

        if (extensions.length > 0) {
            isValid = validateExtension(file.getOriginalFilename());
        }

        if (isValid && contentTypes.length > 0) {
            isValid = validateContentTypes(file.getContentType());
        }

        if (!isValid) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(getErrorMessage())
                    .addConstraintViolation();
        }

        return isValid;
    }

    private boolean validateExtension(String filename) {
        if (filename == null) return false;

        String fileExtension = filename.substring(filename.lastIndexOf(".") + 1)
                .toLowerCase();

        return matchValue(extensions, fileExtension);
    }

    private boolean validateContentTypes(String contentType) {
        if (contentType == null) return false;

        return matchValue(contentTypes, contentType);
    }

    private String getErrorMessage() {
        StringBuilder message = new StringBuilder("Allowed file types: ");

        if (extensions.length > 0) {
            message.append("Extension: ")
                    .append(String.join(", ", extensions));
        }
        if (contentTypes.length > 0) {
            if (extensions.length > 0) {
                message.append("; ");
            }

            message.append("Content Types: ")
                    .append(String.join(", ", contentTypes));
        }

        return message.toString();
    }

    private boolean matchValue(String[] array, String value) {
        return Arrays.stream(array)
                .anyMatch(extension -> extension.equalsIgnoreCase(value));
    }
}
