package com.rhombuzz.gpbackend.modules.medgroup.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;
import java.util.Arrays;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "med_group_insights", indexes = {
        @Index(name = "idx_med_group_insight_med_group_id", columnList = "med_group_id")
})
public class MedGroupInsights {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Column(name = "insight_date", nullable = false)
    private LocalDate insightDate;

    @Column(name = "intake_viewed")
    private int intakeViewed;

    @Column(name = "intake_submitted")
    private int intakeSubmitted;

    @Column(name = "intake_updated")
    private int intakeUpdated;

    @Column(name = "patient_added")
    private int patientAdded;

    @Column(name = "appt_form_viewed")
    private int appointmentFormViewed;

    @Column(name = "appt_requested_by_patient")
    private int appointmentRequestedByPatient;

    @Column(name = "appt_booked_by_patient")
    private int appointmentBookedByPatient;

    @Column(name = "appt_booked_by_staff")
    private int appointmentBookedByStaff;

    @Column(name = "total_appt_created")
    private int totalAppointmentCreated;

    @Column(name = "appt_canceled_by_patient")
    private int appointmentCanceledByPatient;

    @Column(name = "appt_canceled_by_staff")
    private int appointmentCanceledByStaff;

    @Column(name = "total_appt_canceled")
    private int totalAppointmentCanceled;

    @Column(name = "appt_denied_by_staff")
    private int appointmentDeniedByStaff;

    @Column(name = "missed_appointment")
    private int missedAppointment;

    @Column(name = "waitlist_appointment")
    private int waitlistAppointment;

    @Column(name = "sms_sent")
    private int smsSent;

    @Column(name = "sms_failed")
    private int smsFailed;

    @Column(name = "email_sent")
    private int emailSent;

    @Column(name = "email_failed")
    private int emailFailed;

    @Column(name = "patient_confirm_appt_by_sms")
    private int patientConfirmAppointmentBySMS;

    @Column(name = "patient_confirm_appt_by_email")
    private int patientConfirmAppointmentByEmail;

    @Column(name = "sms_reminder_sent")
    private int smsReminderSent;

    @Column(name = "sms_reminder_failed")
    private int smsReminderFailed;

    @Column(name = "email_reminder_sent")
    private int emailReminderSent;

    @Column(name = "email_reminder_failed")
    private int emailReminderFailed;

    @Column(name = "quick_survey_requested")
    private int quickSurveyRequested;

    @Column(name = "quick_survey_submitted")
    private int quickSurveySubmitted;

    @Column(name = "google_review_requested")
    private int googleReviewRequested;

    @Column(name = "ccof_submitted")
    private int cCOFSubmitted;

    @Column(name = "request_payment")
    private int requestPayment;

    @Column(name = "cash_in_hand_payment")
    private int cashInHandPayment;

    @Column(name = "card_payment")
    private int cardPayment;

    @Column(name = "payment_failed")
    private int paymentFailed;

    @Column(name = "auto_filled")
    private int autoFilled;


    @Getter
    public enum SourceType {
        PATIENT("intake_viewed,intake_submitted,intake_updated,patient_added"),
        APPOINTMENT("appt_form_viewed,appt_requested_by_patient,appt_booked_by_patient,appt_booked_by_staff,total_appt_created,appt_canceled_by_patient,appt_canceled_by_staff,total_appt_canceled,appt_denied_by_staff,missed_appointment,waitlist_appointment"),
        COMMUNICATION("sms_sent,sms_failed,email_sent,email_failed,patient_confirm_appt_by_sms,patient_confirm_appt_by_email"),
        SURVEY("quick_survey_requested,quick_survey_submitted,google_review_requested"),
        PAYMENT("ccof_submitted,request_payment,cash_in_hand_payment,card_payment,payment_failed");

        private final String columns;

        SourceType(String columns) {
            this.columns = columns;
        }
    }

    public enum InsightsSourceType {
        APPOINTMENT_BOOKED_BY_PATIENT("apptBookedByPatient"),
        APPOINTMENT_BOOKED_BY_STAFF("apptBookedByStaff"),
        APPOINTMENT_CANCELED_BY_PATIENT("apptCanceledByPatient"),
        APPOINTMENT_CANCELED_BY_STAFF("apptCanceledByStaff");

        private final String sourceName;

        InsightsSourceType(String sourceName) {
            this.sourceName = sourceName;
        }

        public static InsightsSourceType fromName(String sourceName) {
            return Arrays.stream(values())
                    .filter(insightsSourceType -> insightsSourceType.sourceName.equals(sourceName))
                    .findFirst()
                    .orElse(null);
        }
    }
}
