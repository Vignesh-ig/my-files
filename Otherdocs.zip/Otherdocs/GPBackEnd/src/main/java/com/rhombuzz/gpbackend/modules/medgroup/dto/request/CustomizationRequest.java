package com.rhombuzz.gpbackend.modules.medgroup.dto.request;

import com.rhombuzz.gpbackend.modules.medgroup.entity.Customization;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record CustomizationRequest(
        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        String groupId,

        @NotNull(message = "Customization type cannot be null")
        Customization.Type type,

        @NotNull(message = "Value cannot be null")
        Object value
) {
}
