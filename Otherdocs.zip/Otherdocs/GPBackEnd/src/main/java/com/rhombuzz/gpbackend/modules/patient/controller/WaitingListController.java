package com.rhombuzz.gpbackend.modules.patient.controller;

import com.rhombuzz.gpbackend.modules.patient.dto.request.WaitingListRequest;
import com.rhombuzz.gpbackend.modules.patient.dto.response.WaitingListResponse;
import com.rhombuzz.gpbackend.modules.patient.service.WaitingListService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/waiting-lists")
public class WaitingListController {
    private final WaitingListService waitingListService;

    @GetMapping
    public ResponseEntity<Page<WaitingListResponse>> getWaitingLists(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId,
            Pageable pageable
    ) {
        Page<WaitingListResponse> waitingLists = waitingListService.getWaitingLists(groupId, pageable);
        return ResponseEntity.ok(waitingLists);
    }

    @PostMapping
    public ResponseEntity<Void> saveWaitingList(@RequestBody @Valid WaitingListRequest request) {
        waitingListService.saveWaitingList(request);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PatchMapping
    public ResponseEntity<Void> updateWaitingList(@RequestBody @Valid WaitingListRequest request) {
        waitingListService.updateWaitingList(request);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWaitingList(
            @PathVariable @NotNull Long id,
            @RequestParam @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        waitingListService.deleteWaitingList(id, patientId, groupId);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/alert/{patientId}")
    public ResponseEntity<Void> updateAlertSent(
            @PathVariable @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        waitingListService.updateAlertSent(patientId, groupId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/patients/{patientId}/check-existence")
    public ResponseEntity<Boolean> checkWaitListExists(
            @PathVariable @NotNull Long patientId,
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        boolean waitingListExists = waitingListService.checkWaitingListExist(patientId, groupId);
        return ResponseEntity.ok(waitingListExists);
    }
}
