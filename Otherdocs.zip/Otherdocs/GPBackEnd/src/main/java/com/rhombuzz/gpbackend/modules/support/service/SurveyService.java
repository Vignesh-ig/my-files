package com.rhombuzz.gpbackend.modules.support.service;

public interface SurveyService {
}
