package com.rhombuzz.gpbackend.modules.medgroup.service.impl;

import com.rhombuzz.gpbackend.exception.domain.NotFoundException;
import com.rhombuzz.gpbackend.modules.medgroup.dto.request.MedGroupTimingRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.MedGroupTimingResponse;
import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupTiming;
import com.rhombuzz.gpbackend.modules.medgroup.repository.MedGroupTimingRepository;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupTimingService;
import com.rhombuzz.gpbackend.modules.task.dto.request.ActivityRequest;
import com.rhombuzz.gpbackend.modules.task.service.ActivityService;
import com.rhombuzz.gpbackend.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class MedGroupTimingServiceImpl implements MedGroupTimingService {

    private final MedGroupTimingRepository medGroupTimingRepository;
    private final ActivityService activityService;

    @Override
    public void updateMedGroupTiming(MedGroupTimingRequest request) {
        log.info("Updating MedGroup timing for group: {}", request.groupId());

        MedGroupTiming medGroupTiming = medGroupTimingRepository.findByGroupId(request.groupId())
                .map(entity -> updateTiming(request, entity))
                .orElseThrow(() -> {
                    log.info("MedGroup timing not found for group: {}", request.groupId());
                    return new NotFoundException("MedGroup timing not found for group: " + request.groupId());
                });

        medGroupTimingRepository.save(medGroupTiming);
        log.info("MedGroup timing updated for group: {}", request.groupId());

        activityService.saveActivity(getActivityRequest(request.groupId(), Utils.getCurrentUsername()));

    }

    @Override
    public MedGroupTimingResponse getMedGroupTiming(String groupId) {
        return medGroupTimingRepository.findByGroupId(groupId)
                .map(MedGroupTimingResponse::fromEntity)
                .orElseThrow(() -> {
                    log.error("MedGroup timing not found for group: {}", groupId);
                    return new NotFoundException("MedGroup timing not found for group: " + groupId);
                });
    }

    private ActivityRequest getActivityRequest(String groupId, String username) {
        return new ActivityRequest() {{
            setGroupId(groupId);
            setActivityType("OFFICE TIMING");
            setActivityDescription("Office timing updated by %s".formatted(username));
        }};
    }

    private MedGroupTiming updateTiming(MedGroupTimingRequest request, MedGroupTiming medGroupTiming) {
        medGroupTiming.setSunday(request.sunday());
        medGroupTiming.setMonday(request.monday());
        medGroupTiming.setTuesday(request.tuesday());
        medGroupTiming.setWednesday(request.wednesday());
        medGroupTiming.setThursday(request.thursday());
        medGroupTiming.setFriday(request.friday());
        medGroupTiming.setSaturday(request.saturday());
        return medGroupTiming;
    }
}
