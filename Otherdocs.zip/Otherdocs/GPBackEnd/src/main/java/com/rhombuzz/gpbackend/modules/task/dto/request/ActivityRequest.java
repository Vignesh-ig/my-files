package com.rhombuzz.gpbackend.modules.task.dto.request;

import com.rhombuzz.gpbackend.modules.patient.entity.Patient;
import com.rhombuzz.gpbackend.modules.provider.entity.Provider;
import com.rhombuzz.gpbackend.util.RegexPattern;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ActivityRequest {

        @NotBlank(message = "Group ID cannot be blank")
        @Size(min = 10, max = 10, message = "Group ID must be exactly 10 characters long")
        @Pattern(regexp = RegexPattern.ONLY_LETTERS, message = "Group ID must contain only letters")
        private String groupId;

        @NotBlank(message = "Activity type cannot be blank")
        @Pattern(regexp = RegexPattern.UPPERCASE_WITH_WHITESPACE_HYPHEN,
                message = "Activity type must be uppercase letters, spaces and hyphen only")
        @Size(max = 100, message = "Activity type must be at most 100 characters long")
        private String activityType;

        @NotBlank(message = "Activity description cannot be blank")
        @Size(max = 500, message = "Activity description must be at most 500 characters long")
        private String activityDescription;

        private Patient patient;
        private Provider provider;
        private String content;
}
