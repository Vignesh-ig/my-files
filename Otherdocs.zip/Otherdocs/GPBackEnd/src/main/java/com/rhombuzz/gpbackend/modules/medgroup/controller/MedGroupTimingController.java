package com.rhombuzz.gpbackend.modules.medgroup.controller;

import com.rhombuzz.gpbackend.modules.medgroup.dto.request.MedGroupTimingRequest;
import com.rhombuzz.gpbackend.modules.medgroup.dto.response.MedGroupTimingResponse;
import com.rhombuzz.gpbackend.modules.medgroup.service.MedGroupTimingService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/med-group-timings")
@Validated
public class MedGroupTimingController {
    private final MedGroupTimingService medGroupTimingService;

    @GetMapping
    public ResponseEntity<MedGroupTimingResponse> getMedGroupTiming(
            @RequestParam @NotBlank @Size(min = 10, max = 10) String groupId
    ) {
        MedGroupTimingResponse response = medGroupTimingService.getMedGroupTiming(groupId);
        return ResponseEntity.ok(response);
    }

    @PutMapping
    public ResponseEntity<Void> updateMedGroupTiming(@RequestBody @Valid MedGroupTimingRequest request) {
        medGroupTimingService.updateMedGroupTiming(request);
        return ResponseEntity.noContent().build();
    }

}
