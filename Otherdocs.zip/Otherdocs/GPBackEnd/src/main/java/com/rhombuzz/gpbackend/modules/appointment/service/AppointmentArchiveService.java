package com.rhombuzz.gpbackend.modules.appointment.service;

public interface AppointmentArchiveService {
}
