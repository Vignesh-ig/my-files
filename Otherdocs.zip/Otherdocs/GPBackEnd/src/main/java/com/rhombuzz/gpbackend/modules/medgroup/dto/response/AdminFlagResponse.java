package com.rhombuzz.gpbackend.modules.medgroup.dto.response;

import com.rhombuzz.gpbackend.modules.medgroup.entity.MedGroupFlag;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AdminFlagResponse {

    private boolean todayAppointment;
    private boolean checkin;
    private boolean checkout;
    private boolean patientCheckinAlert;
    private boolean coverage;
    private boolean onlineIntake;
    private boolean autoRequestReview;
    private boolean integrationPatientRunCheck;
    private boolean integrationAppointmentRuncheck;
    private boolean smsShutoff;
    private boolean emailShutoff;
    private boolean dailySummarySwitch;
    private boolean schedulingActions;
    private boolean documents;
    private boolean payment;
    private boolean insurance;
    private boolean marketingBlast;
    private boolean telehealth;

    public static AdminFlagResponse fromEntity(MedGroupFlag medGroupFlag) {
        return AdminFlagResponse.builder()
                .todayAppointment(medGroupFlag.isTodayAppointment())
                .checkin(medGroupFlag.isCheckin())
                .checkout(medGroupFlag.isCheckout())
                .patientCheckinAlert(medGroupFlag.isPatientCheckinAlert())
                .onlineIntake(medGroupFlag.isOnlineIntake())
                .autoRequestReview(medGroupFlag.isAutoRequestReview())
                .integrationPatientRunCheck(medGroupFlag.isIntegrationPatientRunCheck())
                .integrationAppointmentRuncheck(medGroupFlag.isIntegrationAppointmentRuncheck())
                .smsShutoff(medGroupFlag.isSmsShutoff())
                .emailShutoff(medGroupFlag.isEmailShutoff())
                .dailySummarySwitch(medGroupFlag.isDailySummarySwitch())
                .schedulingActions(medGroupFlag.isSchedulingActions())
                .documents(medGroupFlag.isDocuments())
                .payment(medGroupFlag.isPayment())
                .insurance(medGroupFlag.isInsurance())
                .marketingBlast(medGroupFlag.isMarketingBlast())
                .telehealth(medGroupFlag.isTelehealth())
                .build();
    }
}
