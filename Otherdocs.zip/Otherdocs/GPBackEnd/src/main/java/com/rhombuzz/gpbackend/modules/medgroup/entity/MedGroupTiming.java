package com.rhombuzz.gpbackend.modules.medgroup.entity;

import com.rhombuzz.gpbackend.modules.medgroup.entity.embeddable.DayTiming;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "med_group_timings", indexes = {
        @Index(name = "idx_med_group_timing_med_group_id", columnList = "med_group_id")
})
public class MedGroupTiming {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "med_group_id", nullable = false, referencedColumnName = "group_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MedGroup medGroup;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "startTime", column = @Column(name = "sunday_start_time")),
        @AttributeOverride(name = "endTime", column = @Column(name = "sunday_end_time"))
    })
    private DayTiming sunday;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "startTime", column = @Column(name = "monday_start_time")),
        @AttributeOverride(name = "endTime", column = @Column(name = "monday_end_time"))
    })
    private DayTiming monday;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "startTime", column = @Column(name = "tuesday_start_time")),
        @AttributeOverride(name = "endTime", column = @Column(name = "tuesday_end_time"))
    })
    private DayTiming tuesday;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "startTime", column = @Column(name = "wednesday_start_time")),
        @AttributeOverride(name = "endTime", column = @Column(name = "wednesday_end_time"))
    })
    private DayTiming wednesday;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "startTime", column = @Column(name = "thursday_start_time")),
        @AttributeOverride(name = "endTime", column = @Column(name = "thursday_end_time"))
    })
    private DayTiming thursday;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "startTime", column = @Column(name = "friday_start_time")),
        @AttributeOverride(name = "endTime", column = @Column(name = "friday_end_time"))
    })
    private DayTiming friday;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "startTime", column = @Column(name = "saturday_start_time")),
        @AttributeOverride(name = "endTime", column = @Column(name = "saturday_end_time"))
    })
    private DayTiming saturday;

}
