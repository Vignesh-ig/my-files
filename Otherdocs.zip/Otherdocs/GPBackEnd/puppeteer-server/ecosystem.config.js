module.exports = {
    apps: [{
        name: "puppeteer-server",
        script: "server.js"
    }]
}